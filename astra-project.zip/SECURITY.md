# Security

## Model

| Priority | Implementation |
|---|---|
| Local data encryption | The whole database (chats, memories, documents, tasks, web cache) is encrypted with **SQLCipher (AES-256)**. Its random 256-bit key is stored only in the Keystore-protected vault. Plus Android file-based encryption at rest. Backups are AES-256-GCM files keyed by your passphrase (PBKDF2-HMAC-SHA256, 210,000 rounds). |
| Secure key storage | `KeystoreCipher`: AES-256-GCM, non-exportable key in Android Keystore (StrongBox when available, otherwise TEE). API keys and download tokens are stored only in encrypted form (`SecretStore`). |
| Least privilege | Manifest requests INTERNET, ACCESS_NETWORK_STATE, RECORD_AUDIO (asked on first mic tap), CAMERA (asked only when Camera mode opens), POST_NOTIFICATIONS (asked when you enable the briefing). Notification access is a separate system setting you must grant yourself. Photo picker and folder access use system pickers — no storage permission. |
| Explicit permissions | Permission Center (Allowed / Denied / Ask every time) per category, enforced by the tool firewall on top of Android permissions. |
| Sandboxed tools | Built-in tools are pure in-process functions. Code execution: JavaScript only, in Android's JavaScriptSandbox (separate isolated process, no file system, no network, 64 MB heap, 5 s limit). Plugins are declarative HTTPS calls — no third-party code is loaded. |
| Secure networking | TLS required for every public host (`UrlConnectionTransport` refuses `http://` unless the host is loopback/private-LAN). Platform certificate validation only; no custom TrustManager; user-added CAs are not trusted (`network_security_config.xml`). Timeouts, bounded retries with `Retry-After`, rate-limit mapping. |
| Secure updates | Distributed as an APK you build yourself from source; Play/App Signing when published. |
| Dependency scanning | Enable GitHub Dependabot on the repository (recommended). |
| Audit logging | `RingAuditLog` records every firewall decision with redacted arguments; viewable and clearable in Tools. |

## AI safety firewall

`AI request → policy (mode limits, allowed tools) → permission check → risk classification → user confirmation if required → tool → result (fenced as untrusted) → AI`

- LOW runs automatically (if permissions allow). MEDIUM/HIGH ask unless you opt in to auto-approval. **CRITICAL always asks and requires typing CONFIRM.**
- Chat mode runs no tools; Assist runs only LOW-risk tools; Agent runs multi-step with limits (steps, time, tokens).
- Network tools are blocked unless allowed for the request.

## Prompt injection

- Documents, web pages and tool output are wrapped in `<<UNTRUSTED …>>` fences and **never** placed in the system role. The system prompt instructs the model to treat them as data.
- `PromptInjectionDetector` scores override attempts, role reassignment, fake system tags, exfiltration requests, tool hijacking, fence escapes and hidden characters (English + Hindi patterns). High-risk passages are withheld from the prompt and reported; medium-risk ones are labelled.
- Fence markers and tool-call syntax inside untrusted content are neutralised.

## Logging rules

`Redactor` runs on every diagnostics and audit write: bearer tokens, API-key headers, `sk-…`/`AIza…`/`ghp_…`-style keys, long tokens, Aadhaar/PAN/card numbers, phone numbers and emails are masked. Conversations are never written to diagnostics.

## Reporting

Open a private security advisory on the repository.

## Web safety (v0.2)

- `WebFetcher` accepts only http(s), upgrades to https, refuses loopback/private/link-local addresses (so a page can't make ASTRA probe your home network), re-checks every redirect hop (max 5) and caps page size.
- Fetched pages and search snippets are fenced as untrusted; passages with high injection risk are left out of the prompt; citations that don't point to a real source are removed.
- Downloads: https only; catalog models are pinned to a commit and SHA-256 verified — a mismatched file is deleted.
- File workspace: only folders you grant with the system picker; no path traversal; deleting or moving is HIGH risk and always confirmed; authorised root folders can't be deleted; zip extraction is flat with size caps.
