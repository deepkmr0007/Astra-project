package ai.astra.core.router

import ai.astra.core.device.DeviceState
import ai.astra.core.device.EnergyMode
import ai.astra.core.device.ThermalLevel
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.Locality
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.Availability
import ai.astra.core.provider.Capability
import ai.astra.core.security.PrivacyAssessment
import ai.astra.core.security.Sensitivity
import ai.astra.core.text.TokenEstimator

enum class Complexity { LOW, MEDIUM, HIGH }

enum class TaskKind { CONVERSATION, CODING, REASONING, SUMMARIZE, RESEARCH, CREATIVE }

/** "Never send my data online" / "Ask before sending" / ask only for sensitive content / allow. */
enum class DataControl { NEVER_SEND, ASK_BEFORE_SENDING, ASK_FOR_SENSITIVE, ALLOW }

enum class RoutePreference { AUTO, LOCAL_ONLY, PREFER_LOCAL, PREFER_ONLINE }

data class RouterPolicy(
    val dataControl: DataControl = DataControl.ASK_FOR_SENSITIVE,
    val preference: RoutePreference = RoutePreference.AUTO,
    val energy: EnergyMode = EnergyMode.BALANCED,
    val allowLanInPrivateMode: Boolean = false,
    /** Network routes the user already approved for this conversation ("allow for this chat"). */
    val consentedProviderIds: Set<String> = emptySet(),
)

data class RouteRequest(
    val text: String,
    val privacy: PrivacyAssessment,
    val complexity: Complexity,
    val kind: TaskKind,
    val needsVision: Boolean = false,
    val needsWeb: Boolean = false,
    val contextTokens: Int = TokenEstimator.estimate(text),
    val projectPrivate: Boolean = false,
    /** User picked a model explicitly ("retry with another model"). Policy still applies. */
    val forcedProviderId: String? = null,
)

sealed interface RouteDecision {
    val reasons: List<String>

    data class Route(
        val provider: AiProvider,
        val mode: ExecutionMode,
        val consentRequired: Boolean,
        val fallback: AiProvider?,
        override val reasons: List<String>,
    ) : RouteDecision

    data class NoRoute(override val reasons: List<String>, val hint: String) : RouteDecision
}

/** Heuristic task analysis feeding the router. Deterministic and explainable. */
object TaskAnalyzer {
    private val CODE = Regex("(?i)(```|\\b(kotlin|python|java|javascript|typescript|sql|regex|stack ?trace|exception|compile|function|refactor|debug|bug)\\b|\\bfun \\w+\\(|\\bdef \\w+\\()")
    private val REASON = Regex("(?i)\\b(prove|derive|analy[sz]e|compare|evaluate|step by step|why does|trade-?offs?|architecture|design a|strategy|legal|affidavit|optimi[sz]e|plan for)\\b")
    private val SUMMARY = Regex("(?i)\\b(summari[sz]e|tl;?dr|key points|saar|saaransh|सारांश)\\b")
    private val RESEARCH = Regex("(?i)\\b(latest|current|today|news|search the web|look up|recent|price of|who is the)\\b")
    private val CREATIVE = Regex("(?i)\\b(poem|story|song|lyrics|compose|kavita|kahani)\\b")

    fun kind(text: String): TaskKind = when {
        CODE.containsMatchIn(text) -> TaskKind.CODING
        RESEARCH.containsMatchIn(text) -> TaskKind.RESEARCH
        SUMMARY.containsMatchIn(text) -> TaskKind.SUMMARIZE
        REASON.containsMatchIn(text) -> TaskKind.REASONING
        CREATIVE.containsMatchIn(text) -> TaskKind.CREATIVE
        else -> TaskKind.CONVERSATION
    }

    fun complexity(text: String, attachedTokens: Int = 0): Complexity {
        var score = 0
        val tokens = TokenEstimator.estimate(text) + attachedTokens
        if (tokens > 400) score++
        if (tokens > 2000) score++
        if (REASON.containsMatchIn(text)) score += 2
        if (CODE.containsMatchIn(text)) score++
        if (text.count { it == '?' } >= 3) score++
        if (Regex("(?m)^\\s*(\\d+[.)]|[-*])\\s").findAll(text).count() >= 4) score++
        return when { score >= 3 -> Complexity.HIGH; score >= 1 -> Complexity.MEDIUM; else -> Complexity.LOW }
    }
}

/**
 * ASTRA MODEL ROUTER — decides LOCAL / ONLINE / HYBRID and which provider, and explains why.
 * Hard rules (privacy, connectivity, capability, context window) filter; soft rules score.
 */
class ModelRouter {

    suspend fun route(
        request: RouteRequest,
        providers: List<AiProvider>,
        device: DeviceState,
        policy: RouterPolicy,
    ): RouteDecision {
        val reasons = ArrayList<String>()
        val ready = providers.filter { it.availability() == Availability.Ready }
        if (ready.isEmpty()) {
            return RouteDecision.NoRoute(
                listOf("No model is configured and ready"),
                "Import a local model in Models, or add an online/LAN endpoint.",
            )
        }

        var candidates = ready.filter { Capability.CHAT in it.info.capabilities }

        if (request.forcedProviderId != null) {
            candidates = candidates.filter { it.info.id == request.forcedProviderId }
            if (candidates.isEmpty()) return RouteDecision.NoRoute(listOf("Selected model is not ready"), "Pick another model.")
            reasons += "You selected ${candidates.first().info.displayName}"
        }

        // Hard rule: connectivity.
        if (!device.online) {
            val before = candidates.size
            candidates = candidates.filter { !it.info.locality.usesInternet }
            if (candidates.size < before) reasons += "Offline: internet models unavailable"
        }

        // Hard rule: private mode / LOCAL_ONLY.
        val localOnly = policy.dataControl == DataControl.NEVER_SEND || policy.preference == RoutePreference.LOCAL_ONLY
        if (localOnly) {
            candidates = candidates.filter {
                it.info.locality == Locality.ON_DEVICE || (it.info.locality == Locality.LAN && policy.allowLanInPrivateMode)
            }
            reasons += if (policy.dataControl == DataControl.NEVER_SEND) "\"Never send my data online\" is on" else "Routing preference: local only"
        }

        // Hard rule: capability.
        if (request.needsVision) {
            candidates = candidates.filter { Capability.VISION in it.info.capabilities }
            if (candidates.isEmpty()) return RouteDecision.NoRoute(reasons + "No allowed model can read images", "Use a vision-capable model (local multimodal or online).")
            reasons += "Needs image understanding"
        }

        // Hard rule: context window (leave room for the answer).
        val fits = candidates.filter { it.info.scores.contextWindow >= request.contextTokens + 256 }
        if (fits.isEmpty() && candidates.isNotEmpty()) {
            reasons += "Request (~${request.contextTokens} tokens) exceeds every allowed model's window; context will be compressed"
        } else candidates = fits

        if (candidates.isEmpty()) {
            val hint = when {
                localOnly -> "Install a local model in Models (private mode keeps everything on the device)."
                !device.online -> "You're offline. Install a local model to keep chatting without internet."
                else -> "Configure a model in Models."
            }
            return RouteDecision.NoRoute(reasons, hint)
        }

        val sensitive = request.privacy.level >= Sensitivity.MEDIUM || request.projectPrivate
        val highlySensitive = request.privacy.level == Sensitivity.HIGH || request.projectPrivate

        // Score.
        val scored = candidates.map { p -> p to score(p, request, device, policy, sensitive, highlySensitive) }
            .sortedByDescending { it.second }
        val best = scored.first().first
        val fallback = scored.drop(1).map { it.first }.firstOrNull { it.info.locality == Locality.ON_DEVICE && best.info.locality != Locality.ON_DEVICE }

        // Explain.
        reasons += "Task: ${request.kind.name.lowercase()}, complexity ${request.complexity.name.lowercase()}"
        if (sensitive) reasons += "Sensitive content detected (${request.privacy.kinds.joinToString().ifEmpty { "private project" }})"
        if (device.thermal >= ThermalLevel.MODERATE) reasons += "Device thermal state: ${device.thermal.name.lowercase()}"
        reasons += "Chose ${best.info.displayName} (${best.info.locality.name.lowercase().replace('_', '-')})"

        val network = best.info.locality.usesNetwork
        val consent = network && best.info.id !in policy.consentedProviderIds && when (policy.dataControl) {
            DataControl.NEVER_SEND -> true // only reachable for LAN when explicitly allowed; still ask
            DataControl.ASK_BEFORE_SENDING -> true
            DataControl.ASK_FOR_SENSITIVE -> sensitive
            DataControl.ALLOW -> highlySensitive // never silently upload IDs/secrets
        }
        if (consent) reasons += "Your approval is needed before sending"

        val mode = when {
            !network && request.needsWeb -> ExecutionMode.HYBRID
            network -> ExecutionMode.ONLINE
            else -> ExecutionMode.LOCAL
        }
        return RouteDecision.Route(best, mode, consent, fallback, reasons)
    }

    private fun score(p: AiProvider, r: RouteRequest, d: DeviceState, policy: RouterPolicy, sensitive: Boolean, highlySensitive: Boolean): Double {
        val s = p.info.scores
        val local = p.info.locality == Locality.ON_DEVICE
        var score = 0.0
        // Capability fit.
        score += when (r.kind) {
            TaskKind.CODING -> s.coding * 1.2
            TaskKind.REASONING, TaskKind.RESEARCH -> s.reasoning * 1.2
            TaskKind.SUMMARIZE -> s.reasoning * 0.6 + s.speed * 0.4
            else -> s.speed * 0.5 + s.reasoning * 0.5
        }
        score += when (r.complexity) {
            Complexity.LOW -> if (local) 6.0 else 0.0 // simple chat → local
            Complexity.MEDIUM -> s.reasoning * 0.3
            Complexity.HIGH -> s.reasoning * 0.8
        }
        if (r.needsWeb && !local) score += 4
        // Privacy: sensitive content strongly prefers on-device.
        if (sensitive && local) score += 8
        if (highlySensitive && !local) score -= 15
        // Preferences.
        score += when (policy.preference) {
            RoutePreference.PREFER_LOCAL -> if (local) 6.0 else 0.0
            RoutePreference.PREFER_ONLINE -> if (!local) 6.0 else 0.0
            else -> if (local) 1.0 else 0.0 // local-first tie-break
        }
        // Device health.
        if (local) {
            when (d.thermal) {
                ThermalLevel.MODERATE -> score -= 2
                ThermalLevel.SEVERE -> score -= 5
                ThermalLevel.CRITICAL -> score -= 9
                else -> Unit
            }
            if (policy.energy == EnergyMode.BATTERY_SAVER) score -= s.memoryRequirementMb / 2000.0
            val avail = d.availableRamMb
            if (avail != null && s.memoryRequirementMb > 0 && s.memoryRequirementMb > avail) score -= 6
        } else if (d.metered) score -= 1
        return score
    }
}
