package ai.astra.core.plugins

import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel

data class PluginToolDecl(val name: String, val description: String, val risk: RiskLevel, val inputSchema: String, val network: Boolean)

/** Plugin manifest (see PLUGIN_API.md). Plugins only get the permissions they declare and the user grants. */
data class PluginManifest(
    val id: String,
    val name: String,
    val version: String,
    val permissions: Set<Permission>,
    val tools: List<PluginToolDecl>,
    val uiComponents: List<String>,
) {
    companion object {
        private val ID = Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+$")
        private val SEMVER = Regex("^\\d+\\.\\d+\\.\\d+(-[0-9A-Za-z.-]+)?$")
        private val TOOL = Regex("^[a-z][a-z0-9_]{1,40}$")
        private val UI = setOf("settings_panel", "chat_card", "share_action")

        /** Parses and validates; every problem is reported, nothing is silently ignored. */
        fun parse(text: String): Result<PluginManifest> = runCatching {
            val o = Json.parse(text).obj() ?: error("Manifest must be a JSON object")
            val errors = ArrayList<String>()
            val id = o["id"].str().orEmpty().also { if (!ID.matches(it)) errors += "id must be reverse-DNS, e.g. org.example.weather" }
            val name = o["name"].str().orEmpty().also { if (it.isBlank()) errors += "name is required" }
            val version = o["version"].str().orEmpty().also { if (!SEMVER.matches(it)) errors += "version must be semver (1.2.3)" }
            val perms = o["permissions"].arr().mapNotNull { p ->
                val s = p.str()
                runCatching { Permission.valueOf(s!!.uppercase()) }.getOrElse { errors += "unknown permission '$s'"; null }
            }.toSet()
            val tools = o["tools"].arr().mapNotNull { t ->
                val to = t.obj() ?: run { errors += "tool entries must be objects"; return@mapNotNull null }
                val tn = to["name"].str().orEmpty()
                if (!TOOL.matches(tn)) errors += "tool name '$tn' must be snake_case"
                val risk = runCatching { RiskLevel.valueOf(to["risk"].str()!!.uppercase()) }.getOrElse { errors += "tool '$tn' needs risk LOW|MEDIUM|HIGH|CRITICAL"; RiskLevel.HIGH }
                val network = to["network"]?.let { it == ai.astra.core.json.JsonValue.Bool(true) } ?: false
                if (network && Permission.INTERNET !in perms) errors += "tool '$tn' uses the network but INTERNET is not declared"
                PluginToolDecl(tn, to["description"].str().orEmpty(), risk, to["input_schema"]?.let { Json.write(it) } ?: "{}", network)
            }
            if (tools.map { it.name }.toSet().size != tools.size) errors += "tool names must be unique"
            val ui = o["ui"].arr().mapNotNull { it.str() }.onEach { if (it !in UI) errors += "unknown ui component '$it'" }
            if (errors.isNotEmpty()) throw IllegalArgumentException(errors.joinToString("; "))
            PluginManifest(id, name, version, perms, tools, ui)
        }
    }
}
