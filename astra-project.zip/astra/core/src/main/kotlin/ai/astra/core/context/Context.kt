package ai.astra.core.context

import ai.astra.core.documents.DocHit
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.ContentSource
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.plainText
import ai.astra.core.provider.PromptTurn
import ai.astra.core.security.PromptInjectionDetector
import ai.astra.core.security.Sensitivity
import ai.astra.core.security.UntrustedFence
import ai.astra.core.text.TokenEstimator
import ai.astra.core.text.Tokenizer

enum class Personality(val instruction: String) {
    FRIENDLY("Be warm, natural and encouraging."),
    FORMAL("Be formal, precise and courteous."),
    TECHNICAL("Be technical and exact; prefer specifics, code and numbers."),
    CONCISE("Be brief. Lead with the answer; no filler."),
    TEACHER("Teach step by step, check understanding, use simple examples."),
    RESEARCHER("Be rigorous: separate what is known, retrieved, inferred and uncertain."),
    CREATIVE("Be imaginative and expressive while staying accurate."),
}

enum class ReplyLanguage(val instruction: String) {
    AUTO("Reply in the language the user writes in (English, Hindi or Hinglish)."),
    ENGLISH("Reply in English."),
    HINDI("Reply in Hindi (Devanagari script)."),
    HINGLISH("Reply in Hinglish (Hindi in Latin script mixed with English)."),
}

/** User-configurable assistant profile. Never stores inferred sensitive attributes. */
data class AssistantProfile(
    val userName: String = "",
    val personality: Personality = Personality.FRIENDLY,
    val language: ReplyLanguage = ReplyLanguage.AUTO,
    val technicalLevel: String = "",
    val units: String = "metric",
    val writingStyle: String = "",
    val customInstructions: String = "",
)

data class ContextSegment(val source: ContentSource, val label: String, val tokens: Int, val included: Boolean, val warning: String? = null)

data class BuiltContext(
    val turns: List<PromptTurn>,
    val segments: List<ContextSegment>,
    val totalTokens: Int,
    val warnings: List<String>,
) {
    /** Human summary of what would leave the device if this context is sent to a network model. */
    val dataSentSummary: List<String>
        get() = segments.filter { it.included }.groupBy { it.source }.map { (src, segs) ->
            when (src) {
                ContentSource.SYSTEM -> "instructions"
                ContentSource.USER -> if (segs.size > 1) "your message + ${segs.size - 1} earlier turn(s)" else "your message"
                ContentSource.MEMORY -> "${segs.size} memory item(s)"
                ContentSource.DOCUMENT -> "${segs.size} document passage(s)"
                ContentSource.WEB -> "${segs.size} web passage(s)"
                ContentSource.TOOL_RESULT -> "${segs.size} tool result(s)"
            }
        }
}

data class ContextInputs(
    val profile: AssistantProfile,
    val projectName: String? = null,
    val projectInstructions: String? = null,
    val toolManual: String = "",
    val profileMemories: List<MemoryRecord> = emptyList(),
    val relevantMemories: List<MemoryRecord> = emptyList(),
    val documents: List<DocHit> = emptyList(),
    val historySummary: String? = null,
    val history: List<ChatMessage> = emptyList(),
    val userParts: List<Part>,
    val nowText: String,
    val modelLocal: Boolean,
)

/**
 * Builds the prompt dynamically within a token budget instead of sending the whole history:
 * system + relevant memory + project context + retrieved documents + recent conversation.
 * Untrusted content is fenced and never placed in the system role.
 */
class ContextEngine {

    fun build(inputs: ContextInputs, contextWindow: Int, reserveForOutput: Int): BuiltContext {
        val budget = (contextWindow - reserveForOutput).coerceAtLeast(512)
        val segments = ArrayList<ContextSegment>()
        val warnings = ArrayList<String>()

        // 1. System instructions (always).
        val system = StringBuilder(systemPrompt(inputs))
        segments += ContextSegment(ContentSource.SYSTEM, "instructions", TokenEstimator.estimate(system.toString()), true)

        // 2. Current user message (always; truncated only if absurdly large).
        val userText = inputs.userParts.plainText()
        var used = TokenEstimator.estimate(system.toString()) + TokenEstimator.estimate(userText)
        segments += ContextSegment(ContentSource.USER, "current message", TokenEstimator.estimate(userText), true)

        // 3. Memories (≤ 15% of budget).
        val memBudget = (budget * 0.15).toInt()
        var memUsed = 0
        val memLines = ArrayList<String>()
        (inputs.profileMemories + inputs.relevantMemories).distinctBy { it.id }.forEach { m ->
            val t = TokenEstimator.estimate(m.content) + 2
            val fits = memUsed + t <= memBudget && used + t <= budget
            segments += ContextSegment(ContentSource.MEMORY, m.content.take(60), t, fits)
            if (fits) { memLines += "- ${m.content}"; memUsed += t; used += t }
        }
        if (memLines.isNotEmpty()) {
            system.append("\n\n## Saved memories (the user asked you to remember these)\n").append(memLines.joinToString("\n"))
        }

        // 4. Documents (≤ 40% of budget), fenced as untrusted.
        val docBudget = (budget * 0.40).toInt()
        var docUsed = 0
        val docBlocks = ArrayList<String>()
        for (hit in inputs.documents) {
            val inj = PromptInjectionDetector.assess(hit.chunk.text)
            val block = UntrustedFence.wrap(ContentSource.DOCUMENT, hit.citation, hit.chunk.text, inj.risk)
            val t = TokenEstimator.estimate(block)
            val quarantined = inj.risk == Sensitivity.HIGH
            val fits = !quarantined && docUsed + t <= docBudget && used + t <= budget
            val warn = when {
                quarantined -> "Passage from ${hit.citation} looked like a prompt-injection attempt (${inj.signals.joinToString()}) and was withheld"
                inj.risk == Sensitivity.MEDIUM -> "Passage from ${hit.citation} contains instruction-like text; treated as data"
                else -> null
            }
            warn?.let { warnings += it }
            segments += ContextSegment(ContentSource.DOCUMENT, hit.citation, t, fits, warn)
            if (fits) { docBlocks += block; docUsed += t; used += t }
        }

        // 5. History from newest backwards with the rest of the budget; older part via summary.
        inputs.historySummary?.takeIf { it.isNotBlank() }?.let { s ->
            val t = TokenEstimator.estimate(s)
            if (used + t <= budget) {
                system.append("\n\n## Earlier in this conversation (summary)\n").append(s)
                used += t
                segments += ContextSegment(ContentSource.USER, "conversation summary", t, true)
            }
        }
        val historyTurns = ArrayList<PromptTurn>()
        var dropped = 0
        for (msg in inputs.history.asReversed()) {
            if (msg.role == Role.SYSTEM) continue
            val text = msg.text
            val t = TokenEstimator.estimate(text) + 4
            if (used + t > budget) { dropped++; continue }
            used += t
            val src = when (msg.role) { Role.TOOL -> ContentSource.TOOL_RESULT; else -> ContentSource.USER }
            val content = if (msg.role == Role.TOOL) UntrustedFence.wrap(ContentSource.TOOL_RESULT, "earlier tool result", text, Sensitivity.NONE) else text
            historyTurns += PromptTurn(msg.role, listOf(Part.Text(content)), setOf(src))
            segments += ContextSegment(src, "history: ${text.take(40)}", t, true)
        }
        if (dropped > 0) warnings += "$dropped older message(s) did not fit and were left out"
        historyTurns.reverse()

        // Assemble.
        val finalUser = buildList {
            if (docBlocks.isNotEmpty()) add(Part.Text("Relevant passages from the user's documents (cite as [title, page N]):\n\n" + docBlocks.joinToString("\n\n") + "\n\nUser message:"))
            addAll(inputs.userParts)
        }
        val turns = buildList {
            add(PromptTurn(Role.SYSTEM, listOf(Part.Text(system.toString())), buildSet { add(ContentSource.SYSTEM); if (memLines.isNotEmpty()) add(ContentSource.MEMORY) }))
            addAll(historyTurns)
            add(PromptTurn(Role.USER, finalUser, buildSet { add(ContentSource.USER); if (docBlocks.isNotEmpty()) add(ContentSource.DOCUMENT) }))
        }
        return BuiltContext(turns, segments, used, warnings)
    }

    fun systemPrompt(i: ContextInputs): String = buildString {
        append("You are ASTRA, the user's personal AI. ")
        append(if (i.modelLocal) "You are running entirely on the user's phone. " else "You are running on a server the user chose for this request. ")
        append("Be honest: if you don't know, say so; never invent facts, sources, file contents or tool results. ")
        append("Distinguish what you know, what came from provided documents/tools, and what you infer.\n")
        append(i.profile.personality.instruction).append(' ').append(i.profile.language.instruction).append('\n')
        if (i.profile.userName.isNotBlank()) append("The user's name is ${i.profile.userName}.\n")
        if (i.profile.technicalLevel.isNotBlank()) append("User's technical level: ${i.profile.technicalLevel}.\n")
        append("Preferred units: ${i.profile.units}.\n")
        if (i.profile.writingStyle.isNotBlank()) append("Writing style: ${i.profile.writingStyle}.\n")
        append("Current date/time on the device: ${i.nowText}.\n")
        if (i.projectName != null) append("\n## Project: ${i.projectName}\n").append(i.projectInstructions.orEmpty()).append('\n')
        if (i.profile.customInstructions.isNotBlank()) append("\n## User's custom instructions\n").append(i.profile.customInstructions).append('\n')
        append('\n').append(UntrustedFence.SYSTEM_RULE)
        if (i.toolManual.isNotBlank()) append("\n\n").append(i.toolManual)
    }
}

/**
 * Extractive conversation compressor: keeps decisions, constraints, facts, open tasks and
 * preferences from older turns and discards chit-chat. Works offline without a model; an
 * abstractive model summary can replace it when a capable model is available.
 */
object ConversationCompressor {
    private val KEEP = Regex("(?i)\\b(decid\\w*|agreed|we will|let's|must|should not|never|always|deadline|due|todo|to do|next step|prefer|constraint|important|remember|budget|requirement|because|final|confirmed|tay|pakka|zaroori)\\b|\\d")

    fun compress(messages: List<ChatMessage>, maxTokens: Int = 400): String {
        val lines = ArrayList<String>()
        for (m in messages) {
            if (m.role == Role.SYSTEM || m.role == Role.TOOL) continue
            val who = if (m.role == Role.USER) "User" else "ASTRA"
            Tokenizer.sentences(m.text).filter { s -> s.length > 12 && KEEP.containsMatchIn(s) }.forEach { lines += "$who: ${s(it)}" }
        }
        val out = ArrayList<String>()
        var used = 0
        for (l in lines.distinct().asReversed()) { // prefer the most recent facts
            val t = TokenEstimator.estimate(l)
            if (used + t > maxTokens) break
            out += l; used += t
        }
        return out.asReversed().joinToString("\n") { "- $it" }
    }

    private fun s(x: String) = if (x.length > 240) x.take(237) + "…" else x
}
