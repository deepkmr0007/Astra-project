package ai.astra.core.export

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.num
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemoryType
import ai.astra.core.memory.PrivacyLevel
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.Project
import ai.astra.core.tasks.TaskItem
import java.time.Instant

/**
 * Open, documented export format ("astra-export" v1, JSON) plus Markdown for humans.
 * Embeddings are not exported: they are re-computed on import, keeping files small and portable.
 */
object Exporter {
    const val FORMAT = "astra-export"
    const val VERSION = 1

    fun memoryJson(m: MemoryRecord): JsonValue = jsonObj(
        "id" to m.id, "createdAt" to m.createdAt, "updatedAt" to m.updatedAt, "source" to m.source, "type" to m.type,
        "importance" to m.importance, "confidence" to m.confidence, "privacyLevel" to m.privacyLevel,
        "project" to m.projectId, "content" to m.content, "expiry" to m.expiry, "userEditable" to m.userEditable,
        "subjectKey" to m.subjectKey, "pinned" to m.pinned,
    )

    fun messageJson(m: ChatMessage): JsonValue = jsonObj(
        "id" to m.id, "role" to m.role, "createdAt" to m.createdAt, "text" to m.text,
        "trace" to m.trace?.let { t ->
            jsonObj("provider" to t.providerId, "model" to t.model, "locality" to t.locality, "mode" to t.mode,
                "networkUsed" to t.networkUsed, "dataSent" to t.dataSent, "tools" to t.tools, "tokensOut" to t.tokensOut)
        },
    )

    fun bundle(
        conversations: List<Pair<Conversation, List<ChatMessage>>>,
        memories: List<MemoryRecord>,
        projects: List<Project>,
        tasks: List<TaskItem>,
        settings: Map<String, Any?>,
    ): String = Json.write(
        jsonObj(
            "format" to FORMAT, "version" to VERSION, "exportedAt" to Instant.now().toString(),
            "projects" to jsonArr(projects.map { jsonObj("id" to it.id, "name" to it.name, "instructions" to it.instructions, "privateByDefault" to it.privateByDefault, "createdAt" to it.createdAt) }),
            "conversations" to jsonArr(conversations.map { (c, msgs) ->
                jsonObj("id" to c.id, "title" to c.title, "project" to c.projectId, "folder" to c.folder, "pinned" to c.pinned,
                    "archived" to c.archived, "parent" to c.parentConversationId, "createdAt" to c.createdAt, "messages" to jsonArr(msgs.map { messageJson(it) }))
            }),
            "memories" to jsonArr(memories.map { memoryJson(it) }),
            "tasks" to jsonArr(tasks.map { t ->
                jsonObj("id" to t.id, "title" to t.title, "description" to t.description, "priority" to t.priority, "deadline" to t.deadline,
                    "status" to t.status, "project" to t.projectId, "parent" to t.parentId, "dependsOn" to t.dependsOn.toList())
            }),
            "settings" to settings,
        ),
        pretty = true,
    )

    fun conversationMarkdown(c: Conversation, msgs: List<ChatMessage>): String = buildString {
        appendLine("# ${c.title}")
        appendLine()
        appendLine("_Exported from ASTRA on ${Instant.now()}_")
        msgs.forEach { m ->
            appendLine()
            appendLine("## ${m.role.name.lowercase().replaceFirstChar { it.uppercase() }} — ${Instant.ofEpochMilli(m.createdAt)}")
            appendLine()
            appendLine(m.text)
            m.trace?.let { t ->
                appendLine()
                appendLine("> Model: ${t.model} · Execution: ${t.locality.name.lowercase()} · Network: ${if (t.networkUsed) "used" else "not used"}" +
                    (if (t.tools.isNotEmpty()) " · Tools: ${t.tools.joinToString()}" else ""))
            }
        }
    }

    fun memoriesMarkdown(memories: List<MemoryRecord>): String = buildString {
        appendLine("# ASTRA memory")
        memories.groupBy { it.type }.forEach { (type, list) ->
            appendLine(); appendLine("## ${type.name.lowercase().replace('_', ' ')}")
            list.forEach { appendLine("- ${it.content}") }
        }
    }

    data class ImportedMemory(val content: String, val type: MemoryType, val projectId: String?, val importance: Double, val privacy: PrivacyLevel)

    /** Parses memories from an astra-export file (or a bare JSON array). Validates every field. */
    fun parseMemories(text: String): List<ImportedMemory> {
        val root = Json.parse(text)
        val items = when (root) {
            is JsonValue.Arr -> root.items
            is JsonValue.Obj -> {
                require(root["format"].str() == FORMAT) { "Not an ASTRA export file" }
                root["memories"].arr()
            }
            else -> throw IllegalArgumentException("Unsupported JSON")
        }
        return items.mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            val content = o["content"].str()?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            ImportedMemory(
                content = content.take(4000),
                type = runCatching { MemoryType.valueOf(o["type"].str()!!) }.getOrDefault(MemoryType.LONG_TERM),
                projectId = o["project"].str(),
                importance = (o["importance"].num() ?: 0.5).coerceIn(0.0, 1.0),
                privacy = runCatching { PrivacyLevel.valueOf(o["privacyLevel"].str()!!) }.getOrDefault(PrivacyLevel.PERSONAL),
            )
        }
    }
}
