# Privacy

**Default: everything stays on your phone.** ASTRA has no telemetry, analytics, crash reporting or account. Nothing is sent anywhere unless you configure an online/LAN endpoint *and* the router chooses it *and* your data-control setting allows it.

## Data control (Settings → Privacy)

| Setting | Behaviour |
|---|---|
| Never send my data online | Router uses only on-device models (and LAN servers if you allow that). Every network request is blocked in the transport layer as well. |
| Ask before sending anything online | A dialog shows the destination, what would be sent (your message, N earlier turns, N memory items, N document passages), detected sensitive items and size. You can send once, allow for this chat, or keep it on the phone. |
| Ask before sending sensitive content *(default)* | Same dialog, only when sensitive content is detected or the project is private. |
| Allow | Online models are used when the router prefers them — but IDs, cards, passwords and keys still require approval. |

## What is stored, where

| Data | Location | Leaves the phone? |
|---|---|---|
| Chats, memories, projects, tasks, document text & indexes | App-private Room database | Only via your explicit export |
| Imported models | App-private storage | No |
| API keys / tokens | Encrypted with Android Keystore | Never (not even in exports) |
| Settings | App-private DataStore | Only via export (keys excluded) |
| Diagnostics | In memory, redacted | Only via “Export diagnostics” |

Cloud backup and device-transfer backup are disabled for all app data.

## Memory rules

- ASTRA remembers only what you ask (“remember that …”, “/remember”, “याद रखना कि …”, or the Remember action). Auto-capture is off by default.
- Sensitive information (IDs, card numbers, passwords, keys, items you mark confidential) is refused unless you enable sensitive memory.
- Contradicting facts are shown to you; nothing is silently overwritten.
- You can view, edit, pin, delete, export, import, disable or clear all memory. Deleted memories are removed from the database and can no longer be retrieved.
- Personal attributes are never inferred.

## Microphone and camera

The microphone records only while you are actively dictating; listening stops when the app goes to the background. Photos are taken with the system camera app and stored privately only if you attach them.
