# Third-party licenses

| Component | Use | License |
|---|---|---|
| Kotlin standard library, kotlinx.coroutines | Language runtime, concurrency | Apache-2.0 |
| AndroidX Core, Activity, Lifecycle, Fragment | Android foundations | Apache-2.0 |
| Jetpack Compose (UI, Material 3, Material Icons Extended) | UI | Apache-2.0 |
| Room | Local database | Apache-2.0 |
| DataStore Preferences | Settings | Apache-2.0 |
| AndroidX Biometric | App lock | Apache-2.0 |
| LiteRT-LM (`com.google.ai.edge.litertlm:litertlm-android`) | On-device LLM runtime | Apache-2.0 |
| PDFBox-Android (`com.tom-roush:pdfbox-android`) | PDF text extraction | Apache-2.0 |
| JUnit 4, AndroidX Test | Tests | EPL-1.0 / Apache-2.0 |

## Models

No model weights are bundled with ASTRA. Models you import or download keep their own licenses (for example, Gemma models are governed by Google's Gemma Terms of Use). ASTRA records the license text you enter for every installed model and shows it in **Models**. Do not redistribute models whose licenses prohibit it.

## Original work

ASTRA's engine (`core/`), app code, icon and documentation are original work. ASTRA does not include or reproduce proprietary model weights or provider internals.
