# Plugin API (draft)

Status: the manifest format and validator (`ai.astra.core.plugins.PluginManifest`) are implemented and tested. Loading and running third-party plugins is Phase 4.

## Manifest

```json
{
  "id": "org.example.mandi",
  "name": "Mandi Prices",
  "version": "1.0.0",
  "permissions": ["internet"],
  "tools": [
    {
      "name": "mandi_price",
      "description": "Today's modal price for a crop at a mandi",
      "risk": "low",
      "network": true,
      "input_schema": {"type": "object", "properties": {"crop": {"type": "string"}, "mandi": {"type": "string"}}, "required": ["crop"]}
    }
  ],
  "ui": ["chat_card"]
}
```

Rules enforced by the validator (all problems reported at once):

- `id` reverse-DNS, `version` semver, `name` required.
- `permissions` from: MICROPHONE, CAMERA, FILES, LOCATION, CONTACTS, NOTIFICATIONS, INTERNET, BACKGROUND, EXTERNAL_SERVICES, MEMORY, DOCUMENTS.
- Tool names snake_case and unique; `risk` one of LOW/MEDIUM/HIGH/CRITICAL; a tool with `"network": true` requires the INTERNET permission.
- `ui` from: `settings_panel`, `chat_card`, `share_action`.

## Runtime contract

A plugin tool is a `Tool` (`ai.astra.core.tools.Tool`): `spec` (name, description, schemas, risk, permissions, environment, usesNetwork) and `suspend fun run(args): ToolResult`. Every call goes through the same `ToolFirewall` as built-in tools, so a plugin can never exceed the permissions the user grants, and CRITICAL actions always require explicit confirmation. Plugin output is fenced as untrusted data before the model sees it.
