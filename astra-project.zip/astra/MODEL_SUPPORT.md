# Model support

ASTRA is model-agnostic: every model sits behind `AiProvider`. Nothing is bundled; you choose and install models, and each keeps its own license.

## On-device (today)

| Runtime | Format | Status |
|---|---|---|
| **LiteRT-LM** (Google, Apache-2.0) | `.litertlm` | Implemented (`LiteRtLmProvider`): GPU with CPU fallback, streaming, cancel, vision input for multimodal builds |
| llama.cpp | `.gguf` | Integration point — import is accepted, model marked “Requires runtime” |
| ONNX Runtime GenAI | `.onnx` | Integration point |
| MediaPipe LLM Inference | `.task` | Not bundled (Google lists it as maintenance-only; LiteRT-LM is its successor) |

Examples of `.litertlm` models (check current availability and accept each license yourself): Gemma 3 1B instruction-tuned and Gemma 3n E2B/E4B builds published by the LiteRT community on Hugging Face. Gemma models are under Google's Gemma Terms of Use and require accepting them before download.

### Profiles

| Profile | Rough size | Typical file | Phone RAM |
|---|---|---|---|
| Tiny | ≤ 1.5B params, 4-bit | ~1 GB | 4–6 GB |
| Small | 2–4B | ~2.5 GB | 6–8 GB |
| Medium | 4–8B | ~5 GB | 12 GB |
| Large | 8B+ | ~7.5 GB | 16 GB |

`ProfileRecommender` suggests a profile from total RAM, free storage, heat and battery. The capability scores used by the router are estimated from size and editable per model.

### Benchmark

Models → Benchmark runs a fixed prompt and reports load time, time-to-first-token, tokens/s, native-memory change, battery temperature and battery drop.

## Network providers

| Kind | Works with | Notes |
|---|---|---|
| OpenAI-compatible | OpenAI, OpenRouter, Groq, Together, Ollama, llama.cpp `server`, LM Studio, vLLM | Streaming chat, optional `/v1/embeddings`, vision via `image_url` data URLs |
| Anthropic | Claude models via the Messages API | Streaming, vision, system prompt; consecutive same-role turns merged |

Set **locality** honestly: *Online API*, *My server* (internet-reachable server you run) or *LAN* (home network). The router, consent dialog and private mode use it.

## Embeddings

Default `HashingEmbedder` is fully offline (feature hashing over words, bigrams and character trigrams). It captures lexical similarity, not deep meaning. When an endpoint provides embeddings, `ProviderEmbedder` + `MemoryEngine.reembed` switch to neural vectors.

## Adding a runtime

Implement `AiProvider` (`availability`, `stream`, optionally `embed`/`transcribe`/`speak`/`cancel`/`close`), register it in `ProviderManager.rebuild`, and give it a `ModelCapabilities` profile. No other code changes are needed.
