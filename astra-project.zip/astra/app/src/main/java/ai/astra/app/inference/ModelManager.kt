package ai.astra.app.inference

import ai.astra.core.models.Checksums
import ai.astra.core.models.ModelDescriptor
import ai.astra.core.models.ModelFormat
import ai.astra.core.model.newId
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.DigestInputStream
import java.security.MessageDigest

enum class DownloadStatus { RUNNING, PAUSED, VERIFYING, DONE, FAILED }

data class DownloadRequest(
    val url: String,
    val name: String,
    val license: String,
    val source: String,
    val expectedSha256: String?,
    val supportsVision: Boolean,
)

data class DownloadState(
    val id: String,
    val request: DownloadRequest,
    val totalBytes: Long,
    val downloaded: Long,
    val status: DownloadStatus,
    val error: String? = null,
)

data class ProbeResult(val sizeBytes: Long, val finalHost: String, val fileName: String)

/**
 * Installs models: import from device storage, or download with pause/resume and SHA-256
 * verification. Size, source, license and hardware requirement are shown before any download.
 */
class ModelManager(private val context: Context, private val scope: CoroutineScope) {
    val dir: File = File(context.filesDir, "models").apply { mkdirs() }
    private val catalog = File(dir, "catalog.json")

    private val _models = MutableStateFlow(load())
    val models: StateFlow<List<ModelDescriptor>> = _models.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadState>> = _downloads.asStateFlow()
    private val jobs = HashMap<String, Job>()

    fun fileFor(d: ModelDescriptor) = File(dir, d.fileName)

    private fun load(): List<ModelDescriptor> = if (catalog.exists()) ModelDescriptor.listFromJson(catalog.readText()) else emptyList()

    @Synchronized private fun save(list: List<ModelDescriptor>) {
        val tmp = File(dir, "catalog.json.tmp")
        tmp.writeText(ModelDescriptor.listToJson(list))
        tmp.renameTo(catalog)
        _models.value = list
    }

    fun update(d: ModelDescriptor) = save(_models.value.map { if (it.id == d.id) d else it })

    fun delete(id: String) {
        val d = _models.value.firstOrNull { it.id == id } ?: return
        fileFor(d).delete()
        save(_models.value.filter { it.id != id })
    }

    /** Copies a user-picked model file into private storage, hashing as it goes. */
    suspend fun import(uri: Uri, onProgress: (Long, Long) -> Unit): Result<ModelDescriptor> = withContext(Dispatchers.IO) {
        runCatching {
            val (name, size) = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) (c.getString(0) ?: "model") to (if (c.isNull(1)) -1L else c.getLong(1)) else null
            } ?: ("model" to -1L)
            val free = dir.usableSpace
            require(size < 0 || size < free - 300L * 1024 * 1024) { "Not enough free storage: needs ${size / 1_048_576} MB, ${free / 1_048_576} MB free" }
            val format = ModelFormat.fromFileName(name)
            val id = newId().take(8)
            val target = File(dir, "$id-${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
            val md = MessageDigest.getInstance("SHA-256")
            var copied = 0L
            context.contentResolver.openInputStream(uri)!!.use { raw ->
                DigestInputStream(raw, md).use { input ->
                    FileOutputStream(target).use { out ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copied += n
                            onProgress(copied, size)
                        }
                    }
                }
            }
            val (profile, caps) = ModelDescriptor.estimateFromSize(copied)
            val d = ModelDescriptor(
                id = id, name = name.substringBeforeLast('.'), fileName = target.name, format = format, sizeBytes = copied,
                sha256 = md.digest().joinToString("") { "%02x".format(it) }, source = "Imported from device storage",
                license = "Not specified — check the model card", profile = profile, capabilities = caps,
            )
            save(_models.value + d)
            d
        }
    }

    /** HEAD request so the user sees the size before agreeing to download. */
    suspend fun probe(url: String, token: String?): Result<ProbeResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(url.startsWith("https://")) { "Only https:// downloads are allowed" }
            val conn = (URI(url).toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"; instanceFollowRedirects = true; connectTimeout = 15_000; readTimeout = 15_000
                token?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            try {
                val code = conn.responseCode
                require(code in 200..299) { "Server answered HTTP $code" + if (code == 401 || code == 403) " (gated model? add an access token)" else "" }
                ProbeResult(conn.contentLengthLong, conn.url.host, url.substringAfterLast('/').substringBefore('?'))
            } finally { conn.disconnect() }
        }
    }

    fun startDownload(req: DownloadRequest, token: String?, existingId: String? = null) {
        val id = existingId ?: newId().take(8)
        val part = File(dir, "$id.part")
        jobs[id]?.cancel()
        _downloads.value = _downloads.value + (id to DownloadState(id, req, -1, part.length(), DownloadStatus.RUNNING))
        jobs[id] = scope.launch(Dispatchers.IO) {
            try {
                require(req.url.startsWith("https://")) { "Only https:// downloads are allowed" }
                val have = if (part.exists()) part.length() else 0L
                val conn = (URI(req.url).toURL().openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true; connectTimeout = 20_000; readTimeout = 60_000
                    if (have > 0) setRequestProperty("Range", "bytes=$have-")
                    token?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
                }
                val code = conn.responseCode
                if (code !in 200..299) throw IllegalStateException("HTTP $code" + if (code == 401 || code == 403) " — this model may need an access token / license acceptance" else "")
                val resumed = code == 206
                val total = if (resumed) have + conn.contentLengthLong else conn.contentLengthLong
                var done = if (resumed) have else 0L
                conn.inputStream.use { input ->
                    FileOutputStream(part, resumed).use { out ->
                        val buf = ByteArray(1 shl 20)
                        var lastEmit = 0L
                        while (isActive) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (done - lastEmit > 4 * 1024 * 1024) {
                                lastEmit = done
                                _downloads.value = _downloads.value + (id to DownloadState(id, req, total, done, DownloadStatus.RUNNING))
                            }
                        }
                    }
                }
                conn.disconnect()
                if (!isActive) return@launch
                _downloads.value = _downloads.value + (id to DownloadState(id, req, total, done, DownloadStatus.VERIFYING))
                val sha = Checksums.sha256(part)
                if (!req.expectedSha256.isNullOrBlank() && !sha.equals(req.expectedSha256.trim(), ignoreCase = true)) {
                    part.delete()
                    throw IllegalStateException("Checksum mismatch — file deleted (expected ${req.expectedSha256.take(12)}…, got ${sha.take(12)}…)")
                }
                val fileName = req.url.substringAfterLast('/').substringBefore('?').ifBlank { "model.litertlm" }
                val target = File(dir, "$id-$fileName")
                part.renameTo(target)
                val (profile, caps) = ModelDescriptor.estimateFromSize(target.length())
                val d = ModelDescriptor(id, req.name, target.name, ModelFormat.fromFileName(fileName), target.length(), sha, req.source.ifBlank { req.url },
                    req.license.ifBlank { "Not specified — check the model card" }, profile, caps, supportsVision = req.supportsVision)
                save(_models.value + d)
                _downloads.value = _downloads.value + (id to DownloadState(id, req, total, done, DownloadStatus.DONE))
            } catch (e: kotlinx.coroutines.CancellationException) {
                _downloads.value[id]?.let { _downloads.value = _downloads.value + (id to it.copy(status = DownloadStatus.PAUSED, downloaded = part.length())) }
                throw e
            } catch (e: Exception) {
                _downloads.value = _downloads.value + (id to DownloadState(id, req, -1, part.length(), DownloadStatus.FAILED, e.message))
            }
        }
    }

    fun pause(id: String) { jobs.remove(id)?.cancel() }

    fun resume(id: String, token: String?) { _downloads.value[id]?.let { startDownload(it.request, token, id) } }

    fun cancel(id: String) {
        jobs.remove(id)?.cancel()
        File(dir, "$id.part").delete()
        _downloads.value = _downloads.value - id
    }
}
