@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.models

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.inference.BenchmarkResult
import ai.astra.app.inference.DownloadRequest
import ai.astra.app.inference.DownloadStatus
import ai.astra.app.inference.ProbeResult
import ai.astra.app.security.SecretStore
import ai.astra.app.ui.SectionTitle
import ai.astra.core.model.Locality
import ai.astra.core.model.newId
import ai.astra.core.models.ModelDescriptor
import ai.astra.core.models.ModelProfile
import ai.astra.core.models.ProfileRecommender
import ai.astra.core.provider.Availability
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.EndpointKind
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private fun mb(bytes: Long) = if (bytes >= 1_073_741_824) "%.2f GB".format(bytes / 1_073_741_824.0) else "${bytes / 1_048_576} MB"

@Composable
fun ModelsScreen(c: AppContainer, toast: (String) -> Unit) {
    val models by c.models.models.collectAsState()
    val downloads by c.models.downloads.collectAsState()
    val settings by c.settingsStore.settings.collectAsState()
    val device by c.device.state.collectAsState()
    val status by c.providers.status.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var importing by remember { mutableStateOf<String?>(null) }
    var showDownload by remember { mutableStateOf(false) }
    var editingEndpoint by remember { mutableStateOf<EndpointConfig?>(null) }
    var editingModel by remember { mutableStateOf<ModelDescriptor?>(null) }
    var bench by remember { mutableStateOf<BenchmarkResult?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    val rec = remember(device.totalRamMb, device.freeStorageMb, device.thermal) { ProfileRecommender.recommend(device) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            importing = context.getString(R.string.importing)
            val r = c.models.import(uri) { done, total -> importing = if (total > 0) "${mb(done)} / ${mb(total)}" else mb(done) }
            importing = null
            r.onSuccess { d ->
                editingModel = d
                if (settings.activeLocalModelId == null && d.runnable) c.settingsStore.update { it.copy(activeLocalModelId = d.id) }
            }.onFailure { toast(context.getString(R.string.import_failed, it.message ?: "")) }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_models)) }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            // Recommendation
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.recommended_profile, rec.profile.label, rec.profile.paramsHint), fontWeight = FontWeight.SemiBold)
                    rec.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    Text(stringResource(R.string.recommended_context, rec.contextTokens), style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.model_format_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            SectionTitle(stringResource(R.string.on_device_models))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.use_gpu), Modifier.weight(1f))
                Switch(settings.useGpu, { on -> scope.launch { c.settingsStore.update { it.copy(useGpu = on) } } })
            }
            importing?.let { Text(stringResource(R.string.importing_progress, it)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.import_model)) }
                OutlinedButton(onClick = { showDownload = true }) { Text(stringResource(R.string.download_model)) }
            }
            downloads.values.forEach { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${d.request.name} — ${d.status.name.lowercase()}", fontWeight = FontWeight.SemiBold)
                        if (d.totalBytes > 0) {
                            LinearProgressIndicator(progress = { (d.downloaded.toFloat() / d.totalBytes).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                            Text("${mb(d.downloaded)} / ${mb(d.totalBytes)}", style = MaterialTheme.typography.bodySmall)
                        }
                        d.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Row {
                            when (d.status) {
                                DownloadStatus.RUNNING -> TextButton(onClick = { c.models.pause(d.id) }) { Text(stringResource(R.string.pause)) }
                                DownloadStatus.PAUSED, DownloadStatus.FAILED -> TextButton(onClick = { c.models.resume(d.id, c.secrets.get(SecretStore.DOWNLOAD_TOKEN)) }) { Text(stringResource(R.string.resume)) }
                                else -> Unit
                            }
                            if (d.status != DownloadStatus.DONE) TextButton(onClick = { c.models.cancel(d.id) }) { Text(stringResource(R.string.cancel)) }
                        }
                    }
                }
            }
            if (models.isEmpty()) Text(stringResource(R.string.no_local_models), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
            models.forEach { m ->
                val active = settings.activeLocalModelId == m.id || (settings.activeLocalModelId == null && models.firstOrNull { it.runnable }?.id == m.id)
                val st = status.firstOrNull { it.info.id == "local:${m.id}" }
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text((if (active) "● " else "") + m.name, fontWeight = FontWeight.SemiBold)
                        Text("${m.format.runtime} · ${mb(m.sizeBytes)} · ${m.profile.label}" + (if (m.supportsVision) " · vision" else ""), style = MaterialTheme.typography.bodySmall)
                        Text(stringResource(R.string.model_license, m.license), style = MaterialTheme.typography.bodySmall)
                        Text(stringResource(R.string.model_source, m.source), style = MaterialTheme.typography.bodySmall)
                        Text("SHA-256 ${m.sha256.take(16)}…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        st?.let { Text(it.detail, style = MaterialTheme.typography.labelSmall, color = if (it.availability is Availability.Ready) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                        if (!m.runnable) Text(stringResource(R.string.requires_runtime, m.format.runtime), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (!active && m.runnable) TextButton(onClick = { scope.launch { c.settingsStore.update { it.copy(activeLocalModelId = m.id) } } }) { Text(stringResource(R.string.make_active)) }
                            if (active && m.runnable) TextButton(enabled = busy == null, onClick = {
                                scope.launch {
                                    busy = m.id
                                    c.providers.loadLocal().onSuccess { toast(context.getString(R.string.model_loaded)) }.onFailure { toast(context.getString(R.string.model_load_failed, it.message ?: "")) }
                                    busy = null
                                }
                            }) { Text(stringResource(R.string.load_now)) }
                            if (active && m.runnable) TextButton(enabled = busy == null, onClick = {
                                scope.launch {
                                    busy = m.id
                                    val p = c.providers.localProvider()
                                    if (p != null) runCatching { c.providers.benchmark(p) }.onSuccess { bench = it }.onFailure { toast(it.message ?: "Benchmark failed") }
                                    busy = null
                                }
                            }) { Text(stringResource(R.string.benchmark)) }
                            if (active) TextButton(onClick = { c.providers.unloadLocal(); scope.launch { c.providers.refreshStatus() } }) { Text(stringResource(R.string.unload)) }
                            TextButton(onClick = { editingModel = m }) { Text(stringResource(R.string.edit)) }
                            TextButton(onClick = { c.models.delete(m.id) }) { Text(stringResource(R.string.delete)) }
                        }
                        if (busy == m.id) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }

            SectionTitle(stringResource(R.string.online_lan_endpoints))
            Text(stringResource(R.string.endpoints_explainer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            settings.endpoints.forEach { e ->
                val st = status.firstOrNull { it.info.id == "endpoint:${e.id}" }
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.displayName, fontWeight = FontWeight.SemiBold)
                        Text("${e.kind.name.lowercase().replace('_', '-')} · ${e.locality.name.lowercase()} · ${e.model}", style = MaterialTheme.typography.bodySmall)
                        Text(e.baseUrl, style = MaterialTheme.typography.labelSmall)
                        st?.let { s -> Text(when (val a = s.availability) { is Availability.Ready -> stringResource(R.string.ready); is Availability.NotConfigured -> a.reason; is Availability.Unavailable -> a.reason; Availability.RequiresInternet -> stringResource(R.string.requires_internet) }, style = MaterialTheme.typography.labelSmall) }
                        Row {
                            TextButton(onClick = { editingEndpoint = e }) { Text(stringResource(R.string.edit)) }
                            TextButton(onClick = {
                                scope.launch {
                                    busy = e.id
                                    val r = c.providers.testEndpoint(e)
                                    busy = null
                                    toast(r.fold({ it }, { context.getString(R.string.test_failed, it.message ?: "") }))
                                }
                            }) { Text(stringResource(R.string.test)) }
                            TextButton(onClick = { scope.launch { c.secrets.remove(SecretStore.endpointKey(e.id)); c.settingsStore.update { s -> s.copy(endpoints = s.endpoints.filter { it.id != e.id }) } } }) { Text(stringResource(R.string.delete)) }
                        }
                        if (busy == e.id) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
            OutlinedButton(onClick = { editingEndpoint = EndpointConfig(newId().take(8), "", EndpointKind.OPENAI_COMPATIBLE, "", "", Locality.REMOTE) }) { Text(stringResource(R.string.add_endpoint)) }
            Text(stringResource(R.string.future_runtimes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp))
        }
    }

    editingEndpoint?.let { e -> EndpointDialog(c, e, isNew = settings.endpoints.none { it.id == e.id }) { editingEndpoint = null } }
    editingModel?.let { m -> ModelMetaDialog(m, onSave = { c.models.update(it); editingModel = null }, onDismiss = { editingModel = null }) }
    if (showDownload) DownloadDialog(c) { showDownload = false }
    bench?.let { b ->
        AlertDialog(onDismissRequest = { bench = null }, title = { Text(stringResource(R.string.benchmark)) },
            text = {
                Column {
                    b.loadMs?.let { Text(stringResource(R.string.bench_load, it)) }
                    Text(stringResource(R.string.bench_ttft, b.firstTokenMs))
                    Text(stringResource(R.string.bench_speed, "%.1f".format(b.tokensPerSecond), b.tokens))
                    Text(stringResource(R.string.bench_total, b.totalMs))
                    Text(stringResource(R.string.bench_ram, b.nativeHeapDeltaMb))
                    Text(stringResource(R.string.bench_temp, b.batteryTempBeforeC?.toString() ?: "?", b.batteryTempAfterC?.toString() ?: "?"))
                    b.batteryDropPercent?.let { Text(stringResource(R.string.bench_battery, it)) }
                }
            }, confirmButton = { TextButton(onClick = { bench = null }) { Text(stringResource(R.string.done)) } })
    }
}

@Composable
private fun ModelMetaDialog(m: ModelDescriptor, onSave: (ModelDescriptor) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(m.name) }
    var license by remember { mutableStateOf(m.license) }
    var source by remember { mutableStateOf(m.source) }
    var vision by remember { mutableStateOf(m.supportsVision) }
    var profile by remember { mutableStateOf(m.profile) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(R.string.model_details)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${m.fileName} · ${mb(m.sizeBytes)}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, singleLine = true)
                OutlinedTextField(license, { license = it }, label = { Text(stringResource(R.string.license)) })
                OutlinedTextField(source, { source = it }, label = { Text(stringResource(R.string.source)) })
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(vision, { vision = it }); Text(stringResource(R.string.supports_images)) }
                Text(stringResource(R.string.profile), style = MaterialTheme.typography.labelSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ModelProfile.entries.forEach { p -> FilterChip(selected = p == profile, onClick = { profile = p }, label = { Text(p.label) }) }
                }
                Text(stringResource(R.string.hardware_requirement, profile.minRamMb / 1000), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val (_, caps) = ModelDescriptor.estimateFromSize(m.sizeBytes)
                val tuned = when (profile) {
                    ModelProfile.TINY -> caps.copy(reasoning = 2, coding = 2, speed = 9)
                    ModelProfile.SMALL -> caps.copy(reasoning = 4, coding = 4, speed = 7)
                    ModelProfile.MEDIUM -> caps.copy(reasoning = 6, coding = 6, speed = 5)
                    ModelProfile.LARGE -> caps.copy(reasoning = 7, coding = 7, speed = 3)
                }
                onSave(m.copy(name = name.ifBlank { m.name }, license = license, source = source, supportsVision = vision, profile = profile,
                    capabilities = tuned.copy(vision = if (vision) 6 else 0)))
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun DownloadDialog(c: AppContainer, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var license by remember { mutableStateOf("") }
    var sha by remember { mutableStateOf("") }
    var token by remember { mutableStateOf(c.secrets.get(SecretStore.DOWNLOAD_TOKEN) ?: "") }
    var vision by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf<ProbeResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(R.string.download_model)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.download_explainer), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(url, { url = it; probe = null }, label = { Text("https://…/model.litertlm") }, singleLine = true)
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, singleLine = true)
                OutlinedTextField(license, { license = it }, label = { Text(stringResource(R.string.license_required)) })
                OutlinedTextField(sha, { sha = it }, label = { Text(stringResource(R.string.sha_optional)) }, singleLine = true)
                OutlinedTextField(token, { token = it }, label = { Text(stringResource(R.string.access_token_optional)) }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(vision, { vision = it }); Text(stringResource(R.string.supports_images)) }
                probe?.let { p ->
                    val (profile, _) = ModelDescriptor.estimateFromSize(p.sizeBytes)
                    Card { Column(Modifier.padding(10.dp)) {
                        Text(stringResource(R.string.probe_size, if (p.sizeBytes > 0) mb(p.sizeBytes) else "?"), fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.probe_source, p.finalHost))
                        Text(stringResource(R.string.probe_license, license.ifBlank { "—" }))
                        Text(stringResource(R.string.probe_hardware, profile.label, profile.minRamMb / 1000))
                    } }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (checking) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            if (probe == null) TextButton(enabled = url.startsWith("https://") && !checking, onClick = {
                scope.launch {
                    checking = true; error = null
                    c.models.probe(url.trim(), token).onSuccess { probe = it; if (name.isBlank()) name = it.fileName.substringBeforeLast('.') }.onFailure { error = it.message }
                    checking = false
                }
            }) { Text(stringResource(R.string.check_size)) }
            else TextButton(enabled = license.isNotBlank(), onClick = {
                c.secrets.put(SecretStore.DOWNLOAD_TOKEN, token.ifBlank { null })
                c.models.startDownload(DownloadRequest(url.trim(), name.ifBlank { "Model" }, license, url.trim(), sha.ifBlank { null }, vision), token.ifBlank { null })
                onDismiss()
            }) { Text(stringResource(R.string.download)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun EndpointDialog(c: AppContainer, initial: EndpointConfig, isNew: Boolean, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initial.displayName) }
    var kind by remember { mutableStateOf(initial.kind) }
    var url by remember { mutableStateOf(initial.baseUrl) }
    var model by remember { mutableStateOf(initial.model) }
    var locality by remember { mutableStateOf(initial.locality) }
    var vision by remember { mutableStateOf(initial.vision) }
    var embed by remember { mutableStateOf(initial.embeddingModel ?: "") }
    var context by remember { mutableStateOf(initial.scores.contextWindow.toString()) }
    var key by remember { mutableStateOf("") }
    val hasKey = remember { c.secrets.has(SecretStore.endpointKey(initial.id)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(if (isNew) R.string.add_endpoint else R.string.edit_endpoint)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(kind == EndpointKind.OPENAI_COMPATIBLE, { kind = EndpointKind.OPENAI_COMPATIBLE }, label = { Text(stringResource(R.string.kind_openai)) })
                    FilterChip(kind == EndpointKind.ANTHROPIC, {
                        kind = EndpointKind.ANTHROPIC
                        if (url.isBlank()) url = "https://api.anthropic.com"
                        if (model.isBlank()) model = "claude-sonnet-5-5"
                    }, label = { Text(stringResource(R.string.kind_anthropic)) })
                }
                Text(stringResource(R.string.where_does_it_run), style = MaterialTheme.typography.labelSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Locality.REMOTE to R.string.loc_remote, Locality.USER_HOSTED to R.string.loc_user_hosted, Locality.LAN to R.string.loc_lan).forEach { (l, res) ->
                        FilterChip(locality == l, { locality = l }, label = { Text(stringResource(res)) })
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, singleLine = true)
                OutlinedTextField(url, { url = it }, label = { Text(stringResource(R.string.base_url)) }, singleLine = true, placeholder = { Text("https://api.example.com  ·  http://192.168.1.20:11434") })
                OutlinedTextField(model, { model = it }, label = { Text(stringResource(R.string.model_id)) }, singleLine = true)
                OutlinedTextField(key, { key = it }, label = { Text(if (hasKey) stringResource(R.string.api_key_saved) else stringResource(R.string.api_key)) }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(context, { context = it.filter(Char::isDigit) }, label = { Text(stringResource(R.string.context_window)) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (kind == EndpointKind.OPENAI_COMPATIBLE) OutlinedTextField(embed, { embed = it }, label = { Text(stringResource(R.string.embedding_model_optional)) }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(vision, { vision = it }); Text(stringResource(R.string.supports_images)) }
                Text(stringResource(R.string.key_vault_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = url.isNotBlank() && model.isNotBlank(), onClick = {
                val cfg = initial.copy(
                    displayName = name.ifBlank { model }, kind = kind, baseUrl = url.trim(), model = model.trim(), locality = locality, vision = vision,
                    embeddingModel = embed.trim().ifBlank { null },
                    scores = initial.scores.copy(contextWindow = context.toIntOrNull()?.coerceAtLeast(2048) ?: initial.scores.contextWindow,
                        reasoning = if (locality == Locality.LAN) 6 else initial.scores.reasoning, coding = if (locality == Locality.LAN) 6 else initial.scores.coding),
                )
                if (key.isNotBlank()) c.secrets.put(SecretStore.endpointKey(initial.id), key.trim())
                scope.launch { c.settingsStore.update { s -> s.copy(endpoints = s.endpoints.filter { it.id != cfg.id } + cfg) } }
                onDismiss()
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } })
}
