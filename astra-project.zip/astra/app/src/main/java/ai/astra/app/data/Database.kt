package ai.astra.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String?,
    val folder: String?,
    val pinned: Boolean,
    val archived: Boolean,
    val parentId: String?,
    val forkedFromMessageId: String?,
    val temporary: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val summary: String? = null,
    val summaryUntil: Long? = null,
)

@Entity(tableName = "messages", indices = [Index("conversationId")])
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val partsJson: String,
    val createdAt: Long,
    val traceJson: String?,
    val feedback: String,
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val createdAt: Long,
    val updatedAt: Long,
    val source: String,
    val type: String,
    val importance: Double,
    val confidence: Double,
    val privacyLevel: String,
    val projectId: String?,
    val conversationId: String?,
    val content: String,
    val embedding: ByteArray,
    val embedderId: String,
    val expiry: Long?,
    val userEditable: Boolean,
    val subjectKey: String?,
    val pinned: Boolean,
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val instructions: String,
    val privateByDefault: Boolean,
    val createdAt: Long,
)

@Entity(tableName = "tasks", indices = [Index("projectId")])
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val priority: String,
    val deadline: Long?,
    val status: String,
    val projectId: String?,
    val parentId: String?,
    val dependsOn: String,
    val estimateMinutes: Int?,
    val createdAt: Long,
)

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val mimeType: String,
    val locator: String,
    val unitCount: Int,
    val chunkCount: Int,
    val projectId: String?,
    val sha256: String,
    val importedAt: Long,
    val embedderId: String,
)

@Entity(tableName = "chunks", indices = [Index("documentId")])
data class ChunkEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val ordinal: Int,
    val unit: Int,
    val text: String,
    val embedding: ByteArray,
)

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE archived = :archived ORDER BY pinned DESC, updatedAt DESC")
    fun observe(archived: Boolean): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun get(id: String): ConversationEntity?

    @Query("SELECT * FROM conversations")
    suspend fun all(): List<ConversationEntity>

    @Upsert
    suspend fun upsert(c: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE conversations SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: String, time: Long)

    @Query("UPDATE conversations SET summary = :summary, summaryUntil = :until WHERE id = :id")
    suspend fun setSummary(id: String, summary: String, until: Long)

    @Query("SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversationId = c.id WHERE c.title LIKE '%' || :q || '%' OR m.partsJson LIKE '%' || :q || '%' ORDER BY c.updatedAt DESC LIMIT 50")
    suspend fun search(q: String): List<ConversationEntity>
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun observe(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    suspend fun list(conversationId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteForConversation(conversationId: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId AND createdAt > :after")
    suspend fun deleteAfter(conversationId: String, after: Long)

    @Query("UPDATE messages SET feedback = :feedback WHERE id = :id")
    suspend fun setFeedback(id: String, feedback: String)
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories")
    suspend fun all(): List<MemoryEntity>

    @Query("SELECT * FROM memories ORDER BY updatedAt DESC")
    fun observe(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE id = :id")
    suspend fun get(id: String): MemoryEntity?

    @Upsert
    suspend fun upsert(m: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: String): Int

    @Query("DELETE FROM memories")
    suspend fun clear()
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observe(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects")
    suspend fun all(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: String): ProjectEntity?

    @Upsert
    suspend fun upsert(p: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt ASC")
    fun observe(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks")
    suspend fun all(): List<TaskEntity>

    @Upsert
    suspend fun upsert(t: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id OR parentId = :id")
    suspend fun delete(id: String)
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY importedAt DESC")
    fun observe(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents")
    suspend fun all(): List<DocumentEntity>

    @Upsert
    suspend fun upsert(d: DocumentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChunks(chunks: List<ChunkEntity>)

    @Query("SELECT * FROM chunks WHERE documentId IN (:ids)")
    suspend fun chunks(ids: List<String>): List<ChunkEntity>

    @Query("DELETE FROM chunks WHERE documentId = :id")
    suspend fun deleteChunks(id: String)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocument(id: String)
}

@Database(
    entities = [ConversationEntity::class, MessageEntity::class, MemoryEntity::class, ProjectEntity::class, TaskEntity::class, DocumentEntity::class, ChunkEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AstraDatabase : RoomDatabase() {
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun memories(): MemoryDao
    abstract fun projects(): ProjectDao
    abstract fun tasks(): TaskDao
    abstract fun documents(): DocumentDao

    companion object {
        fun create(context: Context): AstraDatabase =
            Room.databaseBuilder(context, AstraDatabase::class.java, "astra.db").build()
    }
}
