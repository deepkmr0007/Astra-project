@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package ai.astra.app.ui.chat

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.MarkdownText
import ai.astra.app.ui.ModeIndicator
import ai.astra.app.ui.modeColor
import ai.astra.app.ui.shareFile
import ai.astra.app.voice.ListenState
import ai.astra.core.agent.ActivityItem
import ai.astra.core.memory.ConflictResolution
import ai.astra.core.model.AssistMode
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionTrace
import ai.astra.core.model.Feedback
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.router.DataControl
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

@Composable
fun ChatScreen(
    vm: ChatViewModel,
    c: AppContainer,
    onOpenDrawer: () -> Unit,
    onNavigate: (NavTarget) -> Unit,
    onImportDocument: () -> Unit,
    prefill: String?,
    onPrefillConsumed: () -> Unit,
) {
    val context = LocalContext.current
    val messages by vm.messages.collectAsState()
    val streaming by vm.streaming.collectAsState()
    val busy by vm.busy.collectAsState()
    val activity by vm.runActivity.collectAsState()
    val notices by vm.notices.collectAsState()
    val route by vm.route.collectAsState()
    val predicted by vm.predicted.collectAsState()
    val failure by vm.failure.collectAsState()
    val mode by vm.mode.collectAsState()
    val images by vm.pendingImages.collectAsState()
    val settings by c.settingsStore.settings.collectAsState()
    val listen by c.speechIn.state.collectAsState()
    val partial by c.speechIn.partial.collectAsState()
    val conflict by vm.conflict.collectAsState()
    val forget by vm.forgetCandidates.collectAsState()
    val nav by vm.navRequest.collectAsState()
    val share by vm.shareFile.collectAsState()
    val importReq by vm.importRequest.collectAsState()
    val providers by c.providers.status.collectAsState()

    var input by remember { mutableStateOf("") }
    var traceFor by remember { mutableStateOf<ChatMessage?>(null) }
    var editing by remember { mutableStateOf<ChatMessage?>(null) }
    var retryMenu by remember { mutableStateOf(false) }
    var showActivity by remember { mutableStateOf(false) }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(prefill) { if (!prefill.isNullOrBlank()) { input = prefill; onPrefillConsumed() } }
    LaunchedEffect(nav) { nav?.let { onNavigate(it); vm.navRequest.value = null } }
    LaunchedEffect(share) { share?.let { shareFile(context, it, "text/markdown"); vm.shareFile.value = null } }
    LaunchedEffect(importReq) { if (importReq) { onImportDocument(); vm.importRequest.value = false } }
    LaunchedEffect(messages.size, failure) { val last = listState.layoutInfo.totalItemsCount - 1; if (last > 0) listState.animateScrollToItem(last) }
    LaunchedEffect(streaming.length / 80) { val last = listState.layoutInfo.totalItemsCount - 1; if (streaming.isNotEmpty() && last > 0) listState.scrollToItem(last) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.attachImage(it) } }
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = cameraFile
        if (ok && f != null) vm.attachImage(FileProvider.getUriForFile(context, context.packageName + ".files", f))
    }
    val startListening = {
        c.speechOut.stop() // barge-in
        c.speechIn.start(null, onFinal = { text -> input = (input + " " + text).trim() }, onError = { vm.toast.value = it })
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else vm.toast.value = context.getString(R.string.mic_denied)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onOpenDrawer) { Icon(Icons.Filled.Menu, stringResource(R.string.cd_conversations)) } },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ASTRA", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.size(10.dp))
                        ModeIndicator(route?.mode ?: predicted, settings.dataControl == DataControl.NEVER_SEND, Modifier.clickable { showActivity = true })
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigate(NavTarget.SEARCH) }) { Icon(Icons.Filled.Search, stringResource(R.string.cd_search)) }
                    var menu by remember { mutableStateOf(false) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.cd_more)) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        AssistMode.entries.forEach { m ->
                            DropdownMenuItem(text = { Text((if (m == mode) "✓ " else "   ") + modeLabel(m)) }, onClick = { vm.mode.value = m; menu = false })
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text(stringResource(R.string.ai_activity)) }, onClick = { showActivity = true; menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.new_temporary_chat)) }, onClick = { vm.newChat(c.currentProjectId, temporary = true); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.export_chat)) }, onClick = { vm.exportCurrent(); menu = false })
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (messages.isEmpty() && !busy) item { Welcome(providers.isEmpty(), onNavigate) }
                items(messages, key = { it.id }) { m ->
                    MessageBubble(
                        m, isLast = m.id == messages.lastOrNull()?.id,
                        onTrace = { traceFor = m },
                        onCopy = { context.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ASTRA", m.text)); vm.toast.value = context.getString(R.string.copied) },
                        onEdit = { editing = m },
                        onRemember = { vm.remember(m) },
                        onSpeak = { vm.speak(m) },
                        onRegenerate = { vm.regenerate() },
                        onContinue = { vm.continueAnswer() },
                        onBranch = { vm.branchFrom(m) },
                        onRetryWith = { retryMenu = true },
                        onExport = { vm.exportCurrent() },
                        onDelete = { vm.deleteMessage(m) },
                        onFeedback = { vm.feedback(m, it) },
                    )
                }
                if (busy) item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        route?.let { r -> Text(stringResource(R.string.running_on, r.provider), style = MaterialTheme.typography.labelSmall, color = modeColor(r.mode)) }
                        if (activity.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(activity.takeLast(4)) { a -> AssistChip(onClick = { showActivity = true }, label = { Text(a.title, maxLines = 1, overflow = TextOverflow.Ellipsis) }) }
                        }
                        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(16.dp)) {
                            Box(Modifier.padding(12.dp)) { MarkdownText(streaming.ifEmpty { "…" }) }
                        }
                    }
                }
                failure?.let { f ->
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(f.reason, color = MaterialTheme.colorScheme.onErrorContainer)
                                f.hint?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer) }
                                f.alternatives.forEach { alt -> OutlinedButton(onClick = { vm.regenerate(alt.id) }) { Text(stringResource(R.string.retry_with, alt.displayName)) } }
                                if (f.hint?.contains("Models") == true || f.reason.contains("model", true)) TextButton(onClick = { onNavigate(NavTarget.MODELS) }) { Text(stringResource(R.string.open_models)) }
                            }
                        }
                    }
                }
            }
            notices.forEach { n -> Text("ⓘ $n", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) }

            // Slash command suggestions.
            if (input.startsWith("/") && !input.contains(' ')) {
                val matches = SLASH_COMMANDS.filter { it.name.startsWith(input.lowercase()) }
                if (matches.isNotEmpty()) Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp)) {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        matches.forEach { cmd ->
                            Row(Modifier.fillMaxWidth().clickable { input = cmd.name + " " }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Text(cmd.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.widthIn(min = 96.dp))
                                Text(cmd.hint, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            if (images.isNotEmpty()) LazyRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(images) { path -> AttachmentThumb(path) { vm.removeImage(path) } }
            }

            // Input bar: attach · image · camera · mic · text · send/stop
            Surface(tonalElevation = 2.dp) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    if (listen != ListenState.IDLE) Text(if (partial.isNotBlank()) partial else stringResource(R.string.listening), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onImportDocument) { Icon(Icons.Filled.AttachFile, stringResource(R.string.cd_attach_document)) }
                        IconButton(onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Icon(Icons.Filled.ImageIcon, stringResource(R.string.cd_attach_image)) }
                        IconButton(onClick = {
                            val f = File(File(context.cacheDir, "camera").apply { mkdirs() }, "shot-${System.currentTimeMillis()}.jpg")
                            cameraFile = f
                            takePicture.launch(FileProvider.getUriForFile(context, context.packageName + ".files", f))
                        }) { Icon(Icons.Filled.PhotoCamera, stringResource(R.string.cd_camera)) }
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            placeholder = { Text(stringResource(if (mode == AssistMode.CHAT) R.string.input_hint else R.string.input_hint_tools, modeLabel(mode))) },
                            modifier = Modifier.weight(1f), maxLines = 6, shape = RoundedCornerShape(20.dp),
                        )
                        IconButton(onClick = {
                            when {
                                listen != ListenState.IDLE -> c.speechIn.stop()
                                settings.permissions[ai.astra.core.security.Permission.MICROPHONE] == ai.astra.core.security.PermissionState.DENIED -> vm.toast.value = context.getString(R.string.mic_denied_center)
                                ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> startListening()
                                else -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }) { Icon(if (listen != ListenState.IDLE) Icons.Filled.Stop else Icons.Filled.Mic, stringResource(R.string.cd_voice), tint = if (listen != ListenState.IDLE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) }
                        if (busy) FilledIconButton(onClick = { vm.stop() }) { Icon(Icons.Filled.Stop, stringResource(R.string.cd_stop)) }
                        else FilledIconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank() || images.isNotEmpty()) { Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.cd_send)) }
                    }
                }
            }
        }
    }

    traceFor?.let { m -> TraceSheet(m) { traceFor = null } }
    if (showActivity) ActivitySheet(c.activity.collectAsState().value) { showActivity = false }
    editing?.let { m ->
        var text by remember(m) { mutableStateOf(m.text) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text(stringResource(R.string.edit_message)) },
            text = { OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { vm.editAndResend(m, text); editing = null }) { Text(stringResource(R.string.resend)) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } })
    }
    if (retryMenu) AlertDialog(onDismissRequest = { retryMenu = false }, title = { Text(stringResource(R.string.retry_another_model)) },
        text = {
            Column {
                providers.forEach { p ->
                    TextButton(onClick = { vm.regenerate(p.info.id); retryMenu = false }) { Text("${p.info.displayName} · ${p.info.locality.name.lowercase()}") }
                }
                if (providers.isEmpty()) Text(stringResource(R.string.no_models))
            }
        }, confirmButton = { TextButton(onClick = { retryMenu = false }) { Text(stringResource(R.string.cancel)) } })
    conflict?.let { cf ->
        AlertDialog(onDismissRequest = { vm.conflict.value = null }, title = { Text(stringResource(R.string.memory_conflict)) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(stringResource(R.string.memory_conflict_old, cf.existing.content)); Text(stringResource(R.string.memory_conflict_new, cf.incoming.content)) } },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = { vm.resolveConflict(ConflictResolution.REPLACE_WITH_NEW) }) { Text(stringResource(R.string.keep_new)) }
                    TextButton(onClick = { vm.resolveConflict(ConflictResolution.KEEP_BOTH) }) { Text(stringResource(R.string.keep_both)) }
                }
            },
            dismissButton = { TextButton(onClick = { vm.resolveConflict(ConflictResolution.KEEP_EXISTING) }) { Text(stringResource(R.string.keep_old)) } })
    }
    forget?.let { list ->
        val chosen = remember(list) { mutableStateListOf<String>().apply { addAll(list.map { it.id }) } }
        AlertDialog(onDismissRequest = { vm.forgetCandidates.value = null }, title = { Text(stringResource(R.string.forget_title)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (list.isEmpty()) Text(stringResource(R.string.forget_none))
                    list.forEach { r ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(r.id in chosen, { on -> if (on) chosen.add(r.id) else chosen.remove(r.id) })
                            Text(r.content, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(enabled = chosen.isNotEmpty(), onClick = { vm.confirmForget(chosen.toList()) }) { Text(stringResource(R.string.forget_selected, chosen.size)) } },
            dismissButton = { TextButton(onClick = { vm.forgetCandidates.value = null }) { Text(stringResource(R.string.cancel)) } })
    }
}

@Composable
fun modeLabel(m: AssistMode): String = when (m) {
    AssistMode.CHAT -> stringResource(R.string.assist_chat)
    AssistMode.ASSIST -> stringResource(R.string.assist_assist)
    AssistMode.AGENT -> stringResource(R.string.assist_agent)
}

@Composable
private fun Welcome(noModels: Boolean, onNavigate: (NavTarget) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp, start = 12.dp, end = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(stringResource(R.string.welcome_title), style = MaterialTheme.typography.headlineSmall)
        Text(stringResource(R.string.welcome_body), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (noModels) Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.setup_model_title), fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.setup_model_body), style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { onNavigate(NavTarget.MODELS) }) { Text(stringResource(R.string.open_models)) }
            }
        }
        Text(stringResource(R.string.welcome_tips), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AttachmentThumb(path: String, onRemove: () -> Unit) {
    val bmp = remember(path) { runCatching { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 8 }) }.getOrNull() }
    Box(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it.asImageBitmap(), contentDescription = stringResource(R.string.cd_attached_image), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        IconButton(onClick = onRemove, modifier = Modifier.align(Alignment.TopEnd).size(24.dp)) { Icon(Icons.Filled.Close, stringResource(R.string.cd_remove)) }
    }
}

@Composable
private fun MessageBubble(
    m: ChatMessage, isLast: Boolean,
    onTrace: () -> Unit, onCopy: () -> Unit, onEdit: () -> Unit, onRemember: () -> Unit, onSpeak: () -> Unit,
    onRegenerate: () -> Unit, onContinue: () -> Unit, onBranch: () -> Unit, onRetryWith: () -> Unit, onExport: () -> Unit,
    onDelete: () -> Unit, onFeedback: (Feedback) -> Unit,
) {
    val user = m.role == Role.USER
    var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (user) Alignment.End else Alignment.Start) {
        Box {
            Surface(
                color = if (user) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (user) 18.dp else 4.dp, bottomEnd = if (user) 4.dp else 18.dp),
                modifier = Modifier.widthIn(max = 340.dp).combinedClickable(onClick = {}, onLongClick = { menu = true }),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    m.parts.filterIsInstance<Part.Image>().forEach { AttachmentPreview(it.path) }
                    MarkdownText(m.parts.filter { it !is Part.Image }.joinToString("\n") { p ->
                        when (p) { is Part.Text -> p.text; is Part.Code -> "```${p.language}\n${p.code}\n```"; is Part.DocumentRef -> "📄 ${p.title}"; else -> "" }
                    })
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(stringResource(R.string.copy)) }, onClick = { onCopy(); menu = false })
                if (user) DropdownMenuItem(text = { Text(stringResource(R.string.edit)) }, onClick = { onEdit(); menu = false })
                DropdownMenuItem(text = { Text(stringResource(R.string.remember)) }, onClick = { onRemember(); menu = false })
                if (!user) DropdownMenuItem(text = { Text(stringResource(R.string.speak)) }, onClick = { onSpeak(); menu = false })
                if (!user && isLast) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.regenerate)) }, onClick = { onRegenerate(); menu = false })
                    DropdownMenuItem(text = { Text(stringResource(R.string.continue_answer)) }, onClick = { onContinue(); menu = false })
                    DropdownMenuItem(text = { Text(stringResource(R.string.retry_another_model)) }, onClick = { onRetryWith(); menu = false })
                }
                DropdownMenuItem(text = { Text(stringResource(R.string.branch)) }, onClick = { onBranch(); menu = false })
                DropdownMenuItem(text = { Text(stringResource(R.string.export_chat)) }, onClick = { onExport(); menu = false })
                DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, onClick = { onDelete(); menu = false })
            }
        }
        if (!user) Row(verticalAlignment = Alignment.CenterVertically) {
            m.trace?.let { t -> TraceChip(t, onTrace) }
            IconButton(onClick = onSpeak, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.VolumeUp, stringResource(R.string.speak), Modifier.size(16.dp)) }
            IconButton(onClick = { onFeedback(Feedback.UP) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.ThumbUp, stringResource(R.string.cd_good), Modifier.size(16.dp), tint = if (m.feedback == Feedback.UP) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { onFeedback(Feedback.DOWN) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.ThumbDown, stringResource(R.string.cd_bad), Modifier.size(16.dp), tint = if (m.feedback == Feedback.DOWN) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AttachmentPreview(path: String) {
    val bmp = remember(path) { runCatching { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 4 }) }.getOrNull() }
    bmp?.let { Image(it.asImageBitmap(), contentDescription = stringResource(R.string.cd_attached_image), modifier = Modifier.heightIn(max = 220.dp).clip(RoundedCornerShape(10.dp))) }
}

@Composable
private fun TraceChip(t: ExecutionTrace, onClick: () -> Unit) {
    val where = if (t.locality == Locality.ON_DEVICE) stringResource(R.string.trace_on_device) else stringResource(R.string.trace_network)
    val speed = if (t.tokensPerSecond > 0) " · ${"%.1f".format(t.tokensPerSecond)} tok/s" else ""
    Row(Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Info, contentDescription = stringResource(R.string.cd_trace), Modifier.size(14.dp), tint = modeColor(t.mode))
        Spacer(Modifier.size(4.dp))
        Text("$where · ${t.model.take(22)}$speed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

/** "Which model? Where? What was sent? Which tools?" for one response. */
@Composable
private fun TraceSheet(m: ChatMessage, onDismiss: () -> Unit) {
    val t = m.trace ?: return
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.trace_title), style = MaterialTheme.typography.titleMedium)
            TraceRow(stringResource(R.string.trace_model), t.model)
            TraceRow(stringResource(R.string.trace_execution), when (t.locality) {
                Locality.ON_DEVICE -> stringResource(R.string.trace_on_device)
                Locality.LAN -> stringResource(R.string.trace_lan)
                Locality.USER_HOSTED -> stringResource(R.string.trace_user_hosted)
                Locality.REMOTE -> stringResource(R.string.trace_remote)
            } + " (${t.mode.name})")
            TraceRow(stringResource(R.string.trace_network_label), if (t.networkUsed) stringResource(R.string.trace_network_used, t.bytesSent / 1024) else stringResource(R.string.trace_network_not_used))
            if (t.dataSent.isNotEmpty()) TraceRow(stringResource(R.string.trace_data_sent), t.dataSent.joinToString())
            TraceRow(stringResource(R.string.trace_tools), t.tools.joinToString().ifEmpty { stringResource(R.string.none) })
            TraceRow(stringResource(R.string.trace_speed), "${t.tokensOut} tokens · ${"%.1f".format(t.tokensPerSecond)} tok/s · ${t.latencyMs} ms")
            t.verification?.let { v -> TraceRow(stringResource(R.string.trace_verification), v.lines().joinToString("\n")) }
            if (t.routeReasons.isNotEmpty()) TraceRow(stringResource(R.string.trace_why), t.routeReasons.joinToString("\n") { "• $it" })
            if (t.warnings.isNotEmpty()) TraceRow(stringResource(R.string.trace_warnings), t.warnings.joinToString("\n"))
        }
    }
}

@Composable
private fun TraceRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ActivitySheet(items: List<ActivityItem>, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text(stringResource(R.string.ai_activity), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.ai_activity_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(Modifier.heightIn(max = 480.dp)) {
                items(items.asReversed()) { a ->
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Text("${a.kind.name} · ${a.title}", fontWeight = FontWeight.SemiBold, color = if (a.ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
                        if (a.detail.isNotBlank()) Text(a.detail.take(600), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
                if (items.isEmpty()) item { Text(stringResource(R.string.ai_activity_empty), modifier = Modifier.padding(vertical = 16.dp)) }
            }
        }
    }
}

@Composable
fun ConversationDrawerContent(vm: ChatViewModel, onPick: () -> Unit) {
    val conversations by vm.conversations.collectAsState()
    val current by vm.currentId.collectAsState()
    var query by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<Conversation?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("ASTRA", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.newChat(); onPick() }) { Text(stringResource(R.string.new_chat)) }
            OutlinedButton(onClick = { vm.newChat(temporary = true); onPick() }) { Text(stringResource(R.string.temporary)) }
        }
        OutlinedTextField(query, { query = it }, placeholder = { Text(stringResource(R.string.search_chats)) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        val shown = conversations.filter { query.isBlank() || it.title.contains(query, true) }
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.id }) { conv ->
                var menu by remember { mutableStateOf(false) }
                Box {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .background(if (conv.id == current) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else androidx.compose.ui.graphics.Color.Transparent)
                            .combinedClickable(onClick = { vm.select(conv.id); onPick() }, onLongClick = { menu = true })
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                    ) {
                        Text((if (conv.pinned) "📌 " else "") + (if (conv.temporary) "⏳ " else "") + (if (conv.parentConversationId != null) "⑂ " else "") + conv.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { renaming = conv; menu = false })
                        DropdownMenuItem(text = { Text(stringResource(if (conv.pinned) R.string.unpin else R.string.pin)) }, onClick = { vm.togglePin(conv.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.archive)) }, onClick = { vm.archive(conv.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, onClick = { vm.delete(conv.id); menu = false })
                    }
                }
            }
        }
    }
    renaming?.let { conv ->
        var t by remember(conv) { mutableStateOf(conv.title) }
        AlertDialog(onDismissRequest = { renaming = null }, title = { Text(stringResource(R.string.rename)) },
            text = { OutlinedTextField(t, { t = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(conv.id, t); renaming = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text(stringResource(R.string.cancel)) } })
    }
}
