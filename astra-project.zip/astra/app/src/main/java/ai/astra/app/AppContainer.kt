package ai.astra.app

import ai.astra.app.data.AstraDatabase
import ai.astra.app.data.ChatRepository
import ai.astra.app.data.RoomDocumentStore
import ai.astra.app.data.RoomMemoryStore
import ai.astra.app.data.SettingsStore
import ai.astra.app.device.DeviceMonitor
import ai.astra.app.documents.DocumentImporter
import ai.astra.app.inference.ModelManager
import ai.astra.app.inference.ProviderManager
import ai.astra.app.security.SecretStore
import ai.astra.app.voice.SpeechInput
import ai.astra.app.voice.SpeechOutput
import ai.astra.core.agent.AgentRunner
import ai.astra.core.chat.ChatEngine
import ai.astra.core.chat.ConsentAnswer
import ai.astra.core.chat.ConsentGate
import ai.astra.core.chat.ConsentRequest
import ai.astra.core.diagnostics.Diagnostics
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.memory.HashingEmbedder
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.provider.NetworkGate
import ai.astra.core.router.ModelRouter
import ai.astra.core.security.ConfirmationGate
import ai.astra.core.security.ConfirmationRequest
import ai.astra.core.security.RingAuditLog
import ai.astra.core.security.ToolFirewall
import ai.astra.core.tools.defaultTools
import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** A question the engine is waiting on the user to answer. */
sealed interface PendingPrompt {
    data class Consent(val request: ConsentRequest, val answer: CompletableDeferred<ConsentAnswer>) : PendingPrompt
    data class Confirm(val request: ConfirmationRequest, val answer: CompletableDeferred<Boolean>) : PendingPrompt
}

/** Bridges engine suspension points (consent, tool confirmation) to dialogs in the UI. */
class UiBridge {
    private val _pending = MutableStateFlow<PendingPrompt?>(null)
    val pending: StateFlow<PendingPrompt?> = _pending.asStateFlow()
    private val serial = Mutex()

    val consentGate = ConsentGate { req ->
        serial.withLock {
            val d = CompletableDeferred<ConsentAnswer>()
            _pending.value = PendingPrompt.Consent(req, d)
            try { d.await() } finally { _pending.value = null }
        }
    }

    val confirmationGate = ConfirmationGate { req ->
        serial.withLock {
            val d = CompletableDeferred<Boolean>()
            _pending.value = PendingPrompt.Confirm(req, d)
            try { d.await() } finally { _pending.value = null }
        }
    }
}

/**
 * Manual dependency injection: one place that wires every replaceable component. Swapping the
 * embedder, a provider, a store or the router is a one-line change here.
 */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val db = AstraDatabase.create(appContext)
    val settingsStore = SettingsStore(appContext, scope)
    val secrets = SecretStore(appContext)
    val device = DeviceMonitor(appContext).also { it.start() }
    val diagnostics = Diagnostics()
    val audit = RingAuditLog()
    val bridge = UiBridge()
    val gate = NetworkGate()

    val chatRepo = ChatRepository(db)
    val memoryStore = RoomMemoryStore(db)
    val documentStore = RoomDocumentStore(db)
    val embedder = HashingEmbedder()
    val memory = MemoryEngine(memoryStore, embedder, settingsStore.settings.value.memoryPolicy())
    val documents = DocumentIndex(documentStore, embedder)
    val importer = DocumentImporter(appContext, documents)

    val models = ModelManager(appContext, scope)
    val providers = ProviderManager(appContext, models, secrets, gate, device)

    /** Project of the conversation currently on screen (scopes memory/document tools). */
    @Volatile var currentProjectId: String? = null
    val tools = defaultTools(memory, documents) { currentProjectId }
    val firewall = ToolFirewall(settingsStore.permissionCenter, bridge.confirmationGate, audit)
    val agent = AgentRunner(tools, firewall)

    val engine = ChatEngine(
        repo = chatRepo,
        providers = { providers.providers() },
        router = ModelRouter(),
        memory = memory,
        documents = documents,
        tools = tools,
        agent = agent,
        consent = bridge.consentGate,
        device = { device.state.value },
        settings = { settingsStore.settings.value.engineSettings() },
        diagnostics = diagnostics,
    )

    /** "AI Activity" panel: every routing decision, retrieval, tool call and policy event. */
    private val _activity = MutableStateFlow<List<ai.astra.core.agent.ActivityItem>>(emptyList())
    val activity: StateFlow<List<ai.astra.core.agent.ActivityItem>> = _activity.asStateFlow()
    fun recordActivity(item: ai.astra.core.agent.ActivityItem) { _activity.value = (_activity.value + item).takeLast(300) }
    fun clearActivity() { _activity.value = emptyList() }

    val speechIn = SpeechInput(appContext)
    val speechOut = SpeechOutput(appContext)

    init {
        // Keep providers, policies and gates in sync with settings + installed models.
        scope.launch {
            combine(settingsStore.settings, models.models) { s, m -> s to m }.collect { (s, m) ->
                memory.policy = s.memoryPolicy()
                firewall.policy = s.firewallPolicy()
                providers.rebuild(s, m)
                providers.refreshStatus()
            }
        }
        scope.launch { device.state.collect { providers.refreshStatus() } }
        scope.launch {
            val purged = memory.purgeExpired()
            if (purged > 0) diagnostics.log("memory", "Purged $purged expired temporary memories")
        }
    }
}
