package ai.astra.app.ui.chat

import ai.astra.app.AppContainer
import ai.astra.core.agent.ActivityItem
import ai.astra.core.chat.ChatEvent
import ai.astra.core.chat.ChatRequest
import ai.astra.core.export.Exporter
import ai.astra.core.memory.ConflictResolution
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.RememberResult
import ai.astra.core.model.AssistMode
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.Feedback
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.newId
import ai.astra.core.router.DataControl
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class RouteBadge(val mode: ExecutionMode, val provider: String, val locality: Locality)

data class SlashCommand(val name: String, val hint: String)

val SLASH_COMMANDS = listOf(
    SlashCommand("/chat", "Single answer, no tools"),
    SlashCommand("/assist", "Allow low-risk tools"),
    SlashCommand("/agent", "Multi-step with permission controls"),
    SlashCommand("/remember", "Save a fact to memory"),
    SlashCommand("/forget", "Find and delete memories"),
    SlashCommand("/private", "Toggle “Never send my data online”"),
    SlashCommand("/model", "Models & endpoints"),
    SlashCommand("/memory", "Open memory"),
    SlashCommand("/file", "Import a document"),
    SlashCommand("/project", "Projects"),
    SlashCommand("/search", "Search chats, memory & documents"),
    SlashCommand("/research", "Search the web and answer with cited sources"),
    SlashCommand("/team", "Multi-agent: research | code | study | decision"),
    SlashCommand("/code", "Coding Lab"),
    SlashCommand("/camera", "Camera mode (live text & labels, ask about a frame)"),
    SlashCommand("/record", "Record & transcribe on device"),
    SlashCommand("/notifications", "Summarise recent notifications (on device)"),
    SlashCommand("/briefing", "Run the morning briefing now"),
    SlashCommand("/plugins", "Plugins"),
    SlashCommand("/knowledge", "Knowledge graph"),
    SlashCommand("/setup", "Set up models"),
    SlashCommand("/export", "Export this chat"),
    SlashCommand("/settings", "Settings"),
    SlashCommand("/new", "New chat"),
    SlashCommand("/temp", "New temporary chat (deleted when you leave)"),
)

enum class NavTarget { MODELS, MEMORY, FILES, PROJECTS, SETTINGS, SEARCH, SETUP, CAMERA, CODE, RECORDER, PLUGINS, KNOWLEDGE, AUTOMATIONS }

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(private val c: AppContainer) : ViewModel() {

    val conversations: StateFlow<List<Conversation>> = c.chatRepo.observeConversations()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val currentId = MutableStateFlow<String?>(null)

    val messages: StateFlow<List<ChatMessage>> = currentId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else c.chatRepo.observeMessages(id)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val streaming = MutableStateFlow("")
    val busy = MutableStateFlow(false)
    val runActivity = MutableStateFlow<List<ActivityItem>>(emptyList())
    val notices = MutableStateFlow<List<String>>(emptyList())
    val route = MutableStateFlow<RouteBadge?>(null)
    val failure = MutableStateFlow<ChatEvent.Failed?>(null)
    val conflict = MutableStateFlow<RememberResult.Conflict?>(null)
    val forgetCandidates = MutableStateFlow<List<MemoryRecord>?>(null)
    val mode = MutableStateFlow(c.settingsStore.settings.value.defaultMode)
    val pendingImages = MutableStateFlow<List<String>>(emptyList())
    val navRequest = MutableStateFlow<NavTarget?>(null)
    val toast = MutableStateFlow<String?>(null)
    val shareFile = MutableStateFlow<File?>(null)
    val importRequest = MutableStateFlow(false)

    /** Indicator for the top bar when idle: what would happen right now. */
    val predicted: StateFlow<ExecutionMode> = combine(c.settingsStore.settings, c.device.state, c.providers.status) { s, d, st ->
        val hasLocal = st.any { it.info.locality == Locality.ON_DEVICE }
        val hasNet = st.any { it.info.locality.usesNetwork }
        when {
            s.dataControl == DataControl.NEVER_SEND || !d.online -> ExecutionMode.LOCAL
            hasLocal && !hasNet -> ExecutionMode.LOCAL
            !hasLocal && hasNet -> ExecutionMode.ONLINE
            else -> ExecutionMode.HYBRID // router decides per message
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, ExecutionMode.LOCAL)

    /** True once any model (on-device or endpoint) is ready. */
    val hasModel: StateFlow<Boolean> = c.providers.status.map { list -> list.any { it.availability is ai.astra.core.provider.Availability.Ready } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun addImagePath(path: String) { pendingImages.value = pendingImages.value + path }

    private var job: Job? = null

    fun select(id: String?) {
        leaveTemporary()
        currentId.value = id
        route.value = null; failure.value = null; runActivity.value = emptyList(); streaming.value = ""
        viewModelScope.launch { c.currentProjectId = id?.let { c.chatRepo.conversation(it)?.projectId } }
    }

    fun newChat(projectId: String? = null, temporary: Boolean = false) {
        leaveTemporary()
        val conv = Conversation(title = if (temporary) "Temporary chat" else "New chat", projectId = projectId, temporary = temporary)
        viewModelScope.launch {
            c.chatRepo.save(conv)
            currentId.value = conv.id
            c.currentProjectId = projectId
            route.value = null; failure.value = null; runActivity.value = emptyList()
        }
    }

    private fun leaveTemporary() {
        val id = currentId.value ?: return
        val conv = conversations.value.firstOrNull { it.id == id } ?: return
        if (conv.temporary) viewModelScope.launch { c.chatRepo.delete(id) }
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() && pendingImages.value.isEmpty()) return
        if (trimmed.startsWith("/") && handleCommand(trimmed)) return
        val parts = buildList<Part> {
            if (trimmed.isNotEmpty()) add(Part.Text(trimmed))
            pendingImages.value.forEach { add(Part.Image(it)) }
        }
        pendingImages.value = emptyList()
        run(parts, persist = true, forced = null)
    }

    private fun run(parts: List<Part>, persist: Boolean, forced: String?) {
        val titleText = parts.filterIsInstance<Part.Text>().firstOrNull()?.text.orEmpty()
        val team = teamWorkflow.value
        runFlow(titleText) { convId ->
            c.engine.send(ChatRequest(convId, parts, mode.value, forcedProviderId = forced, selfReview = c.settingsStore.settings.value.selfReview,
                persistUserMessage = persist, team = team))
        }
    }

    /** Collects any engine flow (chat, research) into the screen state. */
    private fun runFlow(titleText: String, flow: (String) -> kotlinx.coroutines.flow.Flow<ChatEvent>) {
        if (busy.value) return
        job = viewModelScope.launch {
            val convId = currentId.value ?: Conversation(title = "New chat").also { c.chatRepo.save(it); currentId.value = it.id }.id
            val conv = c.chatRepo.conversation(convId)
            if (conv != null && conv.title == "New chat" && titleText.isNotBlank()) c.chatRepo.save(conv.copy(title = titleText.lines().first().take(48)))
            busy.value = true; streaming.value = ""; failure.value = null; runActivity.value = emptyList(); notices.value = emptyList()
            try {
                flow(convId).collect { e ->
                    when (e) {
                        is ChatEvent.Token -> streaming.value += e.text
                        is ChatEvent.Routed -> route.value = RouteBadge(e.mode, e.providerName, e.locality)
                        is ChatEvent.Activity -> { runActivity.value = runActivity.value + e.item; c.recordActivity(e.item) }
                        is ChatEvent.Notice -> notices.value = (notices.value + e.text).takeLast(3)
                        is ChatEvent.MemoryConflict -> conflict.value = e.conflict
                        is ChatEvent.Failed -> failure.value = e
                        is ChatEvent.Completed -> if (c.settingsStore.settings.value.autoSpeak || handsFree.value) speakThenListen(e.message.text)
                        is ChatEvent.UserSaved -> Unit
                    }
                }
            } finally {
                busy.value = false
                streaming.value = ""
                if (handsFree.value && failure.value != null) listenHandsFree()
            }
        }
    }

    // ---------- Phase 2: hands-free voice conversation ----------

    val handsFree = MutableStateFlow(false)

    fun toggleHandsFree(): Boolean {
        handsFree.value = !handsFree.value
        if (handsFree.value) listenHandsFree() else { c.speechIn.stop(); c.speechOut.stop() }
        return handsFree.value
    }

    private fun voiceTag(): String? = c.settingsStore.settings.value.voiceLanguage.ifBlank { null }

    private fun listenHandsFree() {
        if (!handsFree.value) return
        viewModelScope.launch(Dispatchers.Main) {
            c.speechIn.start(voiceTag(), onFinal = { text -> if (handsFree.value) send(text) }, onError = { err ->
                // Silence or no match: keep listening; real errors end hands-free mode.
                if (handsFree.value && err.startsWith("Didn't catch")) viewModelScope.launch(Dispatchers.Main) { kotlinx.coroutines.delay(400); listenHandsFree() }
                else { handsFree.value = false; toast.value = err }
            })
        }
    }

    private fun speakThenListen(text: String) {
        if (handsFree.value) {
            c.speechOut.onFinished = { viewModelScope.launch(Dispatchers.Main) { if (handsFree.value) listenHandsFree() } }
        } else c.speechOut.onFinished = null
        c.speechOut.speak(text)
    }

    /** Barge-in: user taps while ASTRA is speaking. */
    fun bargeIn() { c.speechOut.stop(); if (handsFree.value) listenHandsFree() }

    // ---------- Phase 3: research & team ----------

    val teamWorkflow = MutableStateFlow<ai.astra.core.agent.TeamWorkflow?>(null)

    fun research(question: String) {
        if (question.isBlank()) { toast.value = "Usage: /research <question>"; return }
        runFlow(question) { convId -> c.engine.research(convId, question) }
    }

    // ---------- Audio transcription ----------

    data class TranscriptResult(val name: String, val text: String)
    val transcript = MutableStateFlow<TranscriptResult?>(null)
    val transcribing = MutableStateFlow<String?>(null)

    fun transcribe(file: java.io.File, name: String) {
        viewModelScope.launch {
            transcribing.value = "…"
            val r = c.transcriber.transcribe(file, voiceTag()) { i, n -> transcribing.value = "$i / $n" }
            transcribing.value = null
            r.onSuccess { transcript.value = TranscriptResult(name, it) }.onFailure { toast.value = it.message }
        }
    }

    fun transcribeUri(uri: android.net.Uri) {
        viewModelScope.launch {
            val f = withContext(Dispatchers.IO) {
                runCatching {
                    val name = c.appContext.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                        if (cur.moveToFirst()) cur.getString(0) else null
                    } ?: "audio"
                    val out = java.io.File(java.io.File(c.appContext.cacheDir, "audio").apply { mkdirs() }, "${newId().take(6)}-${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                    c.appContext.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    out to name
                }.getOrNull()
            }
            if (f == null) toast.value = "Could not read the audio file" else transcribe(f.first, f.second)
        }
    }

    fun sendTranscript(t: TranscriptResult, instruction: String) {
        transcript.value = null
        send("$instruction\n\n[Transcript of ${t.name}]\n${t.text.take(12_000)}")
    }

    fun saveTranscriptAsDocument(t: TranscriptResult) {
        transcript.value = null
        viewModelScope.launch {
            runCatching { c.importer.indexBytes("Transcript — ${t.name}.txt", "text/plain", t.text.toByteArray(), c.currentProjectId) {} }
                .onSuccess { toast.value = "Saved to Files: ${it.title}" }.onFailure { toast.value = it.message }
        }
    }

    // ---------- Notifications ----------

    fun summarizeNotifications() {
        val items = ai.astra.app.notify.NotificationCollector.recent.value
        when {
            !c.settingsStore.settings.value.notificationSummaries -> { toast.value = "Turn on Notification summaries in Settings first"; return }
            items.isEmpty() -> { toast.value = "No notifications collected yet"; return }
        }
        viewModelScope.launch {
            val r = c.engine.oneShot(ai.astra.app.notify.NotificationCollector.prompt(items.takeLast(60)), 600, localOnly = true)
            val text = r.getOrElse {
                "No on-device model to summarise, so here is the list (notifications never leave the phone):\n\n" +
                    items.takeLast(40).groupBy { it.app }.entries.joinToString("\n\n") { (app, list) -> "**$app**\n" + list.joinToString("\n") { "• ${it.title}: ${it.text.take(120)}" } }
            }
            val convId = currentId.value ?: Conversation(title = "Notifications").also { c.chatRepo.save(it); currentId.value = it.id }.id
            c.chatRepo.append(ChatMessage(conversationId = convId, role = Role.ASSISTANT, parts = listOf(Part.Text(text)),
                trace = ai.astra.core.model.ExecutionTrace("astra-notifications", if (r.isSuccess) "On-device model" else "List (no model)", Locality.ON_DEVICE,
                    ExecutionMode.LOCAL, false, 0, emptyList(), listOf("notifications"), 0, 0.0, 0, listOf("Notification summary — on device only"))))
        }
    }

    fun stop() {
        c.providers.providers().forEach { it.cancel() }
        job?.cancel()
        busy.value = false
    }

    private fun lastUser(): ChatMessage? = messages.value.lastOrNull { it.role == Role.USER }

    fun regenerate(forcedProviderId: String? = null) {
        val user = lastUser() ?: return
        viewModelScope.launch {
            messages.value.filter { it.createdAt > user.createdAt }.forEach { c.chatRepo.deleteMessage(it.id) }
            run(user.parts, persist = false, forced = forcedProviderId)
        }
    }

    fun continueAnswer() = run(listOf(Part.Text("Continue from where you stopped.")), persist = true, forced = null)

    fun editAndResend(message: ChatMessage, newText: String) {
        val convId = currentId.value ?: return
        viewModelScope.launch {
            c.chatRepo.deleteAfter(convId, message.createdAt - 1)
            send(newText)
        }
    }

    /** "Fork from here": an independent conversation containing history up to this message. */
    fun branchFrom(message: ChatMessage) {
        val convId = currentId.value ?: return
        viewModelScope.launch {
            val src = c.chatRepo.conversation(convId) ?: return@launch
            val fork = Conversation(title = "${src.title} (branch)", projectId = src.projectId, parentConversationId = src.id, forkedFromMessageId = message.id)
            c.chatRepo.save(fork)
            messages.value.filter { it.createdAt <= message.createdAt }.forEach { m -> c.chatRepo.append(m.copy(id = newId(), conversationId = fork.id)) }
            select(fork.id)
            toast.value = "Branched into a new chat"
        }
    }

    fun remember(message: ChatMessage) {
        viewModelScope.launch {
            when (val r = c.memory.remember(message.text.take(2000), MemorySource.USER_EXPLICIT, projectId = c.currentProjectId)) {
                is RememberResult.Stored -> toast.value = "Saved to memory"
                is RememberResult.Duplicate -> toast.value = "Already in memory"
                is RememberResult.Conflict -> conflict.value = r
                is RememberResult.Refused -> toast.value = "Not saved: ${r.reason}"
            }
        }
    }

    fun forgetAbout(query: String) {
        viewModelScope.launch { forgetCandidates.value = c.memory.forgetCandidates(query).distinctBy { it.id } }
    }

    fun confirmForget(ids: Collection<String>) {
        viewModelScope.launch {
            ids.forEach { c.memory.forget(it) }
            forgetCandidates.value = null
            toast.value = "Forgot ${ids.size} item(s)"
        }
    }

    fun resolveConflict(resolution: ConflictResolution) {
        val cf = conflict.value ?: return
        viewModelScope.launch { c.memory.resolveConflict(cf, resolution); conflict.value = null; toast.value = "Memory updated" }
    }

    fun feedback(message: ChatMessage, f: Feedback) {
        viewModelScope.launch { c.chatRepo.setFeedback(message.id, if (message.feedback == f) Feedback.NONE else f) }
    }

    fun deleteMessage(message: ChatMessage) { viewModelScope.launch { c.chatRepo.deleteMessage(message.id) } }

    fun rename(id: String, title: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(title = title.take(80))) } } }
    fun togglePin(id: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(pinned = !it.pinned)) } } }
    fun archive(id: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(archived = true)) }; if (currentId.value == id) currentId.value = null } }
    fun delete(id: String) { viewModelScope.launch { c.chatRepo.delete(id); if (currentId.value == id) currentId.value = null } }

    fun speak(message: ChatMessage) = c.speechOut.speak(message.text)
    fun stopSpeaking() = c.speechOut.stop()

    fun exportCurrent() {
        val id = currentId.value ?: return
        viewModelScope.launch {
            val conv = c.chatRepo.conversation(id) ?: return@launch
            val md = Exporter.conversationMarkdown(conv, c.chatRepo.messages(id))
            shareFile.value = withContext(Dispatchers.IO) {
                File(c.appContext.cacheDir, "exports").apply { mkdirs() }.let { dir ->
                    File(dir, conv.title.replace(Regex("[^A-Za-z0-9 _-]"), "").ifBlank { "chat" }.take(40) + ".md").apply { writeText(md) }
                }
            }
        }
    }

    /** Copies and downsizes an image into private storage so it can be attached. */
    fun attachImage(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val resolver = c.appContext.contentResolver
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1536) sample *= 2
                    val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
                        ?: error("Unreadable image")
                    val out = File(File(c.appContext.filesDir, "attachments").apply { mkdirs() }, "${newId()}.jpg")
                    FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    out.absolutePath
                }.getOrElse { toast.value = "Could not attach image: ${it.message}"; null }
            }
            if (path != null) pendingImages.value = pendingImages.value + path
        }
    }

    fun removeImage(path: String) { pendingImages.value = pendingImages.value - path }

    /** Returns true if the text was a command handled locally. */
    private fun handleCommand(text: String): Boolean {
        val cmd = text.substringBefore(' ').lowercase()
        val arg = text.substringAfter(' ', "").trim()
        when (cmd) {
            "/chat" -> { mode.value = AssistMode.CHAT; toast.value = "Chat mode: one answer, no tools" }
            "/assist" -> { mode.value = AssistMode.ASSIST; toast.value = "Assist mode: low-risk tools allowed" }
            "/agent" -> { mode.value = AssistMode.AGENT; toast.value = "Agent mode: multi-step, every risky step asks you" }
            "/remember" -> { if (arg.isNotEmpty()) run(listOf(Part.Text("remember that $arg")), true, null) else toast.value = "Usage: /remember <fact>" }
            "/forget" -> if (arg.isNotEmpty()) forgetAbout(arg) else navRequest.value = NavTarget.MEMORY
            "/private" -> viewModelScope.launch {
                c.settingsStore.update { it.copy(dataControl = if (it.dataControl == DataControl.NEVER_SEND) DataControl.ASK_FOR_SENSITIVE else DataControl.NEVER_SEND) }
                toast.value = if (c.settingsStore.settings.value.dataControl == DataControl.NEVER_SEND) "Private mode ON — nothing leaves this phone" else "Private mode OFF — sensitive content still asks first"
            }
            "/model" -> navRequest.value = NavTarget.MODELS
            "/memory" -> navRequest.value = NavTarget.MEMORY
            "/file" -> importRequest.value = true
            "/project" -> navRequest.value = NavTarget.PROJECTS
            "/settings" -> navRequest.value = NavTarget.SETTINGS
            "/search" -> navRequest.value = NavTarget.SEARCH
            "/export" -> exportCurrent()
            "/new" -> newChat(c.currentProjectId)
            "/temp" -> newChat(c.currentProjectId, temporary = true)
            "/research", "/web" -> research(arg)
            "/team" -> {
                val first = arg.substringBefore(' ')
                val wf = ai.astra.core.agent.TeamWorkflows.byId(first)
                val task = if (wf != null) arg.substringAfter(' ', "").trim() else arg
                if (task.isBlank()) {
                    teamWorkflow.value = if (teamWorkflow.value == null) (wf ?: ai.astra.core.agent.TeamWorkflows.RESEARCH) else null
                    toast.value = teamWorkflow.value?.let { "Team mode on: ${it.name} (${it.description}). /team again to turn off." } ?: "Team mode off"
                } else {
                    val chosen = wf ?: ai.astra.core.agent.TeamWorkflows.guess(task)
                    val prev = teamWorkflow.value
                    teamWorkflow.value = chosen
                    run(listOf(Part.Text(task)), persist = true, forced = null)
                    viewModelScope.launch { kotlinx.coroutines.delay(300); teamWorkflow.value = prev }
                }
            }
            "/code" -> navRequest.value = NavTarget.CODE
            "/camera" -> navRequest.value = NavTarget.CAMERA
            "/record" -> navRequest.value = NavTarget.RECORDER
            "/notifications" -> summarizeNotifications()
            "/briefing" -> viewModelScope.launch { toast.value = "Running briefing…"; toast.value = c.automations.runBriefing().message }
            "/plugins" -> navRequest.value = NavTarget.PLUGINS
            "/knowledge" -> navRequest.value = NavTarget.KNOWLEDGE
            "/setup" -> navRequest.value = NavTarget.SETUP
            else -> return false
        }
        return true
    }
}
