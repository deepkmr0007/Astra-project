package ai.astra.app.ui.chat

import ai.astra.app.AppContainer
import ai.astra.core.agent.ActivityItem
import ai.astra.core.chat.ChatEvent
import ai.astra.core.chat.ChatRequest
import ai.astra.core.export.Exporter
import ai.astra.core.memory.ConflictResolution
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.RememberResult
import ai.astra.core.model.AssistMode
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.Feedback
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.newId
import ai.astra.core.router.DataControl
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class RouteBadge(val mode: ExecutionMode, val provider: String, val locality: Locality)

data class SlashCommand(val name: String, val hint: String)

val SLASH_COMMANDS = listOf(
    SlashCommand("/chat", "Single answer, no tools"),
    SlashCommand("/assist", "Allow low-risk tools"),
    SlashCommand("/agent", "Multi-step with permission controls"),
    SlashCommand("/remember", "Save a fact to memory"),
    SlashCommand("/forget", "Find and delete memories"),
    SlashCommand("/private", "Toggle “Never send my data online”"),
    SlashCommand("/model", "Models & endpoints"),
    SlashCommand("/memory", "Open memory"),
    SlashCommand("/file", "Import a document"),
    SlashCommand("/project", "Projects"),
    SlashCommand("/search", "Search chats, memory & documents"),
    SlashCommand("/web", "Web research"),
    SlashCommand("/code", "Coding lab"),
    SlashCommand("/export", "Export this chat"),
    SlashCommand("/settings", "Settings"),
    SlashCommand("/new", "New chat"),
    SlashCommand("/temp", "New temporary chat (deleted when you leave)"),
)

enum class NavTarget { MODELS, MEMORY, FILES, PROJECTS, SETTINGS, SEARCH }

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(private val c: AppContainer) : ViewModel() {

    val conversations: StateFlow<List<Conversation>> = c.chatRepo.observeConversations()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val currentId = MutableStateFlow<String?>(null)

    val messages: StateFlow<List<ChatMessage>> = currentId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else c.chatRepo.observeMessages(id)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val streaming = MutableStateFlow("")
    val busy = MutableStateFlow(false)
    val runActivity = MutableStateFlow<List<ActivityItem>>(emptyList())
    val notices = MutableStateFlow<List<String>>(emptyList())
    val route = MutableStateFlow<RouteBadge?>(null)
    val failure = MutableStateFlow<ChatEvent.Failed?>(null)
    val conflict = MutableStateFlow<RememberResult.Conflict?>(null)
    val forgetCandidates = MutableStateFlow<List<MemoryRecord>?>(null)
    val mode = MutableStateFlow(c.settingsStore.settings.value.defaultMode)
    val pendingImages = MutableStateFlow<List<String>>(emptyList())
    val navRequest = MutableStateFlow<NavTarget?>(null)
    val toast = MutableStateFlow<String?>(null)
    val shareFile = MutableStateFlow<File?>(null)
    val importRequest = MutableStateFlow(false)

    /** Indicator for the top bar when idle: what would happen right now. */
    val predicted: StateFlow<ExecutionMode> = combine(c.settingsStore.settings, c.device.state, c.providers.status) { s, d, st ->
        val hasLocal = st.any { it.info.locality == Locality.ON_DEVICE }
        val hasNet = st.any { it.info.locality.usesNetwork }
        when {
            s.dataControl == DataControl.NEVER_SEND || !d.online -> ExecutionMode.LOCAL
            hasLocal && !hasNet -> ExecutionMode.LOCAL
            !hasLocal && hasNet -> ExecutionMode.ONLINE
            else -> ExecutionMode.HYBRID // router decides per message
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, ExecutionMode.LOCAL)

    private var job: Job? = null

    fun select(id: String?) {
        leaveTemporary()
        currentId.value = id
        route.value = null; failure.value = null; runActivity.value = emptyList(); streaming.value = ""
        viewModelScope.launch { c.currentProjectId = id?.let { c.chatRepo.conversation(it)?.projectId } }
    }

    fun newChat(projectId: String? = null, temporary: Boolean = false) {
        leaveTemporary()
        val conv = Conversation(title = if (temporary) "Temporary chat" else "New chat", projectId = projectId, temporary = temporary)
        viewModelScope.launch {
            c.chatRepo.save(conv)
            currentId.value = conv.id
            c.currentProjectId = projectId
            route.value = null; failure.value = null; runActivity.value = emptyList()
        }
    }

    private fun leaveTemporary() {
        val id = currentId.value ?: return
        val conv = conversations.value.firstOrNull { it.id == id } ?: return
        if (conv.temporary) viewModelScope.launch { c.chatRepo.delete(id) }
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() && pendingImages.value.isEmpty()) return
        if (trimmed.startsWith("/") && handleCommand(trimmed)) return
        val parts = buildList<Part> {
            if (trimmed.isNotEmpty()) add(Part.Text(trimmed))
            pendingImages.value.forEach { add(Part.Image(it)) }
        }
        pendingImages.value = emptyList()
        run(parts, persist = true, forced = null)
    }

    private fun run(parts: List<Part>, persist: Boolean, forced: String?) {
        if (busy.value) return
        job = viewModelScope.launch {
            val convId = currentId.value ?: Conversation(title = "New chat").also { c.chatRepo.save(it); currentId.value = it.id }.id
            val conv = c.chatRepo.conversation(convId)
            if (conv != null && conv.title == "New chat") {
                val firstText = parts.filterIsInstance<Part.Text>().firstOrNull()?.text.orEmpty()
                if (firstText.isNotBlank()) c.chatRepo.save(conv.copy(title = firstText.lines().first().take(48)))
            }
            busy.value = true; streaming.value = ""; failure.value = null; runActivity.value = emptyList(); notices.value = emptyList()
            try {
                c.engine.send(ChatRequest(convId, parts, mode.value, forcedProviderId = forced, selfReview = c.settingsStore.settings.value.selfReview, persistUserMessage = persist)).collect { e ->
                    when (e) {
                        is ChatEvent.Token -> streaming.value += e.text
                        is ChatEvent.Routed -> route.value = RouteBadge(e.mode, e.providerName, e.locality)
                        is ChatEvent.Activity -> { runActivity.value = runActivity.value + e.item; c.recordActivity(e.item) }
                        is ChatEvent.Notice -> notices.value = (notices.value + e.text).takeLast(3)
                        is ChatEvent.MemoryConflict -> conflict.value = e.conflict
                        is ChatEvent.Failed -> failure.value = e
                        is ChatEvent.Completed -> if (c.settingsStore.settings.value.autoSpeak) c.speechOut.speak(e.message.text)
                        is ChatEvent.UserSaved -> Unit
                    }
                }
            } finally {
                busy.value = false
                streaming.value = ""
            }
        }
    }

    fun stop() {
        c.providers.providers().forEach { it.cancel() }
        job?.cancel()
        busy.value = false
    }

    private fun lastUser(): ChatMessage? = messages.value.lastOrNull { it.role == Role.USER }

    fun regenerate(forcedProviderId: String? = null) {
        val user = lastUser() ?: return
        viewModelScope.launch {
            messages.value.filter { it.createdAt > user.createdAt }.forEach { c.chatRepo.deleteMessage(it.id) }
            run(user.parts, persist = false, forced = forcedProviderId)
        }
    }

    fun continueAnswer() = run(listOf(Part.Text("Continue from where you stopped.")), persist = true, forced = null)

    fun editAndResend(message: ChatMessage, newText: String) {
        val convId = currentId.value ?: return
        viewModelScope.launch {
            c.chatRepo.deleteAfter(convId, message.createdAt - 1)
            send(newText)
        }
    }

    /** "Fork from here": an independent conversation containing history up to this message. */
    fun branchFrom(message: ChatMessage) {
        val convId = currentId.value ?: return
        viewModelScope.launch {
            val src = c.chatRepo.conversation(convId) ?: return@launch
            val fork = Conversation(title = "${src.title} (branch)", projectId = src.projectId, parentConversationId = src.id, forkedFromMessageId = message.id)
            c.chatRepo.save(fork)
            messages.value.filter { it.createdAt <= message.createdAt }.forEach { m -> c.chatRepo.append(m.copy(id = newId(), conversationId = fork.id)) }
            select(fork.id)
            toast.value = "Branched into a new chat"
        }
    }

    fun remember(message: ChatMessage) {
        viewModelScope.launch {
            when (val r = c.memory.remember(message.text.take(2000), MemorySource.USER_EXPLICIT, projectId = c.currentProjectId)) {
                is RememberResult.Stored -> toast.value = "Saved to memory"
                is RememberResult.Duplicate -> toast.value = "Already in memory"
                is RememberResult.Conflict -> conflict.value = r
                is RememberResult.Refused -> toast.value = "Not saved: ${r.reason}"
            }
        }
    }

    fun forgetAbout(query: String) {
        viewModelScope.launch { forgetCandidates.value = c.memory.forgetCandidates(query).distinctBy { it.id } }
    }

    fun confirmForget(ids: Collection<String>) {
        viewModelScope.launch {
            ids.forEach { c.memory.forget(it) }
            forgetCandidates.value = null
            toast.value = "Forgot ${ids.size} item(s)"
        }
    }

    fun resolveConflict(resolution: ConflictResolution) {
        val cf = conflict.value ?: return
        viewModelScope.launch { c.memory.resolveConflict(cf, resolution); conflict.value = null; toast.value = "Memory updated" }
    }

    fun feedback(message: ChatMessage, f: Feedback) {
        viewModelScope.launch { c.chatRepo.setFeedback(message.id, if (message.feedback == f) Feedback.NONE else f) }
    }

    fun deleteMessage(message: ChatMessage) { viewModelScope.launch { c.chatRepo.deleteMessage(message.id) } }

    fun rename(id: String, title: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(title = title.take(80))) } } }
    fun togglePin(id: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(pinned = !it.pinned)) } } }
    fun archive(id: String) { viewModelScope.launch { c.chatRepo.conversation(id)?.let { c.chatRepo.save(it.copy(archived = true)) }; if (currentId.value == id) currentId.value = null } }
    fun delete(id: String) { viewModelScope.launch { c.chatRepo.delete(id); if (currentId.value == id) currentId.value = null } }

    fun speak(message: ChatMessage) = c.speechOut.speak(message.text)
    fun stopSpeaking() = c.speechOut.stop()

    fun exportCurrent() {
        val id = currentId.value ?: return
        viewModelScope.launch {
            val conv = c.chatRepo.conversation(id) ?: return@launch
            val md = Exporter.conversationMarkdown(conv, c.chatRepo.messages(id))
            shareFile.value = withContext(Dispatchers.IO) {
                File(c.appContext.cacheDir, "exports").apply { mkdirs() }.let { dir ->
                    File(dir, conv.title.replace(Regex("[^A-Za-z0-9 _-]"), "").ifBlank { "chat" }.take(40) + ".md").apply { writeText(md) }
                }
            }
        }
    }

    /** Copies and downsizes an image into private storage so it can be attached. */
    fun attachImage(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val resolver = c.appContext.contentResolver
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1536) sample *= 2
                    val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
                        ?: error("Unreadable image")
                    val out = File(File(c.appContext.filesDir, "attachments").apply { mkdirs() }, "${newId()}.jpg")
                    FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    out.absolutePath
                }.getOrElse { toast.value = "Could not attach image: ${it.message}"; null }
            }
            if (path != null) pendingImages.value = pendingImages.value + path
        }
    }

    fun removeImage(path: String) { pendingImages.value = pendingImages.value - path }

    /** Returns true if the text was a command handled locally. */
    private fun handleCommand(text: String): Boolean {
        val cmd = text.substringBefore(' ').lowercase()
        val arg = text.substringAfter(' ', "").trim()
        when (cmd) {
            "/chat" -> { mode.value = AssistMode.CHAT; toast.value = "Chat mode: one answer, no tools" }
            "/assist" -> { mode.value = AssistMode.ASSIST; toast.value = "Assist mode: low-risk tools allowed" }
            "/agent" -> { mode.value = AssistMode.AGENT; toast.value = "Agent mode: multi-step, every risky step asks you" }
            "/remember" -> { if (arg.isNotEmpty()) run(listOf(Part.Text("remember that $arg")), true, null) else toast.value = "Usage: /remember <fact>" }
            "/forget" -> if (arg.isNotEmpty()) forgetAbout(arg) else navRequest.value = NavTarget.MEMORY
            "/private" -> viewModelScope.launch {
                c.settingsStore.update { it.copy(dataControl = if (it.dataControl == DataControl.NEVER_SEND) DataControl.ASK_FOR_SENSITIVE else DataControl.NEVER_SEND) }
                toast.value = if (c.settingsStore.settings.value.dataControl == DataControl.NEVER_SEND) "Private mode ON — nothing leaves this phone" else "Private mode OFF — sensitive content still asks first"
            }
            "/model" -> navRequest.value = NavTarget.MODELS
            "/memory" -> navRequest.value = NavTarget.MEMORY
            "/file" -> importRequest.value = true
            "/project" -> navRequest.value = NavTarget.PROJECTS
            "/settings" -> navRequest.value = NavTarget.SETTINGS
            "/search" -> navRequest.value = NavTarget.SEARCH
            "/export" -> exportCurrent()
            "/new" -> newChat(c.currentProjectId)
            "/temp" -> newChat(c.currentProjectId, temporary = true)
            "/web" -> toast.value = "Web research: Requires provider — arrives in Phase 3 (search tool + source trust engine)"
            "/code" -> toast.value = "Coding lab: arrives in Phase 3 (file tree, diff, approval, sandboxed runs)"
            else -> return false
        }
        return true
    }
}
