package ai.astra.app.inference

import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.plainText
import ai.astra.core.models.ModelDescriptor
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.Availability
import ai.astra.core.provider.Capability
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.GenerationStats
import ai.astra.core.provider.ProviderErrorKind
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.ProviderInfo
import ai.astra.core.provider.StreamEvent
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

enum class LoadState { NOT_LOADED, LOADING, READY, FAILED }

/**
 * On-device inference through Google's LiteRT-LM runtime (Apache-2.0). Loads a user-imported
 * .litertlm model; tries GPU first when allowed and falls back to CPU. Each request gets a fresh
 * LiteRT conversation seeded with ASTRA's own context, so ASTRA's context engine stays in control.
 */
class LiteRtLmProvider(
    private val descriptor: ModelDescriptor,
    private val modelFile: File,
    private val cacheDir: File,
    private val preferGpu: Boolean,
) : AiProvider {

    @Volatile var loadState: LoadState = LoadState.NOT_LOADED
        private set
    @Volatile var loadError: String? = null
        private set
    @Volatile var backendName: String = "—"
        private set
    @Volatile var loadMillis: Long = 0
        private set

    private var engine: Engine? = null
    private val lock = Mutex()
    @Volatile private var active: Conversation? = null

    override val info: ProviderInfo = ProviderInfo(
        id = "local:${descriptor.id}",
        displayName = descriptor.name,
        model = descriptor.name,
        locality = Locality.ON_DEVICE,
        capabilities = buildSet {
            add(Capability.CHAT); add(Capability.STREAM); add(Capability.TOOL_CALL)
            if (descriptor.supportsVision) add(Capability.VISION)
        },
        scores = descriptor.capabilities,
        runtime = "LiteRT-LM",
    )

    override suspend fun availability(): Availability = when {
        !modelFile.exists() -> Availability.NotConfigured("Model file missing — re-import it in Models")
        !descriptor.runnable -> Availability.NotConfigured("${descriptor.format.runtime}: this format needs a runtime that isn't installed")
        loadState == LoadState.FAILED -> Availability.Unavailable(loadError ?: "Model failed to load")
        else -> Availability.Ready // loads lazily on first use
    }

    suspend fun load(): Result<Unit> = withContext(Dispatchers.Default) {
        lock.withLock { ensureLoadedLocked() }
    }

    private fun ensureLoadedLocked(): Result<Unit> {
        if (engine != null) return Result.success(Unit)
        loadState = LoadState.LOADING
        val started = System.currentTimeMillis()
        val attempts = if (preferGpu) listOf<Pair<String, () -> Backend>>("GPU" to { Backend.GPU() }, "CPU" to { Backend.CPU() }) else listOf("CPU" to { Backend.CPU() })
        var last: Throwable? = null
        for ((name, backend) in attempts) {
            try {
                val config = EngineConfig(
                    modelPath = modelFile.absolutePath,
                    backend = backend(),
                    visionBackend = if (descriptor.supportsVision) backend() else null,
                    cacheDir = cacheDir.absolutePath,
                )
                val e = Engine(config)
                e.initialize()
                engine = e
                backendName = name
                loadState = LoadState.READY
                loadError = null
                loadMillis = System.currentTimeMillis() - started
                return Result.success(Unit)
            } catch (t: Throwable) {
                last = t
            }
        }
        loadState = LoadState.FAILED
        loadError = last?.message ?: last?.javaClass?.simpleName ?: "unknown error"
        return Result.failure(last ?: IllegalStateException("load failed"))
    }

    override fun stream(request: GenerationRequest): Flow<StreamEvent> = flow {
        lock.withLock {
            ensureLoadedLocked().onFailure { throw ProviderException(ProviderErrorKind.MODEL_CRASH, "Could not load ${descriptor.name}: ${it.message}", cause = it) }
            val eng = engine!!
            val system = request.turns.filter { it.role == Role.SYSTEM }.joinToString("\n\n") { it.parts.plainText() }
            val rest = request.turns.filter { it.role != Role.SYSTEM }
            val last = rest.lastOrNull() ?: throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Empty prompt")
            val history = rest.dropLast(1).map { t ->
                if (t.role == Role.ASSISTANT) Message.model(t.parts.plainText()) else Message.user(t.parts.plainText())
            }
            val config = ConversationConfig(
                systemInstruction = Contents.of(system),
                initialMessages = history,
                samplerConfig = SamplerConfig(topK = 40, topP = request.topP, temperature = request.temperature),
                maxOutputToken = request.maxOutputTokens,
            )
            val contents = buildList<Content> {
                add(Content.Text(last.parts.filter { it !is Part.Image }.plainText()))
                if (descriptor.supportsVision) last.parts.filterIsInstance<Part.Image>().forEach { add(Content.ImageFile(it.path)) }
            }
            val started = System.currentTimeMillis()
            var first = -1L
            var tokens = 0
            try {
                eng.createConversation(config).use { conv ->
                    active = conv
                    conv.sendMessageAsync(Contents.of(contents)).collect { msg ->
                        val piece = msg.toString()
                        if (piece.isNotEmpty()) {
                            if (first < 0) first = System.currentTimeMillis() - started
                            tokens++
                            emit(StreamEvent.Token(piece))
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ProviderException) {
                throw e
            } catch (t: Throwable) {
                throw ProviderException(ProviderErrorKind.MODEL_CRASH, "On-device model error: ${t.message ?: t.javaClass.simpleName}", cause = t)
            } finally {
                active = null
            }
            emit(StreamEvent.Done(GenerationStats(tokens, System.currentTimeMillis() - started, first.coerceAtLeast(0), 0, 0)))
        }
    }.flowOn(Dispatchers.Default)

    override fun cancel() {
        runCatching { active?.cancelProcess() }
    }

    override fun close() {
        runCatching { engine?.close() }
        engine = null
        loadState = LoadState.NOT_LOADED
    }
}
