package ai.astra.app.documents

import ai.astra.core.documents.DocumentIndex
import ai.astra.core.documents.DocumentMeta
import ai.astra.core.documents.ExtractedDocument
import ai.astra.core.documents.LocatorKind
import ai.astra.core.documents.OfficeExtractors
import ai.astra.core.documents.SourceUnit
import ai.astra.core.documents.TextExtractors
import ai.astra.core.models.Checksums
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

/**
 * IMPORT → EXTRACT on Android: PDF (PDFBox, real page numbers), DOCX/XLSX (core Office reader),
 * text/Markdown/CSV/JSON/HTML/code (core extractors). Then hands off to the core index.
 */
class DocumentImporter(private val context: Context, private val index: DocumentIndex) {
    @Volatile private var pdfReady = false

    companion object {
        const val MAX_BYTES = 60L * 1024 * 1024
    }

    suspend fun import(uri: Uri, projectId: String?, onProgress: (String) -> Unit): Result<DocumentMeta> = withContext(Dispatchers.IO) {
        runCatching {
            val (name, size) = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) (c.getString(0) ?: "document") to (if (c.isNull(1)) -1L else c.getLong(1)) else null
            } ?: ("document" to -1L)
            require(size <= MAX_BYTES) { "File is larger than ${MAX_BYTES / 1_048_576} MB" }
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            onProgress("Reading $name")
            val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            require(bytes.size <= MAX_BYTES) { "File is too large" }
            val sha = Checksums.sha256(ByteArrayInputStream(bytes))
            onProgress("Extracting text")
            val doc = extract(name, mime, bytes)
            require(doc.units.any { it.text.isNotBlank() }) {
                if (mime == "application/pdf") "No selectable text found — this looks like a scanned PDF. OCR arrives in Phase 2."
                else "No readable text found in $name"
            }
            onProgress("Indexing ${doc.units.size} ${doc.locator.label}(s)")
            index.index(doc, sha, projectId) { done, total -> onProgress("Embedding $done / $total passages") }
        }
    }

    fun extract(name: String, mime: String, bytes: ByteArray): ExtractedDocument = when {
        mime == "application/pdf" || name.endsWith(".pdf", true) -> pdf(name, bytes)
        OfficeExtractors.supports(name) -> OfficeExtractors.extract(name, mime, bytes)
        TextExtractors.supports(mime, name) -> TextExtractors.extract(name, mime, bytes)
        mime.startsWith("image/") -> throw IllegalArgumentException("Images are analyzed in chat with a vision-capable model (attach it there). Text OCR import arrives in Phase 2.")
        else -> throw IllegalArgumentException("Unsupported file type ($mime)")
    }

    private fun pdf(name: String, bytes: ByteArray): ExtractedDocument {
        if (!pdfReady) { PDFBoxResourceLoader.init(context.applicationContext); pdfReady = true }
        return PDDocument.load(bytes).use { doc ->
            val stripper = PDFTextStripper()
            val units = (1..doc.numberOfPages).map { page ->
                stripper.startPage = page
                stripper.endPage = page
                SourceUnit(page, stripper.getText(doc))
            }
            ExtractedDocument(name, "application/pdf", LocatorKind.PAGE, units)
        }
    }
}
