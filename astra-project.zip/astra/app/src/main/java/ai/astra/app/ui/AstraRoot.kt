@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.chat.ChatScreen
import ai.astra.app.ui.chat.ChatViewModel
import ai.astra.app.ui.chat.ConversationDrawerContent
import ai.astra.app.ui.chat.NavTarget
import ai.astra.app.ui.files.FilesScreen
import ai.astra.app.ui.memory.MemoryScreen
import ai.astra.app.ui.models.ModelsScreen
import ai.astra.app.ui.projects.ProjectsScreen
import ai.astra.app.ui.settings.SettingsScreen
import ai.astra.app.ui.tools.ToolsScreen
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

enum class Screen { CHAT, PROJECTS, MEMORY, MODELS, FILES, TOOLS, AUTOMATIONS, SETTINGS, SEARCH }

/** Content shared into ASTRA from another app. */
sealed interface SharedContent {
    data class TextIn(val text: String) : SharedContent
    data class ImageIn(val uri: Uri) : SharedContent
    data class DocumentIn(val uri: Uri) : SharedContent
}

@Composable
fun AstraRoot(c: AppContainer, shared: SharedContent?, onSharedConsumed: () -> Unit) {
    val vm: ChatViewModel = viewModel { ChatViewModel(c) }
    var screen by remember { mutableStateOf(Screen.CHAT) }
    var moreOpen by remember { mutableStateOf(false) }
    var prefill by remember { mutableStateOf<String?>(null) }
    var importStatus by remember { mutableStateOf<String?>(null) }
    var quick by remember { mutableStateOf<SharedContent?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val toastMsg by vm.toast.collectAsState()
    val pending by c.bridge.pending.collectAsState()

    fun toast(msg: String) { scope.launch { snackbar.showSnackbar(msg) } }
    LaunchedEffect(toastMsg) { toastMsg?.let { snackbar.showSnackbar(it); vm.toast.value = null } }
    LaunchedEffect(shared) { if (shared != null) { quick = shared; onSharedConsumed() } }

    fun importDocument(uri: Uri, askAfter: String? = null) {
        scope.launch {
            importStatus = context.getString(R.string.importing)
            val r = c.importer.import(uri, c.currentProjectId) { importStatus = it }
            importStatus = null
            r.onSuccess { meta ->
                toast(context.getString(R.string.imported_doc, meta.title, meta.chunkCount))
                if (askAfter != null) { prefill = "$askAfter “${meta.title}”"; screen = Screen.CHAT }
            }.onFailure { toast(context.getString(R.string.import_failed, it.message ?: "")) }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { importDocument(it) } }
    val launchImport = { importLauncher.launch(arrayOf("application/pdf", "text/*", "application/json", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream")) }

    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }

    fun navigate(t: NavTarget) {
        screen = when (t) {
            NavTarget.MODELS -> Screen.MODELS; NavTarget.MEMORY -> Screen.MEMORY; NavTarget.FILES -> Screen.FILES
            NavTarget.PROJECTS -> Screen.PROJECTS; NavTarget.SETTINGS -> Screen.SETTINGS; NavTarget.SEARCH -> Screen.SEARCH
        }
    }

    ModalNavigationDrawer(drawerState = drawer, gesturesEnabled = screen == Screen.CHAT, drawerContent = {
        ModalDrawerSheet { ConversationDrawerContent(vm) { scope.launch { drawer.close() } } }
    }) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (screen != Screen.SEARCH) NavigationBar {
                    navItem(Screen.CHAT, screen, Icons.AutoMirrored.Filled.Chat, stringResource(R.string.nav_chat)) { screen = it }
                    navItem(Screen.PROJECTS, screen, Icons.Filled.Workspaces, stringResource(R.string.nav_projects)) { screen = it }
                    navItem(Screen.MEMORY, screen, Icons.Filled.Psychology, stringResource(R.string.nav_memory)) { screen = it }
                    navItem(Screen.MODELS, screen, Icons.Filled.Memory, stringResource(R.string.nav_models)) { screen = it }
                    NavigationBarItem(
                        selected = screen in setOf(Screen.FILES, Screen.TOOLS, Screen.AUTOMATIONS, Screen.SETTINGS),
                        onClick = { moreOpen = true },
                        icon = { Icon(Icons.Filled.Widgets, null) }, label = { Text(stringResource(R.string.nav_more)) },
                    )
                }
            },
        ) { pad ->
            Box(Modifier.padding(bottom = pad.calculateBottomPadding()).fillMaxSize()) {
                when (screen) {
                    Screen.CHAT -> ChatScreen(vm, c, onOpenDrawer = { scope.launch { drawer.open() } }, onNavigate = ::navigate, onImportDocument = launchImport,
                        prefill = prefill, onPrefillConsumed = { prefill = null })
                    Screen.PROJECTS -> ProjectsScreen(c, onOpenChat = { vm.select(it); screen = Screen.CHAT }, onNewChatInProject = { vm.newChat(it); screen = Screen.CHAT }, toast = ::toast)
                    Screen.MEMORY -> MemoryScreen(c, ::toast)
                    Screen.MODELS -> ModelsScreen(c, ::toast)
                    Screen.FILES -> FilesScreen(c, importStatus, onImport = launchImport, onAsk = { title -> prefill = context.getString(R.string.ask_about_prefill, title); screen = Screen.CHAT })
                    Screen.TOOLS -> ToolsScreen(c)
                    Screen.AUTOMATIONS -> AutomationsScreen()
                    Screen.SETTINGS -> SettingsScreen(c, ::toast)
                    Screen.SEARCH -> SearchScreen(c, onBack = { screen = Screen.CHAT }, onOpenChat = { vm.select(it); screen = Screen.CHAT })
                }
                importStatus?.let { if (screen == Screen.CHAT) Text("⏳ $it", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 64.dp, start = 16.dp)) }
            }
        }
    }

    if (moreOpen) ModalBottomSheet(onDismissRequest = { moreOpen = false }) {
        Column(Modifier.padding(bottom = 32.dp)) {
            listOf(
                Triple(Screen.FILES, Icons.Filled.Folder, R.string.nav_files),
                Triple(Screen.TOOLS, Icons.Filled.Build, R.string.nav_tools),
                Triple(Screen.AUTOMATIONS, Icons.Filled.Schedule, R.string.nav_automations),
                Triple(Screen.SETTINGS, Icons.Filled.Settings, R.string.nav_settings),
            ).forEach { (s, icon, label) ->
                ListItem(headlineContent = { Text(stringResource(label)) }, leadingContent = { Icon(icon, null) },
                    modifier = Modifier.fillMaxWidth().clickable { screen = s; moreOpen = false })
            }
        }
    }

    quick?.let { q -> QuickActionsSheet(q, onDismiss = { quick = null }) { action ->
        quick = null
        screen = Screen.CHAT
        when (q) {
            is SharedContent.TextIn -> prefill = "$action\n\n${q.text.take(6000)}"
            is SharedContent.ImageIn -> { vm.attachImage(q.uri); prefill = action }
            is SharedContent.DocumentIn -> importDocument(q.uri, askAfter = action)
        }
    } }

    PendingPromptDialog(pending)
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.navItem(s: Screen, current: Screen, icon: ImageVector, label: String, onSelect: (Screen) -> Unit) {
    NavigationBarItem(selected = current == s, onClick = { onSelect(s) }, icon = { Icon(icon, null) }, label = { Text(label) })
}

@Composable
private fun AutomationsScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.nav_automations), style = MaterialTheme.typography.titleLarge)
        Text(stringResource(R.string.not_configured), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
        Text(stringResource(R.string.automations_body))
    }
}

/** Share-sheet quick actions: Explain, Summarize, Rewrite, Translate, Analyze, Extract, Ask ASTRA. */
@Composable
private fun QuickActionsSheet(content: SharedContent, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val actions = listOf(
        R.string.qa_explain, R.string.qa_summarize, R.string.qa_rewrite, R.string.qa_translate,
        R.string.qa_analyze, R.string.qa_extract, R.string.qa_ask,
    )
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.share_ask_astra), style = MaterialTheme.typography.titleMedium)
            Text(when (content) {
                is SharedContent.TextIn -> content.text.take(160)
                is SharedContent.ImageIn -> stringResource(R.string.shared_image)
                is SharedContent.DocumentIn -> stringResource(R.string.shared_document)
            }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val labels = actions.map { stringResource(it) }
            labels.forEach { label -> OutlinedButton(onClick = { onPick(label) }, modifier = Modifier.fillMaxWidth()) { Text(label) } }
        }
    }
}
