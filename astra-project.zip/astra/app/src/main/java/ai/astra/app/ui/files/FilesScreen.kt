@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.files

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun FilesScreen(c: AppContainer, importStatus: String?, onImport: () -> Unit, onAsk: (String) -> Unit) {
    val docs by remember { c.documentStore.observe() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_files)) }) },
        floatingActionButton = { FloatingActionButton(onClick = onImport) { Icon(Icons.Filled.Add, stringResource(R.string.import_document)) } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
            Text(stringResource(R.string.files_explainer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            importStatus?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (docs.isEmpty() && importStatus == null) EmptyState(stringResource(R.string.files_empty_title), stringResource(R.string.files_empty_body))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(docs, key = { it.id }) { d ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(d.title, fontWeight = FontWeight.SemiBold)
                            Text("${d.unitCount} ${d.locator.label}(s) · ${d.chunkCount} passages · ${DateFormat.getDateInstance().format(Date(d.importedAt))}" + (if (d.projectId != null) " · project" else ""),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick = { onAsk(d.title) }) { Text(stringResource(R.string.ask_about_this)) }
                                TextButton(onClick = { scope.launch { c.documents.delete(d.id) } }) { Text(stringResource(R.string.delete)) }
                            }
                        }
                    }
                }
            }
            Text(stringResource(R.string.file_workspace_phase3), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp))
        }
    }
}
