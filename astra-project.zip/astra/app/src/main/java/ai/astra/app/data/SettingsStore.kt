package ai.astra.app.data

import ai.astra.core.chat.EngineSettings
import ai.astra.core.context.AssistantProfile
import ai.astra.core.context.Personality
import ai.astra.core.context.ReplyLanguage
import ai.astra.core.device.EnergyMode
import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.memory.MemoryPolicy
import ai.astra.core.model.AssistMode
import ai.astra.core.model.Locality
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.EndpointKind
import ai.astra.core.provider.ModelCapabilities
import ai.astra.core.router.DataControl
import ai.astra.core.router.RoutePreference
import ai.astra.core.router.RouterPolicy
import ai.astra.core.security.FirewallPolicy
import ai.astra.core.security.InMemoryPermissionCenter
import ai.astra.core.security.Permission
import ai.astra.core.security.PermissionCenter
import ai.astra.core.security.PermissionState
import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "astra_settings")

/** Every user-facing knob in one immutable value. Defaults are privacy-first. */
data class AppSettings(
    val dataControl: DataControl = DataControl.ASK_FOR_SENSITIVE,
    val routePreference: RoutePreference = RoutePreference.AUTO,
    val allowLanInPrivate: Boolean = false,
    val energyMode: EnergyMode = EnergyMode.BALANCED,
    val profile: AssistantProfile = AssistantProfile(),
    val memoryEnabled: Boolean = true,
    val autoCapture: Boolean = false,
    val allowSensitiveMemory: Boolean = false,
    val defaultMode: AssistMode = AssistMode.CHAT,
    val selfReview: Boolean = false,
    val maxOutputTokens: Int = 1024,
    val temperature: Double = 0.7,
    val activeLocalModelId: String? = null,
    val useGpu: Boolean = true,
    val appLock: Boolean = false,
    val lockAfterSeconds: Int = 60,
    val autoApproveMedium: Boolean = false,
    val autoApproveHigh: Boolean = false,
    val autoSpeak: Boolean = false,
    val permissions: Map<Permission, PermissionState> = InMemoryPermissionCenter.DEFAULTS,
    val endpoints: List<EndpointConfig> = emptyList(),
    val onboardingDone: Boolean = false,
    // v2
    val searchProvider: String = "wikipedia",
    val searxngUrl: String = "",
    val authorizedFolders: List<String> = emptyList(),
    val briefingEnabled: Boolean = false,
    val briefingHour: Int = 7,
    val briefingFeeds: List<String> = DEFAULT_FEEDS,
    val notificationSummaries: Boolean = false,
    val voiceLanguage: String = "",
) {
    companion object {
        val DEFAULT_FEEDS = listOf(
            "https://www.thehindu.com/news/national/feeder/default.rss",
            "https://feeds.bbci.co.uk/news/world/asia/india/rss.xml",
        )
    }

    fun engineSettings() = EngineSettings(
        routerPolicy = RouterPolicy(dataControl, routePreference, energyMode, allowLanInPrivate),
        profile = profile, maxOutputTokens = maxOutputTokens, temperature = temperature,
        allowNetworkTools = dataControl != DataControl.NEVER_SEND,
    )

    fun memoryPolicy() = MemoryPolicy(enabled = memoryEnabled, autoCapture = autoCapture, allowSensitive = allowSensitiveMemory)
    fun firewallPolicy() = FirewallPolicy(autoApproveMedium, autoApproveHigh)
}

class SettingsStore(private val context: Context, private val scope: CoroutineScope) {
    private val KEY = stringPreferencesKey("settings_json")

    val settings: StateFlow<AppSettings> = context.dataStore.data
        .map { prefs -> prefs[KEY]?.let { decode(it) } ?: AppSettings() }
        .stateIn(scope, SharingStarted.Eagerly, AppSettings())

    /** Reads the persisted settings directly (used at cold start, before the StateFlow has loaded). */
    suspend fun current(): AppSettings = context.dataStore.data.first()[KEY]?.let { decode(it) } ?: AppSettings()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY]?.let { decode(it) } ?: AppSettings()
            prefs[KEY] = encode(transform(current))
        }
    }

    /** Permission Center backed by settings; reads are synchronous from the latest snapshot. */
    val permissionCenter: PermissionCenter = object : PermissionCenter {
        override fun state(p: Permission) = settings.value.permissions[p] ?: PermissionState.ASK
        override fun set(p: Permission, state: PermissionState) {
            scope.launch { update { it.copy(permissions = it.permissions + (p to state)) } }
        }
    }

    fun exportable(s: AppSettings): Map<String, Any?> = mapOf(
        "dataControl" to s.dataControl, "routePreference" to s.routePreference, "energyMode" to s.energyMode,
        "personality" to s.profile.personality, "language" to s.profile.language, "units" to s.profile.units,
        "memoryEnabled" to s.memoryEnabled, "autoCapture" to s.autoCapture, "defaultMode" to s.defaultMode,
        "endpoints" to s.endpoints.map { mapOf("name" to it.displayName, "kind" to it.kind, "baseUrl" to it.baseUrl, "model" to it.model, "locality" to it.locality) },
    )

    companion object {
        private inline fun <reified E : Enum<E>> enumOr(v: String?, d: E): E = v?.let { s -> runCatching { enumValueOf<E>(s) }.getOrNull() } ?: d

        fun encode(s: AppSettings): String = Json.write(jsonObj(
            "dataControl" to s.dataControl, "routePreference" to s.routePreference, "allowLanInPrivate" to s.allowLanInPrivate,
            "energyMode" to s.energyMode, "userName" to s.profile.userName, "personality" to s.profile.personality,
            "language" to s.profile.language, "technicalLevel" to s.profile.technicalLevel, "units" to s.profile.units,
            "writingStyle" to s.profile.writingStyle, "customInstructions" to s.profile.customInstructions,
            "memoryEnabled" to s.memoryEnabled, "autoCapture" to s.autoCapture, "allowSensitiveMemory" to s.allowSensitiveMemory,
            "defaultMode" to s.defaultMode, "selfReview" to s.selfReview, "maxOutputTokens" to s.maxOutputTokens,
            "temperature" to s.temperature, "activeLocalModelId" to s.activeLocalModelId, "useGpu" to s.useGpu,
            "appLock" to s.appLock, "lockAfterSeconds" to s.lockAfterSeconds, "autoApproveMedium" to s.autoApproveMedium,
            "autoApproveHigh" to s.autoApproveHigh, "autoSpeak" to s.autoSpeak, "onboardingDone" to s.onboardingDone,
            "searchProvider" to s.searchProvider, "searxngUrl" to s.searxngUrl, "authorizedFolders" to s.authorizedFolders,
            "briefingEnabled" to s.briefingEnabled, "briefingHour" to s.briefingHour, "briefingFeeds" to s.briefingFeeds,
            "notificationSummaries" to s.notificationSummaries, "voiceLanguage" to s.voiceLanguage,
            "permissions" to s.permissions.mapKeys { it.key.name },
            "endpoints" to jsonArr(s.endpoints.map { e ->
                jsonObj("id" to e.id, "name" to e.displayName, "kind" to e.kind, "baseUrl" to e.baseUrl, "model" to e.model,
                    "locality" to e.locality, "embeddingModel" to e.embeddingModel, "vision" to e.vision,
                    "reasoning" to e.scores.reasoning, "coding" to e.scores.coding, "context" to e.scores.contextWindow)
            }),
        ))

        fun decode(text: String): AppSettings {
            val o = runCatching { Json.parse(text).obj() }.getOrNull() ?: return AppSettings()
            val d = AppSettings()
            val perms = o["permissions"].obj()?.fields?.mapNotNull { (k, v) ->
                val p = runCatching { Permission.valueOf(k) }.getOrNull() ?: return@mapNotNull null
                p to enumOr(v.str(), PermissionState.ASK)
            }?.toMap().orEmpty()
            return AppSettings(
                dataControl = enumOr(o["dataControl"].str(), d.dataControl),
                routePreference = enumOr(o["routePreference"].str(), d.routePreference),
                allowLanInPrivate = o["allowLanInPrivate"].bool() ?: d.allowLanInPrivate,
                energyMode = enumOr(o["energyMode"].str(), d.energyMode),
                profile = AssistantProfile(
                    userName = o["userName"].str() ?: "",
                    personality = enumOr(o["personality"].str(), Personality.FRIENDLY),
                    language = enumOr(o["language"].str(), ReplyLanguage.AUTO),
                    technicalLevel = o["technicalLevel"].str() ?: "",
                    units = o["units"].str() ?: "metric",
                    writingStyle = o["writingStyle"].str() ?: "",
                    customInstructions = o["customInstructions"].str() ?: "",
                ),
                memoryEnabled = o["memoryEnabled"].bool() ?: d.memoryEnabled,
                autoCapture = o["autoCapture"].bool() ?: d.autoCapture,
                allowSensitiveMemory = o["allowSensitiveMemory"].bool() ?: d.allowSensitiveMemory,
                defaultMode = enumOr(o["defaultMode"].str(), d.defaultMode),
                selfReview = o["selfReview"].bool() ?: d.selfReview,
                maxOutputTokens = o["maxOutputTokens"].int() ?: d.maxOutputTokens,
                temperature = (o["temperature"] as? ai.astra.core.json.JsonValue.Num)?.value ?: d.temperature,
                activeLocalModelId = o["activeLocalModelId"].str(),
                useGpu = o["useGpu"].bool() ?: d.useGpu,
                appLock = o["appLock"].bool() ?: d.appLock,
                lockAfterSeconds = o["lockAfterSeconds"].int() ?: d.lockAfterSeconds,
                autoApproveMedium = o["autoApproveMedium"].bool() ?: false,
                autoApproveHigh = o["autoApproveHigh"].bool() ?: false,
                autoSpeak = o["autoSpeak"].bool() ?: false,
                permissions = InMemoryPermissionCenter.DEFAULTS + perms,
                endpoints = o["endpoints"].arr().mapNotNull { v ->
                    val e = v.obj() ?: return@mapNotNull null
                    EndpointConfig(
                        id = e["id"].str() ?: return@mapNotNull null,
                        displayName = e["name"].str() ?: "Endpoint",
                        kind = enumOr(e["kind"].str(), EndpointKind.OPENAI_COMPATIBLE),
                        baseUrl = e["baseUrl"].str() ?: "",
                        model = e["model"].str() ?: "",
                        locality = enumOr(e["locality"].str(), Locality.REMOTE),
                        embeddingModel = e["embeddingModel"].str(),
                        vision = e["vision"].bool() ?: false,
                        scores = ModelCapabilities(reasoning = e["reasoning"].int() ?: 8, coding = e["coding"].int() ?: 8, multilingual = 8, speed = 6, contextWindow = e["context"].int() ?: 128_000),
                    )
                },
                onboardingDone = o["onboardingDone"].bool() ?: false,
                searchProvider = o["searchProvider"].str() ?: d.searchProvider,
                searxngUrl = o["searxngUrl"].str() ?: "",
                authorizedFolders = o["authorizedFolders"].arr().mapNotNull { it.str() },
                briefingEnabled = o["briefingEnabled"].bool() ?: false,
                briefingHour = o["briefingHour"].int() ?: 7,
                briefingFeeds = o["briefingFeeds"]?.arr()?.mapNotNull { it.str() } ?: d.briefingFeeds,
                notificationSummaries = o["notificationSummaries"].bool() ?: false,
                voiceLanguage = o["voiceLanguage"].str() ?: "",
            )
        }
    }
}
