# Security

## Model

| Priority | Implementation |
|---|---|
| Local data encryption | App sandbox + Android file-based encryption at rest. **Not yet:** app-level database encryption (SQLCipher) — planned with the Vault work in Phase 4. |
| Secure key storage | `KeystoreCipher`: AES-256-GCM, non-exportable key in Android Keystore (StrongBox when available, otherwise TEE). API keys and download tokens are stored only in encrypted form (`SecretStore`). |
| Least privilege | Manifest requests only INTERNET, ACCESS_NETWORK_STATE, RECORD_AUDIO (runtime-requested on first mic tap). Camera uses the system camera app via intent — no CAMERA permission. Photo picker needs no storage permission. Documents via the Storage Access Framework. |
| Explicit permissions | Permission Center (Allowed / Denied / Ask every time) per category, enforced by the tool firewall on top of Android permissions. |
| Sandboxed tools | Built-in tools are pure in-process functions. Code execution is not shipped; when it is, it runs in an isolated sandbox with CPU/memory/time/network limits. |
| Secure networking | TLS required for every public host (`UrlConnectionTransport` refuses `http://` unless the host is loopback/private-LAN). Platform certificate validation only; no custom TrustManager; user-added CAs are not trusted (`network_security_config.xml`). Timeouts, bounded retries with `Retry-After`, rate-limit mapping. |
| Secure updates | Distributed as an APK you build yourself from source; Play/App Signing when published. |
| Dependency scanning | Enable GitHub Dependabot on the repository (recommended). |
| Audit logging | `RingAuditLog` records every firewall decision with redacted arguments; viewable and clearable in Tools. |

## AI safety firewall

`AI request → policy (mode limits, allowed tools) → permission check → risk classification → user confirmation if required → tool → result (fenced as untrusted) → AI`

- LOW runs automatically (if permissions allow). MEDIUM/HIGH ask unless you opt in to auto-approval. **CRITICAL always asks and requires typing CONFIRM.**
- Chat mode runs no tools; Assist runs only LOW-risk tools; Agent runs multi-step with limits (steps, time, tokens).
- Network tools are blocked unless allowed for the request.

## Prompt injection

- Documents, web pages and tool output are wrapped in `<<UNTRUSTED …>>` fences and **never** placed in the system role. The system prompt instructs the model to treat them as data.
- `PromptInjectionDetector` scores override attempts, role reassignment, fake system tags, exfiltration requests, tool hijacking, fence escapes and hidden characters (English + Hindi patterns). High-risk passages are withheld from the prompt and reported; medium-risk ones are labelled.
- Fence markers and tool-call syntax inside untrusted content are neutralised.

## Logging rules

`Redactor` runs on every diagnostics and audit write: bearer tokens, API-key headers, `sk-…`/`AIza…`/`ghp_…`-style keys, long tokens, Aadhaar/PAN/card numbers, phone numbers and emails are masked. Conversations are never written to diagnostics.

## Reporting

Open a private security advisory on the repository.
