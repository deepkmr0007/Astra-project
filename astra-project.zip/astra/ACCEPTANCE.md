# Master acceptance test (Section 73) — status

“Engine test” = automated test in `core/src/test/.../AcceptanceTests.kt` (`MasterAcceptanceTest` unless noted). “On device” = manual step in the app once the APK is built.

| Step | What to do on the phone | Engine coverage |
|---|---|---|
| A. Turn off internet | Airplane mode | `a_to_d_offlineQuestionAnsweredLocally` |
| B. Start ASTRA | Open app (badge shows LOCAL) | — |
| C. Ask a question | Type in chat | ✓ |
| D. Answer from local model | Tap ⓘ: *On device · Network: not used* | ✓ asserts locality + no network |
| E. Save a memory | “remember that my dhani is in Mandhan tehsil” | `e_to_g_memorySurvivesRestartAndIsUsed` (handled with no model) |
| F. Restart application | Swipe away, reopen | ✓ new engine over same store |
| G. Retrieve that memory | Ask “where is my dhani?” | ✓ memory present in prompt |
| H. Import a PDF | Files → + | `h_i_documentQuestionIsGroundedWithCitation` (index + citation); PDF parsing on device |
| I. Ask about the PDF | Ask; trace shows sources, Activity shows “page N” | ✓ |
| J. Analyze an image | Attach a photo or use Camera mode. Gemma 4 sees the image directly; text-only models get on-device OCR + labels | `j_imageNeedsVisionModel`, `VisionFallbackTest` |
| K. Voice input | Tap mic, or hands-free from the + menu; Record & transcribe for meetings | On device only; WAV chunking in `wavSplitKeepsAllAudio` |
| L. Voice output | Tap 🔊 on an answer | On device only |
| M. Re-enable internet | Turn off airplane mode | — |
| N. Switch to online provider | Setup → online preset → Fetch models | `m_to_o_onlineProviderAndComparison`, `listModelsParsesBothShapes` |
| O. Compare local vs online | Long-press answer → Retry with another model; compare traces | ✓ forced local vs online traces |
| P. Execute a safe tool | `/assist`, ask “what is 18% of 2500?” | `p_safeToolRuns`, `AgentTest.calculatorLoopAndVisibleStream` |
| Q. Create a project | Projects → + | `q_s_projectScopeAndExport` (project instructions reach prompt) |
| R. Multi-step task | Project → Add task → Break down with AI | `TaskTest` (graph + parsing) |
| S. Export conversation/memory | Chat ⋮ → Export; Memory ⋮ → Export | `q_s_projectScopeAndExport` (astra-export JSON) |
| T. Delete selected memory | Memory → 🗑 | `t_u_deletedMemoryNeverReachesThePrompt` |
| U. Deleted memory not retrieved | Ask again | ✓ asserted absent from prompt; `MemoryEngineTest.deletedMemoryIsNoLongerRetrieved` |
| V. Private mode prevents network | Settings → Never send; Diagnostics shows gate counters | `v_privateModePreventsAnyNetworkTransmission` (transport receives 0 requests), `RemoteProviderTest.privateModeGateAndTlsEnforcement` |

Additional engine tests: consent declined keeps data local, network loss recovers on device, local model crash is reported (never fabricated), prompt-injection passages withheld, step limits stop runaway agents, firewall blocks high-risk tools in Assist mode.

## v0.2 checks on the phone

| Feature | How to check | Engine coverage |
|---|---|---|
| One-tap model | Setup → Download recommended → notification → chat works in airplane mode | `CatalogAndPresetTest` |
| No-model answers | Before downloading, type “18% of 2500” or “hello astra” | `DirectResponderTest` |
| Web research | `/research latest MSP for bajra` → cited answer, Sources list, trace says HYBRID | `WebTest.*` |
| Team | `/team study plan for UPSC EPFO APFC` → Activity shows each stage; trace shows the Verifier result | `TeamTest` |
| Coding Lab | More → Coding Lab → new `main.js` → “add a function that sums an array” → review diff → approve → Run | `CodeTest` |
| Scanned PDF | Import a scanned PDF → ask about page 2 | (ML Kit on device) |
| Encrypted backup | Settings → Back up now → uninstall/reinstall → Restore / merge | `encryptedBundleRoundTripAndWrongPassword`, `lwwMergeAndBundleRestore` |
| Plugins | Plugins → Install example → enable → Agent mode: “use wiki_summary for Jaipur” | `httpPluginValidatesAndRuns` |
| Knowledge graph | Save a few memories → More → Knowledge graph | `graphLinksPeoplePlacesProjects` |
