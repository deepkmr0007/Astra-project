# Master acceptance test (Section 73) — status

“Engine test” = automated test in `core/src/test/.../AcceptanceTests.kt` (`MasterAcceptanceTest` unless noted). “On device” = manual step in the app once the APK is built.

| Step | What to do on the phone | Engine coverage |
|---|---|---|
| A. Turn off internet | Airplane mode | `a_to_d_offlineQuestionAnsweredLocally` |
| B. Start ASTRA | Open app (badge shows LOCAL) | — |
| C. Ask a question | Type in chat | ✓ |
| D. Answer from local model | Tap ⓘ: *On device · Network: not used* | ✓ asserts locality + no network |
| E. Save a memory | “remember that my dhani is in Mandhan tehsil” | `e_to_g_memorySurvivesRestartAndIsUsed` (handled with no model) |
| F. Restart application | Swipe away, reopen | ✓ new engine over same store |
| G. Retrieve that memory | Ask “where is my dhani?” | ✓ memory present in prompt |
| H. Import a PDF | Files → + | `h_i_documentQuestionIsGroundedWithCitation` (index + citation); PDF parsing on device |
| I. Ask about the PDF | Ask; trace shows sources, Activity shows “page N” | ✓ |
| J. Analyze an image | Attach photo; needs a vision-capable model | `j_imageNeedsVisionModel` (refuses honestly without one) |
| K. Voice input | Tap mic | On device only |
| L. Voice output | Tap 🔊 on an answer | On device only |
| M. Re-enable internet | Turn off airplane mode | — |
| N. Switch to online provider | Add endpoint in Models | `m_to_o_onlineProviderAndComparison` |
| O. Compare local vs online | Long-press answer → Retry with another model; compare traces | ✓ forced local vs online traces |
| P. Execute a safe tool | `/assist`, ask “what is 18% of 2500?” | `p_safeToolRuns`, `AgentTest.calculatorLoopAndVisibleStream` |
| Q. Create a project | Projects → + | `q_s_projectScopeAndExport` (project instructions reach prompt) |
| R. Multi-step task | Project → Add task → Break down with AI | `TaskTest` (graph + parsing) |
| S. Export conversation/memory | Chat ⋮ → Export; Memory ⋮ → Export | `q_s_projectScopeAndExport` (astra-export JSON) |
| T. Delete selected memory | Memory → 🗑 | `t_u_deletedMemoryNeverReachesThePrompt` |
| U. Deleted memory not retrieved | Ask again | ✓ asserted absent from prompt; `MemoryEngineTest.deletedMemoryIsNoLongerRetrieved` |
| V. Private mode prevents network | Settings → Never send; Diagnostics shows gate counters | `v_privateModePreventsAnyNetworkTransmission` (transport receives 0 requests), `RemoteProviderTest.privateModeGateAndTlsEnforcement` |

Additional engine tests: consent declined keeps data local, network loss recovers on device, local model crash is reported (never fabricated), prompt-injection passages withheld, step limits stop runaway agents, firewall blocks high-risk tools in Assist mode.
