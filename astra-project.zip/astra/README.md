# ASTRA — Personal AI

**My own AI that lives on my phone.** Local-first, offline-capable, online-enhanced only when you allow it, and transparent about every answer: which model, where it ran, what was sent, which tools were used.

> Status: **Phase 1 foundation + parts of Phases 2–4.** The engine (`:core`) is built and tested (55 automated tests, including an engine-level version of the master acceptance test). The Android app (`:app`) is written against current library APIs but was **not compiled in the authoring environment** (no Android SDK there) — the GitHub workflow below is its first real compile. See [Honest status](#honest-status).

## What works

| Area | What you get |
|---|---|
| Chat | Streaming answers, stop, regenerate, continue, edit & resend, fork-from-here, retry with another model, 👍/👎, export to Markdown, temporary chats, pin/rename/archive/search |
| Local AI | On-device models through **LiteRT-LM** (`.litertlm`, e.g. Gemma 3 / 3n builds). GPU first, CPU fallback. Import from storage or download with size/source/license shown first, pause/resume, SHA-256 check |
| Online / LAN | Any **OpenAI-compatible** endpoint (OpenAI, OpenRouter, Groq, Ollama, llama.cpp server, LM Studio, vLLM) and the **Anthropic** Messages API. Keys in a hardware-backed vault |
| Router | LOCAL / ONLINE / HYBRID per message from connectivity, privacy, task, complexity, context size, battery, heat, capability scores and your preference — with the reasons shown |
| Privacy | Detects Aadhaar (Verhoeff-checked), PAN, cards (Luhn-checked), IFSC, keys, passwords, phone, email, health/finance terms. “Never send my data online” blocks every network request at the transport layer. Consent dialog shows exactly what would be sent |
| Memory | Explicit “remember that…” / “याद रखना कि…”, refuses sensitive data unless enabled, de-duplication, contradictions shown (never silently overwritten), project scoping, temporary memories that expire, consolidation proposals, edit/pin/delete/export/import, clear all |
| Documents | PDF (real page numbers), DOCX, XLSX, CSV, TXT, Markdown, HTML, JSON, code → chunked, embedded and indexed on the phone; answers cite “Report.pdf, page 17” |
| Tools & agents | Calculator, unit converter (incl. acre/hectare/quintal), date math, memory search, document search. Chat / Assist / Agent modes with step, time and token limits |
| Safety | Firewall: policy → permission → risk (LOW…CRITICAL) → your confirmation. CRITICAL needs typed CONFIRM. Prompt-injection detection; documents/web/tool output fenced as untrusted data. Audit log |
| Voice | Push-to-talk speech-to-text (on-device recognizer when the phone has one), read-aloud, barge-in |
| Vision | Attach or shoot a photo; routed to a vision-capable model only |
| Projects & tasks | Projects with their own instructions, privacy and context boundary; tasks with dependencies, progress and “break down with AI” |
| Everything else | Global search, Permission Center, AI Activity panel, diagnostics (export/clear), model benchmark, energy modes, thermal throttling, app lock, share-sheet quick actions, “/” command bar, English + Hindi UI |

## Get the APK on your phone (no computer needed)

1. Create a free GitHub account and a new repository (private is fine).
2. **Add file → Upload files** → upload `astra-project.zip` (as-is, don't unzip).
3. **Add file → Create new file** → name it `.github/workflows/build-from-zip.yml` → paste the contents of `tools/build-from-zip.yml` (also sent alongside the zip) → **Commit**.
4. Open **Actions** — “Build ASTRA (from zip)” runs (~10–15 min). When it's green, open **Releases** → newest *ASTRA build* → download the `.apk` → install (allow “install unknown apps”).

If a step fails, open it, copy the red error lines, and bring them back — fixes are usually small.

**On a computer:** open the folder in Android Studio (latest stable), let it sync, press Run. Or `./gradlew :app:assembleDebug`.

## First run

1. **Models →** *Import model file* (a `.litertlm` you downloaded) or *Download model* (paste an https link; Gemma models need you to accept Google's license on Hugging Face and paste an access token).
2. Optional: **Models → Add endpoint** for an online API or your PC (e.g. Ollama at `http://192.168.1.20:11434`, locality “LAN”, model `gemma3:4b`).
3. Chat. Tap the **LOCAL/ONLINE/HYBRID** badge for AI Activity, and the ⓘ under any answer for its full trace.

## Repository layout

```
core/   Pure Kotlin engine — no Android. Providers, router, privacy, memory, context, firewall,
        tools, agent loop, documents, export, tasks, plugins, diagnostics. Fully unit-tested.
app/    Android app — Compose UI, Room, DataStore, Keystore vault, LiteRT-LM provider,
        PDF/Office import, voice, device health, share sheet.
```

Docs: [ARCHITECTURE](ARCHITECTURE.md) · [SECURITY](SECURITY.md) · [PRIVACY](PRIVACY.md) · [MODEL_SUPPORT](MODEL_SUPPORT.md) · [PLUGIN_API](PLUGIN_API.md) · [CONTRIBUTING](CONTRIBUTING.md) · [THIRD_PARTY_LICENSES](THIRD_PARTY_LICENSES.md) · [ACCEPTANCE](ACCEPTANCE.md)

## Honest status

- **Verified:** `:core` compiles and all 55 tests pass (JSON, calculator, privacy validators, injection detection, router decisions, memory lifecycle incl. delete-then-not-retrieved, document citations, context budgeting and fencing, OpenAI/Anthropic streaming parsers, firewall, agent limits, offline answering, private mode never touching the network, consent decline, network-loss recovery, local-crash reporting, export).
- **Not yet verified:** the Android module has not been compiled or run on a device. Library versions mirror Google's *Now in Android* sample (AGP 9.3.2, Kotlin 2.3.0, Compose BOM 2025.09.01). LiteRT-LM is pulled as `latest.release`, as Google's docs recommend.
- **Not built yet (clearly marked “Not configured” / “Requires provider” in the app):** web search & research pipeline, coding lab, file workspace, automations, sync, knowledge graph, wake word, real-time camera mode, OCR of scanned PDFs, database-level encryption, plugin loading (manifest validation exists).
- ASTRA does not reproduce any proprietary model or internals. It runs open-weight models you choose and talks to APIs you configure.
