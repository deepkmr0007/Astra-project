# ASTRA — Personal AI

**My own AI that lives on my phone.** Local-first, offline-capable, online-enhanced only when you allow it, and transparent about every answer: which model, where it ran, what was sent, which tools were used.

> Status: **v0.2 — Phases 1–5 implemented.** The engine (`:core`) has 79 passing automated tests, including an engine-level version of the master acceptance test. v0.1 compiled and installed from GitHub Actions; v0.2's new Android code is written against the same library APIs but its first compile is again the GitHub build. See [Honest status](#honest-status).

## New in v0.2

- **One-tap setup.** A Setup screen recommends a model for your phone and downloads it from Hugging Face with no account or token: **Gemma 4 E2B** (2.6 GB · text, photos, audio · Hindi), Gemma 4 E4B, Qwen3.5 0.8B, Qwen3 0.6B. All Apache-2.0, pinned to exact versions and SHA-256 verified. Downloads run through Android's download manager (screen off is fine, resumes after drops), then the model is activated and loaded automatically.
- **Online presets** with “Fetch models”: Google Gemini (free tier), Anthropic, OpenAI, Groq, OpenRouter, Ollama / LM Studio on your Wi-Fi.
- **Useful with no model**: calculations, unit conversion, date/time, memory recall and document search answer directly, clearly labelled as tool results.
- **Phase 2**: on-device OCR (English + Hindi) for photos and scanned PDFs; a text-only model can answer about photos through on-device OCR and labels; Camera mode with live recognition at 0.5/1/2 fps; hands-free voice conversation with barge-in; record & transcribe meetings on the phone (Gemma 4 audio, 30-second chunks).
- **Phase 3**: `/research` web research (Wikipedia, DuckDuckGo, Brave, SearXNG or Tavily) → read pages → trust scoring → cross-check → cited answer (HYBRID: web online, writing on-device); saved web pages; folder workspace tools; **Coding Lab** with diff → approve → apply and a sandboxed JavaScript runner; `/team` multi-agent workflows (Researcher → Analyst → Critic → Writer → Verifier, and code / study / decision).
- **Phase 4**: SQLCipher-encrypted database; morning-briefing automation from RSS; declarative HTTPS plugins; encrypted backup & merge-restore (sync through any folder, e.g. Drive); knowledge graph; opt-in on-device notification summaries.
- Reasoning tags (`<think>…</think>`) are hidden; a verification summary is shown instead.

## Install / update

**Updating from v0.1: uninstall the old ASTRA once first.** v0.1 was signed with a random key, so Android won't install over it. From v0.2 on every build uses the same key (`app/astra-personal.keystore`), so future versions install as normal updates and keep your data.

Phone-only build (same as before):
1. In your GitHub repository, **Add file → Upload files** → upload the new `astra-project.zip` **with exactly that name**, so it replaces the old one.
2. The workflow `.github/workflows/build-from-zip.yml` you already have runs by itself (~15 min). If you're starting fresh, create it from `tools/build-from-zip.yml`.
3. **Releases** → newest *ASTRA build* → download the `.apk` → install.

On a computer: open in Android Studio and Run, or `./gradlew :app:assembleDebug`.

## First run

1. ASTRA opens **Setup**. Tap **Download** on the recommended model (Wi-Fi recommended for 2.6 GB). When it finishes you get a notification and the model is loaded.
2. Or pick an online preset (e.g. Gemini → “Get an API key” → paste → Fetch models → Save).
3. Chat. The badge shows LOCAL / ONLINE / HYBRID (or SET UP if nothing is ready). Tap ⓘ under any answer for its full trace. Type `/` for all commands.

## Repository layout

```
core/   Pure Kotlin engine — no Android. Providers, router, privacy, memory, context, firewall, tools,
        agent + team loops, documents, web research + source trust, code diff, RSS, plugins,
        encrypted sync, knowledge graph, WAV tools, model catalog. 79 unit tests.
app/    Android app — Compose UI, SQLCipher Room DB, DataStore, Keystore vault, LiteRT-LM provider,
        DownloadManager, ML Kit OCR/labels, CameraX, voice + recorder, SAF workspace, JS sandbox,
        WorkManager automations, notification listener, share sheet.
```

Docs: [ARCHITECTURE](ARCHITECTURE.md) · [SECURITY](SECURITY.md) · [PRIVACY](PRIVACY.md) · [MODEL_SUPPORT](MODEL_SUPPORT.md) · [PLUGIN_API](PLUGIN_API.md) · [CONTRIBUTING](CONTRIBUTING.md) · [THIRD_PARTY_LICENSES](THIRD_PARTY_LICENSES.md) · [ACCEPTANCE](ACCEPTANCE.md)

## Honest status

- **Verified here:** `:core` compiles; 79 tests pass — everything listed for v0.1 plus the model catalog and recommendation, endpoint URL rules and model listing, hidden reasoning, no-model direct answers, photo→OCR fallback with injection fencing, web search parsing, safe page fetching (redirects, private-address refusal), source trust and conflict detection, cited research with fake-citation removal, HYBRID research in private and consent modes, lossless line diff, team workflows, RSS/Atom, encrypted backups (wrong passphrase rejected), last-writer-wins merge, full export round-trip, WAV splitting, knowledge-graph extraction, and plugin validation and execution.
- **Verified on GitHub:** v0.1's Android code compiled and installed. v0.2's Android code was syntax-checked here and every call into the engine was checked against its real signature, but Android/Compose libraries can't be compiled here, so the GitHub build is its first full compile.
- **Not on device yet:** none of the v0.2 screens have been run on a phone.
- **Honest limits:** speech-to-text uses Android's recognizer (offline if the phone has the language pack); in-app transcription needs an audio-capable model such as Gemma 4. JavaScript is the only language the Coding Lab executes. Plugins are HTTPS actions only (no third-party code). Custom sync servers and wake word are not built; they are marked “Not configured”. Memory and document search use a lexical, fully offline embedder; neural embeddings are supported in the engine but not switched on in the app yet.
- ASTRA does not reproduce any proprietary model or internals. It runs open-weight models you choose and talks to APIs you configure.
