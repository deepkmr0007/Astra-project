package ai.astra.core.json

/**
 * Minimal, dependency-free JSON model, writer and parser.
 *
 * ASTRA keeps its export/import format, provider wire formats and tool-call protocol on plain
 * JSON so that nothing is locked into a proprietary serialization library. The parser is strict
 * (RFC 8259) and rejects trailing garbage.
 */
sealed interface JsonValue {
    data object Null : JsonValue
    data class Bool(val value: Boolean) : JsonValue
    data class Num(val value: Double) : JsonValue
    data class Str(val value: String) : JsonValue
    data class Arr(val items: List<JsonValue>) : JsonValue
    data class Obj(val fields: Map<String, JsonValue>) : JsonValue {
        operator fun get(key: String): JsonValue? = fields[key]
    }
}

class JsonParseException(message: String, val position: Int) : RuntimeException("$message at $position")

// ---------- convenience accessors ----------

fun JsonValue?.str(): String? = (this as? JsonValue.Str)?.value
fun JsonValue?.num(): Double? = (this as? JsonValue.Num)?.value
fun JsonValue?.int(): Int? = num()?.toInt()
fun JsonValue?.long(): Long? = num()?.toLong()
fun JsonValue?.bool(): Boolean? = (this as? JsonValue.Bool)?.value
fun JsonValue?.obj(): JsonValue.Obj? = this as? JsonValue.Obj
fun JsonValue?.arr(): List<JsonValue> = (this as? JsonValue.Arr)?.items ?: emptyList()

// ---------- builders ----------

fun jsonObj(vararg pairs: Pair<String, Any?>): JsonValue.Obj =
    JsonValue.Obj(LinkedHashMap<String, JsonValue>().apply { pairs.forEach { (k, v) -> put(k, toJson(v)) } })

fun jsonArr(items: Iterable<Any?>): JsonValue.Arr = JsonValue.Arr(items.map { toJson(it) })

fun toJson(v: Any?): JsonValue = when (v) {
    null -> JsonValue.Null
    is JsonValue -> v
    is String -> JsonValue.Str(v)
    is Boolean -> JsonValue.Bool(v)
    is Int -> JsonValue.Num(v.toDouble())
    is Long -> JsonValue.Num(v.toDouble())
    is Float -> JsonValue.Num(v.toDouble())
    is Double -> JsonValue.Num(v)
    is Enum<*> -> JsonValue.Str(v.name)
    is Map<*, *> -> JsonValue.Obj(LinkedHashMap<String, JsonValue>().apply {
        v.forEach { (k, value) -> put(k.toString(), toJson(value)) }
    })
    is Iterable<*> -> JsonValue.Arr(v.map { toJson(it) })
    is Array<*> -> JsonValue.Arr(v.map { toJson(it) })
    is FloatArray -> JsonValue.Arr(v.map { JsonValue.Num(it.toDouble()) })
    else -> JsonValue.Str(v.toString())
}

// ---------- writer ----------

object Json {

    fun write(value: JsonValue, pretty: Boolean = false): String =
        StringBuilder().also { writeTo(it, value, pretty, 0) }.toString()

    fun parse(text: String): JsonValue = Parser(text).parseDocument()

    fun quote(s: String): String = StringBuilder().also { writeString(it, s) }.toString()

    private fun writeTo(sb: StringBuilder, v: JsonValue, pretty: Boolean, indent: Int) {
        when (v) {
            JsonValue.Null -> sb.append("null")
            is JsonValue.Bool -> sb.append(if (v.value) "true" else "false")
            is JsonValue.Num -> sb.append(formatNumber(v.value))
            is JsonValue.Str -> writeString(sb, v.value)
            is JsonValue.Arr -> {
                if (v.items.isEmpty()) { sb.append("[]"); return }
                sb.append('[')
                v.items.forEachIndexed { i, item ->
                    if (i > 0) sb.append(',')
                    if (pretty) newline(sb, indent + 1)
                    writeTo(sb, item, pretty, indent + 1)
                }
                if (pretty) newline(sb, indent)
                sb.append(']')
            }
            is JsonValue.Obj -> {
                if (v.fields.isEmpty()) { sb.append("{}"); return }
                sb.append('{')
                var first = true
                for ((k, item) in v.fields) {
                    if (!first) sb.append(',')
                    first = false
                    if (pretty) newline(sb, indent + 1)
                    writeString(sb, k)
                    sb.append(if (pretty) ": " else ":")
                    writeTo(sb, item, pretty, indent + 1)
                }
                if (pretty) newline(sb, indent)
                sb.append('}')
            }
        }
    }

    private fun newline(sb: StringBuilder, indent: Int) {
        sb.append('\n')
        repeat(indent) { sb.append("  ") }
    }

    private fun formatNumber(d: Double): String {
        require(!d.isNaN() && !d.isInfinite()) { "JSON cannot encode $d" }
        return if (d == Math.rint(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString() else d.toString()
    }

    private fun writeString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun parseDocument(): JsonValue {
            skipWs()
            val v = parseValue(0)
            skipWs()
            if (i != s.length) throw JsonParseException("Unexpected trailing content", i)
            return v
        }

        private fun parseValue(depth: Int): JsonValue {
            if (depth > 256) throw JsonParseException("Nesting too deep", i)
            skipWs()
            if (i >= s.length) throw JsonParseException("Unexpected end", i)
            return when (val c = s[i]) {
                '{' -> parseObject(depth)
                '[' -> parseArray(depth)
                '"' -> JsonValue.Str(parseString())
                't' -> literal("true", JsonValue.Bool(true))
                'f' -> literal("false", JsonValue.Bool(false))
                'n' -> literal("null", JsonValue.Null)
                else -> if (c == '-' || c.isDigit()) parseNumber() else throw JsonParseException("Unexpected '$c'", i)
            }
        }

        private fun literal(word: String, v: JsonValue): JsonValue {
            if (!s.startsWith(word, i)) throw JsonParseException("Expected $word", i)
            i += word.length
            return v
        }

        private fun parseObject(depth: Int): JsonValue {
            i++ // {
            val map = LinkedHashMap<String, JsonValue>()
            skipWs()
            if (peek() == '}') { i++; return JsonValue.Obj(map) }
            while (true) {
                skipWs()
                if (peek() != '"') throw JsonParseException("Expected key", i)
                val key = parseString()
                skipWs()
                expect(':')
                map[key] = parseValue(depth + 1)
                skipWs()
                when (peek()) {
                    ',' -> i++
                    '}' -> { i++; return JsonValue.Obj(map) }
                    else -> throw JsonParseException("Expected , or }", i)
                }
            }
        }

        private fun parseArray(depth: Int): JsonValue {
            i++ // [
            val list = ArrayList<JsonValue>()
            skipWs()
            if (peek() == ']') { i++; return JsonValue.Arr(list) }
            while (true) {
                list.add(parseValue(depth + 1))
                skipWs()
                when (peek()) {
                    ',' -> i++
                    ']' -> { i++; return JsonValue.Arr(list) }
                    else -> throw JsonParseException("Expected , or ]", i)
                }
            }
        }

        private fun parseString(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw JsonParseException("Unterminated string", i)
                val c = s[i++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (i >= s.length) throw JsonParseException("Bad escape", i)
                        when (val e = s[i++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C'); 'n' -> sb.append('\n')
                            'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) throw JsonParseException("Bad unicode escape", i)
                                val hex = s.substring(i, i + 4)
                                sb.append(hex.toIntOrNull(16)?.toChar() ?: throw JsonParseException("Bad unicode escape", i))
                                i += 4
                            }
                            else -> throw JsonParseException("Bad escape \\$e", i)
                        }
                    }
                    c < ' ' -> throw JsonParseException("Control character in string", i)
                    else -> sb.append(c)
                }
            }
        }

        private fun parseNumber(): JsonValue {
            val start = i
            if (peek() == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val text = s.substring(start, i)
            return JsonValue.Num(text.toDoubleOrNull() ?: throw JsonParseException("Bad number '$text'", start))
        }

        private fun expect(c: Char) {
            if (peek() != c) throw JsonParseException("Expected '$c'", i)
            i++
        }

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun skipWs() {
            while (i < s.length && s[i] in " \t\r\n") i++
        }
    }
}
