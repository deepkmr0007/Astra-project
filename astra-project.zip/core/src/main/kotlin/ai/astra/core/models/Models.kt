package ai.astra.core.models

import ai.astra.core.device.DeviceState
import ai.astra.core.device.ThermalLevel
import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.provider.ModelCapabilities
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

enum class ModelProfile(val label: String, val paramsHint: String, val minRamMb: Long, val typicalFileMb: Long, val contextTokens: Int) {
    TINY("Tiny", "≤ 1.5B params, 4-bit", 3_000, 900, 2048),
    SMALL("Small", "2–4B params, 4-bit", 6_000, 2_600, 4096),
    MEDIUM("Medium", "4–8B params, 4-bit", 10_000, 4_800, 8192),
    LARGE("Large", "8B+ params, 4-bit", 14_000, 7_500, 8192),
}

enum class ModelFormat(val extensions: List<String>, val runtime: String) {
    LITERT_LM(listOf("litertlm"), "LiteRT-LM"),
    MEDIAPIPE_TASK(listOf("task"), "MediaPipe LLM Inference (not bundled)"),
    GGUF(listOf("gguf"), "llama.cpp (integration point)"),
    ONNX(listOf("onnx"), "ONNX Runtime GenAI (integration point)"),
    UNKNOWN(emptyList(), "Unknown");

    companion object {
        fun fromFileName(name: String): ModelFormat {
            val ext = name.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { ext in it.extensions } ?: UNKNOWN
        }
    }
}

/** A model the user installed. License/source are user-visible and recorded for compliance. */
data class ModelDescriptor(
    val id: String,
    val name: String,
    val fileName: String,
    val format: ModelFormat,
    val sizeBytes: Long,
    val sha256: String,
    val source: String,
    val license: String,
    val profile: ModelProfile,
    val capabilities: ModelCapabilities,
    val supportsVision: Boolean = false,
    val supportsAudio: Boolean = false,
    val installedAt: Long = System.currentTimeMillis(),
) {
    val runnable: Boolean get() = format == ModelFormat.LITERT_LM

    fun toJson(): JsonValue = jsonObj(
        "id" to id, "name" to name, "fileName" to fileName, "format" to format, "sizeBytes" to sizeBytes,
        "sha256" to sha256, "source" to source, "license" to license, "profile" to profile,
        "supportsVision" to supportsVision, "supportsAudio" to supportsAudio, "installedAt" to installedAt,
        "capabilities" to jsonObj(
            "reasoning" to capabilities.reasoning, "coding" to capabilities.coding, "vision" to capabilities.vision,
            "multilingual" to capabilities.multilingual, "speed" to capabilities.speed,
            "contextWindow" to capabilities.contextWindow, "memoryRequirementMb" to capabilities.memoryRequirementMb,
        ),
    )

    companion object {
        fun fromJson(v: JsonValue): ModelDescriptor? {
            val o = v.obj() ?: return null
            val c = o["capabilities"].obj()
            return ModelDescriptor(
                id = o["id"].str() ?: return null,
                name = o["name"].str() ?: "Model",
                fileName = o["fileName"].str() ?: return null,
                format = runCatching { ModelFormat.valueOf(o["format"].str()!!) }.getOrDefault(ModelFormat.UNKNOWN),
                sizeBytes = o["sizeBytes"].long() ?: 0,
                sha256 = o["sha256"].str() ?: "",
                source = o["source"].str() ?: "Imported file",
                license = o["license"].str() ?: "Unknown — check the model card",
                profile = runCatching { ModelProfile.valueOf(o["profile"].str()!!) }.getOrDefault(ModelProfile.SMALL),
                capabilities = ModelCapabilities(
                    reasoning = c?.get("reasoning").int() ?: 3, coding = c?.get("coding").int() ?: 3,
                    vision = c?.get("vision").int() ?: 0, multilingual = c?.get("multilingual").int() ?: 3,
                    speed = c?.get("speed").int() ?: 5, contextWindow = c?.get("contextWindow").int() ?: 4096,
                    memoryRequirementMb = c?.get("memoryRequirementMb").int() ?: 0,
                ),
                supportsVision = o["supportsVision"].bool() ?: false,
                supportsAudio = o["supportsAudio"].bool() ?: false,
                installedAt = o["installedAt"].long() ?: 0,
            )
        }

        fun listToJson(list: List<ModelDescriptor>): String = Json.write(jsonArr(list.map { it.toJson() }), pretty = true)
        fun listFromJson(text: String): List<ModelDescriptor> =
            runCatching { Json.parse(text).arr().mapNotNull { fromJson(it) } }.getOrDefault(emptyList())

        /** Estimates profile + capability scores from file size when the user doesn't specify them. */
        fun estimateFromSize(sizeBytes: Long): Pair<ModelProfile, ModelCapabilities> {
            val mb = sizeBytes / (1024 * 1024)
            val profile = when {
                mb < 1_600 -> ModelProfile.TINY
                mb < 3_800 -> ModelProfile.SMALL
                mb < 6_500 -> ModelProfile.MEDIUM
                else -> ModelProfile.LARGE
            }
            val caps = when (profile) {
                ModelProfile.TINY -> ModelCapabilities(reasoning = 2, coding = 2, multilingual = 3, speed = 9, contextWindow = 2048)
                ModelProfile.SMALL -> ModelCapabilities(reasoning = 4, coding = 4, multilingual = 5, speed = 7, contextWindow = 4096)
                ModelProfile.MEDIUM -> ModelCapabilities(reasoning = 6, coding = 6, multilingual = 6, speed = 5, contextWindow = 8192)
                ModelProfile.LARGE -> ModelCapabilities(reasoning = 7, coding = 7, multilingual = 7, speed = 3, contextWindow = 8192)
            }
            return profile to caps.copy(memoryRequirementMb = (mb * 1.3).toInt())
        }
    }
}

data class ProfileRecommendation(val profile: ModelProfile, val contextTokens: Int, val reasons: List<String>)

object ProfileRecommender {
    fun recommend(device: DeviceState): ProfileRecommendation {
        val reasons = ArrayList<String>()
        val ram = device.totalRamMb
        var profile = when {
            ram == null -> ModelProfile.SMALL.also { reasons += "RAM unknown: defaulting to Small" }
            ram >= 15_000 -> ModelProfile.LARGE
            ram >= 11_000 -> ModelProfile.MEDIUM
            ram >= 6_500 -> ModelProfile.SMALL
            else -> ModelProfile.TINY
        }
        if (ram != null) reasons += "Total RAM ${ram / 1024} GB → ${profile.label}"
        val free = device.freeStorageMb
        while (free != null && profile.ordinal > 0 && free < profile.typicalFileMb * 1.5) {
            profile = ModelProfile.entries[profile.ordinal - 1]
            reasons += "Free storage ${free / 1024} GB is limited → ${profile.label}"
        }
        if (device.thermal >= ThermalLevel.SEVERE && profile.ordinal > 0) {
            profile = ModelProfile.entries[profile.ordinal - 1]
            reasons += "Device is hot → ${profile.label}"
        }
        if (!device.charging && (device.batteryPercent ?: 100) < 25 && profile.ordinal > 0) {
            profile = ModelProfile.entries[profile.ordinal - 1]
            reasons += "Low battery → ${profile.label}"
        }
        return ProfileRecommendation(profile, profile.contextTokens, reasons)
    }
}

object Checksums {
    fun sha256(input: InputStream, onProgress: (Long) -> Unit = {}): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(1 shl 16)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
            total += n
            onProgress(total)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun sha256(file: File): String = file.inputStream().use { sha256(it) }
}
