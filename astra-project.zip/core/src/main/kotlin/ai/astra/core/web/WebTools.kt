package ai.astra.core.web

import ai.astra.core.json.JsonValue
import ai.astra.core.json.num
import ai.astra.core.json.str
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec

/** Agent tool: web search. Network; the firewall asks unless Internet is "Allowed" in the Permission Center. */
class WebSearchTool(private val provider: () -> SearchProvider) : Tool {
    override val spec = ToolSpec(
        "web_search", "Searches the web and returns titles, URLs and snippets. Use for current or unknown facts.",
        """{"type":"object","properties":{"query":{"type":"string"},"limit":{"type":"number"}},"required":["query"]}""",
        """{"type":"string"}""", RiskLevel.LOW, setOf(Permission.INTERNET), ExecutionEnvironment.NETWORK,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val q = args["query"].str() ?: return ToolResult.Error("Missing 'query'")
        val p = provider()
        return runCatching { p.search(q, (args["limit"].num()?.toInt() ?: 5).coerceIn(1, 8)) }.fold(
            { list -> ToolResult.Ok(if (list.isEmpty()) "No results from ${p.name}." else list.mapIndexed { i, r -> "${i + 1}. ${r.title}\n${r.url}\n${r.snippet.take(300)}" }.joinToString("\n\n")) },
            { ToolResult.Error("${p.name} search failed: ${it.message}") },
        )
    }
}

/** Agent tool: read one public web page as text (cached locally). */
class WebFetchTool(private val fetcher: WebFetcher, private val cache: WebCache?) : Tool {
    override val spec = ToolSpec(
        "web_fetch", "Downloads a public web page and returns its readable text (first part). Private-network addresses are refused.",
        """{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}""",
        """{"type":"string"}""", RiskLevel.LOW, setOf(Permission.INTERNET), ExecutionEnvironment.NETWORK,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val url = args["url"].str() ?: return ToolResult.Error("Missing 'url'")
        return runCatching { fetcher.fetch(url) }.fold(
            { p -> runCatching { cache?.put(p) }; ToolResult.Ok("Title: ${p.title}\nURL: ${p.finalUrl}\n\n${p.text.take(6000)}") },
            { ToolResult.Error("Could not fetch: ${it.message}") },
        )
    }
}
