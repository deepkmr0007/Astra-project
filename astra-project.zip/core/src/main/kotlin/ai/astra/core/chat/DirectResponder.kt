package ai.astra.core.chat

import ai.astra.core.documents.DocumentIndex
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.tools.CalcException
import ai.astra.core.tools.Calculator
import ai.astra.core.tools.Units
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

data class DirectAnswer(val text: String, val tool: String)

/**
 * Answers that need no language model: arithmetic, unit conversion, date/time, "what do you
 * remember", document look-ups and help. Used when no model is installed or reachable, and
 * always labelled as a direct tool result — it never pretends to be AI-generated text.
 */
class DirectResponder(
    private val memory: MemoryEngine,
    private val documents: DocumentIndex,
    private val now: () -> ZonedDateTime = { ZonedDateTime.now() },
) {
    private val calcLead = Regex("(?i)^\\s*(what('?s| is)|calculate|calc|compute|kitna( hai)?|solve)\\s*[:]?\\s*")
    private val mathOnly = Regex("^[\\d\\s.,+\\-*/^%()!×÷−a-z]*\\d[\\d\\s.,+\\-*/^%()!×÷−a-z]*$", RegexOption.IGNORE_CASE)
    private val unitRx = Regex("(?i)^\\s*(?:convert\\s+)?(-?\\d+(?:[.,]\\d+)?)\\s*([a-z°/²³ ]+?)\\s+(?:to|in|into|me|mein)\\s+([a-z°/²³ ]+?)\\s*\\??$")
    private val timeRx = Regex("(?i)\\b(what('?s| is) the (time|date|day)|today'?s date|time now|aaj (ki )?(tareekh|date)|kitne baje|समय|तारीख)\\b")
    private val memRx = Regex("(?i)^(what do you (remember|know) about|do you remember|what('?s| is) my|where('?s| is) my|who('?s| is) my|mujhe yaad|my )\\s*(.*)$")
    private val docRx = Regex("(?i)^(search|find|look up)\\s+(my )?(docs?|documents?|files?|pdfs?)\\s+(for|about)\\s+(.+)$")
    private val helpRx = Regex("(?i)^(help|hi|hello|hey|namaste|namaskar|hello astra|hi astra)\\b.*$")

    suspend fun answer(text: String, projectId: String?): DirectAnswer? {
        val t = text.trim().trimEnd('?', '.', '!').trim()
        if (t.isEmpty()) return null

        unitRx.find(t)?.let { m ->
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull()
            if (v != null) runCatching { Units.convert(v, m.groupValues[2].trim(), m.groupValues[3].trim()) }.getOrNull()?.let { r ->
                return DirectAnswer("${Calculator.format(v)} ${m.groupValues[2].trim()} = **${Calculator.format(r)} ${m.groupValues[3].trim()}**", "unit_convert")
            }
        }

        val expr = calcLead.replace(t, "").replace("into", "*").replace(" x ", " * ")
        if (expr.any { it.isDigit() } && mathOnly.matches(expr) && expr.any { it in "+-*/^%!×÷−" || expr.contains("sqrt") || expr.contains(" of ") }) {
            try {
                return DirectAnswer("${expr.trim()} = **${Calculator.format(Calculator.evaluate(expr))}**", "calculator")
            } catch (_: CalcException) { /* not a calculation */ }
        }

        if (timeRx.containsMatchIn(t)) {
            return DirectAnswer(now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy · HH:mm (z)")), "datetime")
        }

        docRx.find(t)?.let { m ->
            val hits = documents.search(m.groupValues[5], projectId = projectId, limit = 3)
            return DirectAnswer(
                if (hits.isEmpty()) "No passage in your documents matches “${m.groupValues[5]}”."
                else "Closest passages in your documents:\n\n" + hits.joinToString("\n\n") { "**${it.citation}**\n${it.chunk.text.take(400)}" },
                "document_search",
            )
        }

        memRx.find(t)?.let { m ->
            val q = m.groupValues.last().ifBlank { t }
            val hits = memory.recall(q, projectId, limit = 4, minScore = 0.15)
            if (hits.isNotEmpty()) return DirectAnswer("From your saved memories:\n" + hits.joinToString("\n") { "• ${it.record.content}" }, "memory_search")
        }

        if (helpRx.matches(t)) return DirectAnswer(HELP, "help")
        return null
    }

    companion object {
        const val HELP =
            "Namaste! I don't have a language model yet, so I can't hold a conversation — but I can already:\n" +
                "• calculate: “18% of 2500”, “(45+5)*3”\n" +
                "• convert units: “5 acre to hectare”, “30 C to F”\n" +
                "• tell the date and time\n" +
                "• remember things: “remember that my dhani is in Mandhan”\n" +
                "• recall them: “what do you remember about dhani”\n" +
                "• search imported documents: “search documents for survival rate”\n\n" +
                "To chat properly, open **Setup** and download a model (one tap, works offline afterwards) or connect an online model."
    }
}
