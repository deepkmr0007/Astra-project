package ai.astra.core.desk

import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Pairing and message encryption between the phone and the ASTRA Desk browser extension.
 *
 * Pairing: both sides create an ephemeral ECDH P-256 key pair and exchange public keys over the
 * LAN. Each side derives the same 256-bit key with HKDF-SHA256 and a 6-digit comparison code. The
 * user checks that the phone and the computer show the same code (like Bluetooth numeric
 * comparison), which defeats a man-in-the-middle. Afterwards every message is AES-256-GCM with a
 * random 96-bit nonce. The same primitives exist in Web Crypto, so the extension interoperates
 * byte for byte (see desk-extension/desk-core.js and its interop test).
 */
object DeskCrypto {
    private val random = SecureRandom()
    private const val KEY_INFO = "astra-desk-v1 key"
    private const val SAS_INFO = "astra-desk-v1 sas"

    data class Derived(val key: ByteArray, val code: String)

    fun newKeyPair(): KeyPair = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1"), random) }.generateKeyPair()

    /** Uncompressed SEC1 point: 0x04 || X(32) || Y(32) — what Web Crypto's "raw" export produces. */
    fun rawPublic(pub: ECPublicKey): ByteArray {
        fun fixed(b: BigInteger): ByteArray {
            val a = b.toByteArray()
            return when {
                a.size == 32 -> a
                a.size > 32 -> a.copyOfRange(a.size - 32, a.size)
                else -> ByteArray(32 - a.size) + a
            }
        }
        return byteArrayOf(4) + fixed(pub.w.affineX) + fixed(pub.w.affineY)
    }

    fun publicFromRaw(raw: ByteArray, params: ECParameterSpec): ECPublicKey {
        require(raw.size == 65 && raw[0] == 4.toByte()) { "Bad public key" }
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        val curve = params.curve
        val p = (curve.field as java.security.spec.ECFieldFp).p
        require(x < p && y < p) { "Bad public key" }
        // y² = x³ + ax + b (mod p): refuse points that are not on the curve (invalid-curve attacks).
        require(y.modPow(BigInteger.valueOf(2), p) == x.modPow(BigInteger.valueOf(3), p).add(curve.a.multiply(x)).add(curve.b).mod(p)) { "Public key is not on P-256" }
        return KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), params)) as ECPublicKey
    }

    fun sharedSecret(own: PrivateKey, peer: ECPublicKey): ByteArray =
        KeyAgreement.getInstance("ECDH").apply { init(own); doPhase(peer, true) }.generateSecret()

    /** RFC 5869 HKDF-SHA256. */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        val prk = hmac(salt.takeIf { it.isNotEmpty() } ?: ByteArray(32), ikm)
        val out = java.io.ByteArrayOutputStream()
        var t = ByteArray(0)
        var counter = 1
        while (out.size() < length) {
            t = hmac(prk, t + info + byteArrayOf(counter.toByte()))
            out.write(t); counter++
        }
        return out.toByteArray().copyOf(length)
    }

    fun hmac(key: ByteArray, data: ByteArray): ByteArray = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(key, "HmacSHA256")) }.doFinal(data)

    fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    /** Salt binds both public keys (phone first), so a swapped key gives a different code. */
    fun derive(shared: ByteArray, phonePub: ByteArray, extensionPub: ByteArray): Derived {
        val salt = sha256(phonePub + extensionPub)
        val key = hkdf(shared, salt, KEY_INFO.toByteArray(), 32)
        val sas = hkdf(shared, salt, SAS_INFO.toByteArray(), 4)
        val n = ((sas[0].toLong() and 0xff) shl 24 or ((sas[1].toLong() and 0xff) shl 16) or ((sas[2].toLong() and 0xff) shl 8) or (sas[3].toLong() and 0xff)) % 1_000_000
        return Derived(key, n.toString().padStart(6, '0'))
    }

    fun seal(key: ByteArray, plaintext: ByteArray, aad: ByteArray): ByteArray {
        val iv = ByteArray(12).also(random::nextBytes)
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv)); updateAAD(aad) }
        return iv + c.doFinal(plaintext)
    }

    fun open(key: ByteArray, sealed: ByteArray, aad: ByteArray): ByteArray {
        require(sealed.size > 12 + 16) { "Message too short" }
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, sealed.copyOfRange(0, 12))); updateAAD(aad)
        }
        return c.doFinal(sealed, 12, sealed.size - 12)
    }

    fun b64(b: ByteArray): String = Base64.getEncoder().encodeToString(b)
    fun unb64(s: String): ByteArray = Base64.getDecoder().decode(s)
    fun randomId(bytes: Int = 16): String = ByteArray(bytes).also(random::nextBytes).joinToString("") { "%02x".format(it) }
}
