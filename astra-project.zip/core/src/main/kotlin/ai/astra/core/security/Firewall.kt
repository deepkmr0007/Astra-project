package ai.astra.core.security

import ai.astra.core.model.AssistMode

enum class Permission { MICROPHONE, CAMERA, FILES, LOCATION, CONTACTS, NOTIFICATIONS, INTERNET, BACKGROUND, EXTERNAL_SERVICES, MEMORY, DOCUMENTS }

enum class PermissionState { ALLOWED, DENIED, ASK }

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }

/** Central permission dashboard state. Defaults are conservative: network-touching things ask. */
interface PermissionCenter {
    fun state(p: Permission): PermissionState
    fun set(p: Permission, state: PermissionState)
}

class InMemoryPermissionCenter(initial: Map<Permission, PermissionState> = DEFAULTS) : PermissionCenter {
    private val map = HashMap(initial)
    override fun state(p: Permission) = map[p] ?: PermissionState.ASK
    override fun set(p: Permission, state: PermissionState) { map[p] = state }

    companion object {
        val DEFAULTS: Map<Permission, PermissionState> = Permission.entries.associateWith {
            when (it) {
                Permission.MEMORY, Permission.DOCUMENTS -> PermissionState.ALLOWED
                else -> PermissionState.ASK
            }
        }
    }
}

data class ConfirmationRequest(
    val title: String,
    val detail: String,
    val risk: RiskLevel,
    /** CRITICAL actions must be confirmed by an explicit typed/held action in the UI, not a single tap. */
    val requiresStrongConfirmation: Boolean,
)

/** Implemented by the UI. Suspends until the user answers. */
fun interface ConfirmationGate {
    suspend fun confirm(request: ConfirmationRequest): Boolean
}

data class FirewallPolicy(
    /** Lets MEDIUM-risk tools run without asking (user opt-in). HIGH/CRITICAL can never be auto-approved. */
    val autoApproveMedium: Boolean = false,
    /** Lets HIGH-risk tools run without asking (e.g. delete inside a sandbox folder). CRITICAL is never auto. */
    val autoApproveHigh: Boolean = false,
)

sealed interface FirewallDecision {
    data object Allowed : FirewallDecision
    data class Denied(val reason: String) : FirewallDecision
}

data class AuditEntry(val time: Long, val tool: String, val risk: RiskLevel, val decision: String, val detail: String)

interface AuditLog {
    fun record(entry: AuditEntry)
    fun entries(): List<AuditEntry>
    fun clear()
}

class RingAuditLog(private val capacity: Int = 500) : AuditLog {
    private val items = ArrayDeque<AuditEntry>()
    @Synchronized override fun record(entry: AuditEntry) {
        items.addLast(entry.copy(detail = Redactor.redact(entry.detail).take(300)))
        while (items.size > capacity) items.removeFirst()
    }
    @Synchronized override fun entries(): List<AuditEntry> = items.toList()
    @Synchronized override fun clear() = items.clear()
}

/**
 * The AI safety firewall. Every tool call passes:
 * AI REQUEST → POLICY → PERMISSION CHECK → RISK CLASSIFICATION → USER CONFIRMATION (if required) → TOOL.
 */
class ToolFirewall(
    private val permissions: PermissionCenter,
    private val gate: ConfirmationGate,
    private val audit: AuditLog,
    var policy: FirewallPolicy = FirewallPolicy(),
) {
    suspend fun authorize(
        toolName: String,
        risk: RiskLevel,
        required: Set<Permission>,
        mode: AssistMode,
        argumentsPreview: String,
        allowedTools: Set<String>? = null,
    ): FirewallDecision {
        fun deny(reason: String): FirewallDecision {
            audit.record(AuditEntry(System.currentTimeMillis(), toolName, risk, "DENIED", reason))
            return FirewallDecision.Denied(reason)
        }
        // 1. Policy: mode limits.
        if (mode == AssistMode.CHAT) return deny("Tools are disabled in Chat mode")
        if (mode == AssistMode.ASSIST && risk > RiskLevel.LOW) return deny("Assist mode only runs low-risk tools; switch to Agent mode")
        if (allowedTools != null && toolName !in allowedTools) return deny("Tool not enabled for this run")

        // 2. Permissions.
        var mustAsk = false
        for (p in required) when (permissions.state(p)) {
            PermissionState.DENIED -> return deny("Permission ${p.name} is denied in the Permission Center")
            PermissionState.ASK -> mustAsk = true
            PermissionState.ALLOWED -> Unit
        }

        // 3. Risk.
        mustAsk = mustAsk || when (risk) {
            RiskLevel.LOW -> false
            RiskLevel.MEDIUM -> !policy.autoApproveMedium
            RiskLevel.HIGH -> !policy.autoApproveHigh
            RiskLevel.CRITICAL -> true
        }

        // 4. Confirmation.
        if (mustAsk) {
            val ok = gate.confirm(
                ConfirmationRequest(
                    title = "Allow tool \"$toolName\"?",
                    detail = "Risk: ${risk.name}. Permissions: ${required.joinToString { it.name }.ifEmpty { "none" }}.\nArguments: ${Redactor.redact(argumentsPreview).take(400)}",
                    risk = risk,
                    requiresStrongConfirmation = risk == RiskLevel.CRITICAL,
                )
            )
            if (!ok) return deny("User declined")
        }
        audit.record(AuditEntry(System.currentTimeMillis(), toolName, risk, if (mustAsk) "ALLOWED (confirmed)" else "ALLOWED", argumentsPreview))
        return FirewallDecision.Allowed
    }
}
