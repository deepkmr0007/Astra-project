package ai.astra.core.data

import ai.astra.core.json.JsonValue
import ai.astra.core.json.int
import ai.astra.core.json.str
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec

/** Data tables the user imported for automations and analysis. */
interface TableStore {
    suspend fun names(): List<String>
    suspend fun get(name: String): DataTable?
}

class InMemoryTableStore : TableStore {
    val tables = LinkedHashMap<String, DataTable>()
    override suspend fun names() = tables.keys.toList()
    override suspend fun get(name: String) = tables[name] ?: tables.entries.firstOrNull { it.key.equals(name, true) }?.value
}

/**
 * Lets the model answer questions about imported sheets with exact numbers instead of guessing:
 * list, describe, filter, and sum/avg/min/max/count with optional group-by.
 */
class TableQueryTool(private val store: TableStore) : Tool {
    override val spec = ToolSpec(
        name = "table_query",
        description = "Query the user's imported data tables exactly. ops: list | describe(table) | filter(table,column,op2,value,limit) | aggregate(table,column,fn,groupBy,whereColumn,op2,value). op2 is one of = != > < >= <= contains; fn is sum|avg|min|max|count.",
        inputSchema = """{"type":"object","properties":{"op":{"type":"string"},"table":{"type":"string"},"column":{"type":"string"},"op2":{"type":"string"},"value":{"type":"string"},"fn":{"type":"string"},"groupBy":{"type":"string"},"whereColumn":{"type":"string"},"limit":{"type":"integer"}},"required":["op"]}""",
        outputSchema = "Plain-text result table",
        risk = RiskLevel.LOW,
        permissions = setOf(Permission.DOCUMENTS),
        environment = ExecutionEnvironment.IN_PROCESS,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val op = args["op"].str()?.lowercase() ?: return ToolResult.Error("op is required")
        if (op == "list") {
            val names = store.names()
            return ToolResult.Ok(if (names.isEmpty()) "No tables imported. Import an Excel/CSV file in Automations → Data." else names.joinToString("\n") { "- $it" })
        }
        val t = args["table"].str()?.let { store.get(it) } ?: store.names().singleOrNull()?.let { store.get(it) } ?: return ToolResult.Error("Unknown table. Use op=list first.")
        return when (op) {
            "describe" -> ToolResult.Ok("Table ${t.name}: ${t.size} rows\nColumns: ${t.headers.joinToString()}\n" + t.preview(5))
            "filter" -> {
                val rows = filter(t, args) ?: return ToolResult.Error("Unknown column")
                val limit = (args["limit"].int() ?: 20).coerceIn(1, 100)
                ToolResult.Ok("${rows.size} matching row(s)\n" + t.withRows(rows.take(limit)).preview(limit))
            }
            "aggregate" -> aggregate(t, args)
            else -> ToolResult.Error("Unknown op $op")
        }
    }

    private fun filter(t: DataTable, args: JsonValue.Obj): List<List<String>>? {
        val colName = args["column"].str() ?: return t.rows
        val c = t.column(colName).takeIf { it >= 0 } ?: return null
        val cmp = (args["op2"].str() ?: args["comparator"].str() ?: "=").trim()
        val v = args["value"].str().orEmpty()
        return t.rows.filter { r -> compare(r.getOrElse(c) { "" }, cmp, v) }
    }

    private fun compare(cell: String, op: String, v: String): Boolean {
        val a = num(cell); val b = num(v)
        return when (op) {
            "=", "==" -> if (a != null && b != null) a == b else cell.equals(v, true)
            "!=" -> if (a != null && b != null) a != b else !cell.equals(v, true)
            ">" -> a != null && b != null && a > b
            "<" -> a != null && b != null && a < b
            ">=" -> a != null && b != null && a >= b
            "<=" -> a != null && b != null && a <= b
            "contains" -> cell.contains(v, true)
            else -> false
        }
    }

    private fun num(s: String) = s.replace(",", "").replace("₹", "").trim().toDoubleOrNull()

    private fun aggregate(t: DataTable, args: JsonValue.Obj): ToolResult {
        val fn = args["fn"].str()?.lowercase() ?: "count"
        val where = args["whereColumn"].str()
        val rows = if (where == null) t.rows else filter(t, JsonValue.Obj(mapOf("column" to JsonValue.Str(where)) + args.fields.filterKeys { it == "op2" || it == "value" })) ?: return ToolResult.Error("Unknown column $where")
        val target = args["column"].str()?.let { t.column(it) } ?: -1
        val g = args["groupBy"].str()?.let { t.column(it) }?.takeIf { it >= 0 }
        val groups = if (g == null) mapOf("all" to rows) else rows.groupBy { it.getOrElse(g) { "" } }
        val lines = groups.map { (k, rs) ->
            val nums = if (target >= 0) rs.mapNotNull { num(it.getOrElse(target) { "" }) } else emptyList()
            val value = when (fn) {
                "count" -> rs.size.toDouble()
                "sum" -> nums.sum()
                "avg" -> if (nums.isEmpty()) Double.NaN else nums.average()
                "min" -> nums.minOrNull() ?: Double.NaN
                "max" -> nums.maxOrNull() ?: Double.NaN
                else -> return ToolResult.Error("fn must be sum|avg|min|max|count")
            }
            "$k: " + if (value.isNaN()) "no numbers" else if (value == Math.rint(value)) value.toLong().toString() else "%.2f".format(value)
        }
        return ToolResult.Ok("$fn${args["column"].str()?.let { " of $it" } ?: ""}${g?.let { " by ${t.headers[it]}" } ?: ""}\n" + lines.joinToString("\n"))
    }
}
