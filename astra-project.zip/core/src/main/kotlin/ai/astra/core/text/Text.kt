package ai.astra.core.text

import kotlin.math.ceil
import kotlin.math.ln

/** Unicode-aware word tokenizer (works for English, Hindi/Devanagari and Hinglish). */
object Tokenizer {
    private val STOPWORDS = setOf(
        "a", "an", "the", "and", "or", "but", "if", "then", "of", "to", "in", "on", "at", "by", "for",
        "with", "about", "as", "is", "are", "was", "were", "be", "been", "it", "its", "this", "that",
        "these", "those", "i", "me", "my", "you", "your", "we", "our", "he", "she", "they", "them",
        "do", "does", "did", "what", "which", "who", "whom", "how", "why", "when", "where", "can",
        "could", "should", "would", "will", "shall", "so", "not", "no", "from", "into", "than", "too",
        "very", "just", "also", "please", "hai", "hain", "ka", "ki", "ke", "ko", "se", "me", "mein",
        "aur", "ya", "kya", "yeh", "ye", "woh", "wo", "tha", "thi", "the", "हैं", "है", "का", "की", "के",
        "को", "से", "में", "और", "या", "क्या", "यह", "वह", "था", "थी",
    )

    fun words(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in text.lowercase()) {
            // Devanagari combining marks (matras, virama) are not letters but belong to the word.
            if (ch.isLetterOrDigit() || Character.getType(ch) == Character.NON_SPACING_MARK.toInt() ||
                Character.getType(ch) == Character.COMBINING_SPACING_MARK.toInt()
            ) {
                sb.append(ch)
            } else if (sb.isNotEmpty()) {
                out.add(sb.toString()); sb.clear()
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    fun terms(text: String): List<String> = words(text).filter { it !in STOPWORDS && it.length > 1 }

    fun sentences(text: String): List<String> =
        text.split(Regex("(?<=[.!?।])\\s+|\\n{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
}

/**
 * Conservative token estimate used for context budgeting when a runtime tokenizer is not exposed.
 * ~4 chars/token for Latin script, ~2 chars/token for Indic scripts (sub-word tokenizers split
 * Devanagari much finer). Over-estimating is deliberate: it keeps prompts inside the window.
 */
object TokenEstimator {
    fun estimate(text: String): Int {
        if (text.isEmpty()) return 0
        var latin = 0
        var other = 0
        for (c in text) if (c.code < 0x0250) latin++ else other++
        return ceil(latin / 3.6 + other / 1.8).toInt() + 1
    }
}

/** Okapi BM25 over a small in-memory corpus. Used for the keyword half of hybrid search. */
class Bm25(docs: List<List<String>>, private val k1: Double = 1.2, private val b: Double = 0.75) {
    private val n = docs.size
    private val docTf: List<Map<String, Int>> = docs.map { d -> d.groupingBy { it }.eachCount() }
    private val docLen = docs.map { it.size }
    private val avgLen = if (n == 0) 0.0 else docLen.sum().toDouble() / n
    private val df: Map<String, Int> = HashMap<String, Int>().apply {
        docTf.forEach { tf -> tf.keys.forEach { put(it, (get(it) ?: 0) + 1) } }
    }

    fun score(query: List<String>, docIndex: Int): Double {
        if (n == 0) return 0.0
        val tf = docTf[docIndex]
        var s = 0.0
        for (q in query.toSet()) {
            val f = tf[q] ?: continue
            val idf = ln(1.0 + (n - (df[q] ?: 0) + 0.5) / ((df[q] ?: 0) + 0.5))
            s += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * docLen[docIndex] / avgLen.coerceAtLeast(1.0)))
        }
        return s
    }

    /** Scores normalized to 0..1 relative to the best match. */
    fun normalizedScores(query: List<String>): DoubleArray {
        val raw = DoubleArray(n) { score(query, it) }
        val max = raw.maxOrNull() ?: 0.0
        if (max <= 0.0) return raw
        for (i in raw.indices) raw[i] = raw[i] / max
        return raw
    }
}
