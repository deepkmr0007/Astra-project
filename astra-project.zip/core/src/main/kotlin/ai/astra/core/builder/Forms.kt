package ai.astra.core.builder

import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str

enum class FieldType { TEXT, NUMBER, DATE, SELECT, RADIO, CHECKBOX, TEXTAREA, EMAIL, PHONE, PASSWORD, FILE, BUTTON, OTHER }

/**
 * One field on a form or screen, as the ASTRA Desk extension (browser) or the phone agent
 * (accessibility) reports it. [selector] is how a driver finds it again.
 */
data class FormField(
    val selector: String,
    val label: String,
    val name: String = "",
    val type: FieldType = FieldType.TEXT,
    val options: List<String> = emptyList(),
    val required: Boolean = false,
    val maxLength: Int? = null,
    val pattern: String? = null,
    val value: String = "",
    val placeholder: String = "",
) {
    /** Text used for matching against data columns. */
    val matchText: String get() = listOf(label, name, placeholder).filter { it.isNotBlank() }.joinToString(" ")

    fun toJson(): JsonValue.Obj = jsonObj(
        "selector" to selector, "label" to label, "name" to name, "type" to type.name, "options" to options,
        "required" to required, "maxLength" to maxLength, "pattern" to pattern, "value" to value, "placeholder" to placeholder,
    )

    companion object {
        fun fromJson(o: JsonValue.Obj): FormField = FormField(
            selector = o["selector"].str().orEmpty(),
            label = o["label"].str().orEmpty(),
            name = o["name"].str().orEmpty(),
            type = o["type"].str()?.let { t -> FieldType.entries.firstOrNull { it.name.equals(t, true) } } ?: FieldType.TEXT,
            options = o["options"].arr().mapNotNull { it.str() },
            required = o["required"].bool() ?: false,
            maxLength = o["maxLength"].int()?.takeIf { it > 0 },
            pattern = o["pattern"].str()?.takeIf { it.isNotBlank() },
            value = o["value"].str().orEmpty(),
            placeholder = o["placeholder"].str().orEmpty(),
        )
    }
}

data class FormSnapshot(val url: String, val title: String, val fields: List<FormField>) {
    val inputs: List<FormField> get() = fields.filter { it.type != FieldType.BUTTON }
    val buttons: List<FormField> get() = fields.filter { it.type == FieldType.BUTTON }

    fun toJson(): JsonValue.Obj = jsonObj("url" to url, "title" to title, "fields" to fields.map { it.toJson() })

    /** Compact description for prompts. */
    fun describe(maxFields: Int = 60): String = buildString {
        appendLine("Page: $title ($url)")
        inputs.take(maxFields).forEach { f ->
            append("- field \"${f.label.ifBlank { f.name }}\" [${f.type.name.lowercase()}] selector=${f.selector}")
            if (f.required) append(" required")
            if (f.options.isNotEmpty()) append(" options=" + f.options.take(12).joinToString("/") + if (f.options.size > 12) "/…" else "")
            appendLine()
        }
        buttons.take(20).forEach { b -> appendLine("- button \"${b.label}\" selector=${b.selector}") }
    }.trim()

    companion object {
        fun fromJson(o: JsonValue.Obj): FormSnapshot = FormSnapshot(
            o["url"].str().orEmpty(), o["title"].str().orEmpty(), o["fields"].arr().mapNotNull { it.obj()?.let(FormField::fromJson) },
        )
    }
}

data class MappingSuggestion(val field: FormField, val column: String?, val score: Double, val reason: String)

/**
 * Matches spreadsheet / register columns to form fields. Works offline: normalised token overlap,
 * character similarity and a bilingual synonym table for Indian government and cooperative forms
 * (naam/name, pita/father, khata/account, gaon/village, dinank/date…). A model can refine the
 * result, but the user always sees and can change every mapping.
 */
object FieldMapper {
    private val SYNONYMS: List<Set<String>> = listOf(
        setOf("name", "naam", "नाम", "fullname", "applicant", "member", "farmer", "kisan", "sadasya", "सदस्य", "किसान", "beneficiary", "customer"),
        setOf("father", "pita", "पिता", "husband", "pati", "पति", "guardian", "fathername", "so", "wo", "do"),
        setOf("mobile", "phone", "mob", "contact", "cell", "मोबाइल", "फोन", "phoneno", "mobileno"),
        setOf("aadhaar", "aadhar", "adhar", "uid", "uidai", "आधार"),
        setOf("account", "acct", "ac", "khata", "खाता", "accountno", "acno", "khatano"),
        setOf("village", "gaon", "gram", "गांव", "गाँव", "ग्राम", "dhani", "ढाणी"),
        setOf("tehsil", "tahsil", "तहसील", "taluka", "block"),
        setOf("district", "jila", "zila", "जिला", "dist"),
        setOf("amount", "rashi", "राशि", "rs", "rupees", "amt", "principal", "sum", "रकम"),
        setOf("date", "dinank", "दिनांक", "dt", "tarikh", "तारीख"),
        setOf("dob", "birth", "janm", "जन्म", "birthdate", "dateofbirth"),
        setOf("gender", "sex", "ling", "लिंग"),
        setOf("address", "pata", "पता", "addr"),
        setOf("pincode", "pin", "postal", "zip", "पिनकोड"),
        setOf("ifsc", "ifsccode", "branchcode"),
        setOf("bank", "बैंक", "bankname"),
        setOf("caste", "category", "jati", "वर्ग", "श्रेणी"),
        setOf("land", "area", "bhumi", "भूमि", "hectare", "bigha", "acre", "rakba", "रकबा"),
        setOf("crop", "fasal", "फसल"),
        setOf("khasra", "survey", "खसरा", "plot"),
        setOf("email", "mail", "ईमेल"),
        setOf("age", "umar", "आयु", "उम्र"),
        setOf("number", "no", "num", "sankhya", "संख्या", "kramank", "क्रमांक", "serial", "sno", "sr"),
        setOf("remarks", "remark", "tippani", "टिप्पणी", "note", "notes"),
        setOf("share", "ansh", "अंश", "shares"),
        setOf("pan", "pancard"),
    )

    private val CANON: Map<String, Int> = HashMap<String, Int>().apply { SYNONYMS.forEachIndexed { i, s -> s.forEach { put(it, i) } } }

    fun tokens(text: String): List<String> {
        val spaced = text.replace(Regex("([a-z])([A-Z])"), "$1 $2").replace(Regex("[_\\-./:#()\\[\\]*]+"), " ").lowercase()
        return spaced.split(Regex("\\s+")).map { it.trim() }.filter { it.isNotEmpty() && it !in STOP }
    }

    private val STOP = setOf("of", "the", "enter", "select", "please", "your", "ka", "ki", "ke", "का", "की", "के", "kr", "करें", "input", "field", "txt", "ddl", "ctl00", "contentplaceholder1", "maincontent")

    private fun concepts(text: String): Set<Int> {
        val t = tokens(text)
        val out = HashSet<Int>()
        t.forEach { w -> CANON[w]?.let(out::add) }
        // Joined forms like "fathername", "mobileno".
        val joined = t.joinToString("")
        SYNONYMS.forEachIndexed { i, s -> if (s.any { it.length >= 4 && joined.contains(it) }) out += i }
        return out
    }

    fun similarity(a: String, b: String): Double {
        val ta = tokens(a).toSet(); val tb = tokens(b).toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val ca = concepts(a); val cb = concepts(b)
        val conceptScore = if (ca.isEmpty() || cb.isEmpty()) 0.0 else ca.intersect(cb).size.toDouble() / maxOf(ca.size, cb.size)
        val tokenScore = ta.intersect(tb).size.toDouble() / maxOf(ta.size, tb.size)
        val charScore = 1.0 - levenshtein(ta.joinToString(""), tb.joinToString("")).toDouble() / maxOf(ta.joinToString("").length, tb.joinToString("").length)
        return maxOf(conceptScore * 0.95, tokenScore, charScore * 0.8)
    }

    /** One suggestion per input field; each column is used at most once (best matches first). */
    fun suggest(columns: List<String>, form: FormSnapshot, threshold: Double = 0.55): List<MappingSuggestion> {
        val fields = form.inputs
        val pairs = fields.flatMap { f -> columns.map { c -> Triple(f, c, similarity(f.matchText, c)) } }.sortedByDescending { it.third }
        val usedCols = HashSet<String>(); val chosen = HashMap<String, MappingSuggestion>()
        for ((f, c, s) in pairs) {
            if (s < threshold) break
            if (f.selector in chosen || c in usedCols) continue
            chosen[f.selector] = MappingSuggestion(f, c, s, if (s >= 0.9) "same meaning" else "similar name")
            usedCols += c
        }
        return fields.map { f -> chosen[f.selector] ?: MappingSuggestion(f, null, 0.0, if (f.required) "required — no matching column" else "no matching column") }
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
