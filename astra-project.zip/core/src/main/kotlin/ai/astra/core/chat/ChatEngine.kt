package ai.astra.core.chat

import ai.astra.core.agent.ActivityItem
import ai.astra.core.agent.ActivityKind
import ai.astra.core.agent.AgentLimits
import ai.astra.core.agent.AgentOutcome
import ai.astra.core.agent.AgentRunner
import ai.astra.core.context.AssistantProfile
import ai.astra.core.context.BuiltContext
import ai.astra.core.context.ContextEngine
import ai.astra.core.context.ContextInputs
import ai.astra.core.context.ConversationCompressor
import ai.astra.core.device.DeviceState
import ai.astra.core.device.ThermalGovernor
import ai.astra.core.diagnostics.Diagnostics
import ai.astra.core.documents.DocHit
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.memory.MemoryClassifier
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.RememberResult
import ai.astra.core.model.AssistMode
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.ExecutionTrace
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Project
import ai.astra.core.model.Role
import ai.astra.core.model.VerificationSummary
import ai.astra.core.model.plainText
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.Availability
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.ProviderErrorKind
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.ProviderInfo
import ai.astra.core.router.ModelRouter
import ai.astra.core.router.RouteDecision
import ai.astra.core.router.RouteRequest
import ai.astra.core.router.RouterPolicy
import ai.astra.core.router.TaskAnalyzer
import ai.astra.core.router.Complexity
import ai.astra.core.router.TaskKind
import ai.astra.core.model.ContentSource
import ai.astra.core.security.PromptInjectionDetector
import ai.astra.core.security.UntrustedFence
import ai.astra.core.vision.ImageAnalyzer
import ai.astra.core.agent.TeamRunner
import ai.astra.core.agent.TeamWorkflow
import ai.astra.core.web.ResearchPipeline
import ai.astra.core.router.DataControl
import ai.astra.core.security.Sensitivity
import ai.astra.core.text.ThinkFilter
import ai.astra.core.security.PrivacyAssessment
import ai.astra.core.security.PrivacyClassifier
import ai.astra.core.text.TokenEstimator
import ai.astra.core.tools.ToolRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

interface ConversationRepository {
    suspend fun conversation(id: String): Conversation?
    suspend fun messages(conversationId: String): List<ChatMessage>
    suspend fun append(message: ChatMessage)
    suspend fun summary(conversationId: String): Pair<String, Long>?
    suspend fun setSummary(conversationId: String, summary: String, coveredUntil: Long)
    suspend fun project(id: String): Project?
}

class InMemoryConversationRepository : ConversationRepository {
    val conversations = LinkedHashMap<String, Conversation>()
    val projects = LinkedHashMap<String, Project>()
    private val msgs = HashMap<String, MutableList<ChatMessage>>()
    private val summaries = HashMap<String, Pair<String, Long>>()
    private val lock = Any()
    override suspend fun conversation(id: String) = synchronized(lock) { conversations[id] }
    override suspend fun messages(conversationId: String) = synchronized(lock) { msgs[conversationId]?.toList().orEmpty() }
    override suspend fun append(message: ChatMessage) { synchronized(lock) { msgs.getOrPut(message.conversationId) { ArrayList() }.add(message) } }
    override suspend fun summary(conversationId: String) = synchronized(lock) { summaries[conversationId] }
    override suspend fun setSummary(conversationId: String, summary: String, coveredUntil: Long) { synchronized(lock) { summaries[conversationId] = summary to coveredUntil } }
    override suspend fun project(id: String) = synchronized(lock) { projects[id] }
}

enum class ConsentAnswer { DENY, ALLOW_ONCE, ALLOW_FOR_CHAT }

data class ConsentRequest(
    val provider: ProviderInfo,
    val dataSummary: List<String>,
    val sensitiveKinds: Set<String>,
    val approxBytes: Long,
    val reasons: List<String>,
)

/** UI hook: asks the user before anything is sent to a network model. */
fun interface ConsentGate {
    suspend fun ask(request: ConsentRequest): ConsentAnswer
}

data class EngineSettings(
    val routerPolicy: RouterPolicy = RouterPolicy(),
    val profile: AssistantProfile = AssistantProfile(),
    val maxOutputTokens: Int = 1024,
    val temperature: Double = 0.7,
    val useDocuments: Boolean = true,
    val useMemory: Boolean = true,
    val allowNetworkTools: Boolean = false,
)

data class ChatRequest(
    val conversationId: String,
    val parts: List<Part>,
    val mode: AssistMode = AssistMode.CHAT,
    val forcedProviderId: String? = null,
    val documentIds: List<String>? = null,
    val selfReview: Boolean = false,
    /** Re-run for an existing user message (regenerate/continue): don't store the user turn again. */
    val persistUserMessage: Boolean = true,
    /** Run a multi-agent workflow (Researcher → Analyst → Critic → Writer → Verifier…) instead of a single answer. */
    val team: TeamWorkflow? = null,
    /** Live voice conversation (short spoken answers). */
    val voice: Boolean = false,
)

sealed interface ChatEvent {
    data class UserSaved(val message: ChatMessage) : ChatEvent
    data class Routed(val providerName: String, val mode: ExecutionMode, val locality: Locality, val reasons: List<String>) : ChatEvent
    data class Token(val text: String) : ChatEvent
    data class Activity(val item: ActivityItem) : ChatEvent
    data class Notice(val text: String) : ChatEvent
    data class MemoryConflict(val conflict: RememberResult.Conflict) : ChatEvent
    data class Completed(val message: ChatMessage) : ChatEvent
    data class Failed(val reason: String, val hint: String?, val alternatives: List<ProviderInfo>) : ChatEvent
}

/**
 * Orchestrates one turn: memory command → privacy check → local retrieval → routing → consent →
 * context building → agent loop → transparency trace → persistence → recovery on failure.
 */
class ChatEngine(
    private val repo: ConversationRepository,
    private val providers: () -> List<AiProvider>,
    private val router: ModelRouter,
    private val memory: MemoryEngine,
    private val documents: DocumentIndex,
    private val tools: ToolRegistry,
    private val agent: AgentRunner,
    private val consent: ConsentGate,
    private val device: () -> DeviceState,
    private val settings: () -> EngineSettings,
    private val diagnostics: Diagnostics,
    private val contextEngine: ContextEngine = ContextEngine(),
    private val direct: DirectResponder? = null,
    private val imageAnalyzer: ImageAnalyzer? = null,
    private val research: () -> ResearchPipeline? = { null },
    private val teamRunner: TeamRunner = TeamRunner(),
    /** Taught skills that match a message (see ai.astra.core.learn). */
    private val skillLookup: suspend (String) -> List<ai.astra.core.learn.Skill> = { emptyList() },
) {
    private val chatConsents = HashMap<String, MutableSet<String>>()

    fun send(request: ChatRequest): Flow<ChatEvent> = channelFlow {
        val cfg = settings()
        val conv = repo.conversation(request.conversationId)
        val project = conv?.projectId?.let { repo.project(it) }
        val userText = request.parts.plainText()

        val userMsg = ChatMessage(conversationId = request.conversationId, role = Role.USER, parts = request.parts)
        if (request.persistUserMessage) {
            repo.append(userMsg)
            send(ChatEvent.UserSaved(userMsg))
        }

        // 1. Explicit memory command — handled deterministically on-device, no model needed.
        MemoryClassifier.explicitRequest(userText)?.let { fact ->
            val result = memory.remember(fact, MemorySource.USER_EXPLICIT, projectId = conv?.projectId, conversationId = request.conversationId)
            val reply = when (result) {
                is RememberResult.Stored -> "Saved to memory: “${result.record.content}”"
                is RememberResult.Duplicate -> "I already have that in memory: “${result.existing.content}”"
                is RememberResult.Conflict -> {
                    send(ChatEvent.MemoryConflict(result))
                    "This conflicts with something I remember: “${result.existing.content}”. Choose which to keep."
                }
                is RememberResult.Refused -> "Not saved: ${result.reason}"
            }
            send(ChatEvent.Activity(ActivityItem(ActivityKind.MEMORY, "Memory", reply, ok = result is RememberResult.Stored || result is RememberResult.Duplicate)))
            val msg = ChatMessage(
                conversationId = request.conversationId, role = Role.ASSISTANT, parts = listOf(Part.Text(reply)),
                trace = ExecutionTrace("astra-memory", "Memory engine", Locality.ON_DEVICE, ExecutionMode.LOCAL, false, 0, emptyList(), listOf("memory"), 0, 0.0, 0, listOf("Memory command handled on device")),
            )
            repo.append(msg)
            send(ChatEvent.Token(reply))
            send(ChatEvent.Completed(msg))
            return@channelFlow
        }

        // 2. Privacy + local retrieval (always on-device).
        val privacy: PrivacyAssessment = PrivacyClassifier.assess(userText)
        val memories = if (cfg.useMemory) memory.recall(userText, conv?.projectId, request.conversationId).map { it.record } else emptyList()
        val profileMems = if (cfg.useMemory) memory.profile() else emptyList()
        val docs: List<DocHit> = if (cfg.useDocuments) documents.search(userText, request.documentIds, conv?.projectId) else emptyList()
        if (memories.isNotEmpty() || docs.isNotEmpty()) {
            send(ChatEvent.Activity(ActivityItem(ActivityKind.RETRIEVAL, "Found ${memories.size} memory item(s), ${docs.size} document passage(s)", docs.joinToString("\n") { it.citation })))
        }

        val tone = ai.astra.core.live.ToneReader.read(userText)
        val skills = runCatching { skillLookup(userText) }.getOrDefault(emptyList())
        if (skills.isNotEmpty()) send(ChatEvent.Activity(ActivityItem(ActivityKind.RETRIEVAL, "Using taught skill: ${skills.joinToString { it.name }}")))

        // 3. Route.
        val history = repo.messages(request.conversationId).filter { it.id != userMsg.id }
        val summary = repo.summary(request.conversationId)
        var parts = request.parts
        var needsVision = parts.any { it is Part.Image }
        val all = providers()
        // Vision fallback: no vision-capable model allowed → describe images with on-device OCR + labels.
        if (needsVision && imageAnalyzer != null) {
            val visionRoute = router.route(
                RouteRequest(userText, privacy, Complexity.LOW, TaskKind.CONVERSATION, needsVision = true, projectPrivate = project?.privateByDefault == true, forcedProviderId = request.forcedProviderId),
                all, device(), cfg.routerPolicy.copy(consentedProviderIds = cfg.routerPolicy.consentedProviderIds + chatConsents[request.conversationId].orEmpty()),
            )
            if (visionRoute is RouteDecision.NoRoute) {
                send(ChatEvent.Activity(ActivityItem(ActivityKind.RETRIEVAL, "Analyzing image on device (OCR + labels)")))
                parts = parts.map { p ->
                    if (p is Part.Image) {
                        val a = runCatching { imageAnalyzer.analyze(p.path) }.getOrElse { e -> diagnostics.log("vision", "Image analysis failed: ${e.message}"); null }
                        val text = a?.describe() ?: "The attached image could not be analyzed."
                        Part.Text(UntrustedFence.wrap(ContentSource.DOCUMENT, "attached photo", text, PromptInjectionDetector.assess(text).risk))
                    } else p
                }
                needsVision = false
                send(ChatEvent.Notice("No model here can see images — using on-device text recognition and labels instead."))
            }
        }
        val approxTokens = TokenEstimator.estimate(userText) + docs.sumOf { TokenEstimator.estimate(it.chunk.text) } + 600
        val routeReq = RouteRequest(
            text = userText, privacy = privacy,
            complexity = TaskAnalyzer.complexity(userText, approxTokens - TokenEstimator.estimate(userText)),
            kind = TaskAnalyzer.kind(userText), needsVision = needsVision, contextTokens = approxTokens,
            projectPrivate = project?.privateByDefault == true, forcedProviderId = request.forcedProviderId,
        )
        val policy = cfg.routerPolicy.copy(consentedProviderIds = cfg.routerPolicy.consentedProviderIds + chatConsents[request.conversationId].orEmpty())
        val decision = router.route(routeReq, all, device(), policy)
        if (decision is RouteDecision.NoRoute) {
            diagnostics.log("router", "No route: ${decision.reasons.joinToString("; ")}")
            // Direct tools still work with no model at all — clearly labelled as such.
            val directAnswer = direct?.answer(userText, conv?.projectId)
            if (directAnswer != null) {
                val msg = ChatMessage(
                    conversationId = request.conversationId, role = Role.ASSISTANT, parts = listOf(Part.Text(directAnswer.text)),
                    trace = ExecutionTrace("astra-direct", "Direct tool (no language model)", Locality.ON_DEVICE, ExecutionMode.LOCAL, false, 0, emptyList(),
                        listOf(directAnswer.tool), 0, 0.0, 0, decision.reasons + "Answered by a built-in tool because no model is available"),
                )
                repo.append(msg)
                send(ChatEvent.Token(directAnswer.text))
                send(ChatEvent.Completed(msg))
                return@channelFlow
            }
            send(ChatEvent.Failed(decision.reasons.lastOrNull() ?: "No model available", decision.hint, emptyList()))
            return@channelFlow
        }
        decision as RouteDecision.Route
        var chosen = decision.provider
        var mode = decision.mode
        val reasons = decision.reasons.toMutableList()
        send(ChatEvent.Activity(ActivityItem(ActivityKind.ROUTING, "Route: ${mode.name} → ${chosen.info.displayName}", reasons.joinToString("\n"))))

        fun inputs(local: Boolean) = ContextInputs(
            profile = cfg.profile, projectName = project?.name, projectInstructions = project?.instructions,
            toolManual = if (request.mode == AssistMode.CHAT) "" else tools.manual(),
            profileMemories = profileMems, relevantMemories = memories, documents = docs,
            historySummary = summary?.first, history = history.filter { summary == null || it.createdAt > summary.second },
            userParts = parts, nowText = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEE d MMM yyyy HH:mm z")), modelLocal = local,
            skills = skills, tone = tone, voice = request.voice,
        )
        val plan = ThermalGovernor.plan(device(), cfg.routerPolicy.energy, cfg.maxOutputTokens)
        plan.notes.forEach { send(ChatEvent.Notice(it)) }
        fun buildFor(p: AiProvider): BuiltContext {
            val window = (p.info.scores.contextWindow * plan.contextFraction).toInt().coerceAtLeast(1024)
            return contextEngine.build(inputs(p.info.locality == Locality.ON_DEVICE), window, minOf(plan.maxOutputTokens, window / 3))
        }
        var context = buildFor(chosen)

        // 4. Consent before anything leaves the device.
        if (decision.consentRequired) {
            val answer = consent.ask(
                ConsentRequest(chosen.info, context.dataSentSummary, privacy.kinds, context.totalTokens * 4L, reasons)
            )
            when (answer) {
                ConsentAnswer.DENY -> {
                    val local = decision.fallback
                    if (local == null) {
                        send(ChatEvent.Failed("Not sent — you declined sending to ${chosen.info.displayName}", "Install a local model to answer privately on the device.", emptyList()))
                        return@channelFlow
                    }
                    send(ChatEvent.Notice("Kept on device: answering with ${local.info.displayName}"))
                    chosen = local; mode = ExecutionMode.LOCAL; reasons += "You declined sending; using on-device model"
                    context = buildFor(chosen)
                }
                ConsentAnswer.ALLOW_FOR_CHAT -> { chatConsents.getOrPut(request.conversationId) { HashSet() } += chosen.info.id; reasons += "You approved sending for this chat" }
                ConsentAnswer.ALLOW_ONCE -> reasons += "You approved sending once"
            }
        }
        context.warnings.forEach { send(ChatEvent.Notice(it)) }
        send(ChatEvent.Routed(chosen.info.displayName, mode, chosen.info.locality, reasons))

        // 5. Generate (with recovery).
        val template = GenerationRequest(context.turns, plan.maxOutputTokens, cfg.temperature)
        val limits = AgentLimits.forMode(request.mode).copy(allowNetworkTools = cfg.allowNetworkTools && device().online)
        val started = System.currentTimeMillis()
        var outcome: AgentOutcome? = null
        var teamIssues: String? = null
        var attempt = 0
        while (outcome == null) {
            try {
                val turnsNow = if (attempt == 0) context.turns else buildFor(chosen).turns
                outcome = if (request.team != null) {
                    val t = teamRunner.run(chosen, request.team, turnsNow, template,
                        onStage = { role -> send(ChatEvent.Notice("Team: ${role.title} working…")) },
                        onToken = { send(ChatEvent.Token(it)) },
                        onActivity = { send(ChatEvent.Activity(it)) })
                    teamIssues = t.issues
                    AgentOutcome(t.finalText, listOf("team:${request.team.id}"), t.stages.size, 0, emptyList(),
                        ai.astra.core.provider.GenerationStats(t.tokens, t.durationMs, 0, 0, 0), null, 0, t.verified != null)
                } else agent.run(
                    chosen, turnsNow, template, request.mode, limits, request.selfReview,
                    onToken = { send(ChatEvent.Token(it)) },
                    onActivity = { send(ChatEvent.Activity(it)) },
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: ProviderException) {
                diagnostics.log("provider", "${chosen.info.id}: ${e.kind} ${e.message}")
                val networkFailure = chosen.info.locality.usesNetwork && e.kind in setOf(ProviderErrorKind.NETWORK, ProviderErrorKind.TIMEOUT)
                val local = all.firstOrNull { it.info.locality == Locality.ON_DEVICE && it.availability() == Availability.Ready }
                if (networkFailure && local != null && attempt == 0) {
                    send(ChatEvent.Activity(ActivityItem(ActivityKind.RECOVERY, "Network lost — switched to ${local.info.displayName}", e.message ?: "", ok = false)))
                    send(ChatEvent.Notice("Connection lost. Continuing on the device."))
                    chosen = local; mode = ExecutionMode.LOCAL; reasons += "Recovered from network failure on device"
                    attempt++
                    continue
                }
                val alternatives = all.filter { it !== chosen && it.availability() == Availability.Ready }.map { it.info }
                val hint = when (e.kind) {
                    ProviderErrorKind.AUTH -> "Check the API key for ${chosen.info.displayName} in Models."
                    ProviderErrorKind.RATE_LIMIT -> "Rate-limited. Try again shortly or pick another model."
                    ProviderErrorKind.MODEL_CRASH -> "The local model stopped. You can reload it or retry with another configured model."
                    else -> if (alternatives.isNotEmpty()) "Retry with another model." else null
                }
                send(ChatEvent.Failed("${chosen.info.displayName}: ${e.message}", hint, alternatives))
                return@channelFlow
            } catch (e: Exception) {
                diagnostics.log("engine", "Unexpected: ${e::class.simpleName}: ${e.message}")
                send(ChatEvent.Failed("Unexpected error: ${e.message}", null, emptyList()))
                return@channelFlow
            }
        }
        val o = outcome!!

        // 6. Transparency trace + persistence.
        val trace = ExecutionTrace(
            providerId = chosen.info.id, model = chosen.info.model, locality = chosen.info.locality,
            mode = if (mode == ExecutionMode.LOCAL && o.toolsUsed.any { tools.get(it)?.spec?.usesNetwork == true }) ExecutionMode.HYBRID else mode,
            networkUsed = chosen.info.locality.usesNetwork || o.toolsUsed.any { tools.get(it)?.spec?.usesNetwork == true },
            bytesSent = o.stats.bytesSent,
            dataSent = if (chosen.info.locality.usesNetwork) context.dataSentSummary else emptyList(),
            tools = o.toolsUsed, tokensOut = o.stats.tokensOut, tokensPerSecond = o.stats.tokensPerSecond,
            latencyMs = System.currentTimeMillis() - started, routeReasons = reasons, warnings = context.warnings,
            verification = if (request.mode == AssistMode.CHAT && !request.selfReview && request.team == null) null else VerificationSummary(
                steps = o.steps, toolCalls = o.toolsUsed.size + o.toolFailures, toolFailures = o.toolFailures,
                calculationsVerified = o.calculationsVerified, sourcesUsed = docs.size, selfReview = o.selfReviewed,
                uncertainties = buildList {
                    if (o.injectionWarnings > 0) add("${o.injectionWarnings} tool result(s) contained instruction-like text")
                    teamIssues?.let { add("Verifier: ${it.take(300)}") }
                },
                limitsHit = o.limitsHit,
            ),
        )
        val answer = ChatMessage(conversationId = request.conversationId, role = Role.ASSISTANT, parts = listOf(Part.Text(o.text)), trace = trace)
        repo.append(answer)
        diagnostics.recordGeneration(chosen.info, o.stats)
        send(ChatEvent.Completed(answer))

        // 7. Context compression when the conversation grows.
        maybeCompress(request.conversationId, chosen.info.scores.contextWindow)
    }


    /**
     * Web research: QUESTION → SEARCH → SOURCES → TRUST → CROSS-CHECK → SYNTHESIS → CITATIONS.
     * HYBRID when the web is searched online and the answer is written by the on-device model.
     */
    fun research(conversationId: String, question: String): Flow<ChatEvent> = channelFlow {
        val cfg = settings()
        val parts = listOf(Part.Text("/research $question"))
        val userMsg = ChatMessage(conversationId = conversationId, role = Role.USER, parts = parts)
        repo.append(userMsg)
        send(ChatEvent.UserSaved(userMsg))
        val pipeline = research()
        when {
            cfg.routerPolicy.dataControl == DataControl.NEVER_SEND -> {
                send(ChatEvent.Failed("Web research needs the internet, and “Never send my data online” is on.", "Turn it off in Settings → Privacy to allow web research.", emptyList())); return@channelFlow
            }
            !device().online -> { send(ChatEvent.Failed("Requires internet.", "Connect to the internet to research the web. Saved pages are in Files.", emptyList())); return@channelFlow }
            pipeline == null -> { send(ChatEvent.Failed("Web research: Requires provider", "Choose a search provider in Settings → Web research.", emptyList())); return@channelFlow }
        }
        pipeline!!
        val privacy = PrivacyClassifier.assess(question)
        val sensitive = privacy.level >= Sensitivity.MEDIUM
        val searchInfo = ProviderInfo("web:search", "Web search", "search", Locality.REMOTE, emptySet(), ai.astra.core.provider.ModelCapabilities(), "HTTPS")
        val askSearch = "web:search" !in chatConsents[conversationId].orEmpty() && when (cfg.routerPolicy.dataControl) {
            DataControl.ASK_BEFORE_SENDING -> true
            DataControl.ASK_FOR_SENSITIVE -> sensitive
            DataControl.ALLOW -> privacy.level == Sensitivity.HIGH
            DataControl.NEVER_SEND -> true
        }
        if (askSearch) {
            when (consent.ask(ConsentRequest(searchInfo, listOf("your question as a search query", "requests to up to 5 public web pages"), privacy.kinds, question.length.toLong() + 2000, listOf("Web research")))) {
                ConsentAnswer.DENY -> { send(ChatEvent.Failed("Not searched — you kept it on the phone.", null, emptyList())); return@channelFlow }
                ConsentAnswer.ALLOW_FOR_CHAT -> chatConsents.getOrPut(conversationId) { HashSet() } += "web:search"
                ConsentAnswer.ALLOW_ONCE -> Unit
            }
        }
        // Writer model: normal routing rules; sources are public, but the question may be personal.
        val decision = router.route(RouteRequest(question, privacy, Complexity.MEDIUM, TaskKind.RESEARCH, contextTokens = 3500), providers(), device(),
            cfg.routerPolicy.copy(consentedProviderIds = cfg.routerPolicy.consentedProviderIds + chatConsents[conversationId].orEmpty()))
        var writer: AiProvider? = (decision as? RouteDecision.Route)?.provider
        if (decision is RouteDecision.Route && decision.consentRequired) {
            when (consent.ask(ConsentRequest(decision.provider.info, listOf("your question", "passages from the web sources"), privacy.kinds, 12_000, decision.reasons))) {
                ConsentAnswer.DENY -> writer = decision.fallback
                ConsentAnswer.ALLOW_FOR_CHAT -> chatConsents.getOrPut(conversationId) { HashSet() } += decision.provider.info.id
                ConsentAnswer.ALLOW_ONCE -> Unit
            }
        }
        val started = System.currentTimeMillis()
        send(ChatEvent.Routed(writer?.info?.displayName ?: "Web search", if (writer?.info?.locality == Locality.ON_DEVICE) ExecutionMode.HYBRID else ExecutionMode.ONLINE,
            writer?.info?.locality ?: Locality.REMOTE, listOf("Web research")))
        val report = try {
            pipeline.run(question, writer,
                onStep = { step, detail -> send(ChatEvent.Activity(ActivityItem(ActivityKind.TOOL_CALL, step, detail))) },
                onToken = { send(ChatEvent.Token(it)) }, maxOutputTokens = cfg.maxOutputTokens)
        } catch (e: CancellationException) { throw e } catch (e: Exception) {
            diagnostics.log("research", e.message ?: "failed")
            send(ChatEvent.Failed("Research failed: ${e.message}", null, emptyList())); return@channelFlow
        }
        val sourcesMd = report.sourcesMarkdown()
        send(ChatEvent.Token(sourcesMd))
        val writerNetwork = writer?.info?.locality?.usesNetwork == true
        val trace = ExecutionTrace(
            providerId = writer?.info?.id ?: "astra-research", model = writer?.info?.model ?: "Extractive (no model)",
            locality = writer?.info?.locality ?: Locality.ON_DEVICE,
            mode = if (writerNetwork) ExecutionMode.ONLINE else ExecutionMode.HYBRID, networkUsed = true, bytesSent = 0,
            dataSent = buildList { add("search query"); add("${report.sources.size} page request(s)"); if (writerNetwork) add("question + source passages to ${writer?.info?.displayName}") },
            tools = listOf("web_search", "web_fetch"), tokensOut = 0, tokensPerSecond = 0.0, latencyMs = System.currentTimeMillis() - started,
            routeReasons = listOf("Web research via search provider") + ((decision as? RouteDecision.Route)?.reasons ?: emptyList()),
            verification = VerificationSummary(
                steps = report.queries.size + report.sources.size + 1, toolCalls = report.queries.size + report.sources.size, toolFailures = report.failures.size,
                calculationsVerified = null, sourcesUsed = report.sources.count { it.duplicateOf == null }, selfReview = false,
                uncertainties = report.conflicts.map { c -> "Sources disagree on ${c.topic}" } + report.sources.filter { it.trust < 0.5 }.map { "Low-trust source: ${it.domain}" },
                limitsHit = emptyList(),
            ),
        )
        val msg = ChatMessage(conversationId = conversationId, role = Role.ASSISTANT, parts = listOf(Part.Text(report.answer + sourcesMd)), trace = trace)
        repo.append(msg)
        send(ChatEvent.Completed(msg))
    }

    /**
     * One routed generation outside any conversation (task breakdown, quick actions). The same
     * privacy, consent and routing rules apply; nothing is persisted.
     */
    suspend fun oneShot(prompt: String, maxTokens: Int = 700, localOnly: Boolean = false): Result<String> {
        val cfg = settings()
        val privacy = PrivacyClassifier.assess(prompt)
        val request = RouteRequest(prompt, privacy, TaskAnalyzer.complexity(prompt), TaskAnalyzer.kind(prompt))
        val policy = if (localOnly) cfg.routerPolicy.copy(preference = ai.astra.core.router.RoutePreference.LOCAL_ONLY) else cfg.routerPolicy
        val decision = router.route(request, providers(), device(), policy)
        if (decision is RouteDecision.NoRoute) return Result.failure(IllegalStateException("${decision.reasons.lastOrNull() ?: "No model"} — ${decision.hint}"))
        decision as RouteDecision.Route
        var provider = decision.provider
        if (decision.consentRequired) {
            val answer = consent.ask(ConsentRequest(provider.info, listOf("this one request"), privacy.kinds, prompt.length.toLong(), decision.reasons))
            if (answer == ConsentAnswer.DENY) provider = decision.fallback ?: return Result.failure(IllegalStateException("Not sent — you declined"))
        }
        val ctx = contextEngine.build(
            ContextInputs(profile = cfg.profile, userParts = listOf(Part.Text(prompt)), nowText = ZonedDateTime.now().toString(), modelLocal = provider.info.locality == Locality.ON_DEVICE),
            provider.info.scores.contextWindow, maxTokens,
        )
        return try {
            Result.success(ThinkFilter.strip(provider.generate(GenerationRequest(ctx.turns, maxTokens, 0.3)).text))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            diagnostics.log("oneShot", "${provider.info.id}: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun resolveMemoryConflict(conflict: RememberResult.Conflict, resolution: ai.astra.core.memory.ConflictResolution) =
        memory.resolveConflict(conflict, resolution)

    private suspend fun maybeCompress(conversationId: String, window: Int) {
        val msgs = repo.messages(conversationId)
        val prior = repo.summary(conversationId)
        val live = msgs.filter { prior == null || it.createdAt > prior.second }
        val tokens = live.sumOf { TokenEstimator.estimate(it.text) }
        if (tokens < window * 0.6 || live.size <= 10) return
        val toCompress = live.dropLast(8)
        val newSummary = listOfNotNull(prior?.first, ConversationCompressor.compress(toCompress)).joinToString("\n").lines().takeLast(40).joinToString("\n")
        repo.setSummary(conversationId, newSummary, toCompress.last().createdAt)
        diagnostics.log("context", "Compressed ${toCompress.size} messages into summary")
    }
}
