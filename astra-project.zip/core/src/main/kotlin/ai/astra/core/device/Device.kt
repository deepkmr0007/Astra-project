package ai.astra.core.device

import ai.astra.core.provider.GenerationRequest

enum class ThermalLevel { NONE, LIGHT, MODERATE, SEVERE, CRITICAL }

enum class EnergyMode { PERFORMANCE, BALANCED, BATTERY_SAVER }

/** Snapshot of the device as reported by platform APIs. Unknown values are null, never guessed. */
data class DeviceState(
    val online: Boolean,
    val metered: Boolean = false,
    val batteryPercent: Int? = null,
    val charging: Boolean = false,
    val thermal: ThermalLevel = ThermalLevel.NONE,
    val totalRamMb: Long? = null,
    val availableRamMb: Long? = null,
    val freeStorageMb: Long? = null,
    val cpuCores: Int = Runtime.getRuntime().availableProcessors(),
    val batteryTempC: Double? = null,
)

/** Generation limits after applying energy mode and thermal state. */
data class ThrottlePlan(
    val maxOutputTokens: Int,
    val contextFraction: Double,
    val allowLargeLocalModels: Boolean,
    val pauseRecommended: Boolean,
    val notes: List<String>,
)

object ThermalGovernor {
    fun plan(device: DeviceState, energy: EnergyMode, requestedMaxTokens: Int): ThrottlePlan {
        val notes = ArrayList<String>()
        var tokens = requestedMaxTokens
        var ctx = 1.0
        var large = true
        when (energy) {
            EnergyMode.PERFORMANCE -> Unit
            EnergyMode.BALANCED -> if (!device.charging && (device.batteryPercent ?: 100) < 20) {
                tokens = minOf(tokens, 512); ctx = 0.6; large = false; notes += "Battery below 20%: shorter answers"
            }
            EnergyMode.BATTERY_SAVER -> { tokens = minOf(tokens, 384); ctx = 0.5; large = false; notes += "Battery Saver: small model, short context" }
        }
        when (device.thermal) {
            ThermalLevel.NONE, ThermalLevel.LIGHT -> Unit
            ThermalLevel.MODERATE -> { tokens = minOf(tokens, 512); ctx = minOf(ctx, 0.7); notes += "Phone is warm: reduced load" }
            ThermalLevel.SEVERE -> { tokens = minOf(tokens, 256); ctx = minOf(ctx, 0.5); large = false; notes += "Phone is hot: minimal load" }
            ThermalLevel.CRITICAL -> { tokens = minOf(tokens, 128); ctx = minOf(ctx, 0.4); large = false; notes += "Phone is very hot: pause recommended" }
        }
        return ThrottlePlan(tokens, ctx, large, device.thermal >= ThermalLevel.CRITICAL, notes)
    }

    fun apply(request: GenerationRequest, plan: ThrottlePlan): GenerationRequest =
        request.copy(maxOutputTokens = minOf(request.maxOutputTokens, plan.maxOutputTokens))
}
