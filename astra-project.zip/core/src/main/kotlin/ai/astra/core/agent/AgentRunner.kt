package ai.astra.core.agent

import ai.astra.core.json.Json
import ai.astra.core.model.AssistMode
import ai.astra.core.model.ContentSource
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.GenerationStats
import ai.astra.core.provider.PromptTurn
import ai.astra.core.provider.StreamEvent
import ai.astra.core.security.FirewallDecision
import ai.astra.core.security.PromptInjectionDetector
import ai.astra.core.security.Sensitivity
import ai.astra.core.security.ToolFirewall
import ai.astra.core.security.UntrustedFence
import ai.astra.core.text.ThinkFilter
import ai.astra.core.tools.ToolCallParser
import ai.astra.core.tools.ToolCallStreamFilter
import ai.astra.core.tools.ToolRegistry
import ai.astra.core.tools.ToolResult

data class AgentLimits(
    val maxSteps: Int,
    val timeLimitMs: Long,
    val tokenLimit: Int,
    val allowNetworkTools: Boolean = false,
    val allowedTools: Set<String>? = null,
) {
    companion object {
        fun forMode(mode: AssistMode) = when (mode) {
            AssistMode.CHAT -> AgentLimits(maxSteps = 1, timeLimitMs = 180_000, tokenLimit = 4096)
            AssistMode.ASSIST -> AgentLimits(maxSteps = 3, timeLimitMs = 180_000, tokenLimit = 6000)
            AssistMode.AGENT -> AgentLimits(maxSteps = 8, timeLimitMs = 300_000, tokenLimit = 12000)
        }
    }
}

enum class ActivityKind { ROUTING, RETRIEVAL, MEMORY, TOOL_CALL, TOOL_RESULT, POLICY, VERIFY, RECOVERY }

data class ActivityItem(
    val kind: ActivityKind,
    val title: String,
    val detail: String = "",
    val ok: Boolean = true,
    val time: Long = System.currentTimeMillis(),
)

data class AgentOutcome(
    val text: String,
    val toolsUsed: List<String>,
    val steps: Int,
    val toolFailures: Int,
    val limitsHit: List<String>,
    val stats: GenerationStats,
    val calculationsVerified: Boolean?,
    val injectionWarnings: Int,
    val selfReviewed: Boolean,
)

/**
 * Controlled agent loop: UNDERSTAND → PLAN → REQUEST TOOLS → EXECUTE → OBSERVE → VERIFY → COMPLETE.
 * Every tool call passes the [ToolFirewall]; steps, time and tokens are bounded; tool output is
 * fenced as untrusted data before it is shown to the model again.
 */
class AgentRunner(private val tools: ToolRegistry, private val firewall: ToolFirewall) {

    suspend fun run(
        provider: AiProvider,
        baseTurns: List<PromptTurn>,
        template: GenerationRequest,
        mode: AssistMode,
        limits: AgentLimits,
        selfReview: Boolean,
        onToken: suspend (String) -> Unit,
        onActivity: suspend (ActivityItem) -> Unit,
    ): AgentOutcome {
        val started = System.currentTimeMillis()
        val turns = baseTurns.toMutableList()
        val toolsUsed = ArrayList<String>()
        val limitsHit = ArrayList<String>()
        var failures = 0
        var injection = 0
        var calcVerified: Boolean? = null
        var tokensOut = 0
        var bytesSent = 0L
        var bytesRecv = 0L
        var firstToken = -1L
        var finalText = ""
        var steps = 0

        while (true) {
            steps++
            val filter = ToolCallStreamFilter()
            val think = ThinkFilter()
            val raw = StringBuilder()
            provider.stream(template.copy(turns = turns)).collect { e ->
                when (e) {
                    is StreamEvent.Token -> {
                        if (firstToken < 0) firstToken = System.currentTimeMillis() - started
                        raw.append(e.text)
                        val unthought = think.accept(e.text)
                        val visible = if (mode == AssistMode.CHAT) unthought else filter.accept(unthought)
                        if (visible.isNotEmpty()) onToken(visible)
                    }
                    is StreamEvent.Done -> {
                        tokensOut += e.stats.tokensOut; bytesSent += e.stats.bytesSent; bytesRecv += e.stats.bytesReceived
                    }
                }
            }
            val tail = think.finish()
            val tailVisible = if (mode == AssistMode.CHAT) tail else filter.accept(tail) + filter.finish()
            if (tailVisible.isNotEmpty()) onToken(tailVisible)
            val text = ThinkFilter.strip(raw.toString())
            val calls = if (mode == AssistMode.CHAT) emptyList() else ToolCallParser.parse(text)
            finalText = ToolCallParser.stripCalls(text)
            if (calls.isEmpty()) break

            val elapsed = System.currentTimeMillis() - started
            when {
                steps >= limits.maxSteps -> limitsHit += "max steps (${limits.maxSteps})"
                elapsed >= limits.timeLimitMs -> limitsHit += "time limit (${limits.timeLimitMs / 1000}s)"
                tokensOut >= limits.tokenLimit -> limitsHit += "token limit (${limits.tokenLimit})"
            }
            if (limitsHit.isNotEmpty()) {
                onActivity(ActivityItem(ActivityKind.POLICY, "Stopped: ${limitsHit.joinToString()}", ok = false))
                if (finalText.isBlank()) finalText = "I stopped before finishing because a safety limit was reached (${limitsHit.joinToString()})."
                break
            }

            turns += PromptTurn(Role.ASSISTANT, listOf(Part.Text(text)), setOf(ContentSource.USER))
            for (call in calls) {
                val tool = tools.get(call.name)
                val argsText = Json.write(call.arguments)
                onActivity(ActivityItem(ActivityKind.TOOL_CALL, "${call.name}", argsText))
                val resultText: String = if (tool == null) {
                    failures++
                    "Error: unknown tool '${call.name}'"
                } else if (tool.spec.usesNetwork && !limits.allowNetworkTools) {
                    failures++
                    onActivity(ActivityItem(ActivityKind.POLICY, "Blocked network tool ${call.name}", "Network tools are not allowed for this request", ok = false))
                    "Error: tool '${call.name}' needs the internet, which is not allowed for this request"
                } else when (val d = firewall.authorize(call.name, tool.spec.risk, tool.spec.permissions, mode, argsText, limits.allowedTools)) {
                    is FirewallDecision.Denied -> {
                        failures++
                        onActivity(ActivityItem(ActivityKind.POLICY, "Denied ${call.name}", d.reason, ok = false))
                        "Error: tool call denied (${d.reason})"
                    }
                    FirewallDecision.Allowed -> when (val r = runCatching { tool.run(call.arguments) }.getOrElse { ToolResult.Error("Tool crashed: ${it.message}") }) {
                        is ToolResult.Ok -> {
                            toolsUsed += call.name
                            if (call.name == "calculator") calcVerified = true
                            onActivity(ActivityItem(ActivityKind.TOOL_RESULT, "${call.name} ✓", r.output.take(500)))
                            r.output
                        }
                        is ToolResult.Error -> {
                            failures++
                            if (call.name == "calculator") calcVerified = false
                            onActivity(ActivityItem(ActivityKind.TOOL_RESULT, "${call.name} failed", r.message, ok = false))
                            "Error: ${r.message}"
                        }
                    }
                }
                val inj = PromptInjectionDetector.assess(resultText)
                if (inj.risk >= Sensitivity.MEDIUM) injection++
                turns += PromptTurn(Role.TOOL, listOf(Part.Text(UntrustedFence.wrap(ContentSource.TOOL_RESULT, call.name, resultText, inj.risk))), setOf(ContentSource.TOOL_RESULT))
            }
            onToken("\n")
        }

        var reviewed = false
        if (selfReview && finalText.isNotBlank() && limitsHit.isEmpty()) {
            onActivity(ActivityItem(ActivityKind.VERIFY, "Self-review pass"))
            val critique = turns + PromptTurn(Role.ASSISTANT, listOf(Part.Text(finalText)), setOf(ContentSource.USER)) +
                PromptTurn(Role.USER, listOf(Part.Text(REVIEW_PROMPT)), setOf(ContentSource.SYSTEM))
            val review = runCatching { provider.generate(template.copy(turns = critique, temperature = 0.2)) }.getOrNull()
            if (review != null) {
                tokensOut += review.stats.tokensOut; bytesSent += review.stats.bytesSent; bytesRecv += review.stats.bytesReceived
                val verdict = ThinkFilter.strip(review.text)
                reviewed = true
                if (!verdict.startsWith("OK", ignoreCase = true) && verdict.length > 20) {
                    onActivity(ActivityItem(ActivityKind.VERIFY, "Self-review revised the answer"))
                    finalText = verdict.removePrefix("REVISED:").trim()
                    onToken("\n\n— revised after self-review —\n$finalText")
                } else onActivity(ActivityItem(ActivityKind.VERIFY, "Self-review: no issues found"))
            }
        }

        val duration = System.currentTimeMillis() - started
        return AgentOutcome(
            text = finalText,
            toolsUsed = toolsUsed.distinct(),
            steps = steps,
            toolFailures = failures,
            limitsHit = limitsHit,
            stats = GenerationStats(tokensOut, duration, firstToken.coerceAtLeast(0), bytesSent, bytesRecv),
            calculationsVerified = calcVerified,
            injectionWarnings = injection,
            selfReviewed = reviewed,
        )
    }

    companion object {
        const val REVIEW_PROMPT =
            "Check your previous answer for factual, logical or arithmetic errors and for anything not supported by the tool results or documents. " +
                "If it is correct, reply with exactly: OK. If not, reply with REVISED: followed by the corrected full answer."
    }
}
