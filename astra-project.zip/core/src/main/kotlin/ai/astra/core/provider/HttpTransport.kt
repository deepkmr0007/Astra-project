package ai.astra.core.provider

import ai.astra.core.model.Locality
import java.io.BufferedReader
import java.io.Closeable
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.nio.charset.StandardCharsets

data class HttpRequest(
    val url: String,
    val method: String = "POST",
    val headers: Map<String, String> = emptyMap(),
    val body: String? = null,
    val connectTimeoutMs: Int = 15_000,
    val readTimeoutMs: Int = 120_000,
)

class HttpResponse(
    val status: Int,
    val headers: Map<String, String>,
    private val stream: InputStream,
    private val onClose: () -> Unit = {},
) : Closeable {
    var bytesReceived: Long = 0
        private set

    private val reader by lazy { BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)) }

    /** Reads the next line, or null at end of stream. Counts bytes for transparency stats. */
    fun readLine(): String? = reader.readLine()?.also { bytesReceived += it.toByteArray(StandardCharsets.UTF_8).size + 1 }

    fun readText(): String = buildString {
        while (true) { append(readLine() ?: break); append('\n') }
    }

    fun header(name: String): String? = headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value

    override fun close() {
        runCatching { reader.close() }
        onClose()
    }
}

/** Blocking HTTP transport; callers run it on an IO dispatcher. Swappable for tests. */
fun interface HttpTransport {
    fun open(request: HttpRequest): HttpResponse
}

/**
 * Network kill-switch shared by every network-capable component. When private mode is on, no
 * request leaves the device regardless of what the router or a plugin decides (defense in depth).
 */
class NetworkGate {
    @Volatile var privateMode: Boolean = false
    @Volatile var allowLanInPrivateMode: Boolean = false
    @Volatile var requests: Long = 0
        private set
    @Volatile var blocked: Long = 0
        private set

    fun check(locality: Locality, url: String) {
        if (privateMode && !(locality == Locality.LAN && allowLanInPrivateMode)) {
            blocked++
            throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Blocked by private mode (\"Never send my data online\"): ${hostOf(url)}")
        }
        requests++
    }
}

fun hostOf(url: String): String = runCatching { java.net.URI(url).toURL().host }.getOrDefault("?")

/** True for loopback, link-local and RFC1918 / CGNAT addresses or *.local names. */
fun isPrivateHost(host: String): Boolean {
    if (host.equals("localhost", true) || host.endsWith(".local", true)) return true
    val literal = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host) || host.contains(':')
    if (!literal) return false
    return runCatching {
        val a = InetAddress.getByName(host)
        a.isLoopbackAddress || a.isSiteLocalAddress || a.isLinkLocalAddress ||
            (a.address.size == 4 && (a.address[0].toInt() and 0xFF) == 100 && (a.address[1].toInt() and 0xC0) == 64)
    }.getOrDefault(false)
}

/**
 * HttpURLConnection-based transport (works on Android and the JVM, no extra dependency).
 * TLS is mandatory for anything that is not a private/LAN address. Certificate validation is
 * always the platform default; this class never installs a permissive TrustManager.
 */
class UrlConnectionTransport(private val gate: NetworkGate, private val locality: Locality) : HttpTransport {
    override fun open(request: HttpRequest): HttpResponse {
        val url = java.net.URI(request.url).toURL()
        if (url.protocol != "https" && !(url.protocol == "http" && isPrivateHost(url.host))) {
            throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Refusing plain HTTP to a public host (${url.host}); use https://")
        }
        gate.check(locality, request.url)
        val conn = try {
            (url.openConnection() as HttpURLConnection).apply {
                requestMethod = request.method
                connectTimeout = request.connectTimeoutMs
                readTimeout = request.readTimeoutMs
                instanceFollowRedirects = false
                useCaches = false
                request.headers.forEach { (k, v) -> setRequestProperty(k, v) }
                if (request.body != null) {
                    doOutput = true
                    val bytes = request.body.toByteArray(StandardCharsets.UTF_8)
                    setFixedLengthStreamingMode(bytes.size)
                    outputStream.use { it.write(bytes) }
                }
            }
        } catch (e: UnknownHostException) {
            throw ProviderException(ProviderErrorKind.NETWORK, "Cannot resolve ${url.host} (offline?)", cause = e)
        } catch (e: SocketTimeoutException) {
            throw ProviderException(ProviderErrorKind.TIMEOUT, "Connection to ${url.host} timed out", cause = e)
        } catch (e: java.io.IOException) {
            throw ProviderException(ProviderErrorKind.NETWORK, "Network error: ${e.message}", cause = e)
        }
        val status = try { conn.responseCode } catch (e: java.io.IOException) {
            conn.disconnect()
            throw ProviderException(ProviderErrorKind.NETWORK, "No response from ${url.host}: ${e.message}", cause = e)
        }
        val headers = conn.headerFields.filterKeys { it != null }.mapValues { it.value.joinToString(",") }
        val body = (if (status >= 400) conn.errorStream else conn.inputStream) ?: java.io.ByteArrayInputStream(ByteArray(0))
        return HttpResponse(status, headers, body) { conn.disconnect() }
    }
}

/** Shared error mapping + bounded retry for providers (only before streaming has started). */
internal fun openWithRetry(transport: HttpTransport, request: HttpRequest, maxRetries: Int = 2): HttpResponse {
    var attempt = 0
    while (true) {
        val resp = transport.open(request)
        if (resp.status in 200..299) return resp
        val errorBody = runCatching { resp.readText().take(600) }.getOrDefault("")
        resp.close()
        val retryAfter = resp.header("retry-after")?.trim()?.toLongOrNull()?.times(1000)
        val kind = when (resp.status) {
            401, 403 -> ProviderErrorKind.AUTH
            429 -> ProviderErrorKind.RATE_LIMIT
            in 500..599 -> ProviderErrorKind.SERVER
            else -> ProviderErrorKind.BAD_RESPONSE
        }
        val retryable = kind == ProviderErrorKind.RATE_LIMIT || kind == ProviderErrorKind.SERVER
        if (!retryable || attempt >= maxRetries) {
            throw ProviderException(kind, "HTTP ${resp.status}: ${sanitizeError(errorBody)}", retryAfter)
        }
        val wait = (retryAfter ?: (1000L shl attempt)).coerceAtMost(15_000)
        Thread.sleep(wait)
        attempt++
    }
}

private fun sanitizeError(body: String): String =
    ai.astra.core.security.Redactor.redact(body.replace(Regex("\\s+"), " ").trim())
