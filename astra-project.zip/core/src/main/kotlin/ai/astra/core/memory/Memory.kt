package ai.astra.core.memory

import ai.astra.core.model.newId
import ai.astra.core.security.PrivacyClassifier
import ai.astra.core.security.Sensitivity
import ai.astra.core.text.Bm25
import ai.astra.core.text.Tokenizer

enum class MemoryType { SHORT_TERM, SESSION, LONG_TERM, PROJECT, USER_PROFILE, DOCUMENT, TASK }

enum class MemorySource { USER_EXPLICIT, AUTO_CAPTURE, CORRECTION, DOCUMENT, IMPORT, CONSOLIDATION }

enum class PrivacyLevel { PUBLIC, PERSONAL, SENSITIVE }

enum class MemoryClass { TEMPORARY, USEFUL, PERSISTENT, PROJECT_SPECIFIC, IRRELEVANT }

data class MemoryRecord(
    val id: String = newId(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
    val source: MemorySource,
    val type: MemoryType,
    val importance: Double,
    val confidence: Double,
    val privacyLevel: PrivacyLevel,
    val projectId: String?,
    val conversationId: String? = null,
    val content: String,
    val embedding: FloatArray,
    val embedderId: String,
    val expiry: Long? = null,
    val userEditable: Boolean = true,
    /** Normalized subject (e.g. "my home city") used to detect contradicting facts. */
    val subjectKey: String? = null,
    val pinned: Boolean = false,
) {
    fun isExpired(now: Long = System.currentTimeMillis()) = expiry != null && expiry <= now
    override fun equals(other: Any?) = other is MemoryRecord && other.id == id && other.updatedAt == updatedAt && other.content == content
    override fun hashCode() = id.hashCode()
}

/** Persistence port. The app implements it with Room; tests use [InMemoryMemoryStore]. */
interface MemoryStore {
    suspend fun upsert(record: MemoryRecord)
    suspend fun get(id: String): MemoryRecord?
    suspend fun delete(id: String): Boolean
    suspend fun all(): List<MemoryRecord>
    suspend fun clear()
}

class InMemoryMemoryStore : MemoryStore {
    private val map = LinkedHashMap<String, MemoryRecord>()
    private val lock = Any()
    override suspend fun upsert(record: MemoryRecord) { synchronized(lock) { map[record.id] = record } }
    override suspend fun get(id: String) = synchronized(lock) { map[id] }
    override suspend fun delete(id: String) = synchronized(lock) { map.remove(id) != null }
    override suspend fun all() = synchronized(lock) { map.values.toList() }
    override suspend fun clear() = synchronized(lock) { map.clear() }
}

data class MemoryPolicy(
    val enabled: Boolean = true,
    /** Auto-capture of facts the user didn't explicitly ask to remember. Off by default. */
    val autoCapture: Boolean = false,
    /** Store sensitive info (IDs, health, secrets). Off by default; explicit requests are still refused unless on. */
    val allowSensitive: Boolean = false,
    val temporaryTtlMs: Long = 24L * 3600_000,
)

data class Classification(val cls: MemoryClass, val type: MemoryType, val importance: Double, val subjectKey: String?, val reasons: List<String>)

/**
 * Decides whether something is worth remembering and how. Rule-based so it works with no model;
 * a model-assisted classifier can wrap it later.
 */
object MemoryClassifier {
    private val EXPLICIT = Regex("(?i)^\\s*(/remember\\s+|please remember( that)?\\s+|remember( that)?\\s+|note( that)?\\s*:?\\s+|yaad rakh(na|o|iye)?( ki)?\\s+|याद रख(ना|ो|िए)?( कि)?\\s+)")
    private val PROFILE = Regex("(?i)\\b(my name is|i am|i'm|i live|i work|my (birthday|job|profession|city|village|hometown|wife|husband|son|daughter|father|mother|brother|sister|friend|email|phone)|mera naam|main .{0,20} (rehta|kaam karta))\\b")
    private val PREFERENCE = Regex("(?i)\\b(i (prefer|like|love|hate|dislike|don't like|want you to)|always|never|from now on|call me|reply in|use (metric|imperial|hindi|english))\\b")
    private val TASKY = Regex("(?i)\\b(deadline|due|by (monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow)|todo|to-do|remind me)\\b")
    private val TRIVIAL = Regex("(?i)^((ok(ay)?|thanks?|thank you|hi|hello|hmm+|yes|no|cool|great|nice|done|shukriya|dhanyavaad|haan|nahi|ji)[.!, ]*)+$")
    private val FACT_PATTERNS = listOf(
        Regex("(?i)\\bmy ([a-z][a-z ]{1,30}?) (?:is|are|was) (.+)"),
        Regex("(?i)\\bi (live|work|study|stay) (?:in|at) (.+)"),
        Regex("(?i)\\bmera ([a-z ]{1,30}?) (.+) hai\\b"),
    )

    fun explicitRequest(text: String): String? = EXPLICIT.find(text)?.let { text.substring(it.range.last + 1).trim().takeIf { s -> s.isNotEmpty() } }

    fun subjectKey(text: String): String? {
        for (p in FACT_PATTERNS) {
            val m = p.find(text) ?: continue
            return m.groupValues[1].trim().lowercase().replace(Regex("\\s+"), " ").let { if (p === FACT_PATTERNS[1]) "i $it" else "my $it" }
        }
        return null
    }

    fun classify(text: String, explicit: Boolean, projectId: String?): Classification {
        val reasons = ArrayList<String>()
        val t = text.trim()
        if (t.length < 4 || TRIVIAL.matches(t)) return Classification(MemoryClass.IRRELEVANT, MemoryType.SHORT_TERM, 0.0, null, listOf("Small talk"))
        var importance = if (explicit) 0.8 else 0.35
        var type = MemoryType.LONG_TERM
        var cls = if (explicit) MemoryClass.PERSISTENT else MemoryClass.USEFUL
        if (PROFILE.containsMatchIn(t)) { type = MemoryType.USER_PROFILE; importance += 0.15; reasons += "About you" }
        if (PREFERENCE.containsMatchIn(t)) { importance += 0.1; reasons += "Preference" ; if (!explicit) cls = MemoryClass.PERSISTENT }
        if (TASKY.containsMatchIn(t)) { type = MemoryType.TASK; reasons += "Task-related"; if (!explicit) cls = MemoryClass.TEMPORARY }
        if (projectId != null && type == MemoryType.LONG_TERM) { type = MemoryType.PROJECT; cls = if (explicit) MemoryClass.PERSISTENT else MemoryClass.PROJECT_SPECIFIC; reasons += "Project context" }
        if (explicit) reasons += "You asked to remember this"
        return Classification(cls, type, importance.coerceIn(0.0, 1.0), subjectKey(t), reasons)
    }
}

sealed interface RememberResult {
    data class Stored(val record: MemoryRecord) : RememberResult
    data class Duplicate(val existing: MemoryRecord) : RememberResult
    /** Contradicts an existing memory. Nothing is overwritten; the user resolves it. */
    data class Conflict(val existing: MemoryRecord, val incoming: MemoryRecord) : RememberResult
    data class Refused(val reason: String) : RememberResult
}

data class ScoredMemory(val record: MemoryRecord, val score: Double)

data class ConsolidationGroup(val members: List<MemoryRecord>, val merged: String)

enum class ConflictResolution { KEEP_EXISTING, REPLACE_WITH_NEW, KEEP_BOTH }

/**
 * The personal memory engine: classification, sensitive-data gating, de-duplication, contradiction
 * detection, hybrid retrieval (vector + BM25 + importance + recency), expiry, consolidation and
 * user-controlled forgetting.
 */
class MemoryEngine(
    private val store: MemoryStore,
    private var embedder: Embedder,
    var policy: MemoryPolicy = MemoryPolicy(),
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    val embedderId: String get() = embedder.id

    suspend fun remember(
        content: String,
        source: MemorySource,
        projectId: String? = null,
        conversationId: String? = null,
        explicit: Boolean = source == MemorySource.USER_EXPLICIT,
        typeOverride: MemoryType? = null,
    ): RememberResult {
        if (!policy.enabled) return RememberResult.Refused("Memory is turned off")
        val text = content.trim()
        if (text.isEmpty()) return RememberResult.Refused("Nothing to remember")
        if (!explicit && !policy.autoCapture) return RememberResult.Refused("Auto-capture is off")

        val privacy = PrivacyClassifier.assess(text)
        if (privacy.level == Sensitivity.HIGH && !policy.allowSensitive) {
            return RememberResult.Refused("Contains sensitive data (${privacy.kinds.joinToString()}). Enable sensitive memory in Settings to store it.")
        }
        val cls = MemoryClassifier.classify(text, explicit, projectId)
        if (cls.cls == MemoryClass.IRRELEVANT) return RememberResult.Refused("Not worth remembering")

        val now = clock()
        val embedding = embedder.embed(listOf(text)).first()
        val type = typeOverride ?: cls.type
        val record = MemoryRecord(
            createdAt = now, updatedAt = now, source = source, type = type,
            importance = cls.importance, confidence = if (explicit) 0.95 else 0.6,
            privacyLevel = when (privacy.level) { Sensitivity.HIGH -> PrivacyLevel.SENSITIVE; Sensitivity.MEDIUM, Sensitivity.LOW -> PrivacyLevel.PERSONAL; else -> PrivacyLevel.PUBLIC },
            projectId = projectId, conversationId = conversationId, content = text,
            embedding = embedding, embedderId = embedder.id,
            expiry = if (cls.cls == MemoryClass.TEMPORARY || type == MemoryType.SESSION || type == MemoryType.SHORT_TERM) now + policy.temporaryTtlMs else null,
            subjectKey = cls.subjectKey,
        )

        val existing = live()
        // Duplicate: same scope and near-identical content.
        existing.firstOrNull { it.projectId == projectId && (normalized(it.content) == normalized(text) || cosine(it.embedding, embedding) >= 0.92f) }?.let { dup ->
            val bumped = dup.copy(updatedAt = now, importance = maxOf(dup.importance, record.importance), confidence = maxOf(dup.confidence, record.confidence))
            store.upsert(bumped)
            return RememberResult.Duplicate(bumped)
        }
        // Contradiction: same subject, different statement.
        if (record.subjectKey != null) {
            existing.firstOrNull { it.subjectKey == record.subjectKey && it.projectId == projectId }?.let { return RememberResult.Conflict(it, record) }
        }
        store.upsert(record)
        return RememberResult.Stored(record)
    }

    suspend fun resolveConflict(conflict: RememberResult.Conflict, resolution: ConflictResolution): MemoryRecord? = when (resolution) {
        ConflictResolution.KEEP_EXISTING -> conflict.existing
        ConflictResolution.REPLACE_WITH_NEW -> {
            store.delete(conflict.existing.id)
            conflict.incoming.also { store.upsert(it) }
        }
        ConflictResolution.KEEP_BOTH -> conflict.incoming.copy(subjectKey = null).also { store.upsert(it) }
    }

    /** Hybrid retrieval scoped to global memory + the given project (+ this chat's session memory). */
    suspend fun recall(query: String, projectId: String? = null, conversationId: String? = null, limit: Int = 6, minScore: Double = 0.12): List<ScoredMemory> {
        if (!policy.enabled) return emptyList()
        val pool = live().filter { r ->
            (r.projectId == null || r.projectId == projectId) &&
                (r.conversationId == null || r.type !in setOf(MemoryType.SESSION, MemoryType.SHORT_TERM) || r.conversationId == conversationId)
        }
        if (pool.isEmpty()) return emptyList()
        val q = embedder.embed(listOf(query)).first()
        val bm = Bm25(pool.map { Tokenizer.terms(it.content) }).normalizedScores(Tokenizer.terms(query))
        val now = clock()
        return pool.mapIndexed { i, r ->
            val vec = if (r.embedderId == embedder.id) cosine(q, r.embedding).toDouble().coerceAtLeast(0.0) else 0.0
            val ageDays = (now - r.updatedAt) / 86_400_000.0
            val recency = 1.0 / (1.0 + ageDays / 30.0)
            val s = 0.5 * vec + 0.3 * bm[i] + 0.12 * r.importance + 0.05 * recency + if (r.pinned) 0.05 else 0.0
            ScoredMemory(r, if (vec == 0.0 && bm[i] == 0.0) 0.0 else s)
        }.filter { it.score >= minScore }.sortedByDescending { it.score }.take(limit)
    }

    /** Profile memories are always useful context, independent of the query. */
    suspend fun profile(limit: Int = 8): List<MemoryRecord> =
        live().filter { it.type == MemoryType.USER_PROFILE && it.projectId == null }.sortedByDescending { it.importance }.take(limit)

    suspend fun list(): List<MemoryRecord> = live().sortedByDescending { it.updatedAt }

    suspend fun edit(id: String, newContent: String): MemoryRecord? {
        val r = store.get(id) ?: return null
        if (!r.userEditable) return null
        val updated = r.copy(content = newContent.trim(), updatedAt = clock(), embedding = embedder.embed(listOf(newContent)).first(),
            embedderId = embedder.id, subjectKey = MemoryClassifier.subjectKey(newContent), source = MemorySource.CORRECTION, confidence = 0.95)
        store.upsert(updated)
        return updated
    }

    suspend fun setPinned(id: String, pinned: Boolean) { store.get(id)?.let { store.upsert(it.copy(pinned = pinned)) } }

    suspend fun forget(id: String): Boolean = store.delete(id)

    /** Candidates matching a "forget everything about X" request; the UI confirms before deletion. */
    suspend fun forgetCandidates(query: String): List<MemoryRecord> = recall(query, projectId = null, limit = 20, minScore = 0.2).map { it.record } +
        live().filter { it.projectId != null && it.content.contains(query, ignoreCase = true) }

    suspend fun clearAll() = store.clear()

    suspend fun purgeExpired(): Int {
        val now = clock()
        val expired = store.all().filter { it.isExpired(now) }
        expired.forEach { store.delete(it.id) }
        return expired.size
    }

    /** Proposes merges of closely related memories. Applied only after the user approves. */
    suspend fun proposeConsolidation(threshold: Float = 0.55f): List<ConsolidationGroup> {
        val items = live().filter { !it.pinned }
        val used = HashSet<String>()
        val groups = ArrayList<ConsolidationGroup>()
        for (a in items) {
            if (a.id in used) continue
            val members = items.filter { b -> b.id !in used && b.projectId == a.projectId && b.type == a.type && (b.id == a.id || cosine(a.embedding, b.embedding) >= threshold) }
            if (members.size >= 2) {
                members.forEach { used += it.id }
                val sentences = LinkedHashSet<String>()
                members.sortedBy { it.createdAt }.forEach { m -> Tokenizer.sentences(m.content).forEach { s -> if (sentences.none { normalized(it) == normalized(s) }) sentences += s.trimEnd('.') } }
                groups += ConsolidationGroup(members, sentences.joinToString(". ") + ".")
            }
        }
        return groups
    }

    suspend fun applyConsolidation(group: ConsolidationGroup): MemoryRecord {
        val first = group.members.first()
        val now = clock()
        val merged = MemoryRecord(
            createdAt = group.members.minOf { it.createdAt }, updatedAt = now, source = MemorySource.CONSOLIDATION, type = first.type,
            importance = group.members.maxOf { it.importance }, confidence = group.members.minOf { it.confidence },
            privacyLevel = group.members.maxOf { it.privacyLevel }, projectId = first.projectId, content = group.merged,
            embedding = embedder.embed(listOf(group.merged)).first(), embedderId = embedder.id,
        )
        group.members.forEach { store.delete(it.id) }
        store.upsert(merged)
        return merged
    }

    /** Switch embedder (e.g. a neural model was installed) and re-embed every memory. */
    suspend fun reembed(newEmbedder: Embedder) {
        embedder = newEmbedder
        val all = store.all()
        if (all.isEmpty()) return
        val vectors = newEmbedder.embed(all.map { it.content })
        all.zip(vectors).forEach { (r, v) -> store.upsert(r.copy(embedding = v, embedderId = newEmbedder.id)) }
    }

    private suspend fun live(): List<MemoryRecord> {
        val now = clock()
        return store.all().filter { !it.isExpired(now) }
    }

    private fun normalized(s: String) = Tokenizer.words(s).joinToString(" ")
}
