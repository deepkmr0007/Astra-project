package ai.astra.core.documents

import ai.astra.core.memory.Embedder
import ai.astra.core.memory.cosine
import ai.astra.core.model.newId
import ai.astra.core.text.Bm25
import ai.astra.core.text.Tokenizer

enum class LocatorKind(val label: String) { PAGE("page"), SECTION("section"), ROW("rows"), LINE("lines") }

/** One extracted unit of a source document: a PDF page, a sheet range, a section of a text file. */
data class SourceUnit(val number: Int, val text: String)

data class ExtractedDocument(val title: String, val mimeType: String, val locator: LocatorKind, val units: List<SourceUnit>, val warnings: List<String> = emptyList())

data class DocumentMeta(
    val id: String = newId(),
    val title: String,
    val mimeType: String,
    val locator: LocatorKind,
    val unitCount: Int,
    val chunkCount: Int,
    val projectId: String?,
    val sha256: String,
    val importedAt: Long = System.currentTimeMillis(),
    val embedderId: String,
)

data class DocChunk(
    val id: String = newId(),
    val documentId: String,
    val ordinal: Int,
    val unit: Int,
    val text: String,
    val embedding: FloatArray,
) {
    override fun equals(other: Any?) = other is DocChunk && other.id == id
    override fun hashCode() = id.hashCode()
}

data class DocHit(val chunk: DocChunk, val meta: DocumentMeta, val score: Double) {
    /** Human citation, e.g. "Annual Report.pdf, page 17". */
    val citation: String get() = "${meta.title}, ${meta.locator.label} ${chunk.unit}"
}

interface DocumentStore {
    suspend fun put(meta: DocumentMeta, chunks: List<DocChunk>)
    suspend fun documents(): List<DocumentMeta>
    suspend fun chunks(documentIds: Collection<String>): List<DocChunk>
    suspend fun delete(documentId: String)
}

class InMemoryDocumentStore : DocumentStore {
    private val metas = LinkedHashMap<String, DocumentMeta>()
    private val chunkMap = HashMap<String, List<DocChunk>>()
    private val lock = Any()
    override suspend fun put(meta: DocumentMeta, chunks: List<DocChunk>) { synchronized(lock) { metas[meta.id] = meta; chunkMap[meta.id] = chunks } }
    override suspend fun documents() = synchronized(lock) { metas.values.toList() }
    override suspend fun chunks(documentIds: Collection<String>) = synchronized(lock) { documentIds.flatMap { chunkMap[it].orEmpty() } }
    override suspend fun delete(documentId: String) { synchronized(lock) { metas.remove(documentId); chunkMap.remove(documentId) } }
}

/** Splits units into overlapping chunks on paragraph/sentence boundaries, never across units (keeps page refs exact). */
object Chunker {
    fun chunk(units: List<SourceUnit>, targetChars: Int = 900, overlapChars: Int = 150): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        for (u in units) {
            val clean = u.text.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n").trim()
            if (clean.isEmpty()) continue
            if (clean.length <= targetChars) { out += u.number to clean; continue }
            val pieces = clean.split(Regex("\\n\\n")).flatMap { para -> if (para.length <= targetChars) listOf(para) else Tokenizer.sentences(para) }
            val sb = StringBuilder()
            for (p in pieces) {
                if (sb.isNotEmpty() && sb.length + p.length + 1 > targetChars) {
                    out += u.number to sb.toString().trim()
                    val tail = sb.takeLast(overlapChars).toString()
                    sb.clear(); sb.append(tail.substringAfter(' ', tail)).append(' ')
                }
                if (p.length > targetChars) {
                    // Hard-wrap pathological long sentences (tables, minified text).
                    p.chunked(targetChars).forEach { piece -> if (sb.isNotBlank()) { out += u.number to sb.toString().trim(); sb.clear() }; out += u.number to piece }
                } else sb.append(p).append(if (p.endsWith('.')) " " else "\n")
            }
            if (sb.isNotBlank()) out += u.number to sb.toString().trim()
        }
        return out
    }
}

/**
 * IMPORT → EXTRACT → CLEAN → CHUNK → EMBED → INDEX → RETRIEVE. Extraction is platform-specific
 * (see [TextExtractors] here and the PDF extractor in the app); everything after is here.
 */
class DocumentIndex(private val store: DocumentStore, private val embedder: Embedder) {

    suspend fun index(doc: ExtractedDocument, sha256: String, projectId: String?, onProgress: (Int, Int) -> Unit = { _, _ -> }): DocumentMeta {
        val pieces = Chunker.chunk(doc.units)
        val metaId = newId()
        val chunks = ArrayList<DocChunk>(pieces.size)
        // Embed incrementally in small batches so large documents don't block or spike memory.
        pieces.chunked(32).forEachIndexed { batchIdx, batch ->
            val vecs = embedder.embed(batch.map { it.second })
            batch.forEachIndexed { i, (unit, text) -> chunks += DocChunk(documentId = metaId, ordinal = batchIdx * 32 + i, unit = unit, text = text, embedding = vecs[i]) }
            onProgress(chunks.size, pieces.size)
        }
        val meta = DocumentMeta(metaId, doc.title, doc.mimeType, doc.locator, doc.units.size, chunks.size, projectId, sha256, embedderId = embedder.id)
        store.put(meta, chunks)
        return meta
    }

    suspend fun search(query: String, documentIds: Collection<String>? = null, projectId: String? = null, limit: Int = 5): List<DocHit> {
        val metas = store.documents().filter { m -> (documentIds == null || m.id in documentIds) && (documentIds != null || m.projectId == null || m.projectId == projectId) }
        if (metas.isEmpty()) return emptyList()
        val byId = metas.associateBy { it.id }
        val chunks = store.chunks(byId.keys)
        if (chunks.isEmpty()) return emptyList()
        val q = embedder.embed(listOf(query)).first()
        val qTerms = Tokenizer.terms(query)
        val bm = Bm25(chunks.map { Tokenizer.terms(it.text) }).normalizedScores(qTerms)
        // Explicit locator in the question ("page 17") boosts that unit.
        val wantedUnit = Regex("(?i)\\b(?:page|p\\.|pg|section|पृष्ठ|pana)\\s*(\\d{1,5})").find(query)?.groupValues?.get(1)?.toIntOrNull()
        return chunks.mapIndexed { i, c ->
            val vec = cosine(q, c.embedding).toDouble().coerceAtLeast(0.0)
            var s = 0.55 * vec + 0.45 * bm[i]
            if (wantedUnit != null && c.unit == wantedUnit) s += 0.5
            DocHit(c, byId.getValue(c.documentId), s)
        }.filter { it.score > 0.08 }.sortedByDescending { it.score }.take(limit)
    }

    suspend fun documents() = store.documents()
    suspend fun delete(id: String) = store.delete(id)
}

/** Extractors for formats that need no platform library. */
object TextExtractors {
    private const val SECTION_CHARS = 3000

    fun supports(mime: String, name: String): Boolean = extractorFor(mime, name) != null

    fun extract(name: String, mime: String, bytes: ByteArray): ExtractedDocument {
        val text = String(bytes, Charsets.UTF_8).removePrefix("﻿")
        return when (extractorFor(mime, name)) {
            "csv" -> csv(name, mime, text)
            "html" -> sections(name, mime, htmlToText(text))
            "json" -> sections(name, mime, runCatching { ai.astra.core.json.Json.write(ai.astra.core.json.Json.parse(text), pretty = true) }.getOrDefault(text))
            "lines" -> lines(name, mime, text)
            else -> sections(name, mime, text)
        }
    }

    private fun extractorFor(mime: String, name: String): String? {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext == "csv" || ext == "tsv" || mime == "text/csv" -> "csv"
            ext in setOf("html", "htm", "xhtml") || mime == "text/html" -> "html"
            ext == "json" || mime == "application/json" -> "json"
            ext in CODE_EXT -> "lines"
            ext in setOf("txt", "md", "markdown", "log", "rst") || mime.startsWith("text/") -> "text"
            else -> null
        }
    }

    private val CODE_EXT = setOf("kt", "kts", "java", "py", "js", "ts", "tsx", "jsx", "c", "h", "cpp", "hpp", "rs", "go", "rb", "php", "swift", "sh", "sql", "xml", "yaml", "yml", "toml", "gradle", "css")

    private fun sections(name: String, mime: String, text: String): ExtractedDocument {
        val units = ArrayList<SourceUnit>()
        val sb = StringBuilder()
        for (para in text.split(Regex("\\n\\s*\\n"))) {
            if (sb.length + para.length > SECTION_CHARS && sb.isNotEmpty()) { units += SourceUnit(units.size + 1, sb.toString()); sb.clear() }
            sb.append(para).append("\n\n")
        }
        if (sb.isNotBlank()) units += SourceUnit(units.size + 1, sb.toString())
        return ExtractedDocument(name, mime, LocatorKind.SECTION, units)
    }

    private fun lines(name: String, mime: String, text: String): ExtractedDocument {
        val all = text.lines()
        val units = all.chunked(60).mapIndexed { i, block -> SourceUnit(i * 60 + 1, block.joinToString("\n")) }
        return ExtractedDocument(name, mime, LocatorKind.LINE, units)
    }

    private fun csv(name: String, mime: String, text: String): ExtractedDocument {
        val rows = text.lines().filter { it.isNotBlank() }
        if (rows.isEmpty()) return ExtractedDocument(name, mime, LocatorKind.ROW, emptyList())
        val header = rows.first()
        // Each unit repeats the header so every chunk is self-describing; unit number = first data row.
        val units = rows.drop(1).chunked(40).mapIndexed { i, block -> SourceUnit(i * 40 + 2, header + "\n" + block.joinToString("\n")) }
        return ExtractedDocument(name, mime, LocatorKind.ROW, units.ifEmpty { listOf(SourceUnit(1, header)) })
    }

    fun htmlToText(html: String): String = html
        .replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?i)<br\\s*/?>|</(p|div|h[1-6]|li|tr)>"), "\n")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
        .replace(Regex("[ \\t]+"), " ")
        .replace(Regex("\\n\\s*\\n\\s*\\n+"), "\n\n")
        .trim()
}
