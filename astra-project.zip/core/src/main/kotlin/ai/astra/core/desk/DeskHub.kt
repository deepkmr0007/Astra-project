package ai.astra.core.desk

import ai.astra.core.builder.AutomationDriver
import ai.astra.core.builder.DriverCommand
import ai.astra.core.builder.DriverResult
import ai.astra.core.builder.FormSnapshot
import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import java.security.interfaces.ECPublicKey
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

data class PairedDevice(val id: String, val name: String, val key: ByteArray, val pairedAt: Long)

/** Where paired computers' keys live (the app keeps them in the Keystore-encrypted vault). */
interface PairedDeviceStore {
    fun all(): List<PairedDevice>
    fun save(device: PairedDevice)
    fun remove(id: String)
}

class InMemoryPairedDeviceStore : PairedDeviceStore {
    private val map = ConcurrentHashMap<String, PairedDevice>()
    override fun all() = map.values.sortedBy { it.pairedAt }
    override fun save(device: PairedDevice) { map[device.id] = device }
    override fun remove(id: String) { map.remove(id) }
}

interface DeskListener {
    fun onPairingRequest(sessionId: String, computerName: String, code: String) {}
    fun onPaired(device: PairedDevice) {}
    fun onChat(deviceId: String, chatId: String, text: String) {}
    fun onFormReport(deviceId: String, snapshot: FormSnapshot) {}
    fun onConnectionChanged() {}
}

data class HttpReply(val status: Int, val body: String, val contentType: String = "application/json; charset=utf-8")

/**
 * The phone side of ASTRA Desk. Transport-agnostic: [handle] takes one HTTP request and returns
 * the reply; [DeskServer] feeds it from a socket. Outbound messages (commands, chat replies) wait
 * in a per-computer queue that the extension long-polls.
 */
class DeskHub(
    private val store: PairedDeviceStore,
    var listener: DeskListener = object : DeskListener {},
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private class Pending(val sessionId: String, val name: String, val extPub: ByteArray, val phonePub: ByteArray, val derived: DeskCrypto.Derived, val createdAt: Long) {
        @Volatile var confirmed = false
        @Volatile var rejected = false
    }

    private val pending = ConcurrentHashMap<String, Pending>()
    private val queues = ConcurrentHashMap<String, LinkedBlockingQueue<JsonValue.Obj>>()
    private val lastSeen = ConcurrentHashMap<String, Long>()
    private val seenNonces = ConcurrentHashMap<String, Long>()
    private val waiting = ConcurrentHashMap<String, CompletableDeferred<JsonValue.Obj>>()
    private val helloTimes = ArrayDeque<Long>()
    @Volatile var lastSnapshot: FormSnapshot? = null; private set

    fun pairedDevices(): List<PairedDevice> = store.all()
    fun connectedDevices(): List<PairedDevice> = store.all().filter { (lastSeen[it.id] ?: 0) > clock() - 35_000 }
    fun isConnected(): Boolean = connectedDevices().isNotEmpty()

    fun confirmPairing(sessionId: String): Boolean {
        val p = pending[sessionId] ?: return false
        if (p.rejected || clock() - p.createdAt > PAIRING_TTL) return false
        p.confirmed = true
        val device = PairedDevice(sessionId, p.name, p.derived.key, clock())
        store.save(device)
        listener.onPaired(device)
        return true
    }

    fun rejectPairing(sessionId: String) { pending[sessionId]?.rejected = true }

    fun unpair(id: String) { store.remove(id); queues.remove(id); lastSeen.remove(id); listener.onConnectionChanged() }

    /** Queue a message for a computer (or the first connected one). Returns false if none is connected. */
    fun push(message: JsonValue.Obj, deviceId: String? = null): Boolean {
        val id = deviceId ?: connectedDevices().firstOrNull()?.id ?: return false
        queues.getOrPut(id) { LinkedBlockingQueue() }.offer(message)
        return true
    }

    /** Sends a command and waits for the extension's result. */
    suspend fun command(op: String, args: Map<String, Any?>, timeoutMs: Long, deviceId: String? = null): JsonValue.Obj? {
        val id = DeskCrypto.randomId(8)
        val d = CompletableDeferred<JsonValue.Obj>()
        waiting[id] = d
        try {
            val msg = jsonObj(*(listOf("type" to "command", "cmd" to id, "op" to op) + args.toList()).toTypedArray())
            if (!push(msg, deviceId)) return null
            return withTimeoutOrNull(timeoutMs) { d.await() }
        } finally {
            waiting.remove(id)
        }
    }

    /**
     * Shows a question on the computer (review a record, "log in then continue") and suspends until
     * it is answered there. The phone shows the same question; whichever side answers first wins —
     * the caller cancels the other with [withdraw].
     */
    suspend fun ask(kind: String, title: String, detail: String, options: List<String>, fields: List<Pair<String, String>> = emptyList(), deviceId: String? = null): String? {
        val id = "ask-" + DeskCrypto.randomId(6)
        val d = CompletableDeferred<JsonValue.Obj>()
        waiting[id] = d
        try {
            val msg = jsonObj("type" to "ask", "ask" to id, "kind" to kind, "title" to title, "detail" to detail, "options" to options,
                "fields" to fields.map { jsonObj("label" to it.first, "value" to it.second) })
            if (!push(msg, deviceId)) return null
            currentAsk = id
            return d.await()["value"].str()
        } finally {
            waiting.remove(id)
            if (currentAsk == id) { currentAsk = null; push(jsonObj("type" to "ask_cancel", "ask" to id), deviceId) }
        }
    }

    @Volatile private var currentAsk: String? = null

    fun handle(method: String, path: String, body: String): HttpReply = try {
        when {
            method == "GET" && path == "/desk/ping" -> HttpReply(200, """{"app":"ASTRA","desk":1}""")
            method == "POST" && path == "/desk/hello" -> hello(body)
            method == "POST" && path == "/desk/status" -> status(body)
            method == "POST" && path == "/desk/rpc" -> rpc(body)
            else -> HttpReply(404, """{"error":"not found"}""")
        }
    } catch (e: IllegalArgumentException) {
        HttpReply(400, Json.write(jsonObj("error" to (e.message ?: "bad request"))))
    } catch (e: javax.crypto.AEADBadTagException) {
        HttpReply(403, """{"error":"not paired"}""")
    }

    private fun hello(body: String): HttpReply {
        val now = clock()
        synchronized(helloTimes) {
            while (helloTimes.isNotEmpty() && helloTimes.first() < now - 60_000) helloTimes.removeFirst()
            if (helloTimes.size >= 10) return HttpReply(429, """{"error":"too many pairing attempts"}""")
            helloTimes.addLast(now)
        }
        val o = Json.parse(body).obj() ?: throw IllegalArgumentException("bad body")
        val extRaw = DeskCrypto.unb64(o["pub"].str() ?: throw IllegalArgumentException("pub missing"))
        val name = (o["name"].str() ?: "Computer").take(60).filter { it >= ' ' }
        val kp = DeskCrypto.newKeyPair()
        val phonePub = DeskCrypto.rawPublic(kp.public as ECPublicKey)
        val extPub = DeskCrypto.publicFromRaw(extRaw, (kp.public as ECPublicKey).params)
        val derived = DeskCrypto.derive(DeskCrypto.sharedSecret(kp.private, extPub), phonePub, extRaw)
        val sessionId = DeskCrypto.randomId()
        pending.entries.removeIf { now - it.value.createdAt > PAIRING_TTL || !it.value.confirmed }
        pending[sessionId] = Pending(sessionId, name, extRaw, phonePub, derived, now)
        listener.onPairingRequest(sessionId, name, derived.code)
        return HttpReply(200, Json.write(jsonObj("pub" to DeskCrypto.b64(phonePub), "session" to sessionId)))
    }

    private fun status(body: String): HttpReply {
        val o = Json.parse(body).obj() ?: throw IllegalArgumentException("bad body")
        val p = pending[o["session"].str()] ?: return HttpReply(200, """{"state":"unknown"}""")
        val state = when {
            p.rejected -> "rejected"
            p.confirmed -> "confirmed"
            clock() - p.createdAt > PAIRING_TTL -> "expired"
            else -> "waiting"
        }
        return HttpReply(200, Json.write(jsonObj("state" to state)))
    }

    private fun rpc(body: String): HttpReply {
        val o = Json.parse(body).obj() ?: throw IllegalArgumentException("bad body")
        val id = o["id"].str() ?: throw IllegalArgumentException("id missing")
        val device = store.all().firstOrNull { it.id == id } ?: return HttpReply(403, """{"error":"not paired"}""")
        val boxB64 = o["box"].str() ?: throw IllegalArgumentException("box missing")
        val sealed = DeskCrypto.unb64(boxB64)
        val plain = DeskCrypto.open(device.key, sealed, "req:$id".toByteArray())
        val nonce = DeskCrypto.b64(sealed.copyOfRange(0, 12))
        val now = clock()
        seenNonces.entries.removeIf { it.value < now - NONCE_TTL }
        if (seenNonces.putIfAbsent(nonce, now) != null) return HttpReply(409, """{"error":"replay"}""")
        val msg = Json.parse(String(plain, Charsets.UTF_8)).obj() ?: throw IllegalArgumentException("bad message")
        val ts = msg["ts"].long() ?: 0
        if (kotlin.math.abs(now - ts) > CLOCK_SKEW) return HttpReply(409, """{"error":"clock skew — check the computer's and phone's time"}""")
        val wasConnected = isConnected()
        lastSeen[id] = now
        if (!wasConnected) listener.onConnectionChanged()
        val reply = when (msg["type"].str()) {
            "poll" -> poll(id, (msg["wait"].long() ?: 20_000).coerceIn(0, 25_000))
            "result" -> {
                waiting[msg["cmd"].str()]?.complete(msg)
                jsonObj("ok" to true)
            }
            "answer" -> {
                val askId = msg["ask"].str()
                if (askId == currentAsk) currentAsk = null
                waiting[askId]?.complete(msg)
                jsonObj("ok" to true)
            }
            "chat" -> {
                val chatId = DeskCrypto.randomId(6)
                listener.onChat(id, chatId, (msg["text"].str() ?: "").take(20_000))
                jsonObj("ok" to true, "chatId" to chatId)
            }
            "form" -> {
                msg["snapshot"].obj()?.let { FormSnapshot.fromJson(it) }?.let { s -> lastSnapshot = s; listener.onFormReport(id, s) }
                jsonObj("ok" to true)
            }
            "bye" -> { unpair(id); jsonObj("ok" to true) }
            else -> jsonObj("ok" to false, "error" to "unknown type")
        }
        val out = DeskCrypto.seal(device.key, Json.write(reply).toByteArray(Charsets.UTF_8), "resp:$nonce".toByteArray())
        return HttpReply(200, Json.write(jsonObj("box" to DeskCrypto.b64(out))))
    }

    private fun poll(id: String, waitMs: Long): JsonValue.Obj {
        val q = queues.getOrPut(id) { LinkedBlockingQueue() }
        val first = q.poll(waitMs, TimeUnit.MILLISECONDS)
        val list = ArrayList<JsonValue.Obj>()
        if (first != null) { list += first; q.drainTo(list, 50) }
        lastSeen[id] = clock()
        return jsonObj("messages" to list)
    }

    companion object {
        const val PAIRING_TTL = 5 * 60_000L
        const val NONCE_TTL = 20 * 60_000L
        const val CLOCK_SKEW = 10 * 60_000L
    }
}

/** Runs automations in the user's Chrome through the paired ASTRA Desk extension. */
class DeskDriver(private val hub: DeskHub) : AutomationDriver {
    override val name = "ASTRA Desk (computer)"

    override suspend fun ready(): Boolean = hub.isConnected()

    override suspend fun execute(command: DriverCommand): DriverResult {
        val (op, args, timeout) = when (command) {
            is DriverCommand.Navigate -> Triple("navigate", mapOf("url" to command.url), 45_000L)
            is DriverCommand.FillFields -> Triple("fill", mapOf("fields" to command.values.map { mapOf("selector" to it.selector, "label" to it.label, "value" to it.value, "type" to it.type.name) }), 30_000L)
            is DriverCommand.Click -> Triple("click", mapOf("target" to command.target), 20_000L)
            is DriverCommand.WaitFor -> Triple("wait_for", mapOf("target" to command.target, "timeoutMs" to command.timeoutMs), command.timeoutMs + 10_000)
            is DriverCommand.CheckText -> Triple("check_text", mapOf("text" to command.text, "timeoutMs" to command.timeoutMs), command.timeoutMs + 10_000)
            is DriverCommand.Extract -> Triple("extract", mapOf("target" to command.target), 15_000L)
            DriverCommand.Scan -> Triple("scan", emptyMap<String, Any?>(), 15_000L)
            is DriverCommand.LaunchApp, is DriverCommand.Tap, is DriverCommand.Type, is DriverCommand.Scroll, DriverCommand.Back ->
                return DriverResult(false, "That is a phone step; this automation runs on the computer")
        }
        val r = hub.command(op, args, timeout) ?: return DriverResult(false, if (hub.isConnected()) "The computer did not answer in time" else "The computer is not connected")
        return DriverResult(
            ok = r["ok"].bool() ?: false,
            message = r["message"].str().orEmpty(),
            data = r["data"].str().orEmpty(),
            snapshot = r["snapshot"].obj()?.let(FormSnapshot::fromJson),
            failedFields = r["failed"].arr().mapNotNull { it.str() },
        )
    }
}
