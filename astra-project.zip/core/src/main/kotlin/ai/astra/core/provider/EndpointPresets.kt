package ai.astra.core.provider

import ai.astra.core.model.Locality

/** Ready-made endpoint settings. The model id is editable and can be fetched from the server. */
data class EndpointPreset(
    val id: String,
    val name: String,
    val kind: EndpointKind,
    val baseUrl: String,
    val defaultModel: String,
    val locality: Locality,
    val needsKey: Boolean,
    val keyUrl: String?,
    val note: String,
    val vision: Boolean,
    val contextWindow: Int,
)

object EndpointPresets {
    val all: List<EndpointPreset> = listOf(
        EndpointPreset(
            "gemini", "Google Gemini (free tier available)", EndpointKind.OPENAI_COMPATIBLE,
            "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-3.8-flash", Locality.REMOTE,
            needsKey = true, keyUrl = "https://aistudio.google.com/apikey",
            note = "Create a free API key in Google AI Studio. Free-tier requests may be used by Google to improve its products — check their terms.",
            vision = true, contextWindow = 1_000_000,
        ),
        EndpointPreset(
            "anthropic", "Anthropic Claude", EndpointKind.ANTHROPIC,
            "https://api.anthropic.com", "claude-sonnet-5-5", Locality.REMOTE,
            needsKey = true, keyUrl = "https://console.anthropic.com/settings/keys",
            note = "Paid API. Create a key in the Claude Console.", vision = true, contextWindow = 200_000,
        ),
        EndpointPreset(
            "openai", "OpenAI", EndpointKind.OPENAI_COMPATIBLE, "https://api.openai.com/v1", "", Locality.REMOTE,
            needsKey = true, keyUrl = "https://platform.openai.com/api-keys",
            note = "Paid API. Tap “Fetch models” after adding your key.", vision = true, contextWindow = 128_000,
        ),
        EndpointPreset(
            "groq", "Groq (fast, free tier available)", EndpointKind.OPENAI_COMPATIBLE, "https://api.groq.com/openai/v1", "", Locality.REMOTE,
            needsKey = true, keyUrl = "https://console.groq.com/keys",
            note = "Tap “Fetch models” after adding your key.", vision = false, contextWindow = 128_000,
        ),
        EndpointPreset(
            "openrouter", "OpenRouter (many models)", EndpointKind.OPENAI_COMPATIBLE, "https://openrouter.ai/api/v1", "", Locality.REMOTE,
            needsKey = true, keyUrl = "https://openrouter.ai/keys",
            note = "One key for hundreds of models, some free. Tap “Fetch models”.", vision = false, contextWindow = 128_000,
        ),
        EndpointPreset(
            "ollama", "Ollama on my computer (LAN)", EndpointKind.OPENAI_COMPATIBLE, "http://192.168.1.2:11434", "", Locality.LAN,
            needsKey = false, keyUrl = null,
            note = "On your PC run Ollama with OLLAMA_HOST=0.0.0.0, then put the PC's Wi-Fi IP here and tap “Fetch models”.",
            vision = false, contextWindow = 8192,
        ),
        EndpointPreset(
            "lmstudio", "LM Studio / llama.cpp server (LAN)", EndpointKind.OPENAI_COMPATIBLE, "http://192.168.1.2:1234", "", Locality.LAN,
            needsKey = false, keyUrl = null,
            note = "Start the server on your PC (listen on network), put its Wi-Fi IP here and tap “Fetch models”.",
            vision = false, contextWindow = 8192,
        ),
    )

    fun toConfig(preset: EndpointPreset, id: String, model: String = preset.defaultModel, baseUrl: String = preset.baseUrl): EndpointConfig =
        EndpointConfig(
            id = id, displayName = preset.name.substringBefore(" (").trim(), kind = preset.kind, baseUrl = baseUrl, model = model,
            locality = preset.locality, vision = preset.vision,
            scores = if (preset.locality == Locality.LAN) ModelCapabilities(reasoning = 6, coding = 6, multilingual = 6, speed = 6, contextWindow = preset.contextWindow)
            else ModelCapabilities(reasoning = 8, coding = 8, multilingual = 8, speed = 6, contextWindow = preset.contextWindow),
        )
}
