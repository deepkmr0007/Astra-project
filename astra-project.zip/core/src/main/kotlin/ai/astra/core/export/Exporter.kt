package ai.astra.core.export

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.num
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemoryType
import ai.astra.core.memory.PrivacyLevel
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.Project
import ai.astra.core.tasks.TaskItem
import ai.astra.core.tasks.Priority
import ai.astra.core.tasks.TaskStatus
import ai.astra.core.model.Role
import java.time.Instant

/**
 * Open, documented export format ("astra-export" v1, JSON) plus Markdown for humans.
 * Embeddings are not exported: they are re-computed on import, keeping files small and portable.
 */
object Exporter {
    const val FORMAT = "astra-export"
    const val VERSION = 1

    fun memoryJson(m: MemoryRecord): JsonValue = jsonObj(
        "id" to m.id, "createdAt" to m.createdAt, "updatedAt" to m.updatedAt, "source" to m.source, "type" to m.type,
        "importance" to m.importance, "confidence" to m.confidence, "privacyLevel" to m.privacyLevel,
        "project" to m.projectId, "content" to m.content, "expiry" to m.expiry, "userEditable" to m.userEditable,
        "subjectKey" to m.subjectKey, "pinned" to m.pinned,
    )

    fun messageJson(m: ChatMessage): JsonValue = jsonObj(
        "id" to m.id, "role" to m.role, "createdAt" to m.createdAt, "text" to m.text,
        "trace" to m.trace?.let { t ->
            jsonObj("provider" to t.providerId, "model" to t.model, "locality" to t.locality, "mode" to t.mode,
                "networkUsed" to t.networkUsed, "dataSent" to t.dataSent, "tools" to t.tools, "tokensOut" to t.tokensOut)
        },
    )

    fun bundle(
        conversations: List<Pair<Conversation, List<ChatMessage>>>,
        memories: List<MemoryRecord>,
        projects: List<Project>,
        tasks: List<TaskItem>,
        settings: Map<String, Any?>,
    ): String = Json.write(
        jsonObj(
            "format" to FORMAT, "version" to VERSION, "exportedAt" to Instant.now().toString(),
            "projects" to jsonArr(projects.map { jsonObj("id" to it.id, "name" to it.name, "instructions" to it.instructions, "privateByDefault" to it.privateByDefault, "createdAt" to it.createdAt) }),
            "conversations" to jsonArr(conversations.map { (c, msgs) ->
                jsonObj("id" to c.id, "title" to c.title, "project" to c.projectId, "folder" to c.folder, "pinned" to c.pinned,
                    "archived" to c.archived, "parent" to c.parentConversationId, "createdAt" to c.createdAt, "messages" to jsonArr(msgs.map { messageJson(it) }))
            }),
            "memories" to jsonArr(memories.map { memoryJson(it) }),
            "tasks" to jsonArr(tasks.map { t ->
                jsonObj("id" to t.id, "title" to t.title, "description" to t.description, "priority" to t.priority, "deadline" to t.deadline,
                    "status" to t.status, "project" to t.projectId, "parent" to t.parentId, "dependsOn" to t.dependsOn.toList())
            }),
            "settings" to settings,
        ),
        pretty = true,
    )

    fun conversationMarkdown(c: Conversation, msgs: List<ChatMessage>): String = buildString {
        appendLine("# ${c.title}")
        appendLine()
        appendLine("_Exported from ASTRA on ${Instant.now()}_")
        msgs.forEach { m ->
            appendLine()
            appendLine("## ${m.role.name.lowercase().replaceFirstChar { it.uppercase() }} — ${Instant.ofEpochMilli(m.createdAt)}")
            appendLine()
            appendLine(m.text)
            m.trace?.let { t ->
                appendLine()
                appendLine("> Model: ${t.model} · Execution: ${t.locality.name.lowercase()} · Network: ${if (t.networkUsed) "used" else "not used"}" +
                    (if (t.tools.isNotEmpty()) " · Tools: ${t.tools.joinToString()}" else ""))
            }
        }
    }

    fun memoriesMarkdown(memories: List<MemoryRecord>): String = buildString {
        appendLine("# ASTRA memory")
        memories.groupBy { it.type }.forEach { (type, list) ->
            appendLine(); appendLine("## ${type.name.lowercase().replace('_', ' ')}")
            list.forEach { appendLine("- ${it.content}") }
        }
    }

    data class ImportedMemory(
        val content: String, val type: MemoryType, val projectId: String?, val importance: Double, val privacy: PrivacyLevel,
        val id: String? = null, val updatedAt: Long = 0, val pinned: Boolean = false,
    )

    /** Parses memories from an astra-export file (or a bare JSON array). Validates every field. */
    fun parseMemories(text: String): List<ImportedMemory> {
        val root = Json.parse(text)
        val items = when (root) {
            is JsonValue.Arr -> root.items
            is JsonValue.Obj -> {
                require(root["format"].str() == FORMAT) { "Not an ASTRA export file" }
                root["memories"].arr()
            }
            else -> throw IllegalArgumentException("Unsupported JSON")
        }
        return items.mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            val content = o["content"].str()?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            ImportedMemory(
                content = content.take(4000),
                type = runCatching { MemoryType.valueOf(o["type"].str()!!) }.getOrDefault(MemoryType.LONG_TERM),
                projectId = o["project"].str(),
                importance = (o["importance"].num() ?: 0.5).coerceIn(0.0, 1.0),
                privacy = runCatching { PrivacyLevel.valueOf(o["privacyLevel"].str()!!) }.getOrDefault(PrivacyLevel.PERSONAL),
                id = o["id"].str(),
                updatedAt = o["updatedAt"].num()?.toLong() ?: 0L,
                pinned = o["pinned"] == JsonValue.Bool(true),
            )
        }
    }

    data class ParsedMessage(val id: String, val role: Role, val text: String, val createdAt: Long)
    data class ParsedConversation(val conversation: Conversation, val messages: List<ParsedMessage>)
    data class ParsedBundle(
        val projects: List<Project>,
        val conversations: List<ParsedConversation>,
        val memories: List<ImportedMemory>,
        val tasks: List<TaskItem>,
        val exportedAt: String?,
    )

    /** Full restore/merge input. Unknown or malformed records are skipped, never guessed. */
    fun parseBundle(text: String): ParsedBundle {
        val root = Json.parse(text).obj() ?: throw IllegalArgumentException("Not an ASTRA export file")
        require(root["format"].str() == FORMAT) { "Not an ASTRA export file" }
        require((root["version"].num()?.toInt() ?: 0) <= VERSION) { "This file is from a newer ASTRA version" }
        val projects = root["projects"].arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            Project(o["id"].str() ?: return@mapNotNull null, o["name"].str() ?: return@mapNotNull null, o["instructions"].str().orEmpty(),
                o["privateByDefault"] == JsonValue.Bool(true), o["createdAt"].num()?.toLong() ?: 0L)
        }
        val conversations = root["conversations"].arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            val id = o["id"].str() ?: return@mapNotNull null
            val msgs = o["messages"].arr().mapNotNull { mv ->
                val m = mv.obj() ?: return@mapNotNull null
                ParsedMessage(m["id"].str() ?: return@mapNotNull null, runCatching { Role.valueOf(m["role"].str()!!) }.getOrNull() ?: return@mapNotNull null,
                    m["text"].str().orEmpty(), m["createdAt"].num()?.toLong() ?: 0L)
            }
            val created = o["createdAt"].num()?.toLong() ?: 0L
            ParsedConversation(Conversation(id = id, title = o["title"].str() ?: "Imported chat", projectId = o["project"].str(), folder = o["folder"].str(),
                pinned = o["pinned"] == JsonValue.Bool(true), archived = o["archived"] == JsonValue.Bool(true), parentConversationId = o["parent"].str(),
                createdAt = created, updatedAt = msgs.maxOfOrNull { it.createdAt } ?: created), msgs)
        }
        val tasks = root["tasks"].arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            TaskItem(id = o["id"].str() ?: return@mapNotNull null, title = o["title"].str() ?: return@mapNotNull null, description = o["description"].str().orEmpty(),
                priority = runCatching { Priority.valueOf(o["priority"].str()!!) }.getOrDefault(Priority.MEDIUM), deadline = o["deadline"].num()?.toLong(),
                status = runCatching { TaskStatus.valueOf(o["status"].str()!!) }.getOrDefault(TaskStatus.TODO), projectId = o["project"].str(),
                parentId = o["parent"].str(), dependsOn = o["dependsOn"].arr().mapNotNull { it.str() }.toSet())
        }
        return ParsedBundle(projects, conversations, runCatching { parseMemories(text) }.getOrDefault(emptyList()), tasks, root["exportedAt"].str())
    }
}
