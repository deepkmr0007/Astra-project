package ai.astra.core.model

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

enum class Role { SYSTEM, USER, ASSISTANT, TOOL }

/**
 * Where a piece of prompt content came from. The context engine keeps these separated so that
 * untrusted content (documents, web pages, tool output) can never be promoted to instructions.
 */
enum class ContentSource(val trusted: Boolean) {
    SYSTEM(true), USER(true), MEMORY(true), DOCUMENT(false), WEB(false), TOOL_RESULT(false)
}

/** Unified multimodal message part. */
sealed interface Part {
    data class Text(val text: String) : Part
    data class Image(val path: String, val mimeType: String = "image/jpeg") : Part
    data class Audio(val path: String, val mimeType: String = "audio/wav") : Part
    data class DocumentRef(val documentId: String, val title: String) : Part
    data class Code(val language: String, val code: String) : Part
}

fun List<Part>.plainText(): String = joinToString("\n") {
    when (it) {
        is Part.Text -> it.text
        is Part.Code -> "```${it.language}\n${it.code}\n```"
        is Part.DocumentRef -> "[document: ${it.title}]"
        is Part.Image -> "[image]"
        is Part.Audio -> "[audio]"
    }
}.trim()

enum class ExecutionMode { LOCAL, ONLINE, HYBRID }

/** Where inference physically runs. Anything but ON_DEVICE means bytes leave the phone. */
enum class Locality(val usesNetwork: Boolean, val usesInternet: Boolean) {
    ON_DEVICE(false, false),
    LAN(true, false),
    USER_HOSTED(true, true),
    REMOTE(true, true),
}

/** Answers the four transparency questions for every response: which model, where, what was sent, which tools. */
data class ExecutionTrace(
    val providerId: String,
    val model: String,
    val locality: Locality,
    val mode: ExecutionMode,
    val networkUsed: Boolean,
    val bytesSent: Long,
    val dataSent: List<String>,
    val tools: List<String>,
    val tokensOut: Int,
    val tokensPerSecond: Double,
    val latencyMs: Long,
    val routeReasons: List<String>,
    val warnings: List<String> = emptyList(),
    val verification: VerificationSummary? = null,
)

data class VerificationSummary(
    val steps: Int,
    val toolCalls: Int,
    val toolFailures: Int,
    val calculationsVerified: Boolean?,
    val sourcesUsed: Int,
    val selfReview: Boolean,
    val uncertainties: List<String>,
    val limitsHit: List<String>,
) {
    fun lines(): List<String> = buildList {
        add("Steps: $steps · Tool calls: $toolCalls" + if (toolFailures > 0) " ($toolFailures failed)" else "")
        if (sourcesUsed > 0) add("Sources used: $sourcesUsed")
        calculationsVerified?.let { add("Calculation verified by tool: " + if (it) "yes" else "no") }
        if (selfReview) add("Self-review pass: performed")
        if (uncertainties.isNotEmpty()) add("Potential uncertainty: ${uncertainties.size} item(s)")
        limitsHit.forEach { add("Limit reached: $it") }
    }
}

data class ChatMessage(
    val id: String = newId(),
    val conversationId: String,
    val role: Role,
    val parts: List<Part>,
    val createdAt: Long = System.currentTimeMillis(),
    val trace: ExecutionTrace? = null,
    val feedback: Feedback = Feedback.NONE,
) {
    val text: String get() = parts.plainText()
}

enum class Feedback { NONE, UP, DOWN }

data class Conversation(
    val id: String = newId(),
    val title: String,
    val projectId: String? = null,
    val folder: String? = null,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val parentConversationId: String? = null,
    val forkedFromMessageId: String? = null,
    val temporary: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

data class Project(
    val id: String = newId(),
    val name: String,
    val instructions: String = "",
    val privateByDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)

enum class AssistMode { CHAT, ASSIST, AGENT }
