package ai.astra.core.automation

import ai.astra.core.documents.TextExtractors
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

data class FeedItem(val title: String, val link: String, val summary: String, val published: Long?, val feed: String)

/** Tolerant RSS 2.0 / Atom parser (regex-based; no XML entity expansion, so no XXE risk). */
object FeedParser {
    private fun tag(block: String, name: String): String? =
        Regex("(?is)<$name(?:\\s[^>]*)?>(.*?)</$name>").find(block)?.groupValues?.get(1)?.let { clean(it) }

    private fun clean(s: String): String {
        val noCdata = s.replace(Regex("(?s)<!\\[CDATA\\[(.*?)]]>"), "$1")
        return TextExtractors.htmlToText(noCdata).replace("&#039;", "'").replace(Regex("&#(\\d+);")) { m ->
            m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: ""
        }.replace(Regex("\\s+"), " ").trim()
    }

    private fun parseDate(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val t = s.trim()
        return runCatching { ZonedDateTime.parse(t, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() }.getOrNull()
            ?: runCatching { ZonedDateTime.parse(t).toInstant().toEpochMilli() }.getOrNull()
            ?: runCatching { java.time.OffsetDateTime.parse(t).toInstant().toEpochMilli() }.getOrNull()
    }

    fun parse(xml: String, feedName: String? = null): List<FeedItem> {
        val channelTitle = feedName ?: tag(xml.substringBefore("<item").substringBefore("<entry"), "title") ?: "Feed"
        val items = Regex("(?is)<item(?:\\s[^>]*)?>(.*?)</item>").findAll(xml).map { m ->
            val b = m.groupValues[1]
            FeedItem(tag(b, "title").orEmpty(), tag(b, "link").orEmpty(), (tag(b, "description") ?: tag(b, "content:encoded")).orEmpty().take(600),
                parseDate(tag(b, "pubDate") ?: tag(b, "dc:date")), channelTitle)
        }.toList()
        if (items.isNotEmpty()) return items.filter { it.title.isNotBlank() }
        return Regex("(?is)<entry(?:\\s[^>]*)?>(.*?)</entry>").findAll(xml).map { m ->
            val b = m.groupValues[1]
            val link = Regex("(?is)<link[^>]*href=\"([^\"]+)\"").find(b)?.groupValues?.get(1).orEmpty()
            FeedItem(tag(b, "title").orEmpty(), link, (tag(b, "summary") ?: tag(b, "content")).orEmpty().take(600), parseDate(tag(b, "updated") ?: tag(b, "published")), channelTitle)
        }.filter { it.title.isNotBlank() }.toList()
    }
}

/** Builds the morning briefing: newest items across feeds, de-duplicated. */
object Briefing {
    fun select(items: List<FeedItem>, max: Int = 12, sinceMillis: Long? = null): List<FeedItem> {
        val seen = HashSet<String>()
        return items.filter { sinceMillis == null || (it.published ?: Long.MAX_VALUE) >= sinceMillis }
            .sortedByDescending { it.published ?: 0 }
            .filter { seen.add(it.title.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097f]"), "").take(60)) }
            .take(max)
    }

    fun prompt(items: List<FeedItem>): String = buildString {
        append("Prepare my morning briefing from these headlines. Group related items, put the most important first, ")
        append("one or two lines each, and mention the source. Do not add facts that are not in the items.\n\n")
        items.forEachIndexed { i, it -> append("${i + 1}. [${it.feed}] ${it.title} — ${it.summary.take(240)}\n") }
    }

    fun plain(items: List<FeedItem>): String = items.joinToString("\n") { "• ${it.title} (${it.feed})" }
}
