package ai.astra.core.knowledge

import ai.astra.core.documents.DocumentMeta
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.model.Project
import ai.astra.core.tasks.TaskItem

enum class EntityType { PERSON, ORGANIZATION, PLACE, PROJECT, DOCUMENT, CONCEPT, TASK, EVENT }

enum class RelationType { WORKS_ON, MENTIONS, BELONGS_TO, DEPENDS_ON, LOCATED_AT, CONTRADICTS, SUPPORTS }

data class Entity(val key: String, val name: String, val type: EntityType, val sources: Set<String>)

data class Relation(val from: String, val to: String, val type: RelationType, val evidence: String)

data class Neighbor(val entity: Entity, val relation: RelationType, val outgoing: Boolean, val evidence: String)

/**
 * Local knowledge graph built deterministically from memories, projects, tasks and documents.
 * It links what you told ASTRA without re-reading whole conversations. Nothing is inferred about
 * you beyond what the source text literally says.
 */
class KnowledgeGraph(val entities: Map<String, Entity>, val relations: List<Relation>) {

    fun neighbors(key: String): List<Neighbor> = relations.mapNotNull { r ->
        when (key) {
            r.from -> entities[r.to]?.let { Neighbor(it, r.type, true, r.evidence) }
            r.to -> entities[r.from]?.let { Neighbor(it, r.type, false, r.evidence) }
            else -> null
        }
    }

    /** Entities named in a piece of text, longest names first. */
    fun mentionedIn(text: String): List<Entity> {
        val t = text.lowercase()
        return entities.values.filter { it.name.length >= 3 && Regex("\\b" + Regex.escape(it.name.lowercase()) + "\\b").containsMatchIn(t) }
            .sortedByDescending { it.name.length }
    }

    fun describe(key: String): String {
        val e = entities[key] ?: return "Unknown entity"
        val ns = neighbors(key)
        return buildString {
            append("${e.name} (${e.type.name.lowercase()})")
            ns.forEach { n -> append("\n• ${if (n.outgoing) "" else "← "}${n.relation.name.lowercase().replace('_', ' ')} ${n.entity.name}") }
        }
    }

    companion object {
        fun key(name: String) = name.lowercase().replace(Regex("[^\\p{L}\\p{Nd}]+"), " ").trim()
    }
}

object KnowledgeGraphBuilder {
    private val PERSON_REL = Regex("\\b[Mm]y (friend|brother|sister|father|mother|wife|husband|son|daughter|uncle|aunt|cousin|boss|colleague|teacher|manager)(?: is| named| called)?\\s+([A-Z][a-z]+(?: [A-Z][a-z]+)?)")
    private val PLACE = Regex("\\b(?:in|at|near|from)\\s+([A-Z][a-zA-Z]+(?:[ -][A-Z][a-zA-Z]+){0,3})")
    private val PROPER = Regex("\\b([A-Z][a-zA-Z0-9]+(?:\\s+(?:of\\s+)?[A-Z][a-zA-Z0-9]+){1,4}|[A-Z]{2,}(?:-[A-Z0-9]+)?)\\b")
    private val ORG_HINT = Regex("(?i)\\b(ltd|limited|pvt|inc|authority|ministry|department|bank|board|university|college|samiti|society|court|council|corporation|nhai|epfo|upsc|gss|pacs)\\b")
    private val STOP = setOf("I", "The", "This", "That", "My", "We", "It", "A", "An", "In", "On", "At", "And", "Or", "But", "If", "OK", "AI")

    fun build(memories: List<MemoryRecord>, projects: List<Project>, tasks: List<TaskItem>, documents: List<DocumentMeta>): KnowledgeGraph {
        val ents = LinkedHashMap<String, Entity>()
        val rels = ArrayList<Relation>()
        fun add(name: String, type: EntityType, source: String): String {
            val k = KnowledgeGraph.key(name)
            val prev = ents[k]
            // Specific types beat generic CONCEPT.
            val t = if (prev == null || prev.type == EntityType.CONCEPT) type else prev.type
            ents[k] = Entity(k, prev?.name ?: name.trim(), t, (prev?.sources ?: emptySet()) + source)
            return k
        }
        fun rel(a: String, b: String, t: RelationType, ev: String) { if (a != b && rels.none { it.from == a && it.to == b && it.type == t }) rels += Relation(a, b, t, ev.take(160)) }

        val me = add("Me", EntityType.PERSON, "profile")
        val projectKeys = projects.associate { p -> p.id to add(p.name, EntityType.PROJECT, "project:${p.id}") }
        projectKeys.values.forEach { rel(me, it, RelationType.WORKS_ON, "Your project") }
        val taskKeys = tasks.associate { t -> t.id to add(t.title, EntityType.TASK, "task:${t.id}") }
        tasks.forEach { t ->
            val tk = taskKeys.getValue(t.id)
            t.projectId?.let { projectKeys[it] }?.let { rel(tk, it, RelationType.BELONGS_TO, "Task in project") }
            t.parentId?.let { taskKeys[it] }?.let { rel(tk, it, RelationType.BELONGS_TO, "Subtask") }
            t.dependsOn.mapNotNull { taskKeys[it] }.forEach { rel(tk, it, RelationType.DEPENDS_ON, "Task dependency") }
        }
        documents.forEach { d ->
            val dk = add(d.title, EntityType.DOCUMENT, "document:${d.id}")
            d.projectId?.let { projectKeys[it] }?.let { rel(dk, it, RelationType.BELONGS_TO, "Document in project") }
        }
        for (m in memories) {
            val src = "memory:${m.id}"
            val subject = m.projectId?.let { projectKeys[it] } ?: me
            val text = m.content
            PERSON_REL.findAll(text).forEach { r ->
                val pk = add(r.groupValues[2], EntityType.PERSON, src)
                rel(me, pk, RelationType.MENTIONS, "${r.groupValues[1]}: $text")
            }
            PLACE.findAll(text).forEach { r ->
                val name = r.groupValues[1]
                when {
                    name in STOP -> Unit
                    ORG_HINT.containsMatchIn(name) -> rel(subject, add(name, EntityType.ORGANIZATION, src), RelationType.MENTIONS, text)
                    else -> rel(subject, add(name, EntityType.PLACE, src), RelationType.LOCATED_AT, text)
                }
            }
            PROPER.findAll(text).forEach { r ->
                val name = r.groupValues[1].trim()
                if (name in STOP || name.length < 3) return@forEach
                if (ents[KnowledgeGraph.key(name)]?.type in setOf(EntityType.PLACE, EntityType.PERSON, EntityType.PROJECT)) {
                    rel(subject, KnowledgeGraph.key(name), RelationType.MENTIONS, text); return@forEach
                }
                val type = if (ORG_HINT.containsMatchIn(name)) EntityType.ORGANIZATION else EntityType.CONCEPT
                rel(subject, add(name, type, src), RelationType.MENTIONS, text)
            }
            // Existing project names mentioned in a global memory.
            projects.forEach { p -> if (text.contains(p.name, ignoreCase = true)) rel(me, projectKeys.getValue(p.id), RelationType.MENTIONS, text) }
        }
        return KnowledgeGraph(ents, rels)
    }
}
