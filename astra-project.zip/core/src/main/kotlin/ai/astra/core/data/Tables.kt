package ai.astra.core.data

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * A rectangular table of strings — the common shape for everything ASTRA can read records from:
 * Excel/CSV sheets, tables found in PDF text, and OCR'd paper registers.
 */
data class DataTable(
    val name: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    /** Where the table came from, for the run log ("sheet Members.xlsx › Sheet1", "OCR of photo 3"). */
    val origin: String = name,
    /** 0..1 — how sure the extractor is that columns line up (1.0 for spreadsheets). */
    val confidence: Double = 1.0,
) {
    val size: Int get() = rows.size

    fun column(header: String): Int = headers.indexOfFirst { it.equals(header, ignoreCase = true) }

    fun cell(row: Int, header: String): String = column(header).let { c -> if (c < 0) "" else rows.getOrNull(row)?.getOrNull(c).orEmpty() }

    fun record(row: Int): Map<String, String> = headers.mapIndexed { i, h -> h to rows[row].getOrElse(i) { "" } }.toMap()

    fun records(): List<Map<String, String>> = rows.indices.map { record(it) }

    /** Short preview for prompts and the UI (never the whole sheet). */
    fun preview(maxRows: Int = 5): String = buildString {
        appendLine(headers.joinToString(" | "))
        rows.take(maxRows).forEach { appendLine(it.joinToString(" | ")) }
        if (rows.size > maxRows) append("… ${rows.size - maxRows} more row(s)")
    }.trim()

    fun withRows(newRows: List<List<String>>) = copy(rows = newRows)

    companion object {
        /** Pads/truncates ragged rows, trims cells, drops fully empty rows and makes headers unique and non-blank. */
        fun normalized(name: String, header: List<String>, body: List<List<String>>, origin: String = name, confidence: Double = 1.0): DataTable {
            val width = maxOf(header.size, body.maxOfOrNull { it.size } ?: 0)
            val seen = HashMap<String, Int>()
            val heads = (0 until width).map { i ->
                val base = header.getOrNull(i)?.trim()?.replace(Regex("\\s+"), " ")?.ifBlank { null } ?: "Column ${i + 1}"
                val n = seen.merge(base.lowercase(), 1, Int::plus)!!
                if (n == 1) base else "$base ($n)"
            }
            val rows = body.map { r -> (0 until width).map { i -> r.getOrNull(i)?.trim().orEmpty() } }.filter { r -> r.any { it.isNotBlank() } }
            return DataTable(name, heads, rows, origin, confidence)
        }
    }
}

/** RFC 4180 CSV with delimiter detection (, ; tab |), BOM removal and quoted newlines. */
object CsvCodec {
    fun detectDelimiter(text: String): Char {
        val sample = text.lineSequence().filter { it.isNotBlank() }.take(10).toList()
        return listOf(',', ';', '\t', '|').maxByOrNull { d ->
            val counts = sample.map { line -> countOutsideQuotes(line, d) }
            if (counts.isEmpty() || counts.first() == 0) 0.0 else counts.count { it == counts.first() } * 10.0 + counts.first()
        } ?: ','
    }

    private fun countOutsideQuotes(line: String, d: Char): Int {
        var q = false; var n = 0
        for (c in line) { if (c == '"') q = !q else if (c == d && !q) n++ }
        return n
    }

    fun parseRows(text: String, delimiter: Char = detectDelimiter(text)): List<List<String>> {
        val s = text.removePrefix("\uFEFF")
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var i = 0
        var quoted = false
        while (i < s.length) {
            val c = s[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') { cell.append('"'); i++ } else quoted = false
                } else cell.append(c)
            } else when (c) {
                '"' -> if (cell.isEmpty()) quoted = true else cell.append(c)
                delimiter -> { row.add(cell.toString()); cell.clear() }
                '\r' -> {}
                '\n' -> { row.add(cell.toString()); cell.clear(); rows.add(row); row = ArrayList() }
                else -> cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        return rows
    }

    fun parse(name: String, text: String): DataTable {
        val rows = parseRows(text)
        val h = HeaderDetector.headerRow(rows)
        return DataTable.normalized(name, rows.getOrElse(h) { emptyList() }, rows.drop(h + 1), name)
    }

    fun write(table: DataTable, delimiter: Char = ','): String = buildString {
        fun esc(v: String) = if (v.any { it == delimiter || it == '"' || it == '\n' || it == '\r' }) "\"" + v.replace("\"", "\"\"") + "\"" else v
        appendLine(table.headers.joinToString(delimiter.toString(), transform = ::esc))
        table.rows.forEach { appendLine(it.joinToString(delimiter.toString(), transform = ::esc)) }
    }
}

/** Finds the header row in sheets that have a title or blank rows above the real column names. */
object HeaderDetector {
    fun headerRow(rows: List<List<String>>): Int {
        if (rows.isEmpty()) return 0
        val width = rows.take(30).maxOfOrNull { r -> r.count { it.isNotBlank() } } ?: 0
        if (width == 0) return 0
        for ((i, r) in rows.take(15).withIndex()) {
            val filled = r.filter { it.isNotBlank() }
            if (filled.size < maxOf(2, (width * 0.6).toInt())) continue
            val texty = filled.count { cell -> cell.any { it.isLetter() } && cell.toDoubleOrNull() == null }
            if (texty >= filled.size * 0.7 && filled.map { it.lowercase() }.toSet().size == filled.size) return i
        }
        return rows.indexOfFirst { r -> r.any { it.isNotBlank() } }.coerceAtLeast(0)
    }
}

/**
 * Reads real cell positions from .xlsx (unlike text extraction, empty cells keep their column),
 * shared and inline strings, booleans and date-formatted numbers (→ yyyy-MM-dd).
 */
object XlsxReader {
    private const val MAX_ENTRY = 40L * 1024 * 1024
    private const val MAX_TOTAL = 150L * 1024 * 1024
    private val BUILTIN_DATE_FORMATS = setOf(14, 15, 16, 17, 22, 27, 30, 36, 45, 46, 47, 50, 57)

    fun read(fileName: String, bytes: ByteArray): List<DataTable> {
        val parts = unzip(bytes)
        val shared = parts["xl/sharedStrings.xml"]?.let { ss ->
            Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(ss).map { si -> texts(si.groupValues[1]) }.toList()
        }.orEmpty()
        val dateStyles = dateStyleIndexes(parts["xl/styles.xml"])
        val sheetNames = parts["xl/workbook.xml"]?.let { wb -> Regex("<sheet\\b[^>]*\\bname=\"([^\"]+)\"").findAll(wb).map { unescape(it.groupValues[1]) }.toList() }.orEmpty()
        val sheetKeys = parts.keys.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
            .sortedBy { it.removePrefix("xl/worksheets/sheet").removeSuffix(".xml").toIntOrNull() ?: 0 }
        return sheetKeys.mapIndexedNotNull { idx, key ->
            val grid = sheetGrid(parts.getValue(key), shared, dateStyles)
            if (grid.isEmpty()) return@mapIndexedNotNull null
            val h = HeaderDetector.headerRow(grid)
            val sheet = sheetNames.getOrNull(idx) ?: "Sheet${idx + 1}"
            DataTable.normalized(sheet, grid[h], grid.drop(h + 1), "$fileName › $sheet")
        }
    }

    private fun sheetGrid(xml: String, shared: List<String>, dateStyles: Set<Int>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var lastRow = 0
        Regex("<row\\b([^>]*?)(?:/>|>(.*?)</row>)", RegexOption.DOT_MATCHES_ALL).findAll(xml).forEach { rm ->
            val rAttr = Regex("\\br=\"(\\d+)\"").find(rm.groupValues[1])?.groupValues?.get(1)?.toIntOrNull() ?: (lastRow + 1)
            while (lastRow + 1 < rAttr && rows.size < 1_000_000) { rows.add(emptyList()); lastRow++ }
            lastRow = rAttr
            val cells = ArrayList<String>()
            var nextCol = 0
            Regex("<c\\b([^>]*?)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL).findAll(rm.groupValues[2]).forEach { cm ->
                val attrs = cm.groupValues[1]
                val inner = cm.groupValues[2]
                val col = Regex("\\br=\"([A-Z]+)\\d+\"").find(attrs)?.groupValues?.get(1)?.let(::columnIndex) ?: nextCol
                nextCol = col + 1
                val type = Regex("\\bt=\"(\\w+)\"").find(attrs)?.groupValues?.get(1)
                val style = Regex("\\bs=\"(\\d+)\"").find(attrs)?.groupValues?.get(1)?.toIntOrNull()
                val v = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL).find(inner)?.groupValues?.get(1)?.let(::unescape)
                val value = when (type) {
                    "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) }.orEmpty()
                    "inlineStr" -> texts(inner)
                    "b" -> if (v == "1") "TRUE" else "FALSE"
                    "str", "e" -> v.orEmpty()
                    else -> when {
                        v == null -> ""
                        style != null && style in dateStyles -> v.toDoubleOrNull()?.let { excelDate(it) } ?: v
                        else -> cleanNumber(v)
                    }
                }
                while (cells.size < col) cells.add("")
                if (cells.size == col) cells.add(value) else cells[col] = value
            }
            rows.add(cells)
        }
        return rows.dropLastWhile { r -> r.all { it.isBlank() } }
    }

    /** Excel serial date (1900 system) → ISO date. */
    fun excelDate(serial: Double): String = LocalDate.of(1899, 12, 30).plusDays(serial.toLong()).toString()

    private fun cleanNumber(v: String): String {
        val d = v.toDoubleOrNull() ?: return v
        // Excel stores 12-digit IDs as 1.23456789012E11 — show them as written.
        return if (d == Math.rint(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString() else java.math.BigDecimal(v).stripTrailingZeros().toPlainString()
    }

    fun columnIndex(letters: String): Int = letters.fold(0) { acc, c -> acc * 26 + (c - 'A' + 1) } - 1

    private fun dateStyleIndexes(styles: String?): Set<Int> {
        if (styles == null) return emptySet()
        val custom = Regex("<numFmt\\b[^>]*numFmtId=\"(\\d+)\"[^>]*formatCode=\"([^\"]*)\"").findAll(styles)
            .filter { m -> val f = unescape(m.groupValues[2]).replace(Regex("\"[^\"]*\"|\\[[^]]*]"), "").lowercase(); f.contains('d') || f.contains('y') || (f.contains('m') && !f.contains('0')) }
            .map { it.groupValues[1].toInt() }.toSet()
        val xfs = Regex("<cellXfs\\b[^>]*>(.*?)</cellXfs>", RegexOption.DOT_MATCHES_ALL).find(styles)?.groupValues?.get(1) ?: return emptySet()
        return Regex("<xf\\b([^>]*)").findAll(xfs).mapIndexedNotNull { i, m ->
            val id = Regex("numFmtId=\"(\\d+)\"").find(m.groupValues[1])?.groupValues?.get(1)?.toIntOrNull() ?: 0
            if (id in BUILTIN_DATE_FORMATS || id in custom) i else null
        }.toSet()
    }

    private fun texts(xml: String) = Regex("<t(?:\\s[^>]*)?>(.*?)</t>", RegexOption.DOT_MATCHES_ALL).findAll(xml).joinToString("") { unescape(it.groupValues[1]) }

    internal fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
        .replace(Regex("&#(\\d+);")) { it.groupValues[1].toInt().toChar().toString() }
        .replace(Regex("&#x([0-9a-fA-F]+);")) { it.groupValues[1].toInt(16).toChar().toString() }
        .replace("&amp;", "&")

    private fun unzip(bytes: ByteArray): Map<String, String> {
        val out = HashMap<String, String>()
        var total = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val n = e.name
                if (e.isDirectory || !(n == "xl/sharedStrings.xml" || n == "xl/workbook.xml" || n == "xl/styles.xml" || n.startsWith("xl/worksheets/sheet"))) continue
                val buf = ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                var size = 0L
                while (true) {
                    val r = zip.read(chunk)
                    if (r < 0) break
                    size += r; total += r
                    require(size <= MAX_ENTRY && total <= MAX_TOTAL) { "Spreadsheet is too large or malformed" }
                    buf.write(chunk, 0, r)
                }
                out[n] = buf.toString(Charsets.UTF_8.name())
            }
        }
        require(out.keys.any { it.startsWith("xl/worksheets/") }) { "Not a valid .xlsx file" }
        return out
    }
}

/** Writes a minimal, valid .xlsx (one sheet per table, inline strings) — for run logs and cleaned data. */
object XlsxWriter {
    fun write(tables: List<DataTable>): ByteArray {
        require(tables.isNotEmpty())
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            fun put(name: String, content: String) { z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""" +
                tables.indices.joinToString("") { """<Override PartName="/xl/worksheets/sheet${it + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""" } + "</Types>")
            put("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""" +
                tables.mapIndexed { i, t -> """<sheet name="${esc(safeSheetName(t.name, i))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""" }.joinToString("") + "</sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
                tables.indices.joinToString("") { """<Relationship Id="rId${it + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${it + 1}.xml"/>""" } + "</Relationships>")
            tables.forEachIndexed { i, t -> put("xl/worksheets/sheet${i + 1}.xml", sheet(t)) }
        }
        return bos.toByteArray()
    }

    private fun safeSheetName(n: String, i: Int) = n.replace(Regex("[\\\\/?*\\[\\]:]"), " ").trim().take(31).ifBlank { "Sheet${i + 1}" }

    private fun sheet(t: DataTable): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
        (listOf(t.headers) + t.rows).forEachIndexed { r, row ->
            append("<row r=\"${r + 1}\">")
            row.forEachIndexed { c, v ->
                val ref = colName(c) + (r + 1)
                if (r > 0 && v.matches(Regex("-?(0|[1-9]\\d{0,14})(\\.\\d+)?"))) append("<c r=\"$ref\"><v>$v</v></c>")
                else append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v)}</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    fun colName(i: Int): String { var n = i + 1; val sb = StringBuilder(); while (n > 0) { val m = (n - 1) % 26; sb.append('A' + m); n = (n - 1) / 26 }; return sb.reverse().toString() }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        .filter { it == '\t' || it == '\n' || it == '\r' || it >= ' ' }
}

/**
 * Finds a table in plain text — PDF text layers and OCR of paper registers. Columns are split on
 * tabs, pipes or runs of 2+ spaces; the most common column count wins, and the confidence says how
 * many lines agreed. ASTRA always shows the result for review before using it.
 */
object TextTableExtractor {
    private val SPLIT = Regex("\\t+|\\s*\\|\\s*|\\s{2,}")

    fun extract(name: String, text: String, origin: String = name): DataTable? {
        val lines = text.lines().map { it.trim().trim('|').trim() }.filter { it.isNotBlank() }
        if (lines.size < 2) return null
        val split = lines.map { l -> l.split(SPLIT).map { it.trim() }.filter { it.isNotEmpty() } }
        val counts = split.map { it.size }.filter { it >= 2 }
        if (counts.isEmpty()) return null
        val width = counts.groupingBy { it }.eachCount().maxWithOrNull(compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })!!.key
        val good = split.withIndex().filter { (_, c) -> c.size == width || c.size == width - 1 && width > 3 }
        if (good.size < 2) return null
        val header = good.first().value
        val headerLooksLikeData = header.count { cell -> cell.any(Char::isDigit) } > header.size / 2
        val body = (if (headerLooksLikeData) good else good.drop(1)).map { it.value }
        val heads = if (headerLooksLikeData) (1..width).map { "Column $it" } else header
        val confidence = (good.size.toDouble() / lines.size).coerceIn(0.0, 1.0)
        return DataTable.normalized(name, heads, body, origin, confidence)
    }
}
