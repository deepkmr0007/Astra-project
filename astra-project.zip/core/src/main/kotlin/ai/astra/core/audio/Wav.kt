package ai.astra.core.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class WavInfo(val sampleRate: Int, val channels: Int, val bitsPerSample: Int, val dataOffset: Long, val dataSize: Long) {
    val bytesPerSecond: Int get() = sampleRate * channels * bitsPerSample / 8
    val durationSeconds: Double get() = if (bytesPerSecond == 0) 0.0 else dataSize.toDouble() / bytesPerSecond
}

/** Minimal PCM WAV reader/writer/splitter, used to feed long recordings to audio models in chunks. */
object Wav {
    fun header(sampleRate: Int, channels: Int, bits: Int, dataSize: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataSize).toInt()); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(channels.toShort()); b.putInt(sampleRate)
        b.putInt(sampleRate * channels * bits / 8); b.putShort((channels * bits / 8).toShort()); b.putShort(bits.toShort())
        b.put("data".toByteArray()); b.putInt(dataSize.toInt())
        return b.array()
    }

    fun read(file: File): WavInfo? = RandomAccessFile(file, "r").use { f ->
        val head = ByteArray(12)
        if (f.read(head) != 12 || String(head, 0, 4) != "RIFF" || String(head, 8, 4) != "WAVE") return null
        var rate = 0; var ch = 0; var bits = 0
        while (f.filePointer + 8 <= f.length()) {
            val ck = ByteArray(8); f.readFully(ck)
            val id = String(ck, 0, 4)
            val size = ByteBuffer.wrap(ck, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
            if (id == "fmt ") {
                val fmt = ByteArray(size.toInt().coerceAtMost(64)); f.readFully(fmt)
                val bb = ByteBuffer.wrap(fmt).order(ByteOrder.LITTLE_ENDIAN)
                if (bb.getShort(0).toInt() != 1) return null // PCM only
                ch = bb.getShort(2).toInt(); rate = bb.getInt(4); bits = bb.getShort(14).toInt()
                if (size > 64) f.seek(f.filePointer + size - 64)
            } else if (id == "data") {
                val dataSize = minOf(size, f.length() - f.filePointer)
                return if (rate > 0) WavInfo(rate, ch, bits, f.filePointer, dataSize) else null
            } else f.seek(f.filePointer + size + (size and 1))
        }
        null
    }

    /** Splits a PCM WAV into chunks of at most [seconds]; returns the chunk files (original if already short). */
    fun split(file: File, seconds: Int, outDir: File): List<File> {
        val info = read(file) ?: return listOf(file)
        val chunkBytes = (info.bytesPerSecond.toLong() * seconds).let { it - it % (info.channels * info.bitsPerSample / 8) }
        if (info.dataSize <= chunkBytes) return listOf(file)
        outDir.mkdirs()
        val out = ArrayList<File>()
        RandomAccessFile(file, "r").use { f ->
            var pos = 0L
            var idx = 0
            while (pos < info.dataSize) {
                val len = minOf(chunkBytes, info.dataSize - pos)
                val buf = ByteArray(len.toInt())
                f.seek(info.dataOffset + pos); f.readFully(buf)
                val chunk = File(outDir, "${file.nameWithoutExtension}-part${idx++}.wav")
                chunk.outputStream().use { o -> o.write(header(info.sampleRate, info.channels, info.bitsPerSample, len)); o.write(buf) }
                out += chunk
                pos += len
            }
        }
        return out
    }
}
