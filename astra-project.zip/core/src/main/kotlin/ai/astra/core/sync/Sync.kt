package ai.astra.core.sync

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class BadPassphraseException : RuntimeException("Wrong passphrase or damaged file")

/**
 * Passphrase-encrypted container for backups / sync files: PBKDF2-HMAC-SHA256 (210,000 rounds)
 * → AES-256-GCM. Layout: "ASTRAENC1" | iterations(int) | salt(16) | iv(12) | ciphertext+tag.
 * The passphrase never leaves the device and is not stored.
 */
object EncryptedBundle {
    private val MAGIC = "ASTRAENC1".toByteArray()
    const val ITERATIONS = 210_000

    private fun key(pass: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = f.generateSecret(PBEKeySpec(pass, salt, iterations, 256)).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun encrypt(plain: ByteArray, passphrase: CharArray, iterations: Int = ITERATIONS): ByteArray {
        require(passphrase.size >= 8) { "Use a passphrase of at least 8 characters" }
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(passphrase, salt, iterations), GCMParameterSpec(128, iv))
        c.updateAAD(MAGIC)
        val ct = c.doFinal(plain)
        return ByteArrayOutputStream().apply { write(MAGIC); write(ByteBuffer.allocate(4).putInt(iterations).array()); write(salt); write(iv); write(ct) }.toByteArray()
    }

    fun isEncrypted(data: ByteArray): Boolean = data.size > MAGIC.size && data.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    fun decrypt(data: ByteArray, passphrase: CharArray): ByteArray {
        require(isEncrypted(data)) { "Not an ASTRA encrypted file" }
        var p = MAGIC.size
        val iterations = ByteBuffer.wrap(data, p, 4).int.also { p += 4 }
        require(iterations in 10_000..5_000_000) { "Damaged file" }
        val salt = data.copyOfRange(p, p + 16).also { p += 16 }
        val iv = data.copyOfRange(p, p + 12).also { p += 12 }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(passphrase, salt, iterations), GCMParameterSpec(128, iv))
        c.updateAAD(MAGIC)
        return try { c.doFinal(data, p, data.size - p) } catch (e: javax.crypto.AEADBadTagException) { throw BadPassphraseException() }
    }
}

data class MergeConflict<T>(val local: T, val incoming: T, val kept: T)

data class MergeResult<T>(val toUpsert: List<T>, val unchanged: Int, val added: Int, val updated: Int, val conflicts: List<MergeConflict<T>>)

/**
 * Last-writer-wins merge by record id and version timestamp. When the same record differs on both
 * sides, the newer one is kept and the pair is reported so the user can see what changed.
 */
object LwwMerge {
    fun <T> merge(local: List<T>, incoming: List<T>, id: (T) -> String, version: (T) -> Long, same: (T, T) -> Boolean): MergeResult<T> {
        val byId = local.associateBy(id)
        val out = ArrayList<T>()
        val conflicts = ArrayList<MergeConflict<T>>()
        var added = 0; var updated = 0; var unchanged = 0
        for (inc in incoming) {
            val loc = byId[id(inc)]
            when {
                loc == null -> { out += inc; added++ }
                same(loc, inc) -> unchanged++
                version(inc) > version(loc) -> { out += inc; updated++; conflicts += MergeConflict(loc, inc, inc) }
                else -> { unchanged++; conflicts += MergeConflict(loc, inc, loc) }
            }
        }
        return MergeResult(out, unchanged, added, updated, conflicts)
    }
}
