package ai.astra.core.builder

import ai.astra.core.data.DataTable
import ai.astra.core.json.Json
import ai.astra.core.json.obj
import ai.astra.core.json.str

data class Clarification(val key: String, val question: String, val suggestions: List<String> = emptyList())

data class PlanResult(
    val spec: AutomationSpec,
    val questions: List<Clarification>,
    val warnings: List<String>,
    /** "model" when a language model wrote the plan, "template" when ASTRA's built-in planner did. */
    val origin: String,
)

/**
 * Turns a plain-language requirement ("enter these loan records in the e-PACS portal") into an
 * editable [AutomationSpec]. With a model, the model drafts the plan as JSON and ASTRA validates
 * it; without one (or if the model's JSON is unusable) a built-in template planner produces a
 * sensible first draft. Either way ASTRA lists what it still needs to know.
 */
object RequirementPlanner {
    private val URL = Regex("https?://[^\\s\"'<>)]+")
    private val PHONE_WORDS = Regex("(?i)\\b(phone app|mobile app|on (my|the) phone|whatsapp|android app|फोन|मोबाइल ऐप|app me|app mein)\\b")
    private val BROWSER_WORDS = Regex("(?i)\\b(website|web ?site|portal|erp|browser|chrome|computer|laptop|pc|url|login page|e-?pacs|online form|वेबसाइट|पोर्टल|कंप्यूटर)\\b")
    private val NO_SAVE = Regex("(?i)(only fill|just fill|don'?t (save|submit)|do not (save|submit)|i will (save|submit|click)|sirf bhar|save mat|सिर्फ भर)")
    private val SAVE_WORDS = Regex("(?i)(save|submit|सेव|जमा|सहेज|प्रस्तुत|add record|post)")
    private val SAVE_BUTTON = Regex("(?i)(save|submit|सहेजें|सेव|जमा|प्रस्तुत|add|insert|update|proceed)")
    private val SUCCESS_HINT = "saved successfully"

    fun prompt(requirement: String, table: DataTable?, form: FormSnapshot?, taught: String = ""): String = buildString {
        appendLine("You design safe, human-supervised automations for the user's own accounts. Write a plan as JSON only, no prose.")
        appendLine("The user's requirement:")
        appendLine(requirement.trim())
        appendLine()
        if (table != null) {
            appendLine("Data source \"${table.origin}\" has ${table.size} record(s). Columns and sample rows:")
            appendLine(table.preview(3))
            appendLine()
        }
        if (form != null) {
            appendLine("The target form, as scanned from the page:")
            appendLine(form.describe())
            appendLine()
        }
        if (taught.isNotBlank()) { appendLine("Things the user taught you earlier:"); appendLine(taught); appendLine() }
        appendLine("Rules:")
        appendLine("- The user logs in, solves CAPTCHAs and enters OTPs personally: add a WAIT_FOR_USER step for that. Never try to bypass them.")
        appendLine("- Use SUBMIT only for the button that saves; put REVIEW before it so the user approves each record.")
        appendLine("- Use only these actions: " + StepAction.entries.joinToString { it.name })
        appendLine("- Values are templates with {Column Name} placeholders from the data columns.")
        appendLine("- setup = steps run once; record = steps repeated for each record (end with NEXT_RECORD).")
        appendLine()
        appendLine("JSON shape:")
        appendLine("""{"name":"…","target":"BROWSER|PHONE","setup":[{"action":"OPEN_URL","target":"https://…"},{"action":"WAIT_FOR_USER","value":"Log in, then tap Continue"}],"record":[{"action":"FILL_FORM"},{"action":"REVIEW"},{"action":"SUBMIT","target":"Save"},{"action":"CHECK_TEXT","target":"saved"},{"action":"NEXT_RECORD"}],"mappings":[{"selector":"#txtName","label":"Member name","template":"{Name}","type":"TEXT"}],"questions":["anything you still need to know"]}""")
    }

    /** Parses a model's plan. Returns null when there is no usable JSON (the caller falls back to [draft]). */
    fun parse(modelText: String, requirement: String, table: DataTable?, form: FormSnapshot?): PlanResult? {
        val json = extractJsonObject(modelText) ?: return null
        val o = runCatching { Json.parse(json).obj() }.getOrNull() ?: return null
        val warnings = ArrayList<String>()
        val base = draft(requirement, table, form)
        var spec = runCatching { AutomationCodec.fromJson(o) }.getOrElse { return null }
        if (spec.setupSteps.isEmpty() && spec.recordSteps.isEmpty()) return null
        if (spec.name.isBlank()) spec = spec.copy(name = base.spec.name)
        spec = spec.copy(goal = requirement.trim(), expectedColumns = table?.headers.orEmpty())
        // Keep only mappings that point at real fields/columns; fill the rest from the offline matcher.
        if (form != null) {
            val known = form.inputs.associateBy { it.selector }
            val valid = spec.mappings.filter { m ->
                val ok = m.selector in known && ValueEngine.columnsIn(m.template).all { c -> table == null || table.headers.any { it.equals(c, true) } }
                if (!ok) warnings += "Ignored a suggested mapping for “${m.label.ifBlank { m.selector }}” (field or column not found)"
                ok
            }.map { m -> known[m.selector]?.let { f -> m.copy(type = f.type, options = f.options, required = f.required, maxLength = f.maxLength, pattern = f.pattern, label = m.label.ifBlank { f.label }) } ?: m }
            val offline = base.spec.mappings.filter { b -> valid.none { it.selector == b.selector } }
            spec = spec.copy(mappings = valid + offline)
        } else if (spec.mappings.isEmpty()) spec = spec.copy(mappings = base.spec.mappings)
        spec = enforceSafety(spec, warnings)
        val modelQuestions = o["questions"].let { q -> (q as? ai.astra.core.json.JsonValue.Arr)?.items?.mapNotNull { it.str() }.orEmpty() }
        val questions = questions(spec, requirement, table, form) + modelQuestions.mapIndexed { i, q -> Clarification("model$i", q) }
        return PlanResult(spec, questions.distinctBy { it.question }, warnings, "model")
    }

    /** Built-in planner — no model needed. */
    fun draft(requirement: String, table: DataTable?, form: FormSnapshot?): PlanResult {
        val warnings = ArrayList<String>()
        val url = URL.find(requirement)?.value?.trimEnd('.', ',')
        val target = when {
            PHONE_WORDS.containsMatchIn(requirement) && !BROWSER_WORDS.containsMatchIn(requirement) -> AutomationTarget.PHONE
            else -> AutomationTarget.BROWSER
        }
        val noSave = NO_SAVE.containsMatchIn(requirement)
        val mappings = if (table != null && form != null) mappingsFor(table.headers, form) else emptyList()
        val saveButton = form?.buttons?.firstOrNull { SAVE_BUTTON.containsMatchIn(it.label) }
        val setup = buildList {
            if (target == AutomationTarget.BROWSER) {
                if (url != null) add(Step(StepAction.OPEN_URL, url))
                add(Step(StepAction.WAIT_FOR_USER, value = "Log in (type the CAPTCHA/OTP yourself) and open the entry form, then tap Continue."))
            } else add(Step(StepAction.WAIT_FOR_USER, value = "Open the screen where entries are made, then tap Continue."))
        }
        val record = buildList {
            if (target == AutomationTarget.BROWSER) {
                add(Step(StepAction.FILL_FORM))
                add(Step(StepAction.REVIEW))
                if (!noSave && (SAVE_WORDS.containsMatchIn(requirement) || saveButton != null)) {
                    add(Step(StepAction.SUBMIT, saveButton?.selector ?: "Save"))
                    add(Step(StepAction.PAUSE, value = "2"))
                }
            } else {
                add(Step(StepAction.REVIEW, note = "Add TYPE / TAP steps for each field on the phone screen"))
            }
            if (table != null) add(Step(StepAction.NEXT_RECORD))
        }
        val name = nameFor(requirement)
        val spec = enforceSafety(AutomationSpec(
            name = name, goal = requirement.trim(), target = target, setupSteps = setup, recordSteps = record, mappings = mappings,
            options = RunOptions(dryRun = noSave), expectedColumns = table?.headers.orEmpty(),
        ), warnings)
        return PlanResult(spec, questions(spec, requirement, table, form), warnings, "template")
    }

    fun mappingsFor(columns: List<String>, form: FormSnapshot): List<FieldMapping> =
        FieldMapper.suggest(columns, form).filter { it.column != null }.map { s ->
            val f = s.field
            FieldMapping(
                selector = f.selector, label = f.label.ifBlank { f.name }, template = "{${s.column}}",
                transform = when (f.type) {
                    FieldType.DATE -> Transform.DATE
                    FieldType.NUMBER, FieldType.PHONE -> Transform.DIGITS
                    else -> if (Regex("(?i)aadha|mobile|phone|pin").containsMatchIn(f.matchText)) Transform.DIGITS else Transform.TRIM
                },
                dateFormat = dateFormatHint(f), type = f.type, options = f.options, required = f.required, maxLength = f.maxLength, pattern = f.pattern,
            )
        }

    private fun dateFormatHint(f: FormField): String {
        val p = (f.placeholder + " " + f.label).lowercase()
        return when {
            f.type == FieldType.DATE && f.placeholder.isBlank() -> "yyyy-MM-dd" // HTML <input type=date> wants ISO
            p.contains("yyyy-mm-dd") -> "yyyy-MM-dd"
            p.contains("dd-mm-yyyy") -> "dd-MM-yyyy"
            p.contains("mm/dd/yyyy") -> "MM/dd/yyyy"
            p.contains("dd-mmm-yyyy") -> "dd-MMM-yyyy"
            else -> "dd/MM/yyyy"
        }
    }

    /** Makes sure saving is always preceded by a review when review is on, and that loops end. */
    fun enforceSafety(spec: AutomationSpec, warnings: MutableList<String>): AutomationSpec {
        var record = spec.recordSteps
        val submitAt = record.indexOfFirst { it.action == StepAction.SUBMIT }
        if (submitAt >= 0 && record.take(submitAt).none { it.action == StepAction.REVIEW }) {
            record = record.toMutableList().apply { add(submitAt, Step(StepAction.REVIEW)) }
            warnings += "Added a review step before saving"
        }
        if (record.isNotEmpty() && record.count { it.action == StepAction.NEXT_RECORD } > 1) {
            record = record.filter { it.action != StepAction.NEXT_RECORD } + Step(StepAction.NEXT_RECORD)
        }
        val setup = spec.setupSteps.filter { it.action != StepAction.NEXT_RECORD && it.action != StepAction.SUBMIT }
        if (setup.size != spec.setupSteps.size) warnings += "Moved save/next steps out of the one-time setup"
        return spec.copy(setupSteps = setup, recordSteps = record)
    }

    fun questions(spec: AutomationSpec, requirement: String, table: DataTable?, form: FormSnapshot?): List<Clarification> = buildList {
        if (spec.target == AutomationTarget.BROWSER && spec.setupSteps.none { it.action == StepAction.OPEN_URL })
            add(Clarification("url", "What is the web address of the portal (the login page)?"))
        if (table == null && spec.needsData)
            add(Clarification("data", "Where are the records? Import an Excel/CSV file, a PDF, or photos of the register."))
        if (form == null && spec.recordSteps.any { it.action == StepAction.FILL_FORM })
            add(Clarification("form", "Open the entry form on your computer and tap “Scan form” so I can see its fields."))
        if (table != null && form != null) {
            val mapped = spec.mappings.map { it.selector }.toSet()
            form.inputs.filter { it.required && it.selector !in mapped }.forEach { f ->
                add(Clarification("map:${f.selector}", "Which column (or fixed value) goes into “${f.label.ifBlank { f.name }}”? It's required.", table.headers.take(8)))
            }
        }
        if (spec.recordSteps.none { it.action == StepAction.SUBMIT } && !spec.options.dryRun && spec.target == AutomationTarget.BROWSER && form != null)
            add(Clarification("save", "Should I click Save after you approve each record, or only fill and let you click Save?", listOf("Click Save after I approve", "Only fill")))
        if (spec.recordSteps.any { it.action == StepAction.SUBMIT } && spec.recordSteps.none { it.action == StepAction.CHECK_TEXT })
            add(Clarification("success", "What does the portal show after a record is saved (for example “$SUCCESS_HINT”)? I'll check for it before moving on."))
    }

    private fun nameFor(requirement: String): String {
        val words = requirement.trim().split(Regex("\\s+")).filter { it.length > 2 && !it.startsWith("http") }.take(6)
        return words.joinToString(" ").replaceFirstChar { it.uppercase() }.take(48).ifBlank { "New automation" }
    }

    /** Finds the first balanced {...} block (models often wrap JSON in prose or code fences). */
    fun extractJsonObject(text: String): String? {
        val start = text.indexOf('{').takeIf { it >= 0 } ?: return null
        var depth = 0; var inStr = false; var esc = false
        for (i in start until text.length) {
            val c = text[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) { '"' -> inStr = true; '{' -> depth++; '}' -> { depth--; if (depth == 0) return text.substring(start, i + 1) } }
        }
        return null
    }
}
