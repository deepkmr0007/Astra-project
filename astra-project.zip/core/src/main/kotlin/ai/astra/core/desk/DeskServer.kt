package ai.astra.core.desk

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A deliberately tiny HTTP/1.1 server for the LAN link: one request per connection, bodies up to
 * 4 MB, only private-network clients accepted. Everything after pairing is end-to-end encrypted
 * by [DeskHub], so plain HTTP on the LAN reveals nothing but message sizes.
 */
class DeskServer(private val hub: DeskHub, val port: Int = DEFAULT_PORT, private val log: (String) -> Unit = {}) {
    private var server: ServerSocket? = null
    private val running = AtomicBoolean(false)
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "astra-desk").apply { isDaemon = true } }
    private val slots = Semaphore(24)

    val isRunning: Boolean get() = running.get()

    fun start() {
        if (!running.compareAndSet(false, true)) return
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        pool.execute {
            while (running.get()) {
                val c = try { s.accept() } catch (e: Exception) { if (running.get()) log("accept: ${e.message}"); break }
                if (!allowed(c.inetAddress) || !slots.tryAcquire()) { runCatching { c.close() }; continue }
                pool.execute { try { serve(c) } finally { slots.release() } }
            }
        }
        log("Listening on port $port")
    }

    fun stop() {
        running.set(false)
        runCatching { server?.close() }
        server = null
    }

    private fun allowed(a: InetAddress): Boolean = a.isLoopbackAddress || a.isSiteLocalAddress || a.isLinkLocalAddress ||
        // IPv6 unique-local (fc00::/7), e.g. some hotspots.
        (a.address.size == 16 && (a.address[0].toInt() and 0xfe) == 0xfc)

    private fun serve(c: Socket) {
        c.use { sock ->
            sock.soTimeout = 30_000
            val input = BufferedInputStream(sock.getInputStream())
            val reply = try {
                val req = readRequest(input)
                hub.handle(req.method, req.path, req.body)
            } catch (e: Exception) {
                HttpReply(400, """{"error":"bad request"}""")
            }
            val body = reply.body.toByteArray(Charsets.UTF_8)
            val head = "HTTP/1.1 ${reply.status} ${reason(reply.status)}\r\nContent-Type: ${reply.contentType}\r\nContent-Length: ${body.size}\r\n" +
                "Cache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n"
            runCatching { sock.getOutputStream().apply { write(head.toByteArray(Charsets.US_ASCII)); write(body); flush() } }
        }
    }

    data class Request(val method: String, val path: String, val headers: Map<String, String>, val body: String)

    companion object {
        const val DEFAULT_PORT = 8765
        private const val MAX_BODY = 4 * 1024 * 1024

        fun reason(code: Int) = when (code) { 200 -> "OK"; 400 -> "Bad Request"; 403 -> "Forbidden"; 404 -> "Not Found"; 409 -> "Conflict"; 429 -> "Too Many Requests"; else -> "Error" }

        fun readRequest(input: InputStream): Request {
            val line = readLine(input) ?: throw IllegalArgumentException("empty")
            val parts = line.split(' ')
            require(parts.size >= 2) { "bad request line" }
            val headers = HashMap<String, String>()
            while (true) {
                val h = readLine(input) ?: break
                if (h.isEmpty()) break
                val i = h.indexOf(':')
                if (i > 0) headers[h.substring(0, i).trim().lowercase()] = h.substring(i + 1).trim()
                require(headers.size < 64) { "too many headers" }
            }
            val len = headers["content-length"]?.toIntOrNull() ?: 0
            require(len in 0..MAX_BODY) { "body too large" }
            val buf = ByteArray(len)
            var read = 0
            while (read < len) { val n = input.read(buf, read, len - read); if (n < 0) break; read += n }
            return Request(parts[0].uppercase(), parts[1].substringBefore('?'), headers, String(buf, 0, read, Charsets.UTF_8))
        }

        private fun readLine(input: InputStream): String? {
            val out = ByteArrayOutputStream()
            while (true) {
                val b = input.read()
                if (b < 0) return if (out.size() == 0) null else out.toString(Charsets.UTF_8.name())
                if (b == '\n'.code) return out.toString(Charsets.UTF_8.name()).trimEnd('\r')
                out.write(b)
                require(out.size() < 8192) { "line too long" }
            }
        }
    }
}
