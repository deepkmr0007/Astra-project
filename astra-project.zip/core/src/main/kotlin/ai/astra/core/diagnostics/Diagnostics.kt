package ai.astra.core.diagnostics

import ai.astra.core.provider.GenerationStats
import ai.astra.core.provider.ProviderInfo
import ai.astra.core.security.Redactor
import java.time.Instant

data class DiagEvent(val time: Long, val tag: String, val message: String)

data class GenerationRecord(val time: Long, val providerId: String, val model: String, val tokensOut: Int, val tokensPerSecond: Double, val firstTokenMs: Long, val durationMs: Long, val bytesSent: Long)

/**
 * Technical diagnostics, kept separate from conversations. Everything is redacted on write, so
 * API keys, tokens and personal identifiers never reach the log. User-clearable and exportable.
 */
class Diagnostics(private val capacity: Int = 400) {
    private val events = ArrayDeque<DiagEvent>()
    private val generations = ArrayDeque<GenerationRecord>()
    private val lock = Any()

    fun log(tag: String, message: String) = synchronized(lock) {
        events.addLast(DiagEvent(System.currentTimeMillis(), tag, Redactor.redact(message).take(500)))
        while (events.size > capacity) events.removeFirst()
    }

    fun recordGeneration(info: ProviderInfo, stats: GenerationStats) = synchronized(lock) {
        generations.addLast(GenerationRecord(System.currentTimeMillis(), info.id, info.model, stats.tokensOut, stats.tokensPerSecond, stats.firstTokenMs, stats.durationMs, stats.bytesSent))
        while (generations.size > 100) generations.removeFirst()
    }

    fun events(): List<DiagEvent> = synchronized(lock) { events.toList() }
    fun generations(): List<GenerationRecord> = synchronized(lock) { generations.toList() }
    fun clear() = synchronized(lock) { events.clear(); generations.clear() }

    fun export(header: Map<String, String>): String = buildString {
        appendLine("ASTRA diagnostics export — ${Instant.now()}")
        header.forEach { (k, v) -> appendLine("$k: ${Redactor.redact(v)}") }
        appendLine()
        appendLine("## Recent generations")
        generations().forEach { g -> appendLine("${Instant.ofEpochMilli(g.time)} ${g.providerId} ${g.model} tokens=${g.tokensOut} tps=${"%.1f".format(g.tokensPerSecond)} ttft=${g.firstTokenMs}ms total=${g.durationMs}ms sent=${g.bytesSent}B") }
        appendLine()
        appendLine("## Events")
        events().forEach { e -> appendLine("${Instant.ofEpochMilli(e.time)} [${e.tag}] ${e.message}") }
    }
}
