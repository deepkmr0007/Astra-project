package ai.astra.core.builder

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.model.newId

/** Where an automation runs. */
enum class AutomationTarget { BROWSER, PHONE }

/**
 * The step vocabulary. Browser steps run through the ASTRA Desk extension in the user's own
 * Chrome; phone steps run through the optional accessibility agent. [commits] marks steps that
 * save or send something — those are never auto-run without the user's review.
 */
enum class StepAction(val target: AutomationTarget?, val commits: Boolean = false, val help: String) {
    OPEN_URL(AutomationTarget.BROWSER, help = "Open a web page (target = URL)"),
    WAIT_FOR_USER(null, help = "Pause until the user taps Continue — for login, CAPTCHA, OTP (value = message)"),
    FILL_FORM(null, help = "Fill every mapped field for the current record"),
    FILL(null, help = "Fill one field (target = selector or label, value = template like {Name})"),
    SELECT(null, help = "Choose a dropdown option (target = selector, value = template)"),
    CLICK(null, help = "Click a button/link that does not save (target = selector or visible text)"),
    SUBMIT(null, commits = true, help = "Click the button that saves/submits (target = selector or text). Always reviewed."),
    WAIT_FOR(null, help = "Wait until text or an element appears (target = selector or text, value = seconds)"),
    CHECK_TEXT(null, help = "Confirm the page shows text, e.g. 'saved successfully' (target = text); failure marks the record failed"),
    EXTRACT(null, help = "Read text from the page into the run log (target = selector, value = column name to store it as)"),
    REVIEW(null, help = "Show the filled record to the user for approval before continuing"),
    PAUSE(null, help = "Wait a fixed time (value = seconds)"),
    NEXT_RECORD(null, help = "Move to the next record and repeat the record steps"),
    LAUNCH_APP(AutomationTarget.PHONE, help = "Open a phone app (target = app name or package)"),
    TAP(AutomationTarget.PHONE, help = "Tap on screen text or element (target = visible text or view id)"),
    TYPE(AutomationTarget.PHONE, help = "Type into a field on screen (target = field label/hint, value = template)"),
    SCROLL(AutomationTarget.PHONE, help = "Scroll (value = up/down)"),
    BACK(AutomationTarget.PHONE, help = "Press Back"),
    ;

    companion object {
        fun parse(s: String?): StepAction? = s?.trim()?.uppercase()?.replace(' ', '_')?.replace('-', '_')?.let { n -> entries.firstOrNull { it.name == n } }
    }
}

data class Step(val action: StepAction, val target: String = "", val value: String = "", val note: String = "") {
    fun toJson() = jsonObj("action" to action.name, "target" to target, "value" to value, "note" to note)
    fun describe(): String = buildString {
        append(action.name.lowercase().replace('_', ' '))
        if (target.isNotBlank()) append(" · ").append(target)
        if (value.isNotBlank()) append(" · ").append(value)
    }
}

data class RunOptions(
    /** Show every filled record for approval before any SUBMIT step. On by default and recommended. */
    val reviewEachRecord: Boolean = true,
    /** Fill only: SUBMIT steps are skipped and the user clicks Save themselves. */
    val dryRun: Boolean = false,
    val stepDelayMs: Long = 400,
    val stopAfterFailures: Int = 3,
    val waitTimeoutSec: Int = 20,
)

/**
 * A reusable automation: setup steps run once (open the portal, wait for the user to log in),
 * record steps run per data row (fill, review, save, confirm), using [mappings] for FILL_FORM.
 */
data class AutomationSpec(
    val id: String = newId(),
    val name: String,
    val goal: String,
    val target: AutomationTarget,
    val setupSteps: List<Step>,
    val recordSteps: List<Step>,
    val mappings: List<FieldMapping> = emptyList(),
    val options: RunOptions = RunOptions(),
    /** Header row of the data the mappings were built for (to warn if a new sheet differs). */
    val expectedColumns: List<String> = emptyList(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val needsData: Boolean get() = recordSteps.isNotEmpty()

    /** Problems that stop the automation from running at all. */
    fun problems(): List<String> = buildList {
        if (name.isBlank()) add("Give the automation a name")
        if (setupSteps.isEmpty() && recordSteps.isEmpty()) add("Add at least one step")
        (setupSteps + recordSteps).forEach { s ->
            if (s.action.target != null && s.action.target != target) add("“${s.describe()}” is a ${s.action.target.name.lowercase()} step but this automation runs on the ${target.name.lowercase()}")
            if (s.action in setOf(StepAction.OPEN_URL) && !s.target.startsWith("http")) add("Open URL needs a web address starting with http(s)")
            if (s.action in setOf(StepAction.FILL, StepAction.SELECT, StepAction.CLICK, StepAction.SUBMIT, StepAction.TAP, StepAction.TYPE, StepAction.CHECK_TEXT, StepAction.WAIT_FOR, StepAction.EXTRACT, StepAction.LAUNCH_APP) && s.target.isBlank())
                add("“${s.action.name.lowercase()}” needs a target")
        }
        if (recordSteps.any { it.action == StepAction.FILL_FORM } && mappings.isEmpty()) add("Fill form needs field mappings — scan the form and match columns")
    }
}

object AutomationCodec {
    fun toJson(s: AutomationSpec): JsonValue.Obj = jsonObj(
        "format" to "astra-automation", "version" to 1,
        "id" to s.id, "name" to s.name, "goal" to s.goal, "target" to s.target.name,
        "setup" to s.setupSteps.map { it.toJson() }, "record" to s.recordSteps.map { it.toJson() },
        "mappings" to s.mappings.map { m ->
            jsonObj("selector" to m.selector, "label" to m.label, "template" to m.template, "transform" to m.transform.name, "dateFormat" to m.dateFormat,
                "type" to m.type.name, "options" to m.options, "required" to m.required, "maxLength" to m.maxLength, "pattern" to m.pattern)
        },
        "options" to jsonObj("reviewEachRecord" to s.options.reviewEachRecord, "dryRun" to s.options.dryRun, "stepDelayMs" to s.options.stepDelayMs,
            "stopAfterFailures" to s.options.stopAfterFailures, "waitTimeoutSec" to s.options.waitTimeoutSec),
        "expectedColumns" to s.expectedColumns, "notes" to s.notes, "createdAt" to s.createdAt, "updatedAt" to s.updatedAt,
    )

    fun encode(s: AutomationSpec, pretty: Boolean = true) = Json.write(toJson(s), pretty)

    fun decode(text: String): AutomationSpec = fromJson(Json.parse(text).obj() ?: error("Not an automation"))

    fun parseSteps(v: JsonValue?): List<Step> = v.arr().mapNotNull { e ->
        val o = e.obj() ?: return@mapNotNull null
        val a = StepAction.parse(o["action"].str()) ?: return@mapNotNull null
        Step(a, (o["target"].str() ?: o["selector"].str() ?: o["url"].str()).orEmpty(), (o["value"].str() ?: o["message"].str()).orEmpty(), o["note"].str().orEmpty())
    }

    fun parseMappings(v: JsonValue?): List<FieldMapping> = v.arr().mapNotNull { e ->
        val o = e.obj() ?: return@mapNotNull null
        val sel = o["selector"].str() ?: return@mapNotNull null
        FieldMapping(
            selector = sel, label = o["label"].str().orEmpty(),
            template = o["template"].str() ?: o["column"].str()?.let { "{$it}" } ?: "",
            transform = o["transform"].str()?.let { t -> Transform.entries.firstOrNull { it.name.equals(t, true) } } ?: Transform.TRIM,
            dateFormat = o["dateFormat"].str() ?: "dd/MM/yyyy",
            type = o["type"].str()?.let { t -> FieldType.entries.firstOrNull { it.name.equals(t, true) } } ?: FieldType.TEXT,
            options = o["options"].arr().mapNotNull { it.str() }, required = o["required"].bool() ?: false,
            maxLength = o["maxLength"].int(), pattern = o["pattern"].str(),
        )
    }

    fun fromJson(o: JsonValue.Obj): AutomationSpec {
        val opts = o["options"].obj()
        return AutomationSpec(
            id = o["id"].str() ?: newId(),
            name = o["name"].str().orEmpty(),
            goal = o["goal"].str().orEmpty(),
            target = o["target"].str()?.let { t -> AutomationTarget.entries.firstOrNull { it.name.equals(t, true) } } ?: AutomationTarget.BROWSER,
            setupSteps = parseSteps(o["setup"] ?: o["setupSteps"]),
            recordSteps = parseSteps(o["record"] ?: o["recordSteps"]),
            mappings = parseMappings(o["mappings"]),
            options = RunOptions(
                reviewEachRecord = opts?.get("reviewEachRecord").bool() ?: true,
                dryRun = opts?.get("dryRun").bool() ?: false,
                stepDelayMs = opts?.get("stepDelayMs").long() ?: 400,
                stopAfterFailures = opts?.get("stopAfterFailures").int() ?: 3,
                waitTimeoutSec = opts?.get("waitTimeoutSec").int() ?: 20,
            ),
            expectedColumns = o["expectedColumns"].arr().mapNotNull { it.str() },
            notes = o["notes"].str().orEmpty(),
            createdAt = o["createdAt"].long() ?: System.currentTimeMillis(),
            updatedAt = o["updatedAt"].long() ?: System.currentTimeMillis(),
        )
    }
}
