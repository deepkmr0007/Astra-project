package ai.astra.core.plugins

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.provider.HttpRequest
import ai.astra.core.provider.HttpTransport
import ai.astra.core.security.Permission
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec
import ai.astra.core.web.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * A declarative plugin tool: an HTTPS call described in the manifest. Arguments are URL-encoded
 * into the template; the response is truncated and returned as untrusted tool output. No plugin
 * code runs on the device.
 */
class HttpPluginTool(private val manifest: PluginManifest, private val decl: PluginToolDecl, private val transport: HttpTransport) : Tool {
    private val http = requireNotNull(decl.http) { "Tool ${decl.name} has no http action" }

    override val spec = ToolSpec(
        name = decl.name,
        description = "[${manifest.name}] ${decl.description}",
        inputSchema = decl.inputSchema,
        outputSchema = """{"type":"string"}""",
        risk = decl.risk,
        permissions = manifest.permissions + Permission.INTERNET + Permission.EXTERNAL_SERVICES,
        environment = ExecutionEnvironment.NETWORK,
        usesNetwork = true,
    )

    private fun fill(template: String, args: JsonValue.Obj, encode: Boolean): String =
        Regex("\\{([a-zA-Z_][a-zA-Z0-9_]*)}").replace(template) { m ->
            val v = when (val a = args[m.groupValues[1]]) {
                is JsonValue.Str -> a.value
                null, JsonValue.Null -> ""
                else -> Json.write(a)
            }
            if (encode) URLEncoder.encode(v, StandardCharsets.UTF_8.name()).replace("+", "%20") else v.replace("\\", "\\\\").replace("\"", "\\\"")
        }

    override suspend fun run(args: JsonValue.Obj): ToolResult = withContext(Dispatchers.IO) {
        val url = fill(http.url, args, encode = true)
        if (!url.startsWith("https://")) return@withContext ToolResult.Error("Plugin URL must be https")
        val body = http.bodyTemplate?.let { fill(it, args, encode = false) }
        val headers = mapOf("User-Agent" to USER_AGENT, "Accept" to "application/json, text/plain") + http.headers +
            (if (body != null) mapOf("Content-Type" to "application/json") else emptyMap())
        runCatching {
            transport.open(HttpRequest(url, http.method, headers, body, 15_000, 30_000)).use { r ->
                val sb = StringBuilder()
                while (sb.length < 64_000) { sb.append(r.readLine() ?: break).append('\n') }
                if (r.status !in 200..299) return@withContext ToolResult.Error("${manifest.name}: HTTP ${r.status}")
                val text = sb.toString().trim()
                val pretty = runCatching { Json.write(Json.parse(text), pretty = true) }.getOrDefault(text)
                ToolResult.Ok(pretty.take(4000) + if (pretty.length > 4000) "\n[…truncated]" else "")
            }
        }.getOrElse { ToolResult.Error("${manifest.name}: ${it.message}") }
    }
}
