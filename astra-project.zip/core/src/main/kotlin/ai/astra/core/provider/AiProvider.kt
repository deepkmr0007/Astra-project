package ai.astra.core.provider

import ai.astra.core.model.ContentSource
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import kotlinx.coroutines.flow.Flow

enum class Capability { CHAT, STREAM, EMBED, TRANSCRIBE, SPEAK, VISION, TOOL_CALL }

/** Model capability scores (0..10) used by the router's capability registry. */
data class ModelCapabilities(
    val reasoning: Int = 3,
    val coding: Int = 3,
    val vision: Int = 0,
    val multilingual: Int = 3,
    val speed: Int = 5,
    val contextWindow: Int = 4096,
    val memoryRequirementMb: Int = 0,
)

data class ProviderInfo(
    val id: String,
    val displayName: String,
    val model: String,
    val locality: Locality,
    val capabilities: Set<Capability>,
    val scores: ModelCapabilities,
    /** Runtime/engine name for diagnostics, e.g. "LiteRT-LM", "OpenAI-compatible HTTP". */
    val runtime: String,
)

sealed interface Availability {
    data object Ready : Availability
    data class NotConfigured(val reason: String) : Availability
    data object RequiresInternet : Availability
    data class Unavailable(val reason: String) : Availability
}

/** A prompt turn with its provenance kept alongside, so transparency can report what was sent. */
data class PromptTurn(val role: Role, val parts: List<Part>, val sources: Set<ContentSource>)

data class GenerationRequest(
    val turns: List<PromptTurn>,
    val maxOutputTokens: Int = 1024,
    val temperature: Double = 0.7,
    val topP: Double = 0.95,
    val stop: List<String> = emptyList(),
)

data class GenerationStats(
    val tokensOut: Int,
    val durationMs: Long,
    val firstTokenMs: Long,
    val bytesSent: Long,
    val bytesReceived: Long,
) {
    val tokensPerSecond: Double get() = if (durationMs <= 0) 0.0 else tokensOut * 1000.0 / durationMs
}

sealed interface StreamEvent {
    data class Token(val text: String) : StreamEvent
    data class Done(val stats: GenerationStats) : StreamEvent
}

enum class ProviderErrorKind { NETWORK, AUTH, RATE_LIMIT, SERVER, BAD_RESPONSE, MODEL_CRASH, NOT_CONFIGURED, UNSUPPORTED, CANCELLED, TIMEOUT }

class ProviderException(
    val kind: ProviderErrorKind,
    message: String,
    val retryAfterMs: Long? = null,
    cause: Throwable? = null,
) : RuntimeException(message, cause)

data class GenerationResult(val text: String, val stats: GenerationStats)

/**
 * The unified AI provider interface. Adapters implement it for on-device runtimes (LiteRT-LM,
 * llama.cpp, ONNX), user-hosted / LAN servers and remote APIs. Capabilities a provider does not
 * have throw [ProviderException] with [ProviderErrorKind.UNSUPPORTED]; nothing is simulated.
 */
interface AiProvider {
    val info: ProviderInfo

    suspend fun availability(): Availability

    /** Token stream. Implementations must emit exactly one [StreamEvent.Done] on success and throw on failure. */
    fun stream(request: GenerationRequest): Flow<StreamEvent>

    suspend fun generate(request: GenerationRequest): GenerationResult {
        val sb = StringBuilder()
        var stats: GenerationStats? = null
        stream(request).collect { e ->
            when (e) {
                is StreamEvent.Token -> sb.append(e.text)
                is StreamEvent.Done -> stats = e.stats
            }
        }
        return GenerationResult(sb.toString(), stats ?: throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Stream ended without completion"))
    }

    suspend fun embed(texts: List<String>): List<FloatArray> = unsupported("embed")

    /** Model ids the endpoint offers (for the "Fetch models" picker). */
    suspend fun listModels(): List<String> = unsupported("model listing")
    suspend fun transcribe(audioPath: String, language: String? = null): String = unsupported("transcribe")
    suspend fun speak(text: String, voice: String? = null): ByteArray = unsupported("speak")

    /** Vision is a [stream] call whose turns contain [Part.Image]; this checks support up-front. */
    fun supportsVision(): Boolean = Capability.VISION in info.capabilities

    /** Ask the runtime to stop the in-flight generation, if it supports it. */
    fun cancel() {}

    fun close() {}

    private fun unsupported(what: String): Nothing =
        throw ProviderException(ProviderErrorKind.UNSUPPORTED, "${info.displayName} does not support $what (Requires provider)")
}

/** Registry of configured providers. New providers can be added at runtime without app changes. */
class ProviderRegistry {
    private val providers = LinkedHashMap<String, AiProvider>()

    @Synchronized fun register(provider: AiProvider) {
        providers.remove(provider.info.id)?.close()
        providers[provider.info.id] = provider
    }

    @Synchronized fun unregister(id: String) { providers.remove(id)?.close() }
    @Synchronized fun get(id: String): AiProvider? = providers[id]
    @Synchronized fun all(): List<AiProvider> = providers.values.toList()
}
