package ai.astra.core.text

/**
 * Hides a model's private reasoning (<think>…</think>, used by Qwen3 / DeepSeek-R1 style models)
 * from the visible stream and the stored answer. ASTRA never shows hidden chain-of-thought; it
 * shows a verification summary instead.
 */
class ThinkFilter(private val open: String = "<think>", private val close: String = "</think>") {
    private val pending = StringBuilder()
    private var inside = false
    var hidChars: Int = 0
        private set

    fun accept(token: String): String {
        pending.append(token)
        val out = StringBuilder()
        while (true) {
            if (!inside) {
                val idx = pending.indexOf(open)
                if (idx >= 0) { out.append(pending, 0, idx); pending.delete(0, idx + open.length); inside = true; continue }
                val keep = (1 until open.length).lastOrNull { k -> pending.length >= k && open.startsWith(pending.substring(pending.length - k)) } ?: 0
                out.append(pending, 0, pending.length - keep); pending.delete(0, pending.length - keep)
                return out.toString()
            } else {
                val idx = pending.indexOf(close)
                if (idx < 0) {
                    // Keep only a possible partial close tag; everything else is hidden reasoning.
                    val keep = minOf(pending.length, close.length - 1)
                    hidChars += pending.length - keep
                    pending.delete(0, pending.length - keep)
                    return out.toString()
                }
                hidChars += idx
                pending.delete(0, idx + close.length); inside = false
            }
        }
    }

    fun finish(): String = if (inside) "" else pending.toString().also { pending.clear() }

    companion object {
        private val BLOCK = Regex("<think>.*?(</think>|$)", RegexOption.DOT_MATCHES_ALL)
        fun strip(text: String): String = BLOCK.replace(text, "").trim()
    }
}
