package ai.astra.core.vision

data class ImageLabel(val text: String, val confidence: Float)

/** What on-device vision found in one image: recognised text (OCR) and object/scene labels. */
data class ImageAnalysis(val ocrText: String, val labels: List<ImageLabel>, val width: Int = 0, val height: Int = 0) {
    val isEmpty: Boolean get() = ocrText.isBlank() && labels.isEmpty()

    /** Text form handed to a text-only model. Labels are general categories, not identifications. */
    fun describe(maxOcrChars: Int = 4000): String = buildString {
        if (labels.isNotEmpty()) {
            append("Detected objects/scene (on-device labels, general categories only): ")
            append(labels.sortedByDescending { it.confidence }.take(10).joinToString { "${it.text} ${(it.confidence * 100).toInt()}%" })
            append('\n')
        }
        if (ocrText.isNotBlank()) {
            append("Text found in the image (OCR):\n")
            append(ocrText.trim().take(maxOcrChars))
            if (ocrText.length > maxOcrChars) append("\n[…truncated]")
        } else append("No readable text found in the image.")
    }
}

/** Platform image analysis (ML Kit on Android). Must run fully on device. */
interface ImageAnalyzer {
    suspend fun analyze(path: String): ImageAnalysis
}
