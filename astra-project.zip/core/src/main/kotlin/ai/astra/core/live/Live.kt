package ai.astra.core.live

enum class Mood { NEUTRAL, HAPPY, STRESSED, FRUSTRATED, SAD, CONFUSED, URGENT, GRATEFUL }

data class Tone(val mood: Mood, val confidence: Double, val cues: List<String>)

/**
 * Reads the emotional tone of a message from words and punctuation (English, Hindi, Hinglish).
 * ASTRA uses it to adjust *how* it answers — calmer and shorter when you're stressed, step by
 * step when you're confused — and never stores it as a fact about you.
 */
object ToneReader {
    private val LEXICON: Map<Mood, List<String>> = mapOf(
        Mood.HAPPY to listOf("great", "awesome", "amazing", "happy", "yay", "love it", "excellent", "perfect", "badhiya", "mast", "zabardast", "shandaar", "khush", "बढ़िया", "शानदार", "खुश", "मज़ा", "😀", "😄", "🎉", "😍"),
        Mood.STRESSED to listOf("stressed", "tension", "pressure", "overwhelmed", "worried", "anxious", "deadline", "too much work", "pareshan", "pareshaan", "chinta", "dar lag", "परेशान", "चिंता", "तनाव", "डर", "😰", "😟"),
        Mood.FRUSTRATED to listOf("not working", "doesn't work", "useless", "annoying", "fed up", "again and again", "why is it", "wtf", "irritating", "bakwas", "bekaar", "gussa", "kaam nahi kar", "बेकार", "गुस्सा", "काम नहीं", "😡", "😤"),
        Mood.SAD to listOf("sad", "lonely", "alone", "upset", "hurt", "crying", "miss them", "heartbroken", "dukhi", "udaas", "akela", "rona", "दुखी", "उदास", "अकेला", "अकेली", "😢", "😭", "💔"),
        Mood.CONFUSED to listOf("confused", "don't understand", "dont understand", "not clear", "what do you mean", "how does", "samajh nahi", "samjh nahi", "kaise", "समझ नहीं", "कैसे", "🤔"),
        Mood.URGENT to listOf("urgent", "asap", "immediately", "right now", "quickly", "hurry", "emergency", "jaldi", "turant", "abhi", "जल्दी", "तुरंत", "अभी"),
        Mood.GRATEFUL to listOf("thank you", "thanks", "thank u", "grateful", "appreciate", "shukriya", "dhanyavaad", "dhanyawad", "धन्यवाद", "शुक्रिया", "🙏"),
    )

    fun read(text: String): Tone {
        val t = " " + text.lowercase() + " "
        val scores = HashMap<Mood, Double>()
        val cues = ArrayList<String>()
        for ((mood, words) in LEXICON) for (w in words) {
            val hit = if (w.length <= 4 && w.all { it.isLetter() && it.code < 128 }) Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(t) else t.contains(w)
            if (hit) { scores.merge(mood, 1.0, Double::plus); cues += w }
        }
        val letters = text.filter { it.isLetter() && it.code < 128 }
        if (letters.length >= 8 && letters.count { it.isUpperCase() } > letters.length * 0.7) { scores.merge(Mood.FRUSTRATED, 0.8, Double::plus); scores.merge(Mood.URGENT, 0.5, Double::plus); cues += "CAPS" }
        if (Regex("!{2,}").containsMatchIn(text)) { scores.merge(Mood.URGENT, 0.4, Double::plus); cues += "!!" }
        if (Regex("\\?{2,}").containsMatchIn(text)) { scores.merge(Mood.CONFUSED, 0.5, Double::plus); scores.merge(Mood.FRUSTRATED, 0.3, Double::plus); cues += "??" }
        val best = scores.maxByOrNull { it.value } ?: return Tone(Mood.NEUTRAL, 1.0, emptyList())
        val total = scores.values.sum()
        return Tone(best.key, (best.value / total).coerceIn(0.0, 1.0) * minOf(1.0, best.value / 1.5), cues.distinct())
    }
}

enum class PersonaStyle(val instruction: String) {
    WARM("Warm, caring and encouraging, like a trusted friend who is also very capable."),
    PROFESSIONAL("Professional, crisp and reliable, like an excellent executive assistant."),
    PLAYFUL("Light-hearted and witty when the moment allows, but never at the cost of being useful."),
    CALM("Calm and grounding; steady pace, reassuring, no hype."),
    MENTOR("A patient mentor: explains the why, checks understanding, celebrates progress."),
}

/** How ASTRA presents herself. Everything is user-chosen; nothing here is inferred about the user. */
data class Persona(
    val name: String = "ASTRA",
    val style: PersonaStyle = PersonaStyle.WARM,
    /** How ASTRA addresses the user ("Deepak", "sir", "bhai") — empty means by name if known. */
    val addressAs: String = "",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val proactive: Boolean = true,
    val extra: String = "",
)

object PersonaPrompt {
    /**
     * Persona and conversation guidance appended to the system prompt. It keeps ASTRA honest
     * about being an AI and healthy for the user while letting her be natural and personal.
     */
    fun build(persona: Persona, tone: Tone?, voice: Boolean): String = buildString {
        append("## Your persona\n")
        append("Your name is ${persona.name}. ").append(persona.style.instruction).append('\n')
        if (persona.addressAs.isNotBlank()) append("Address the user as “${persona.addressAs}” when it feels natural (not in every sentence).\n")
        append("Understand what the user actually needs: if a request is ambiguous and a wrong guess would waste their time, ask one short clarifying question; otherwise act.\n")
        append("Remember context from this conversation and refer back to it naturally. Mirror the user's language (English, Hindi or Hinglish).\n")
        if (persona.proactive) append("When useful, suggest one concrete next step — briefly.\n")
        append("You are an AI. You can understand emotions in what people say and respond with care, but do not claim to have human feelings, a body, consciousness or a life outside this app. If asked, explain this honestly and kindly.\n")
        append("Support the user's wellbeing: be kind when they are struggling, and when something serious is going on, gently encourage talking to people they trust or a professional.\n")
        if (persona.extra.isNotBlank()) append(persona.extra.trim()).append('\n')
        tone?.takeIf { it.mood != Mood.NEUTRAL && it.confidence >= 0.35 }?.let { t ->
            append(
                when (t.mood) {
                    Mood.STRESSED -> "The user sounds stressed: acknowledge it in a few words, then give a calm, short, prioritised answer.\n"
                    Mood.FRUSTRATED -> "The user sounds frustrated: don't be defensive; get straight to the fix, step by step.\n"
                    Mood.SAD -> "The user sounds low: be gentle and present; listen first, advise only if they want it.\n"
                    Mood.CONFUSED -> "The user sounds confused: explain simply, one step at a time, with an example.\n"
                    Mood.URGENT -> "The user is in a hurry: lead with the answer, keep it short.\n"
                    Mood.HAPPY -> "The user is in a good mood: match their energy.\n"
                    Mood.GRATEFUL -> "The user is thanking you: respond warmly and briefly.\n"
                    Mood.NEUTRAL -> ""
                }
            )
        }
        if (voice) {
            append("This is a live voice conversation: reply in short spoken sentences (usually 1–3), no markdown, no lists, no emojis, no URLs. ")
            append("Spell numbers naturally. If the answer needs a table or code, say you've put it on screen and summarise in one sentence.\n")
        }
    }
}

/**
 * Turns a token stream into speakable sentences as soon as each one is complete, so the voice
 * starts while the model is still writing. Strips markdown and skips code blocks.
 */
class SpeechChunker(private val maxChars: Int = 180) {
    private val buf = StringBuilder()
    private var inCode = false
    private var codeAnnounced = false

    fun accept(token: String): List<String> {
        buf.append(token)
        val out = ArrayList<String>()
        while (true) {
            val s = buf.toString()
            if (inCode) {
                val end = s.indexOf("```")
                if (end < 0) { buf.setLength(0); return out }
                buf.delete(0, end + 3); inCode = false; continue
            }
            val fence = s.indexOf("```")
            val boundary = findBoundary(s, if (fence >= 0) fence else s.length)
            if (fence >= 0 && (boundary < 0 || fence < boundary)) {
                clean(s.substring(0, fence))?.let(out::add)
                if (!codeAnnounced) { out += "I've put the code on screen."; codeAnnounced = true }
                buf.delete(0, fence + 3); inCode = true; continue
            }
            if (boundary < 0) {
                if (s.length > maxChars) {
                    val cut = s.lastIndexOfAny(charArrayOf(',', ';', ':', ' '), maxChars).takeIf { it > 20 } ?: maxChars
                    clean(s.substring(0, cut + 1))?.let(out::add); buf.delete(0, cut + 1); continue
                }
                return out
            }
            clean(s.substring(0, boundary + 1))?.let(out::add)
            buf.delete(0, boundary + 1)
        }
    }

    fun finish(): List<String> {
        if (inCode) { buf.setLength(0); return emptyList() }
        val rest = clean(buf.toString()); buf.setLength(0)
        return listOfNotNull(rest)
    }

    private fun findBoundary(s: String, limit: Int): Int {
        for (i in 0 until minOf(limit, s.length)) {
            val c = s[i]
            if (c == '\n') return i
            if (c == '।' || c == '?' || c == '!') return i
            if (c == '.' && i + 1 < s.length && s[i + 1].isWhitespace()) {
                // Not after a single-letter/abbreviation ("Dr.", "e.g.") or inside a number.
                val prevWord = s.substring(0, i).takeLastWhile { it.isLetter() }
                if (prevWord.length <= 2 && prevWord.isNotEmpty() && prevWord[0].isUpperCase()) continue
                if (prevWord.lowercase() in setOf("dr", "mr", "mrs", "ms", "no", "vs", "eg", "ie", "etc", "st", "rs", "sh", "smt")) continue
                return i
            }
        }
        return -1
    }

    companion object {
        fun clean(raw: String): String? {
            var t = raw
            t = t.replace(Regex("!\\[[^]]*]\\([^)]*\\)"), "")
            t = t.replace(Regex("\\[([^]]+)]\\([^)]*\\)"), "$1")
            t = t.replace(Regex("https?://\\S+"), "")
            t = t.replace(Regex("`([^`]*)`"), "$1")
            t = t.replace(Regex("(?m)^\\s{0,3}(#{1,6}|[-*+•]|\\d+[.)]|>)\\s+"), "")
            t = t.replace(Regex("[*_~]{1,3}"), "").replace("|", " ")
            t = t.replace(Regex("\\s+"), " ").trim()
            return t.takeIf { s -> s.any { it.isLetterOrDigit() } }
        }
    }
}

/** Short spoken commands that interrupt or steer a live conversation. */
object VoiceCommands {
    enum class Command { STOP, PAUSE, REPEAT, SLOWER, FASTER }

    private val MAP = listOf(
        Command.STOP to Regex("^(stop|bas|ruko|ruk jao|chup|shh+|रुको|बस|चुप)[.! ]*$", RegexOption.IGNORE_CASE),
        Command.PAUSE to Regex("^(pause|wait|ek minute|ek second|रुकिए)[.! ]*$", RegexOption.IGNORE_CASE),
        Command.REPEAT to Regex("^(repeat|say (that|it) again|phir se|dobara|फिर से|दोबारा)( bolo)?[.! ]*$", RegexOption.IGNORE_CASE),
        Command.SLOWER to Regex("^(slower|speak slowly|dheere|dhire|धीरे)( bolo)?[.! ]*$", RegexOption.IGNORE_CASE),
        Command.FASTER to Regex("^(faster|speak faster|jaldi bolo|tez|तेज़?)( bolo)?[.! ]*$", RegexOption.IGNORE_CASE),
    )

    fun parse(text: String): Command? = MAP.firstOrNull { it.second.matches(text.trim()) }?.first
}
