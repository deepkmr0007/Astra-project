package ai.astra.core.models

import ai.astra.core.device.DeviceState
import ai.astra.core.provider.ModelCapabilities

/**
 * Curated, verified on-device models that download without an account or token.
 * Every entry is pinned to a Hugging Face commit and carries the file's SHA-256, so a download is
 * checked byte-for-byte before ASTRA will load it. Sizes, licenses and sources were read from the
 * Hugging Face API (litert-community) in October 2026.
 */
data class CatalogModel(
    val id: String,
    val name: String,
    val summary: String,
    val repo: String,
    val commit: String,
    val fileName: String,
    val sizeBytes: Long,
    val sha256: String,
    val license: String,
    val profile: ModelProfile,
    val minRamMb: Long,
    val vision: Boolean,
    val audio: Boolean,
    val capabilities: ModelCapabilities,
    val languages: String,
) {
    val url: String get() = "https://huggingface.co/$repo/resolve/$commit/$fileName"
    val sourcePage: String get() = "https://huggingface.co/$repo"

    fun toDescriptor(localFileName: String, sha: String = sha256): ModelDescriptor = ModelDescriptor(
        id = id, name = name, fileName = localFileName, format = ModelFormat.LITERT_LM, sizeBytes = sizeBytes,
        sha256 = sha, source = sourcePage, license = license, profile = profile,
        capabilities = capabilities.copy(vision = if (vision) 6 else 0, memoryRequirementMb = (minRamMb / 3).toInt()),
        supportsVision = vision, supportsAudio = audio,
    )
}

data class CatalogPick(val model: CatalogModel, val reasons: List<String>)

object ModelCatalog {
    val models: List<CatalogModel> = listOf(
        CatalogModel(
            id = "gemma-4-e2b",
            name = "Gemma 4 E2B",
            summary = "Best all-rounder for most phones. Understands text, photos and audio; strong in Hindi and 100+ languages.",
            repo = "litert-community/gemma-4-E2B-it-litert-lm",
            commit = "b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1",
            fileName = "gemma-4-E2B-it.litertlm",
            sizeBytes = 2_588_147_712,
            sha256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
            license = "Apache-2.0",
            profile = ModelProfile.SMALL,
            minRamMb = 5_000, // Android reports ~5.5 GB on a "6 GB" phone
            vision = true, audio = true,
            capabilities = ModelCapabilities(reasoning = 6, coding = 5, multilingual = 8, speed = 7, contextWindow = 8192),
            languages = "Multilingual incl. Hindi",
        ),
        CatalogModel(
            id = "gemma-4-e4b",
            name = "Gemma 4 E4B",
            summary = "Smarter and slower. For phones with 12 GB RAM or more. Text, photos and audio.",
            repo = "litert-community/gemma-4-E4B-it-litert-lm",
            commit = "2eee7ac325f20eb8c9ac1d0e972f7c84663062da",
            fileName = "gemma-4-E4B-it.litertlm",
            sizeBytes = 3_659_530_240,
            sha256 = "0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0",
            license = "Apache-2.0",
            profile = ModelProfile.MEDIUM,
            minRamMb = 10_000,
            vision = true, audio = true,
            capabilities = ModelCapabilities(reasoning = 7, coding = 6, multilingual = 8, speed = 5, contextWindow = 8192),
            languages = "Multilingual incl. Hindi",
        ),
        CatalogModel(
            id = "qwen3.5-0.8b",
            name = "Qwen3.5 0.8B",
            summary = "Small and quick (under 1 GB). Text only. Good for low-memory phones and short answers.",
            repo = "litert-community/Qwen3.5-0.8B",
            commit = "512221aa511cc87d7c02720b99707113276592b0",
            fileName = "Qwen3.5-0.8B_int8.litertlm",
            sizeBytes = 963_184_864,
            sha256 = "64ed396fcdae75e5158945c77a08142b1322ce1bbf1be4d2198783119a1169e8",
            license = "Apache-2.0",
            profile = ModelProfile.TINY,
            minRamMb = 3_000,
            vision = false, audio = false,
            capabilities = ModelCapabilities(reasoning = 3, coding = 3, multilingual = 5, speed = 9, contextWindow = 4096),
            languages = "Multilingual",
        ),
        CatalogModel(
            id = "qwen3-0.6b",
            name = "Qwen3 0.6B",
            summary = "Smallest download (614 MB). Text only. Works on almost any phone; simple answers.",
            repo = "litert-community/Qwen3-0.6B",
            commit = "a3c5d805ae362dff7f580bc25f2dfb9a5a7eaa76",
            fileName = "Qwen3-0.6B.litertlm",
            sizeBytes = 614_236_160,
            sha256 = "555579ff2f4fd13379abe69c1c3ab5200f7338bc92471557f1d6614a6e5ab0b4",
            license = "Apache-2.0",
            profile = ModelProfile.TINY,
            minRamMb = 2_500,
            vision = false, audio = false,
            capabilities = ModelCapabilities(reasoning = 2, coding = 2, multilingual = 4, speed = 9, contextWindow = 4096),
            languages = "Multilingual",
        ),
    )

    fun byId(id: String): CatalogModel? = models.firstOrNull { it.id == id }

    /** Picks the best model that fits the phone's RAM and free storage, with reasons. */
    fun recommend(device: DeviceState): CatalogPick {
        val reasons = ArrayList<String>()
        val ram = device.totalRamMb
        val free = device.freeStorageMb
        val fits = models.filter { m ->
            (ram == null || ram >= m.minRamMb) && (free == null || free * 1024 * 1024 > m.sizeBytes + 1_000_000_000L)
        }
        val pick = when {
            ram == null -> byId("gemma-4-e2b")!!.also { reasons += "RAM unknown — choosing the balanced model" }
            fits.isEmpty() -> models.minBy { it.sizeBytes }.also { reasons += "Very little free storage or RAM — choosing the smallest model" }
            // Prefer E2B over E4B even on big phones: much faster, nearly as capable.
            else -> (fits.firstOrNull { it.id == "gemma-4-e2b" } ?: fits.maxBy { it.capabilities.reasoning }).also {
                reasons += "Phone RAM ${ram / 1024} GB"
                if (free != null) reasons += "Free storage ${free / 1024} GB"
            }
        }
        return CatalogPick(pick, reasons)
    }
}
