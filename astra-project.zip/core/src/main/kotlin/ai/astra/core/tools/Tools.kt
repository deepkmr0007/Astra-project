package ai.astra.core.tools

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel

enum class ExecutionEnvironment { IN_PROCESS, SANDBOX, DEVICE_API, NETWORK }

data class ToolSpec(
    val name: String,
    val description: String,
    /** JSON Schema of the arguments object. */
    val inputSchema: String,
    /** JSON Schema (or prose) describing the output. */
    val outputSchema: String,
    val risk: RiskLevel,
    val permissions: Set<Permission>,
    val environment: ExecutionEnvironment,
    /** True if running the tool sends data off the device. The router/UI treat this as ONLINE/HYBRID. */
    val usesNetwork: Boolean = environment == ExecutionEnvironment.NETWORK,
)

sealed interface ToolResult {
    data class Ok(val output: String, val structured: JsonValue? = null) : ToolResult
    data class Error(val message: String) : ToolResult
}

interface Tool {
    val spec: ToolSpec
    suspend fun run(args: JsonValue.Obj): ToolResult
}

class ToolRegistry {
    private val tools = LinkedHashMap<String, Tool>()
    @Synchronized fun register(tool: Tool) { tools[tool.spec.name] = tool }
    @Synchronized fun unregister(name: String) { tools.remove(name) }
    @Synchronized fun get(name: String): Tool? = tools[name]
    @Synchronized fun all(): List<Tool> = tools.values.toList()

    /** Tool manual injected into the system prompt for models without native function calling. */
    fun manual(names: Collection<String>? = null): String {
        val list = all().filter { names == null || it.spec.name in names }
        if (list.isEmpty()) return ""
        return buildString {
            appendLine("You can use tools. To call one, reply with ONLY this block and nothing else:")
            appendLine("<tool_call>{\"name\": \"TOOL_NAME\", \"arguments\": { ... }}</tool_call>")
            appendLine("You will then receive the result and can continue. Use a tool only when it is needed; never invent tool results.")
            appendLine("Available tools:")
            list.forEach { t -> appendLine("- ${t.spec.name}: ${t.spec.description} Arguments schema: ${t.spec.inputSchema}") }
        }.trim()
    }
}

data class ToolCall(val name: String, val arguments: JsonValue.Obj, val raw: String)

/** Parses the text tool-call protocol used with local models. */
object ToolCallParser {
    private val BLOCK = Regex("<tool_call>\\s*(.*?)\\s*</tool_call>", RegexOption.DOT_MATCHES_ALL)

    fun parse(text: String): List<ToolCall> = BLOCK.findAll(text).mapNotNull { m ->
        val body = m.groupValues[1].removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val obj = runCatching { Json.parse(body) }.getOrNull().obj() ?: return@mapNotNull null
        val name = obj["name"].str() ?: return@mapNotNull null
        val args = when (val a = obj["arguments"]) {
            is JsonValue.Obj -> a
            is JsonValue.Str -> runCatching { Json.parse(a.value) }.getOrNull().obj() ?: JsonValue.Obj(emptyMap())
            else -> JsonValue.Obj(emptyMap())
        }
        ToolCall(name, args, m.value)
    }.toList()

    fun stripCalls(text: String): String = BLOCK.replace(text, "").trim()
}

/**
 * Hides tool-call markup from the token stream shown to the user while still passing everything
 * through for parsing. Text before "<tool_call>" is released; the block itself is held back.
 */
class ToolCallStreamFilter {
    private val pending = StringBuilder()
    private var inCall = false
    private val open = "<tool_call>"
    private val close = "</tool_call>"

    /** Returns the text that is safe to display now. */
    fun accept(token: String): String {
        pending.append(token)
        val out = StringBuilder()
        while (true) {
            if (!inCall) {
                val idx = pending.indexOf(open)
                if (idx >= 0) {
                    out.append(pending, 0, idx); pending.delete(0, idx + open.length); inCall = true; continue
                }
                // Keep a possible partial "<tool_c" prefix back.
                val keep = (1 until open.length).lastOrNull { k -> pending.length >= k && open.startsWith(pending.substring(pending.length - k)) } ?: 0
                out.append(pending, 0, pending.length - keep); pending.delete(0, pending.length - keep)
                return out.toString()
            } else {
                val idx = pending.indexOf(close)
                if (idx < 0) return out.toString()
                pending.delete(0, idx + close.length); inCall = false
            }
        }
    }

    fun finish(): String = if (inCall) "" else pending.toString().also { pending.clear() }
}
