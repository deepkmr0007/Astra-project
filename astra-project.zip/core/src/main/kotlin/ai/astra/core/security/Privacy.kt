package ai.astra.core.security

enum class Sensitivity { NONE, LOW, MEDIUM, HIGH }

data class SensitiveFinding(val kind: String, val severity: Sensitivity, val start: Int, val end: Int)

data class PrivacyAssessment(val level: Sensitivity, val findings: List<SensitiveFinding>) {
    val kinds: Set<String> get() = findings.map { it.kind }.toSet()
}

/**
 * Deterministic detector for personal / secret data. It runs before routing so private content is
 * never silently sent to a network model. Validators (Verhoeff for Aadhaar, Luhn for cards) keep
 * false positives low.
 */
object PrivacyClassifier {

    private val AADHAAR = Regex("(?<!\\d)([2-9]\\d{3})[ -]?(\\d{4})[ -]?(\\d{4})(?!\\d)")
    private val PAN = Regex("(?<![A-Z0-9])[A-Z]{3}[ABCFGHLJPTK][A-Z]\\d{4}[A-Z](?![A-Z0-9])")
    private val CARD = Regex("(?<!\\d)(?:\\d[ -]?){12,18}\\d(?!\\d)")
    private val IFSC = Regex("(?<![A-Z0-9])[A-Z]{4}0[A-Z0-9]{6}(?![A-Z0-9])")
    private val EMAIL = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val PHONE_IN = Regex("(?<!\\d)(?:\\+?91[ -]?)?[6-9]\\d{4}[ -]?\\d{5}(?!\\d)")
    private val API_KEY = Regex("\\b(?:sk-(?:ant-)?[A-Za-z0-9_-]{16,}|AIza[0-9A-Za-z_-]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|xox[abpr]-[A-Za-z0-9-]{10,}|AKIA[0-9A-Z]{16})\\b")
    private val SECRET_ASSIGN = Regex("(?i)\\b(password|passwd|pwd|passcode|pin|otp|cvv|secret|token|api[_ ]?key)\\b\\s*(?:is|=|:)\\s*\\S+")
    private val PRIVATE_MARKERS = Regex("(?i)(^/private\\b|\\bconfidential\\b|\\bstrictly private\\b|\\bdo not share\\b|\\bgopniya\\b|गोपनीय)")
    private val HEALTH = Regex("(?i)\\b(diagnos\\w*|prescription|medical report|blood test|hiv|cancer|depression|therapy|pregnan\\w*|biopsy|beemari|bimari|dawai)\\b")
    private val FINANCE = Regex("(?i)\\b(bank account|account number|salary|income tax|loan|credit score|upi pin|net ?banking|balance)\\b")

    fun assess(text: String): PrivacyAssessment {
        val findings = ArrayList<SensitiveFinding>()
        fun add(kind: String, sev: Sensitivity, m: MatchResult) = findings.add(SensitiveFinding(kind, sev, m.range.first, m.range.last + 1))

        AADHAAR.findAll(text).forEach { m ->
            val digits = m.groupValues.drop(1).joinToString("")
            if (verhoeffValid(digits)) add("aadhaar", Sensitivity.HIGH, m)
        }
        PAN.findAll(text).forEach { add("pan", Sensitivity.HIGH, it) }
        CARD.findAll(text).forEach { m ->
            val digits = m.value.filter { it.isDigit() }
            if (digits.length in 13..19 && luhnValid(digits) && findings.none { f -> f.kind == "aadhaar" && f.start <= m.range.first && m.range.last < f.end }) {
                add("payment_card", Sensitivity.HIGH, m)
            }
        }
        IFSC.findAll(text).forEach { add("ifsc", Sensitivity.MEDIUM, it) }
        API_KEY.findAll(text).forEach { add("api_key", Sensitivity.HIGH, it) }
        SECRET_ASSIGN.findAll(text).forEach { add("secret", Sensitivity.HIGH, it) }
        PRIVATE_MARKERS.findAll(text).forEach { add("marked_private", Sensitivity.HIGH, it) }
        EMAIL.findAll(text).forEach { add("email", Sensitivity.MEDIUM, it) }
        PHONE_IN.findAll(text).forEach { m ->
            if (findings.none { f -> f.start <= m.range.first && m.range.last < f.end }) add("phone", Sensitivity.MEDIUM, m)
        }
        HEALTH.findAll(text).forEach { add("health", Sensitivity.MEDIUM, it) }
        FINANCE.findAll(text).forEach { add("finance", Sensitivity.LOW, it) }

        val level = findings.maxOfOrNull { it.severity } ?: Sensitivity.NONE
        return PrivacyAssessment(level, findings.sortedBy { it.start })
    }

    /** Replaces every finding with a typed placeholder, e.g. for logs or an optional redacted online request. */
    fun redact(text: String, assessment: PrivacyAssessment = assess(text)): String {
        if (assessment.findings.isEmpty()) return text
        val sb = StringBuilder()
        var pos = 0
        for (f in assessment.findings) {
            if (f.start < pos) continue
            sb.append(text, pos, f.start).append("[${f.kind.uppercase()}]")
            pos = f.end
        }
        sb.append(text, pos, text.length)
        return sb.toString()
    }

    fun luhnValid(digits: String): Boolean {
        var sum = 0
        var dbl = false
        for (i in digits.length - 1 downTo 0) {
            var d = digits[i] - '0'
            if (dbl) { d *= 2; if (d > 9) d -= 9 }
            sum += d
            dbl = !dbl
        }
        return sum % 10 == 0
    }

    private val D = arrayOf(
        intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9), intArrayOf(1, 2, 3, 4, 0, 6, 7, 8, 9, 5),
        intArrayOf(2, 3, 4, 0, 1, 7, 8, 9, 5, 6), intArrayOf(3, 4, 0, 1, 2, 8, 9, 5, 6, 7),
        intArrayOf(4, 0, 1, 2, 3, 9, 5, 6, 7, 8), intArrayOf(5, 9, 8, 7, 6, 0, 4, 3, 2, 1),
        intArrayOf(6, 5, 9, 8, 7, 1, 0, 4, 3, 2), intArrayOf(7, 6, 5, 9, 8, 2, 1, 0, 4, 3),
        intArrayOf(8, 7, 6, 5, 9, 3, 2, 1, 0, 4), intArrayOf(9, 8, 7, 6, 5, 4, 3, 2, 1, 0),
    )
    private val P = arrayOf(
        intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9), intArrayOf(1, 5, 7, 6, 2, 8, 3, 0, 9, 4),
        intArrayOf(5, 8, 0, 3, 7, 9, 6, 1, 4, 2), intArrayOf(8, 9, 1, 6, 0, 4, 3, 5, 2, 7),
        intArrayOf(9, 4, 5, 3, 1, 2, 6, 8, 7, 0), intArrayOf(4, 2, 8, 6, 5, 7, 3, 9, 0, 1),
        intArrayOf(2, 7, 9, 3, 8, 0, 6, 4, 1, 5), intArrayOf(7, 0, 4, 6, 9, 1, 3, 2, 5, 8),
    )

    /** Verhoeff checksum, used by Aadhaar numbers. */
    fun verhoeffValid(digits: String): Boolean {
        var c = 0
        digits.reversed().forEachIndexed { i, ch -> c = D[c][P[i % 8][ch - '0']] }
        return c == 0
    }
}

/** Masks credentials and personal identifiers before anything reaches diagnostics or audit logs. */
object Redactor {
    private val BEARER = Regex("(?i)(bearer\\s+)[A-Za-z0-9._~+/=-]{8,}")
    private val HEADER_KEY = Regex("(?i)(x-api-key|authorization|api[_-]?key)(\"?\\s*[:=]\\s*\"?)[^\",\\s}]{6,}")
    private val LONG_TOKEN = Regex("\\b[A-Za-z0-9_-]{40,}\\b")

    fun redact(text: String): String {
        var t = BEARER.replace(text) { it.groupValues[1] + "***" }
        t = HEADER_KEY.replace(t) { it.groupValues[1] + it.groupValues[2] + "***" }
        t = PrivacyClassifier.redact(t)
        t = LONG_TOKEN.replace(t, "[TOKEN]")
        return t
    }
}
