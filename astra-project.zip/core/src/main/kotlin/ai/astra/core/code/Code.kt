package ai.astra.core.code

enum class DiffOp { EQUAL, ADD, DELETE }

data class DiffLine(val op: DiffOp, val text: String, val oldLine: Int?, val newLine: Int?)

data class Hunk(val oldStart: Int, val oldCount: Int, val newStart: Int, val newCount: Int, val lines: List<DiffLine>) {
    val header: String get() = "@@ -$oldStart,$oldCount +$newStart,$newCount @@"
}

/** Line diff using Myers' O((N+M)·D) algorithm. Used for "show diff → approve → apply" in the Coding Lab. */
object LineDiff {

    fun diff(old: String, new: String): List<DiffLine> = diff(splitLines(old), splitLines(new))

    fun splitLines(s: String): List<String> = if (s.isEmpty()) emptyList() else s.removeSuffix("\n").split("\n")

    fun diff(a: List<String>, b: List<String>): List<DiffLine> {
        val n = a.size
        val m = b.size
        val max = n + m
        if (max == 0) return emptyList()
        val offset = max
        val v = IntArray(2 * max + 2)
        val trace = ArrayList<IntArray>()
        var found = false
        loop@ for (d in 0..max) {
            trace.add(v.copyOf())
            var k = -d
            while (k <= d) {
                var x = if (k == -d || (k != d && v[offset + k - 1] < v[offset + k + 1])) v[offset + k + 1] else v[offset + k - 1] + 1
                var y = x - k
                while (x < n && y < m && a[x] == b[y]) { x++; y++ }
                v[offset + k] = x
                if (x >= n && y >= m) { found = true; break@loop }
                k += 2
            }
        }
        check(found)
        // Backtrack.
        val out = ArrayList<DiffLine>()
        var x = n
        var y = m
        for (d in trace.size - 1 downTo 0) {
            val vv = trace[d]
            val k = x - y
            val prevK = if (k == -d || (k != d && vv[offset + k - 1] < vv[offset + k + 1])) k + 1 else k - 1
            val prevX = vv[offset + prevK]
            val prevY = prevX - prevK
            while (x > prevX && y > prevY) { out.add(DiffLine(DiffOp.EQUAL, a[x - 1], x, y)); x--; y-- }
            if (d > 0) {
                if (x == prevX) { out.add(DiffLine(DiffOp.ADD, b[y - 1], null, y)); y-- }
                else { out.add(DiffLine(DiffOp.DELETE, a[x - 1], x, null)); x-- }
            }
        }
        out.reverse()
        return out
    }

    fun hunks(lines: List<DiffLine>, context: Int = 3): List<Hunk> {
        val changed = lines.indices.filter { lines[it].op != DiffOp.EQUAL }
        if (changed.isEmpty()) return emptyList()
        val groups = ArrayList<IntRange>()
        var start = maxOf(0, changed.first() - context)
        var end = minOf(lines.size - 1, changed.first() + context)
        for (i in changed.drop(1)) {
            if (i - context <= end + 1) end = minOf(lines.size - 1, i + context)
            else { groups += start..end; start = maxOf(0, i - context); end = minOf(lines.size - 1, i + context) }
        }
        groups += start..end
        return groups.map { r ->
            val ls = lines.subList(r.first, r.last + 1)
            val oldStart = ls.firstNotNullOfOrNull { it.oldLine } ?: (lines.take(r.first).lastOrNull { it.oldLine != null }?.oldLine ?: 0)
            val newStart = ls.firstNotNullOfOrNull { it.newLine } ?: (lines.take(r.first).lastOrNull { it.newLine != null }?.newLine ?: 0)
            Hunk(oldStart, ls.count { it.op != DiffOp.ADD }, newStart, ls.count { it.op != DiffOp.DELETE }, ls)
        }
    }

    fun unified(oldName: String, newName: String, old: String, new: String): String = buildString {
        val hs = hunks(diff(old, new))
        if (hs.isEmpty()) return ""
        append("--- $oldName\n+++ $newName\n")
        hs.forEach { h ->
            append(h.header).append('\n')
            h.lines.forEach { l -> append(when (l.op) { DiffOp.EQUAL -> ' '; DiffOp.ADD -> '+'; DiffOp.DELETE -> '-' }).append(l.text).append('\n') }
        }
    }

    /** Rebuilds the new text from a diff (proves the diff is lossless). */
    fun applyTo(lines: List<DiffLine>): String = lines.filter { it.op != DiffOp.DELETE }.joinToString("\n") { it.text }

    fun stats(lines: List<DiffLine>): Pair<Int, Int> = lines.count { it.op == DiffOp.ADD } to lines.count { it.op == DiffOp.DELETE }
}

/** Pulls code out of a model answer. */
object CodeBlocks {
    private val FENCE = Regex("```([A-Za-z0-9_+#.-]*)[ \\t]*\\n(.*?)\\n?```", RegexOption.DOT_MATCHES_ALL)

    data class Block(val language: String, val code: String)

    fun all(text: String): List<Block> = FENCE.findAll(text).map { Block(it.groupValues[1].lowercase(), it.groupValues[2]) }.toList()

    /** The largest fenced block (models usually put the full file in the biggest one). */
    fun main(text: String): Block? = all(text).maxByOrNull { it.code.length }

    fun languageFor(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
        "kt", "kts" -> "kotlin"; "java" -> "java"; "py" -> "python"; "js", "mjs" -> "javascript"; "ts" -> "typescript"
        "html", "htm" -> "html"; "css" -> "css"; "json" -> "json"; "md" -> "markdown"; "xml" -> "xml"; "sh" -> "bash"
        "c", "h" -> "c"; "cpp", "hpp" -> "cpp"; "go" -> "go"; "rs" -> "rust"; "sql" -> "sql"; "yml", "yaml" -> "yaml"
        else -> "text"
    }

    fun editPrompt(fileName: String, content: String, instruction: String): String =
        "You are editing the file `$fileName`. Instruction: $instruction\n\n" +
            "Return the COMPLETE updated file in ONE fenced code block and nothing else after it. Keep everything that should not change exactly as it is.\n\n" +
            "```${languageFor(fileName)}\n$content\n```"
}

/** Minimal keyword highlighting tokens for the editor (no external library). */
object SyntaxTokens {
    enum class Kind { KEYWORD, STRING, COMMENT, NUMBER, PLAIN }
    data class Span(val start: Int, val end: Int, val kind: Kind)

    private val KEYWORDS = setOf(
        "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while", "return", "import", "package", "private", "public",
        "override", "suspend", "data", "enum", "sealed", "true", "false", "null", "def", "lambda", "None", "True", "False", "function", "const", "let",
        "new", "this", "self", "static", "void", "int", "boolean", "async", "await", "try", "catch", "finally", "throw", "in", "is", "as", "from", "with",
    )
    private val TOKEN = Regex("(//[^\\n]*|#[^\\n]*|/\\*.*?\\*/)|(\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)", RegexOption.DOT_MATCHES_ALL)

    fun spans(code: String, language: String): List<Span> {
        val hashComments = language in setOf("python", "bash", "yaml")
        return TOKEN.findAll(code).mapNotNull { m ->
            val r = m.range
            when {
                m.groups[1] != null -> if (m.value.startsWith("#") && !hashComments) null else Span(r.first, r.last + 1, Kind.COMMENT)
                m.groups[2] != null -> Span(r.first, r.last + 1, Kind.STRING)
                m.groups[3] != null -> Span(r.first, r.last + 1, Kind.NUMBER)
                m.groups[4] != null && m.value in KEYWORDS -> Span(r.first, r.last + 1, Kind.KEYWORD)
                else -> null
            }
        }.toList()
    }
}
