package ai.astra.core.tasks

import ai.astra.core.model.newId

enum class TaskStatus { TODO, IN_PROGRESS, BLOCKED, DONE, CANCELLED }
enum class Priority { LOW, MEDIUM, HIGH, URGENT }

data class TaskItem(
    val id: String = newId(),
    val title: String,
    val description: String = "",
    val priority: Priority = Priority.MEDIUM,
    val deadline: Long? = null,
    val status: TaskStatus = TaskStatus.TODO,
    val projectId: String? = null,
    val parentId: String? = null,
    val dependsOn: Set<String> = emptySet(),
    val estimateMinutes: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

class TaskGraphException(message: String) : RuntimeException(message)

/** Dependency-aware task logic: validation, execution order, what's ready now, progress. */
object TaskGraph {

    fun validate(tasks: List<TaskItem>) {
        val ids = tasks.map { it.id }.toSet()
        tasks.forEach { t ->
            t.dependsOn.forEach { d -> if (d !in ids) throw TaskGraphException("'${t.title}' depends on a missing task") }
            if (t.id in t.dependsOn) throw TaskGraphException("'${t.title}' depends on itself")
        }
        order(tasks)
    }

    /** Kahn topological sort; throws on cycles. Ties broken by priority then deadline. */
    fun order(tasks: List<TaskItem>): List<TaskItem> {
        val byId = tasks.associateBy { it.id }
        val indeg = tasks.associate { it.id to it.dependsOn.count { d -> d in byId } }.toMutableMap()
        val ready = tasks.filter { indeg[it.id] == 0 }.toMutableList()
        val out = ArrayList<TaskItem>()
        val cmp = compareByDescending<TaskItem> { it.priority.ordinal }.thenBy { it.deadline ?: Long.MAX_VALUE }.thenBy { it.createdAt }
        while (ready.isNotEmpty()) {
            ready.sortWith(cmp)
            val t = ready.removeAt(0)
            out += t
            tasks.filter { t.id in it.dependsOn }.forEach { n ->
                indeg[n.id] = indeg.getValue(n.id) - 1
                if (indeg[n.id] == 0) ready += n
            }
        }
        if (out.size != tasks.size) throw TaskGraphException("Tasks have circular dependencies")
        return out
    }

    fun readyNow(tasks: List<TaskItem>): List<TaskItem> {
        val done = tasks.filter { it.status == TaskStatus.DONE }.map { it.id }.toSet()
        return order(tasks).filter { it.status == TaskStatus.TODO && it.dependsOn.all { d -> d in done } }
    }

    fun progress(tasks: List<TaskItem>, parentId: String? = null): Double {
        val scope = tasks.filter { parentId == null || it.parentId == parentId }.filter { it.status != TaskStatus.CANCELLED }
        if (scope.isEmpty()) return 0.0
        val weight = { t: TaskItem -> (t.estimateMinutes ?: 30).toDouble() }
        return scope.filter { it.status == TaskStatus.DONE }.sumOf(weight) / scope.sumOf(weight)
    }
}

/** Builds the breakdown prompt and parses a model's numbered list into subtasks with dependencies. */
object TaskBreakdown {
    fun prompt(task: TaskItem): String =
        "Break this task into 3–8 concrete, ordered subtasks. Reply ONLY with a numbered list, one per line, formatted as:\n" +
            "1. <subtask title> | <estimate in minutes> | after: <comma-separated numbers of earlier subtasks it depends on, or none>\n\n" +
            "Task: ${task.title}\n${task.description}"

    private val LINE = Regex("^\\s*(\\d+)[.)]\\s*(.+?)\\s*$")

    fun parse(parent: TaskItem, modelOutput: String): List<TaskItem> {
        val rows = modelOutput.lines().mapNotNull { LINE.find(it) }.map { m -> m.groupValues[1].toInt() to m.groupValues[2] }
        val ids = rows.associate { it.first to newId() }
        return rows.map { (n, body) ->
            val parts = body.split('|').map { it.trim() }
            val title = parts[0].trim('*', ' ')
            val estimate = parts.getOrNull(1)?.let { Regex("\\d+").find(it)?.value?.toIntOrNull() }
            val deps = parts.getOrNull(2)?.substringAfter(':', "")?.split(',')?.mapNotNull { it.trim().toIntOrNull() }?.filter { it < n }?.mapNotNull { ids[it] }?.toSet().orEmpty()
            TaskItem(id = ids.getValue(n), title = title, priority = parent.priority, deadline = parent.deadline, projectId = parent.projectId, parentId = parent.id, dependsOn = deps, estimateMinutes = estimate)
        }.filter { it.title.isNotBlank() }
    }
}
