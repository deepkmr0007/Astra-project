package ai.astra.core.learn

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.model.newId
import ai.astra.core.security.PrivacyClassifier
import ai.astra.core.text.Bm25
import ai.astra.core.text.Tokenizer

data class Example(val input: String, val output: String)

/**
 * Something the user taught ASTRA: how to handle a kind of request. Matched skills are added to
 * the prompt, so the model follows them without retraining — the honest, on-phone form of
 * "learning". [automationId] links a skill to an automation ("PACS entry" → run that automation).
 */
data class Skill(
    val id: String = newId(),
    val name: String,
    val triggers: List<String>,
    val instructions: String,
    val examples: List<Example> = emptyList(),
    val automationId: String? = null,
    val enabled: Boolean = true,
    val uses: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): JsonValue.Obj = jsonObj(
        "id" to id, "name" to name, "triggers" to triggers, "instructions" to instructions,
        "examples" to examples.map { jsonObj("input" to it.input, "output" to it.output) },
        "automationId" to automationId, "enabled" to enabled, "uses" to uses, "createdAt" to createdAt, "updatedAt" to updatedAt,
    )

    /** Prompt block for this skill (instructions + at most two examples). */
    fun promptBlock(): String = buildString {
        append("### ").append(name).append('\n').append(instructions.trim())
        examples.takeLast(2).forEach { e -> append("\nExample — user: ").append(e.input.take(300)).append("\n  you: ").append(e.output.take(500)) }
    }

    companion object {
        fun fromJson(o: JsonValue.Obj) = Skill(
            id = o["id"].str() ?: newId(), name = o["name"].str().orEmpty(),
            triggers = o["triggers"].arr().mapNotNull { it.str() }, instructions = o["instructions"].str().orEmpty(),
            examples = o["examples"].arr().mapNotNull { e -> e.obj()?.let { Example(it["input"].str().orEmpty(), it["output"].str().orEmpty()) } },
            automationId = o["automationId"].str(), enabled = o["enabled"].bool() ?: true, uses = o["uses"].int() ?: 0,
            createdAt = o["createdAt"].long() ?: System.currentTimeMillis(), updatedAt = o["updatedAt"].long() ?: System.currentTimeMillis(),
        )
    }
}

interface SkillStore {
    suspend fun all(): List<Skill>
    suspend fun save(skill: Skill)
    suspend fun delete(id: String)
}

class InMemorySkillStore : SkillStore {
    private val map = LinkedHashMap<String, Skill>()
    override suspend fun all() = synchronized(map) { map.values.toList() }
    override suspend fun save(skill: Skill) { synchronized(map) { map[skill.id] = skill } }
    override suspend fun delete(id: String) { synchronized(map) { map.remove(id) } }
}

object SkillMatcher {
    /** Skills relevant to a message: exact trigger phrases first, then BM25 over name/triggers/instructions. */
    fun match(text: String, skills: List<Skill>, limit: Int = 2): List<Skill> {
        val active = skills.filter { it.enabled }
        if (active.isEmpty() || text.isBlank()) return emptyList()
        val lower = text.lowercase()
        val exact = active.filter { s -> s.triggers.any { t -> t.isNotBlank() && lower.contains(t.lowercase().trim()) } }
        val docs = active.map { s -> Tokenizer.terms(s.name + " " + s.triggers.joinToString(" ") + " " + s.name + " " + s.instructions.take(400)) }
        val q = Tokenizer.terms(text)
        val scored = if (q.isEmpty()) emptyList() else {
            val bm = Bm25(docs)
            val norm = bm.normalizedScores(q)
            active.indices.filter { norm[it] >= 0.6 && bm.score(q, it) > 1.2 }.sortedByDescending { norm[it] }.map { active[it] }
        }
        return (exact + scored).distinctBy { it.id }.take(limit)
    }

    fun promptSection(skills: List<Skill>): String =
        if (skills.isEmpty()) "" else "## Skills the user taught you (follow them when they apply)\n" + skills.joinToString("\n\n") { it.promptBlock() }
}

/**
 * Parses teaching commands typed in chat:
 *  /teach Name: instructions
 *  "when I say X, Y" · "whenever I ask for X, Y"
 *  "jab main X bolun to Y" · "जब मैं X कहूं तो Y"
 */
object TeachParser {
    private val SLASH = Regex("^/teach\\s+([^:\\n]{2,60}):\\s*(.+)$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val WHEN_EN = Regex("^(?:astra[,\\s]+)?(?:when(?:ever)?|if) i (?:say|ask(?: for| you to)?|type|tell you)\\s+[\"“']?(.{2,80}?)[\"”']?\\s*[,:-]\\s*(?:then\\s+)?(.{4,})$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val WHEN_HI_LATIN = Regex("^jab (?:bhi )?(?:main|mai|me) [\"“']?(.{2,80}?)[\"”']? (?:bolu|bolun|boloon|kahu|kahun|likhu|likhun)[,\\s]+(?:to|tab)\\s+(.{4,})$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val WHEN_HI = Regex("^जब (?:भी )?मैं [\"“']?(.{2,80}?)[\"”']? (?:कहूं|कहूँ|बोलूं|बोलूँ|लिखूं|लिखूँ)[,\\s]+(?:तो|तब)\\s+(.{4,})$", RegexOption.DOT_MATCHES_ALL)

    fun parse(text: String): Skill? {
        val t = text.trim()
        SLASH.find(t)?.let { m -> val name = m.groupValues[1].trim(); return Skill(name = name, triggers = listOf(name.lowercase()), instructions = m.groupValues[2].trim()) }
        for (r in listOf(WHEN_EN, WHEN_HI_LATIN, WHEN_HI)) {
            val m = r.find(t) ?: continue
            val trigger = m.groupValues[1].trim().trim('"', '“', '”', '\'')
            return Skill(name = trigger.replaceFirstChar { it.uppercase() }, triggers = listOf(trigger.lowercase()), instructions = m.groupValues[2].trim())
        }
        return null
    }
}

enum class Rating { GOOD, BAD, CORRECTED }

/** A rated or corrected answer — the raw material for examples and for PC fine-tuning. */
data class FeedbackRecord(
    val id: String = newId(),
    val prompt: String,
    val answer: String,
    val rating: Rating,
    val correction: String? = null,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun toJson() = jsonObj("id" to id, "prompt" to prompt, "answer" to answer, "rating" to rating.name, "correction" to correction, "note" to note, "createdAt" to createdAt)

    companion object {
        fun fromJson(o: JsonValue.Obj) = FeedbackRecord(
            o["id"].str() ?: newId(), o["prompt"].str().orEmpty(), o["answer"].str().orEmpty(),
            o["rating"].str()?.let { r -> Rating.entries.firstOrNull { it.name == r } } ?: Rating.GOOD,
            o["correction"].str(), o["note"].str().orEmpty(), o["createdAt"].long() ?: 0,
        )
    }
}

data class TrainingExport(val jsonl: String, val examples: Int, val redactions: Int, val skipped: Int)

/**
 * Builds a supervised fine-tuning dataset (chat-format JSONL, one conversation per line) from
 * good answers, corrections and taught skill examples. Personal identifiers are redacted by
 * default. The dataset is for training on a computer (tools/train in the repository) —
 * phones cannot fine-tune multi-billion-parameter models in reasonable time.
 */
object TrainingExporter {
    fun export(feedback: List<FeedbackRecord>, skills: List<Skill>, systemPrompt: String, redact: Boolean = true): TrainingExport {
        var redactions = 0
        var skipped = 0
        fun clean(s: String): String {
            if (!redact) return s
            val a = PrivacyClassifier.assess(s)
            redactions += a.findings.size
            return if (a.findings.isEmpty()) s else PrivacyClassifier.redact(s, a)
        }
        val lines = ArrayList<String>()
        fun add(user: String, assistant: String) {
            if (user.isBlank() || assistant.isBlank()) { skipped++; return }
            lines += Json.write(jsonObj("messages" to listOf(
                jsonObj("role" to "system", "content" to systemPrompt),
                jsonObj("role" to "user", "content" to clean(user)),
                jsonObj("role" to "assistant", "content" to clean(assistant)),
            )))
        }
        feedback.forEach { f ->
            when (f.rating) {
                Rating.GOOD -> add(f.prompt, f.answer)
                Rating.CORRECTED -> add(f.prompt, f.correction.orEmpty())
                Rating.BAD -> skipped++
            }
        }
        skills.filter { it.enabled }.forEach { s -> s.examples.forEach { add(it.input, it.output) } }
        return TrainingExport(lines.joinToString("\n", postfix = if (lines.isEmpty()) "" else "\n"), lines.size, redactions, skipped)
    }
}
