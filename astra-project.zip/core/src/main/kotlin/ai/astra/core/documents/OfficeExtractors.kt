package ai.astra.core.documents

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Dependency-free text extraction for Office Open XML (DOCX, XLSX). Both are ZIP containers of
 * XML parts; we read only the parts we need and never execute or follow external references.
 * Size limits guard against zip bombs.
 */
object OfficeExtractors {
    private const val MAX_ENTRY_BYTES = 40L * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 120L * 1024 * 1024

    fun supports(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in setOf("docx", "xlsx")

    fun extract(name: String, mime: String, bytes: ByteArray): ExtractedDocument = when (name.substringAfterLast('.', "").lowercase()) {
        "docx" -> docx(name, mime, bytes)
        "xlsx" -> xlsx(name, mime, bytes)
        else -> throw IllegalArgumentException("Unsupported Office format: $name")
    }

    private fun readEntries(bytes: ByteArray, wanted: (String) -> Boolean): Map<String, String> {
        val out = HashMap<String, String>()
        var total = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory || !wanted(e.name)) continue
                val buf = java.io.ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                var size = 0L
                while (true) {
                    val n = zip.read(chunk)
                    if (n < 0) break
                    size += n; total += n
                    if (size > MAX_ENTRY_BYTES || total > MAX_TOTAL_BYTES) throw IllegalArgumentException("Document is too large or malformed (zip bomb guard)")
                    buf.write(chunk, 0, n)
                }
                out[e.name] = buf.toString(Charsets.UTF_8.name())
            }
        }
        return out
    }

    private fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun docx(name: String, mime: String, bytes: ByteArray): ExtractedDocument {
        val parts = readEntries(bytes) { it == "word/document.xml" }
        val xml = parts["word/document.xml"] ?: throw IllegalArgumentException("Not a valid DOCX (word/document.xml missing)")
        val paragraphs = Regex("<w:p[ >].*?</w:p>|<w:p/>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { p ->
            val txt = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>", RegexOption.DOT_MATCHES_ALL).findAll(p.value).joinToString("") { m ->
                when {
                    m.value.startsWith("<w:tab") -> "\t"
                    m.value.startsWith("<w:br") -> "\n"
                    else -> unescape(m.groupValues[1])
                }
            }
            txt
        }.toList()
        // Explicit page breaks give real page numbers where the author inserted them; otherwise sections.
        val pageBreaks = xml.contains("w:type=\"page\"")
        val units = ArrayList<SourceUnit>()
        val sb = StringBuilder()
        for (p in paragraphs) {
            if (sb.length > 3000) { units += SourceUnit(units.size + 1, sb.toString()); sb.clear() }
            sb.append(p).append('\n')
        }
        if (sb.isNotBlank()) units += SourceUnit(units.size + 1, sb.toString())
        return ExtractedDocument(name, mime, LocatorKind.SECTION, units, if (pageBreaks) listOf("Page numbers in Word files depend on layout; references use sections.") else emptyList())
    }

    private fun xlsx(name: String, mime: String, bytes: ByteArray): ExtractedDocument {
        val parts = readEntries(bytes) { it == "xl/sharedStrings.xml" || it == "xl/workbook.xml" || (it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml")) }
        val shared = parts["xl/sharedStrings.xml"]?.let { ss ->
            Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(ss).map { si ->
                Regex("<t(?: [^>]*)?>(.*?)</t>", RegexOption.DOT_MATCHES_ALL).findAll(si.groupValues[1]).joinToString("") { unescape(it.groupValues[1]) }
            }.toList()
        }.orEmpty()
        val sheetNames = parts["xl/workbook.xml"]?.let { wb -> Regex("<sheet [^>]*name=\"([^\"]+)\"").findAll(wb).map { unescape(it.groupValues[1]) }.toList() }.orEmpty()
        val sheets = parts.keys.filter { it.startsWith("xl/worksheets/sheet") }.sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val units = ArrayList<SourceUnit>()
        sheets.forEachIndexed { si, key ->
            val rows = Regex("<row [^>]*?r=\"(\\d+)\"[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL).findAll(parts.getValue(key)).map { row ->
                val cells = Regex("<c ([^>]*?)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL).findAll(row.groupValues[2]).map { c ->
                    val attrs = c.groupValues[1]
                    val inner = c.groupValues[2]
                    val v = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL).find(inner)?.groupValues?.get(1)
                    when {
                        attrs.contains("t=\"s\"") -> v?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                        attrs.contains("t=\"inlineStr\"") -> Regex("<t(?: [^>]*)?>(.*?)</t>", RegexOption.DOT_MATCHES_ALL).find(inner)?.groupValues?.get(1)?.let(::unescape) ?: ""
                        else -> v?.let(::unescape) ?: ""
                    }
                }.toList()
                row.groupValues[1].toInt() to cells.joinToString(",") { if (it.contains(',') || it.contains('"')) "\"" + it.replace("\"", "\"\"") + "\"" else it }
            }.toList()
            val sheetName = sheetNames.getOrNull(si) ?: "Sheet${si + 1}"
            val header = rows.firstOrNull()?.second.orEmpty()
            rows.drop(1).chunked(40).forEach { block ->
                units += SourceUnit(block.first().first, "[$sheetName]\n$header\n" + block.joinToString("\n") { it.second })
            }
            if (rows.size == 1) units += SourceUnit(rows[0].first, "[$sheetName]\n$header")
        }
        return ExtractedDocument(name, mime, LocatorKind.ROW, units)
    }
}
