package ai.astra.core.builder

import ai.astra.core.security.PrivacyClassifier
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

enum class Transform { NONE, TRIM, UPPER, LOWER, TITLE, DIGITS, DATE }

/** How a field's value is produced for one record. */
data class FieldMapping(
    val selector: String,
    val label: String,
    /** Template with {Column} placeholders, e.g. "{Name}" or "{Village}, {Tehsil}". A plain string is a constant. */
    val template: String,
    val transform: Transform = Transform.TRIM,
    /** Target date pattern for [Transform.DATE], e.g. "dd/MM/yyyy". */
    val dateFormat: String = "dd/MM/yyyy",
    val type: FieldType = FieldType.TEXT,
    val options: List<String> = emptyList(),
    val required: Boolean = false,
    val maxLength: Int? = null,
    val pattern: String? = null,
)

object ValueEngine {
    private val PLACEHOLDER = Regex("\\{([^{}]+)}")

    fun columnsIn(template: String): List<String> = PLACEHOLDER.findAll(template).map { it.groupValues[1].trim() }.toList()

    /** Fills a template from a record (case-insensitive column names). Missing columns become empty. */
    fun render(template: String, record: Map<String, String>): String {
        val lower = record.mapKeys { it.key.lowercase().trim() }
        return PLACEHOLDER.replace(template) { m -> lower[m.groupValues[1].trim().lowercase()].orEmpty() }.trim()
    }

    fun apply(value: String, t: Transform, dateFormat: String = "dd/MM/yyyy"): String = when (t) {
        Transform.NONE -> value
        Transform.TRIM -> value.trim().replace(Regex("\\s+"), " ")
        Transform.UPPER -> value.trim().uppercase()
        Transform.LOWER -> value.trim().lowercase()
        Transform.TITLE -> value.trim().lowercase().split(Regex("\\s+")).joinToString(" ") { w -> w.replaceFirstChar { it.titlecase() } }
        Transform.DIGITS -> value.filter { it.isDigit() || it in '०'..'९' }.map { if (it in '०'..'९') '0' + (it - '०') else it }.joinToString("")
        Transform.DATE -> parseDate(value)?.format(DateTimeFormatter.ofPattern(dateFormat)) ?: value.trim()
    }

    private val DATE_PATTERNS = listOf("yyyy-MM-dd", "d/M/uuuu", "d-M-uuuu", "d.M.uuuu", "d/M/uu", "d-M-uu", "d.M.uu", "uuuu/M/d", "d MMM uuuu", "d-MMM-uuuu", "d MMMM uuuu", "MMM d, uuuu", "uuuuMMdd")
        .map { p -> DateTimeFormatter.ofPattern(p.replace("yyyy", "uuuu"), java.util.Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT) }

    /** Understands the date formats found in Indian registers and Excel (day first), plus Excel serials. */
    fun parseDate(raw: String): LocalDate? {
        val s = apply(raw, Transform.NONE).trim().map { if (it in '०'..'९') '0' + (it - '०') else it }.joinToString("")
            .replace(Regex("(?i)(\\d)(st|nd|rd|th)"), "$1").replace(Regex("\\s+"), " ")
        if (s.isEmpty()) return null
        s.toDoubleOrNull()?.let { d -> if (d in 20000.0..80000.0 && !s.matches(Regex("\\d{8}"))) return LocalDate.of(1899, 12, 30).plusDays(d.toLong()) }
        val norm = s.split(' ').joinToString(" ") { w -> if (w.length >= 3 && w.all(Char::isLetter)) w.lowercase().replaceFirstChar { it.uppercase() } else w }
        for (f in DATE_PATTERNS) {
            val d = runCatching { LocalDate.parse(norm, f) }.getOrNull() ?: continue
            // Two-digit years: assume 1930..2029.
            return if (d.year > LocalDate.now().year + 3 && f.toString().contains("ReducedValue")) d.minusYears(100) else d
        }
        return null
    }

    /** Picks the dropdown/radio option for a value: exact, normalised, contains, then closest spelling. */
    fun matchOption(value: String, options: List<String>): String? {
        if (options.isEmpty()) return null
        val v = norm(value)
        if (v.isEmpty()) return null
        options.firstOrNull { it == value }?.let { return it }
        options.firstOrNull { norm(it) == v }?.let { return it }
        ALIASES[v]?.let { alias -> options.firstOrNull { norm(it) in alias }?.let { return it } }
        options.filter { norm(it).isNotEmpty() && (norm(it).contains(v) || v.contains(norm(it))) }.minByOrNull { kotlin.math.abs(norm(it).length - v.length) }?.let { return it }
        val best = options.minByOrNull { FieldMapper.levenshtein(norm(it), v) } ?: return null
        val dist = FieldMapper.levenshtein(norm(best), v)
        return if (dist <= maxOf(1, v.length / 4)) best else null
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), "")

    private val ALIAS_GROUPS: List<Set<String>> = listOf(
        setOf("m", "male", "purush", "पुरुष", "man", "boy"),
        setOf("f", "female", "mahila", "महिला", "stree", "स्त्री", "woman", "girl"),
        setOf("y", "yes", "haan", "han", "हाँ", "हां", "true"),
        setOf("n", "no", "nahi", "nahin", "नहीं", "false"),
        setOf("obc", "otherbackwardclass", "पिछड़ावर्ग"),
        setOf("sc", "scheduledcaste", "अनुसूचितजाति"),
        setOf("st", "scheduledtribe", "अनुसूचितजनजाति"),
        setOf("gen", "general", "ur", "unreserved", "सामान्य"),
    )
    private val ALIASES: Map<String, Set<String>> = HashMap<String, Set<String>>().apply { ALIAS_GROUPS.forEach { g -> g.forEach { put(it, g) } } }
}

enum class IssueLevel { WARNING, ERROR }

data class ValueIssue(val field: String, val level: IssueLevel, val message: String)

/** One record turned into concrete field values, with problems found before anything is typed. */
data class PreparedRecord(val index: Int, val values: List<FieldValue>, val issues: List<ValueIssue>) {
    val blocked: Boolean get() = issues.any { it.level == IssueLevel.ERROR }
}

data class FieldValue(val selector: String, val label: String, val value: String, val type: FieldType)

/**
 * Turns a data record into field values and checks them: required fields, numbers, dates,
 * lengths, patterns, dropdown options and common Indian identifiers (mobile, Aadhaar checksum,
 * IFSC, PIN code). Errors stop that record; warnings are shown at review.
 */
object RecordPreparer {
    fun prepare(index: Int, record: Map<String, String>, mappings: List<FieldMapping>): PreparedRecord {
        val values = ArrayList<FieldValue>()
        val issues = ArrayList<ValueIssue>()
        for (m in mappings) {
            val label = m.label.ifBlank { m.selector }
            var v = ValueEngine.apply(ValueEngine.render(m.template, record), m.transform, m.dateFormat)
            val missingCols = ValueEngine.columnsIn(m.template).filter { c -> record.keys.none { it.equals(c, true) } }
            if (missingCols.isNotEmpty()) issues += ValueIssue(label, IssueLevel.ERROR, "Column not found: ${missingCols.joinToString()}")
            if (m.type == FieldType.SELECT || m.type == FieldType.RADIO) {
                if (v.isNotBlank()) {
                    val opt = ValueEngine.matchOption(v, m.options)
                    when {
                        m.options.isEmpty() -> Unit
                        opt == null -> issues += ValueIssue(label, IssueLevel.ERROR, "“$v” is not one of the options")
                        opt != v -> { issues += ValueIssue(label, IssueLevel.WARNING, "“$v” → option “$opt”"); v = opt }
                    }
                }
            }
            if (v.isBlank()) {
                if (m.required) issues += ValueIssue(label, IssueLevel.ERROR, "Required but empty")
                values += FieldValue(m.selector, label, v, m.type)
                continue
            }
            issues += check(label, v, m)
            values += FieldValue(m.selector, label, v, m.type)
        }
        return PreparedRecord(index, values, issues)
    }

    private fun check(label: String, v: String, m: FieldMapping): List<ValueIssue> = buildList {
        val l = (label + " " + m.selector).lowercase()
        when (m.type) {
            FieldType.NUMBER -> if (v.replace(",", "").toDoubleOrNull() == null) add(ValueIssue(label, IssueLevel.ERROR, "“$v” is not a number"))
            FieldType.DATE -> if (ValueEngine.parseDate(v) == null) add(ValueIssue(label, IssueLevel.ERROR, "“$v” is not a date"))
            FieldType.EMAIL -> if (!v.matches(Regex("[^@\\s]+@[^@\\s]+\\.[^@\\s]+"))) add(ValueIssue(label, IssueLevel.ERROR, "Not an email address"))
            else -> Unit
        }
        m.maxLength?.let { if (v.length > it) add(ValueIssue(label, IssueLevel.ERROR, "Longer than $it characters")) }
        m.pattern?.let { p -> val ok = runCatching { v.matches(Regex(p)) }.getOrDefault(true); if (!ok) add(ValueIssue(label, IssueLevel.ERROR, "Doesn't match the form's format")) }
        val digits = v.filter(Char::isDigit)
        if (Regex("mobile|phone|मोबाइल|फोन|contact").containsMatchIn(l) && !(digits.length == 10 && digits[0] in '6'..'9') && !(digits.length == 12 && digits.startsWith("91")))
            add(ValueIssue(label, IssueLevel.WARNING, "Mobile number should be 10 digits starting 6–9"))
        if (Regex("aadha+r|adhar|uid|आधार").containsMatchIn(l)) {
            if (digits.length != 12) add(ValueIssue(label, IssueLevel.ERROR, "Aadhaar must be 12 digits"))
            else if (!PrivacyClassifier.verhoeffValid(digits)) add(ValueIssue(label, IssueLevel.WARNING, "Aadhaar checksum fails — check for a typing mistake"))
        }
        if (Regex("ifsc").containsMatchIn(l) && !v.uppercase().matches(Regex("[A-Z]{4}0[A-Z0-9]{6}"))) add(ValueIssue(label, IssueLevel.ERROR, "IFSC should look like SBIN0001234"))
        if (Regex("\\bpin|pincode|postal|पिन").containsMatchIn(l) && !digits.matches(Regex("[1-9]\\d{5}"))) add(ValueIssue(label, IssueLevel.WARNING, "PIN code should be 6 digits"))
    }
}
