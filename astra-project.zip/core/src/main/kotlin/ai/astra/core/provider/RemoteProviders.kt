package ai.astra.core.provider

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.plainText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Base64

/** One server-sent event. */
data class SseEvent(val event: String?, val data: String)

/** Incremental SSE parser (WHATWG event-stream subset: event/data fields, blank-line dispatch). */
class SseParser {
    private var event: String? = null
    private val data = StringBuilder()

    /** Feed one line (without terminator). Returns an event when a blank line completes one. */
    fun feed(line: String): SseEvent? {
        if (line.isEmpty()) {
            if (data.isEmpty() && event == null) return null
            val e = SseEvent(event, data.toString().removeSuffix("\n"))
            event = null; data.clear()
            return e
        }
        if (line.startsWith(":")) return null
        val idx = line.indexOf(':')
        val field = if (idx < 0) line else line.substring(0, idx)
        var value = if (idx < 0) "" else line.substring(idx + 1)
        if (value.startsWith(" ")) value = value.substring(1)
        when (field) {
            "event" -> event = value
            "data" -> data.append(value).append('\n')
        }
        return null
    }

    fun flush(): SseEvent? = feed("")
}

enum class EndpointKind { OPENAI_COMPATIBLE, ANTHROPIC }

/**
 * A user-configured inference endpoint: a remote API, a server they host, or a LAN box
 * (llama.cpp server, Ollama, LM Studio, vLLM all speak the OpenAI-compatible protocol).
 */
data class EndpointConfig(
    val id: String,
    val displayName: String,
    val kind: EndpointKind,
    val baseUrl: String,
    val model: String,
    val locality: Locality,
    val embeddingModel: String? = null,
    val vision: Boolean = false,
    val scores: ModelCapabilities = ModelCapabilities(reasoning = 8, coding = 8, multilingual = 8, speed = 6, contextWindow = 128_000),
    val connectTimeoutMs: Int = 15_000,
    val readTimeoutMs: Int = 180_000,
)

private fun encodeImage(p: Part.Image): String = Base64.getEncoder().encodeToString(File(p.path).readBytes())

private fun turnText(parts: List<Part>): String = parts.plainText()

abstract class HttpProvider(
    protected val config: EndpointConfig,
    protected val transport: HttpTransport,
    protected val apiKey: () -> String?,
) : AiProvider {

    override val info: ProviderInfo = ProviderInfo(
        id = config.id,
        displayName = config.displayName,
        model = config.model,
        locality = config.locality,
        capabilities = buildSet {
            add(Capability.CHAT); add(Capability.STREAM); add(Capability.TOOL_CALL)
            if (config.vision) add(Capability.VISION)
            if (config.embeddingModel != null) add(Capability.EMBED)
        },
        scores = config.scores.copy(vision = if (config.vision) maxOf(config.scores.vision, 6) else 0),
        runtime = when (config.kind) {
            EndpointKind.OPENAI_COMPATIBLE -> "OpenAI-compatible HTTP"
            EndpointKind.ANTHROPIC -> "Anthropic Messages API"
        },
    )

    override suspend fun availability(): Availability = when {
        config.baseUrl.isBlank() || config.model.isBlank() -> Availability.NotConfigured("Endpoint URL or model missing")
        config.kind == EndpointKind.ANTHROPIC && apiKey().isNullOrBlank() -> Availability.NotConfigured("API key not set")
        else -> Availability.Ready
    }

    protected abstract fun buildRequest(request: GenerationRequest): HttpRequest

    /** Returns the text delta in this event, null if none; throws on a stream-level error event. */
    protected abstract fun parseEvent(e: SseEvent): String?

    protected fun isDone(e: SseEvent): Boolean = e.data == "[DONE]" || e.event == "message_stop"

    override fun stream(request: GenerationRequest): Flow<StreamEvent> = flow {
        val http = buildRequest(request)
        val started = System.currentTimeMillis()
        val resp = openWithRetry(transport, http)
        var tokens = 0
        var firstTokenAt = 0L
        try {
            val sse = SseParser()
            loop@ while (true) {
                currentCoroutineContext().ensureActive()
                val line = resp.readLine()
                val ev = if (line == null) sse.flush() else sse.feed(line)
                if (ev != null) {
                    if (isDone(ev)) break@loop
                    val delta = parseEvent(ev)
                    if (!delta.isNullOrEmpty()) {
                        if (tokens == 0) firstTokenAt = System.currentTimeMillis() - started
                        tokens++
                        emit(StreamEvent.Token(delta))
                    }
                }
                if (line == null) break
            }
            emit(
                StreamEvent.Done(
                    GenerationStats(
                        tokensOut = tokens,
                        durationMs = System.currentTimeMillis() - started,
                        firstTokenMs = firstTokenAt,
                        bytesSent = (http.body?.toByteArray()?.size ?: 0).toLong(),
                        bytesReceived = resp.bytesReceived,
                    )
                )
            )
        } finally {
            resp.close()
        }
    }.flowOn(Dispatchers.IO)

    protected fun badEvent(raw: String): Nothing =
        throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Unparseable stream event: ${raw.take(120)}")
}

/** OpenAI-compatible chat completions (OpenAI, Groq, OpenRouter, llama.cpp server, Ollama, LM Studio, vLLM...). */
class OpenAiCompatibleProvider(
    config: EndpointConfig,
    transport: HttpTransport,
    apiKey: () -> String?,
) : HttpProvider(config, transport, apiKey) {

    private fun endpoint(path: String): String = openAiEndpoint(config.baseUrl, path)

    override suspend fun listModels(): List<String> = withContext(Dispatchers.IO) {
        val resp = openWithRetry(transport, HttpRequest(endpoint("models"), "GET", headers() - "Accept" - "Content-Type", null, config.connectTimeoutMs, 30_000), maxRetries = 0)
        val root = resp.use { Json.parse(it.readText()) }
        // OpenAI/Groq/OpenRouter/Gemini: {"data":[{"id":..}]}; some servers return {"models":[{"name"|"id":..}]}.
        val items = root.obj()?.get("data").arr().ifEmpty { root.obj()?.get("models").arr() }
        items.mapNotNull { it.obj()?.let { o -> o["id"].str() ?: o["name"].str() } }.map { it.removePrefix("models/") }.distinct().sorted()
    }

    private fun headers(): Map<String, String> = buildMap {
        put("Content-Type", "application/json")
        put("Accept", "text/event-stream")
        apiKey()?.takeIf { it.isNotBlank() }?.let { put("Authorization", "Bearer $it") }
    }

    override fun buildRequest(request: GenerationRequest): HttpRequest {
        val messages = request.turns.map { t ->
            val role = when (t.role) {
                Role.SYSTEM -> "system"; Role.USER -> "user"; Role.ASSISTANT -> "assistant"
                Role.TOOL -> "user" // tool output is re-sent as clearly-labelled user-side data
            }
            val images = t.parts.filterIsInstance<Part.Image>()
            val content: Any = if (images.isEmpty() || !config.vision) turnText(t.parts) else jsonArr(
                listOf(jsonObj("type" to "text", "text" to turnText(t.parts.filter { it !is Part.Image }))) +
                    images.map { img ->
                        jsonObj("type" to "image_url", "image_url" to jsonObj("url" to "data:${img.mimeType};base64,${encodeImage(img)}"))
                    }
            )
            jsonObj("role" to role, "content" to content)
        }
        val body = jsonObj(
            "model" to config.model,
            "messages" to jsonArr(messages),
            "stream" to true,
            "max_tokens" to request.maxOutputTokens,
            "temperature" to request.temperature,
            "top_p" to request.topP,
        ).let { if (request.stop.isEmpty()) it else JsonValue.Obj(it.fields + ("stop" to jsonArr(request.stop))) }
        return HttpRequest(endpoint("chat/completions"), "POST", headers(), Json.write(body), config.connectTimeoutMs, config.readTimeoutMs)
    }

    override fun parseEvent(e: SseEvent): String? {
        if (e.data.isBlank()) return null
        val obj = runCatching { Json.parse(e.data) }.getOrElse { badEvent(e.data) }.obj() ?: badEvent(e.data)
        obj["error"]?.let { err ->
            throw ProviderException(ProviderErrorKind.SERVER, "Server error: ${err.obj()?.get("message").str() ?: err.str() ?: "unknown"}")
        }
        val choice = obj["choices"].arr().firstOrNull().obj() ?: return null
        return choice["delta"].obj()?.get("content").str() ?: choice["text"].str()
    }

    override suspend fun embed(texts: List<String>): List<FloatArray> {
        val model = config.embeddingModel ?: return super.embed(texts)
        return withContext(Dispatchers.IO) {
            val body = Json.write(jsonObj("model" to model, "input" to jsonArr(texts)))
            val resp = openWithRetry(transport, HttpRequest(endpoint("embeddings"), "POST", headers() - "Accept", body))
            val parsed = resp.use { Json.parse(it.readText()) }.obj()
            parsed?.get("data").arr().map { item ->
                val v = item.obj()?.get("embedding").arr()
                FloatArray(v.size) { i -> ((v[i] as? JsonValue.Num)?.value ?: 0.0).toFloat() }
            }.also { if (it.size != texts.size) throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Embedding count mismatch") }
        }
    }
}

/** Anthropic Messages API (streaming). */
class AnthropicProvider(
    config: EndpointConfig,
    transport: HttpTransport,
    apiKey: () -> String?,
) : HttpProvider(config, transport, apiKey) {

    override fun buildRequest(request: GenerationRequest): HttpRequest {
        val system = request.turns.filter { it.role == Role.SYSTEM }.joinToString("\n\n") { turnText(it.parts) }
        // The Messages API requires alternating user/assistant turns: merge consecutive same-role turns.
        val merged = ArrayList<Pair<String, MutableList<Part>>>()
        for (t in request.turns.filter { it.role != Role.SYSTEM }) {
            val role = if (t.role == Role.ASSISTANT) "assistant" else "user"
            if (merged.isNotEmpty() && merged.last().first == role) merged.last().second.addAll(listOf(Part.Text("\n\n")) + t.parts)
            else merged.add(role to t.parts.toMutableList())
        }
        if (merged.isEmpty() || merged.first().first != "user") merged.add(0, "user" to mutableListOf(Part.Text("(start)")))
        val messages = merged.map { (role, parts) ->
            val blocks = ArrayList<JsonValue>()
            parts.filterIsInstance<Part.Image>().filter { config.vision }.forEach { img ->
                blocks.add(jsonObj("type" to "image", "source" to jsonObj("type" to "base64", "media_type" to img.mimeType, "data" to encodeImage(img))))
            }
            val text = turnText(parts.filter { it !is Part.Image })
            blocks.add(jsonObj("type" to "text", "text" to text.ifBlank { "." }))
            jsonObj("role" to role, "content" to JsonValue.Arr(blocks))
        }
        val fields = linkedMapOf<String, Any?>(
            "model" to config.model,
            "max_tokens" to request.maxOutputTokens,
            "messages" to jsonArr(messages),
            "stream" to true,
            "temperature" to request.temperature,
        )
        if (system.isNotBlank()) fields["system"] = system
        if (request.stop.isNotEmpty()) fields["stop_sequences"] = request.stop
        val headers = mapOf(
            "Content-Type" to "application/json",
            "Accept" to "text/event-stream",
            "x-api-key" to (apiKey() ?: ""),
            "anthropic-version" to "2023-06-01",
        )
        val base = config.baseUrl.trimEnd('/').ifBlank { "https://api.anthropic.com" }
        return HttpRequest("$base/v1/messages", "POST", headers, Json.write(ai.astra.core.json.toJson(fields)), config.connectTimeoutMs, config.readTimeoutMs)
    }

    override suspend fun listModels(): List<String> = withContext(Dispatchers.IO) {
        val base = config.baseUrl.trimEnd('/').ifBlank { "https://api.anthropic.com" }
        val headers = mapOf("x-api-key" to (apiKey() ?: ""), "anthropic-version" to "2023-06-01")
        val resp = openWithRetry(transport, HttpRequest("$base/v1/models?limit=100", "GET", headers, null, config.connectTimeoutMs, 30_000), maxRetries = 0)
        resp.use { Json.parse(it.readText()) }.obj()?.get("data").arr().mapNotNull { it.obj()?.get("id").str() }
    }

    override fun parseEvent(e: SseEvent): String? {
        if (e.data.isBlank()) return null
        val obj = runCatching { Json.parse(e.data) }.getOrElse { badEvent(e.data) }.obj() ?: badEvent(e.data)
        return when (obj["type"].str() ?: e.event) {
            "content_block_delta" -> obj["delta"].obj()?.let { d -> if (d["type"].str() == "text_delta") d["text"].str() else null }
            "error" -> {
                val err = obj["error"].obj()
                val type = err?.get("type").str()
                val kind = when (type) {
                    "overloaded_error", "api_error" -> ProviderErrorKind.SERVER
                    "rate_limit_error" -> ProviderErrorKind.RATE_LIMIT
                    "authentication_error", "permission_error" -> ProviderErrorKind.AUTH
                    else -> ProviderErrorKind.BAD_RESPONSE
                }
                throw ProviderException(kind, "Anthropic error ($type): ${err?.get("message").str()}")
            }
            else -> null
        }
    }
}

/**
 * OpenAI-compatible base URL rule: a bare host (e.g. http://192.168.1.20:11434) gets "/v1";
 * a URL that already has a path (…/v1, …/openai/v1, …/v1beta/openai) is used as-is.
 */
fun openAiEndpoint(baseUrl: String, path: String): String {
    val base = baseUrl.trim().trimEnd('/')
    val afterScheme = base.substringAfter("://", base)
    val hasPath = afterScheme.contains('/')
    return if (hasPath) "$base/$path" else "$base/v1/$path"
}

fun createHttpProvider(config: EndpointConfig, transport: HttpTransport, apiKey: () -> String?): AiProvider =
    when (config.kind) {
        EndpointKind.OPENAI_COMPATIBLE -> OpenAiCompatibleProvider(config, transport, apiKey)
        EndpointKind.ANTHROPIC -> AnthropicProvider(config, transport, apiKey)
    }
