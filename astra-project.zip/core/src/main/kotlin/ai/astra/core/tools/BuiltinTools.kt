package ai.astra.core.tools

import ai.astra.core.documents.DocumentIndex
import ai.astra.core.json.JsonValue
import ai.astra.core.json.jsonObj
import ai.astra.core.json.num
import ai.astra.core.json.str
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel
import java.math.BigDecimal
import java.math.MathContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.pow

class CalcException(message: String) : RuntimeException(message)

/**
 * Exact-enough arithmetic evaluator (recursive descent). Supports + - * / % ^, parentheses,
 * unary minus, implicit percentage ("18% of 2500"), constants pi/e and common functions.
 */
object Calculator {
    fun evaluate(expression: String): Double {
        val normalized = expression.lowercase()
            .replace("×", "*").replace("÷", "/").replace("−", "-")
            .replace(Regex("(?<=\\d),(?=\\d{2,3}\\b)"), "") // thousands separators: 1,000 / 1,00,000 (Indian grouping)
            .replace(Regex("(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*"), "($1/100)*")
        val p = P(normalized)
        val v = p.expr()
        p.ws()
        if (p.i != p.s.length) throw CalcException("Unexpected '${p.s.substring(p.i)}'")
        if (v.isNaN() || v.isInfinite()) throw CalcException("Result is not a finite number")
        return v
    }

    fun format(v: Double): String {
        if (v == Math.rint(v) && abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun eat(c: Char): Boolean { ws(); if (i < s.length && s[i] == c) { i++; return true }; return false }

        fun expr(): Double {
            var v = term()
            while (true) v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v }
        }

        fun term(): Double {
            var v = factor()
            while (true) v = when {
                eat('*') -> v * factor()
                eat('/') -> factor().let { d -> if (d == 0.0) throw CalcException("Division by zero") else v / d }
                eat('%') -> {
                    ws()
                    if (i >= s.length || s[i] in ")+-*/^,") v / 100.0 // "18%" → 0.18
                    else factor().let { d -> if (d == 0.0) throw CalcException("Modulo by zero") else v % d }
                }
                else -> return v
            }
        }

        /** Unary minus binds looser than ^ (so -3^2 = -9); ^ is right-associative. */
        fun factor(): Double {
            if (eat('-')) return -factor()
            if (eat('+')) return factor()
            val base = postfix(primary())
            return if (eat('^')) base.pow(factor()) else base
        }

        fun postfix(v: Double): Double {
            ws()
            if (i < s.length && s[i] == '!') {
                i++
                if (v < 0 || v != Math.rint(v) || v > 170) throw CalcException("Factorial needs an integer 0..170")
                var r = 1.0; for (k in 2..v.toInt()) r *= k; return r
            }
            return v
        }

        fun primary(): Double {
            ws()
            if (eat('(')) { val v = expr(); if (!eat(')')) throw CalcException("Missing ')'"); return v }
            val start = i
            if (i < s.length && (s[i].isDigit() || s[i] == '.')) {
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                if (i < s.length && s[i] == 'e' && i + 1 < s.length && (s[i + 1].isDigit() || s[i + 1] == '-' || s[i + 1] == '+')) {
                    i += 2; while (i < s.length && s[i].isDigit()) i++
                }
                return s.substring(start, i).toDoubleOrNull() ?: throw CalcException("Bad number '${s.substring(start, i)}'")
            }
            while (i < s.length && s[i].isLetter()) i++
            val name = s.substring(start, i)
            if (name.isEmpty()) throw CalcException(if (i < s.length) "Unexpected '${s[i]}'" else "Unexpected end")
            when (name) { "pi" -> return Math.PI; "e" -> return Math.E }
            if (!eat('(')) throw CalcException("Unknown name '$name'")
            val args = ArrayList<Double>()
            if (!eat(')')) {
                do { args += expr() } while (eat(','))
                if (!eat(')')) throw CalcException("Missing ')' after $name(")
            }
            fun one(): Double = args.singleOrNull() ?: throw CalcException("$name() takes one argument")
            return when (name) {
                "sqrt" -> one().let { if (it < 0) throw CalcException("sqrt of negative") else kotlin.math.sqrt(it) }
                "cbrt" -> Math.cbrt(one())
                "abs" -> abs(one())
                "sin" -> kotlin.math.sin(one()); "cos" -> kotlin.math.cos(one()); "tan" -> kotlin.math.tan(one())
                "asin" -> kotlin.math.asin(one()); "acos" -> kotlin.math.acos(one()); "atan" -> kotlin.math.atan(one())
                "ln" -> one().let { if (it <= 0) throw CalcException("ln of non-positive") else kotlin.math.ln(it) }
                "log" -> one().let { if (it <= 0) throw CalcException("log of non-positive") else kotlin.math.log10(it) }
                "exp" -> kotlin.math.exp(one())
                "round" -> if (args.size == 2) BigDecimal(args[0]).setScale(args[1].toInt(), java.math.RoundingMode.HALF_UP).toDouble() else Math.round(one()).toDouble()
                "floor" -> kotlin.math.floor(one()); "ceil" -> kotlin.math.ceil(one())
                "min" -> args.minOrNull() ?: throw CalcException("min() needs arguments")
                "max" -> args.maxOrNull() ?: throw CalcException("max() needs arguments")
                "pow" -> if (args.size == 2) args[0].pow(args[1]) else throw CalcException("pow(a, b)")
                "rad" -> Math.toRadians(one()); "deg" -> Math.toDegrees(one())
                else -> throw CalcException("Unknown function '$name'")
            }
        }
    }
}

class CalculatorTool : Tool {
    override val spec = ToolSpec(
        name = "calculator",
        description = "Evaluates an arithmetic expression exactly. Supports + - * / % ^ ! ( ), 'X% of Y', sqrt, ln, log, sin, cos, tan, round(x,n), min, max, pi, e.",
        inputSchema = """{"type":"object","properties":{"expression":{"type":"string"}},"required":["expression"]}""",
        outputSchema = """{"type":"object","properties":{"result":{"type":"number"}}}""",
        risk = RiskLevel.LOW, permissions = emptySet(), environment = ExecutionEnvironment.IN_PROCESS,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val expr = args["expression"].str() ?: return ToolResult.Error("Missing 'expression'")
        return try {
            val v = Calculator.evaluate(expr)
            ToolResult.Ok("${expr.trim()} = ${Calculator.format(v)}", jsonObj("result" to v))
        } catch (e: CalcException) {
            ToolResult.Error("Calculation error: ${e.message}")
        }
    }
}

object Units {
    private data class U(val dim: String, val factor: Double)

    private val table: Map<String, U> = buildMap {
        fun add(dim: String, factor: Double, vararg names: String) = names.forEach { put(it, U(dim, factor)) }
        add("length", 1.0, "m", "meter", "meters", "metre", "metres")
        add("length", 1000.0, "km", "kilometer", "kilometers", "kilometre", "kilometres")
        add("length", 0.01, "cm", "centimeter", "centimeters")
        add("length", 0.001, "mm", "millimeter", "millimeters")
        add("length", 0.0254, "in", "inch", "inches")
        add("length", 0.3048, "ft", "foot", "feet")
        add("length", 0.9144, "yd", "yard", "yards")
        add("length", 1609.344, "mi", "mile", "miles")
        add("mass", 1.0, "kg", "kilogram", "kilograms")
        add("mass", 0.001, "g", "gram", "grams")
        add("mass", 100.0, "quintal", "quintals")
        add("mass", 1000.0, "t", "tonne", "tonnes", "ton")
        add("mass", 0.45359237, "lb", "lbs", "pound", "pounds")
        add("mass", 0.028349523125, "oz", "ounce", "ounces")
        add("area", 1.0, "m2", "sqm", "sq m", "square meter", "square meters")
        add("area", 0.09290304, "ft2", "sqft", "sq ft", "square foot", "square feet")
        add("area", 4046.8564224, "acre", "acres")
        add("area", 10000.0, "ha", "hectare", "hectares")
        add("area", 1_000_000.0, "km2", "sq km", "square kilometer")
        add("volume", 1.0, "l", "liter", "liters", "litre", "litres")
        add("volume", 0.001, "ml", "milliliter", "milliliters")
        add("volume", 1000.0, "m3", "cubic meter", "cubic meters")
        add("volume", 3.785411784, "gal", "gallon", "gallons")
        add("speed", 1.0, "m/s", "mps")
        add("speed", 1 / 3.6, "km/h", "kmh", "kph")
        add("speed", 0.44704, "mph")
        add("data", 1.0, "b", "byte", "bytes")
        add("data", 1024.0, "kb", "kib")
        add("data", 1024.0 * 1024, "mb", "mib")
        add("data", 1024.0 * 1024 * 1024, "gb", "gib")
        add("data", 1024.0 * 1024 * 1024 * 1024, "tb", "tib")
        add("time", 1.0, "s", "sec", "second", "seconds")
        add("time", 60.0, "min", "minute", "minutes")
        add("time", 3600.0, "h", "hr", "hour", "hours")
        add("time", 86400.0, "day", "days")
    }

    private val temps = setOf("c", "celsius", "f", "fahrenheit", "k", "kelvin")

    fun convert(value: Double, from: String, to: String): Double {
        val f = from.trim().lowercase(); val t = to.trim().lowercase()
        if (f in temps || t in temps) {
            if (f !in temps || t !in temps) throw CalcException("Cannot convert $from to $to")
            val c = when (f[0]) { 'c' -> value; 'f' -> (value - 32) * 5 / 9; else -> value - 273.15 }
            return when (t[0]) { 'c' -> c; 'f' -> c * 9 / 5 + 32; else -> c + 273.15 }
        }
        val a = table[f] ?: throw CalcException("Unknown unit '$from'")
        val b = table[t] ?: throw CalcException("Unknown unit '$to'")
        if (a.dim != b.dim) throw CalcException("Cannot convert ${a.dim} to ${b.dim}")
        return value * a.factor / b.factor
    }
}

class UnitConverterTool : Tool {
    override val spec = ToolSpec(
        "unit_convert", "Converts a value between units of length, mass, area (acre, hectare), volume, speed, data size, time and temperature.",
        """{"type":"object","properties":{"value":{"type":"number"},"from":{"type":"string"},"to":{"type":"string"}},"required":["value","from","to"]}""",
        """{"type":"object","properties":{"result":{"type":"number"}}}""",
        RiskLevel.LOW, emptySet(), ExecutionEnvironment.IN_PROCESS,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val v = args["value"].num() ?: args["value"].str()?.toDoubleOrNull() ?: return ToolResult.Error("Missing numeric 'value'")
        val from = args["from"].str() ?: return ToolResult.Error("Missing 'from'")
        val to = args["to"].str() ?: return ToolResult.Error("Missing 'to'")
        return try {
            val r = Units.convert(v, from, to)
            ToolResult.Ok("${Calculator.format(v)} $from = ${Calculator.format(r)} $to", jsonObj("result" to r))
        } catch (e: CalcException) { ToolResult.Error(e.message ?: "Conversion error") }
    }
}

class DateTimeTool(private val zone: () -> ZoneId = { ZoneId.systemDefault() }, private val now: () -> Instant = { Instant.now() }) : Tool {
    override val spec = ToolSpec(
        "datetime", "Gives the current date/time on this device, or the number of days between two ISO dates (YYYY-MM-DD), or adds days to a date.",
        """{"type":"object","properties":{"op":{"type":"string","enum":["now","days_between","add_days"]},"from":{"type":"string"},"to":{"type":"string"},"date":{"type":"string"},"days":{"type":"number"}},"required":["op"]}""",
        """{"type":"string"}""", RiskLevel.LOW, emptySet(), ExecutionEnvironment.DEVICE_API,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult = try {
        when (args["op"].str() ?: "now") {
            "now" -> ToolResult.Ok(ZonedDateTime.ofInstant(now(), zone()).format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, HH:mm z")))
            "days_between" -> {
                val a = LocalDate.parse(args["from"].str() ?: return ToolResult.Error("Missing 'from'"))
                val b = LocalDate.parse(args["to"].str() ?: return ToolResult.Error("Missing 'to'"))
                ToolResult.Ok("${ChronoUnit.DAYS.between(a, b)} days from $a to $b")
            }
            "add_days" -> {
                val d = LocalDate.parse(args["date"].str() ?: return ToolResult.Error("Missing 'date'"))
                val n = args["days"].num()?.toLong() ?: return ToolResult.Error("Missing 'days'")
                ToolResult.Ok("$d + $n days = ${d.plusDays(n)} (${d.plusDays(n).dayOfWeek})")
            }
            else -> ToolResult.Error("Unknown op")
        }
    } catch (e: java.time.DateTimeException) { ToolResult.Error("Date error: ${e.message}") }
}

class MemorySearchTool(private val memory: MemoryEngine, private val projectId: () -> String?) : Tool {
    override val spec = ToolSpec(
        "memory_search", "Searches what the user explicitly asked ASTRA to remember.",
        """{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}""",
        """{"type":"string"}""", RiskLevel.LOW, setOf(Permission.MEMORY), ExecutionEnvironment.IN_PROCESS,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val q = args["query"].str() ?: return ToolResult.Error("Missing 'query'")
        val hits = memory.recall(q, projectId())
        return ToolResult.Ok(if (hits.isEmpty()) "No matching memories." else hits.joinToString("\n") { "- ${it.record.content}" })
    }
}

class DocumentSearchTool(private val index: DocumentIndex, private val projectId: () -> String?) : Tool {
    override val spec = ToolSpec(
        "document_search", "Searches the user's imported documents and returns passages with page/section references.",
        """{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}""",
        """{"type":"string"}""", RiskLevel.LOW, setOf(Permission.DOCUMENTS), ExecutionEnvironment.IN_PROCESS,
    )

    override suspend fun run(args: JsonValue.Obj): ToolResult {
        val q = args["query"].str() ?: return ToolResult.Error("Missing 'query'")
        val hits = index.search(q, projectId = projectId())
        return ToolResult.Ok(if (hits.isEmpty()) "No matching passages." else hits.joinToString("\n\n") { "[${it.citation}] ${it.chunk.text.take(700)}" })
    }
}

fun defaultTools(memory: MemoryEngine, documents: DocumentIndex, projectId: () -> String?): ToolRegistry = ToolRegistry().apply {
    register(CalculatorTool())
    register(UnitConverterTool())
    register(DateTimeTool())
    register(MemorySearchTool(memory, projectId))
    register(DocumentSearchTool(documents, projectId))
}
