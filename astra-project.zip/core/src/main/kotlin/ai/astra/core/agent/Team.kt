package ai.astra.core.agent

import ai.astra.core.model.ContentSource
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.model.plainText
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.PromptTurn
import ai.astra.core.provider.StreamEvent
import ai.astra.core.text.ThinkFilter

/** Specialised internal agents. They share one model; only their instructions differ. */
enum class AgentRole(val title: String, val instruction: String) {
    RESEARCHER("Researcher", "You are the Researcher. Gather every relevant fact from the task, the provided documents and memories. List facts as bullets, each with where it came from. Mark anything you are unsure of as UNCERTAIN. Do not write the final answer."),
    ANALYST("Analyst", "You are the Analyst. Using the team notes, identify what matters most, patterns, numbers, trade-offs and implications. Be specific and quantitative where possible."),
    CRITIC("Critic", "You are the Critic. Look for weaknesses in the team notes: unsupported claims, missing considerations, wrong calculations, contradictions, risks. List concrete problems and how to fix them. If there are none, say so."),
    WRITER("Writer", "You are the Writer. Produce the final answer for the user from the team notes, fixing every problem the Critic raised. Clear structure, plain language, no filler. Do not mention the team or the notes."),
    VERIFIER("Verifier", "You are the Verifier. Check the Writer's answer against the team notes and sources for factual consistency and arithmetic. Reply with 'VERIFIED' on the first line if it is consistent; otherwise 'ISSUES' on the first line followed by a short list of specific problems."),
    PLANNER("Planner", "You are the Planner. Break the goal into ordered, concrete steps with time estimates, dependencies and checkpoints."),
    CODER("Coder", "You are the Coder. Write or fix the code needed. Return complete, runnable code in fenced blocks with brief notes on design decisions."),
    TEACHER("Teacher", "You are the Teacher. Explain the material simply, step by step, with examples, and end with 3 short self-check questions."),
}

data class TeamWorkflow(val id: String, val name: String, val description: String, val stages: List<AgentRole>)

object TeamWorkflows {
    val RESEARCH = TeamWorkflow("research", "Research report", "Researcher → Analyst → Critic → Writer → Verifier",
        listOf(AgentRole.RESEARCHER, AgentRole.ANALYST, AgentRole.CRITIC, AgentRole.WRITER, AgentRole.VERIFIER))
    val CODE = TeamWorkflow("code", "Code with review", "Planner → Coder → Critic → Coder → Verifier",
        listOf(AgentRole.PLANNER, AgentRole.CODER, AgentRole.CRITIC, AgentRole.CODER, AgentRole.VERIFIER))
    val STUDY = TeamWorkflow("study", "Study plan & lesson", "Planner → Teacher → Critic → Writer",
        listOf(AgentRole.PLANNER, AgentRole.TEACHER, AgentRole.CRITIC, AgentRole.WRITER))
    val DECISION = TeamWorkflow("decision", "Decision analysis", "Analyst → Critic → Writer → Verifier",
        listOf(AgentRole.ANALYST, AgentRole.CRITIC, AgentRole.WRITER, AgentRole.VERIFIER))
    val all = listOf(RESEARCH, CODE, STUDY, DECISION)
    fun byId(id: String?) = all.firstOrNull { it.id.equals(id, ignoreCase = true) }

    /** Picks a workflow from the task text when the user doesn't name one. */
    fun guess(task: String): TeamWorkflow {
        val t = task.lowercase()
        return when {
            Regex("\\b(code|bug|function|kotlin|python|script|app|api)\\b").containsMatchIn(t) -> CODE
            Regex("\\b(study|learn|exam|syllabus|teach|explain|padhai)\\b").containsMatchIn(t) -> STUDY
            Regex("\\b(should i|decide|choose|compare|which is better|option)\\b").containsMatchIn(t) -> DECISION
            else -> RESEARCH
        }
    }
}

data class StageOutput(val role: AgentRole, val text: String, val tokens: Int)

data class TeamOutcome(val finalText: String, val stages: List<StageOutput>, val verified: Boolean?, val issues: String?, val tokens: Int, val durationMs: Long)

/**
 * Runs a workflow stage by stage on one model. Each stage sees the task, the shared context
 * (memories, documents — already fenced by the context engine) and the previous stages' notes.
 */
class TeamRunner {
    suspend fun run(
        provider: AiProvider,
        workflow: TeamWorkflow,
        baseTurns: List<PromptTurn>,
        template: GenerationRequest,
        onStage: suspend (AgentRole) -> Unit,
        onToken: suspend (String) -> Unit,
        onActivity: suspend (ActivityItem) -> Unit,
    ): TeamOutcome {
        val started = System.currentTimeMillis()
        val system = baseTurns.firstOrNull { it.role == Role.SYSTEM }?.parts?.plainText().orEmpty()
        val task = baseTurns.lastOrNull { it.role == Role.USER }?.parts?.plainText().orEmpty()
        val notes = ArrayList<StageOutput>()
        var tokens = 0
        var finalText = ""
        var verified: Boolean? = null
        var issues: String? = null
        val producer = workflow.stages.indexOfLast { it != AgentRole.VERIFIER && it != AgentRole.CRITIC }
        for ((i, role) in workflow.stages.withIndex()) {
            onStage(role)
            onActivity(ActivityItem(ActivityKind.TOOL_CALL, "Team · ${role.title}", "Stage ${i + 1} of ${workflow.stages.size}"))
            val notesText = notes.joinToString("\n\n") { "### ${it.role.title}\n${it.text}" }
            val turns = listOf(
                PromptTurn(Role.SYSTEM, listOf(Part.Text("$system\n\n## Your role\n${role.instruction}")), setOf(ContentSource.SYSTEM)),
                PromptTurn(Role.USER, listOf(Part.Text(buildString {
                    append("## Task\n").append(task)
                    if (notesText.isNotBlank()) append("\n\n## Team notes so far\n").append(notesText)
                })), setOf(ContentSource.USER)),
            )
            val sb = StringBuilder()
            val think = ThinkFilter()
            val streamToUser = i == producer
            provider.stream(template.copy(turns = turns, temperature = if (role == AgentRole.VERIFIER || role == AgentRole.CRITIC) 0.2 else template.temperature)).collect { e ->
                when (e) {
                    is StreamEvent.Token -> { val v = think.accept(e.text); sb.append(v); if (streamToUser && v.isNotEmpty()) onToken(v) }
                    is StreamEvent.Done -> tokens += e.stats.tokensOut
                }
            }
            sb.append(think.finish())
            val out = sb.toString().trim()
            notes += StageOutput(role, out, 0)
            onActivity(ActivityItem(ActivityKind.TOOL_RESULT, "${role.title} ✓", out.take(400)))
            if (i == producer) finalText = out
            if (role == AgentRole.VERIFIER) {
                verified = out.lineSequence().firstOrNull()?.trim()?.uppercase()?.startsWith("VERIFIED") == true
                if (verified == false) issues = out.substringAfter('\n', out).trim()
            }
        }
        if (finalText.isBlank()) finalText = notes.lastOrNull { it.role != AgentRole.VERIFIER && it.role != AgentRole.CRITIC }?.text.orEmpty()
        if (verified == false && issues != null) onToken("\n\n— Verifier flagged —\n$issues")
        return TeamOutcome(finalText, notes, verified, issues, tokens, System.currentTimeMillis() - started)
    }
}
