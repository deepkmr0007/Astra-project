package ai.astra.core.memory

import ai.astra.core.text.Tokenizer
import kotlin.math.ln
import kotlin.math.sqrt

/** Turns text into a fixed-size vector. Implementations must be deterministic for a given [id]. */
interface Embedder {
    val id: String
    val dimensions: Int
    suspend fun embed(texts: List<String>): List<FloatArray>
}

/**
 * Fully offline embedder based on signed feature hashing of words, word bigrams and character
 * trigrams (sub-word overlap gives some robustness to inflection and Hinglish spelling).
 *
 * Honest scope: this captures lexical similarity, not deep meaning. When a neural embedding model
 * is configured (local or remote, via [ProviderEmbedder]) ASTRA re-embeds memories with it.
 */
class HashingEmbedder(override val dimensions: Int = 512) : Embedder {
    override val id: String = "hash-v1-$dimensions"

    override suspend fun embed(texts: List<String>): List<FloatArray> = texts.map { embedOne(it) }

    fun embedOne(text: String): FloatArray {
        val v = FloatArray(dimensions)
        val words = Tokenizer.terms(text)
        val counts = HashMap<String, Float>()
        fun feature(f: String, w: Float) { counts[f] = (counts[f] ?: 0f) + w }
        words.forEach { w ->
            feature("w:$w", 1.0f)
            if (w.length >= 4) {
                val padded = "^$w$"
                for (i in 0..padded.length - 3) feature("c:" + padded.substring(i, i + 3), 0.25f)
            }
        }
        for (i in 0 until words.size - 1) feature("b:${words[i]}_${words[i + 1]}", 0.6f)
        for ((f, c) in counts) {
            val h = fnv1a(f)
            val idx = ((h ushr 1) % dimensions.toLong()).toInt()
            val sign = if (h and 1L == 0L) 1f else -1f
            v[idx] += sign * (1f + ln(c.toDouble() + 1.0).toFloat())
        }
        return normalize(v)
    }

    private fun fnv1a(s: String): Long {
        var h = 0xcbf29ce484222325uL.toLong()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            h = h xor (b.toLong() and 0xff)
            h *= 0x100000001b3L
        }
        return h and Long.MAX_VALUE
    }
}

fun normalize(v: FloatArray): FloatArray {
    var n = 0.0
    for (x in v) n += x * x
    val norm = sqrt(n).toFloat()
    if (norm > 0f) for (i in v.indices) v[i] /= norm
    return v
}

fun cosine(a: FloatArray, b: FloatArray): Float {
    if (a.size != b.size || a.isEmpty()) return 0f
    var dot = 0.0; var na = 0.0; var nb = 0.0
    for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
    if (na == 0.0 || nb == 0.0) return 0f
    return (dot / (sqrt(na) * sqrt(nb))).toFloat()
}

/** Uses a provider's embedding endpoint (e.g. a local or LAN embedding model). */
class ProviderEmbedder(
    private val provider: ai.astra.core.provider.AiProvider,
    override val dimensions: Int,
) : Embedder {
    override val id: String = "provider:${provider.info.id}:${provider.info.model}"
    override suspend fun embed(texts: List<String>): List<FloatArray> = provider.embed(texts).map { normalize(it) }
}
