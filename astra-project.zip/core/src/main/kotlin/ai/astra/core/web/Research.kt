package ai.astra.core.web

import ai.astra.core.model.ContentSource
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.PromptTurn
import ai.astra.core.security.PromptInjectionDetector
import ai.astra.core.security.Sensitivity
import ai.astra.core.security.UntrustedFence
import ai.astra.core.text.Bm25
import ai.astra.core.text.ThinkFilter
import ai.astra.core.text.Tokenizer
import java.net.URI
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class SourceAssessment(
    val index: Int,
    val title: String,
    val url: String,
    val domain: String,
    val authority: Double,
    val recencyDays: Long?,
    val relevance: Double,
    val corroboration: Double,
    val trust: Double,
    val passages: List<String>,
    val duplicateOf: Int? = null,
    val injectionRisk: Sensitivity = Sensitivity.NONE,
    val cached: Boolean = false,
    val retrievedAt: Long,
) {
    val trustLabel: String get() = when {
        trust >= 0.75 -> "high"
        trust >= 0.55 -> "medium"
        else -> "low"
    }
}

data class Conflict(val topic: String, val values: Map<Int, String>)

/** Scores sources by authority, recency, relevance and corroboration, and finds duplicates and conflicts. */
object SourceTrust {
    private val HIGH = listOf(".gov.in", ".nic.in", ".gov", ".mil", ".edu", ".ac.in", ".ac.uk", ".int", "who.int", "un.org", "rbi.org.in", "sebi.gov.in", "nature.com", "science.org", "nih.gov", "europa.eu")
    private val GOOD = listOf("wikipedia.org", "britannica.com", "reuters.com", "apnews.com", "bbc.com", "bbc.co.uk", "thehindu.com", "indianexpress.com", "livemint.com", "economictimes.indiatimes.com", "pib.gov.in", "arxiv.org", "github.com", "developer.android.com", "docs.python.org", "mozilla.org", "stackoverflow.com")
    private val LOW = listOf("pinterest.", "quora.com", "facebook.com", "instagram.com", "tiktok.com", "x.com", "twitter.com", "blogspot.", "wordpress.com")

    fun domainOf(url: String): String = runCatching { URI(url).host.removePrefix("www.") }.getOrDefault(url)

    fun authority(domain: String): Double = when {
        HIGH.any { domain.endsWith(it.trimStart('.')) || domain.endsWith(it) } -> 0.95
        GOOD.any { domain == it || domain.endsWith(".$it") || domain.endsWith(it) } -> 0.75
        LOW.any { domain.contains(it) } -> 0.3
        domain.endsWith(".org") -> 0.6
        else -> 0.5
    }

    fun recencyDays(published: String?, today: LocalDate = LocalDate.now()): Long? {
        val m = Regex("(\\d{4})-(\\d{2})-(\\d{2})").find(published ?: return null) ?: return null
        return runCatching { ChronoUnit.DAYS.between(LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()), today) }.getOrNull()
    }

    fun recencyScore(days: Long?): Double = when {
        days == null -> 0.5
        days < 30 -> 1.0
        days < 365 -> 0.8
        days < 3 * 365 -> 0.6
        else -> 0.4
    }

    private val NUMBER = Regex("(\\d[\\d,]*(?:\\.\\d+)?)\\s*(%|percent|crore|lakh|million|billion|km|kg|tonnes?|years?|rs\\.?|₹|usd|\\$)?", RegexOption.IGNORE_CASE)

    /** Facts as (unit-or-context, value) pairs from sentences that mention query terms. */
    fun figures(text: String, queryTerms: Set<String>): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (s in Tokenizer.sentences(text).take(400)) {
            val terms = Tokenizer.terms(s).toSet()
            if (terms.intersect(queryTerms).isEmpty()) continue
            for (m in NUMBER.findAll(s)) {
                val unit = m.groupValues[2].lowercase()
                if (unit.isBlank()) continue
                val key = unit.removeSuffix("s").replace("percent", "%")
                out.putIfAbsent(key, m.groupValues[1].replace(",", ""))
            }
        }
        return out
    }

    fun assess(question: String, pages: List<Pair<SearchResult, WebPage?>>, today: LocalDate = LocalDate.now()): Pair<List<SourceAssessment>, List<Conflict>> {
        val qTerms = Tokenizer.terms(question)
        val qSet = qTerms.toSet()
        val texts = pages.map { (r, p) -> p?.text ?: r.snippet }
        val bm = Bm25(texts.map { Tokenizer.terms(it) }).normalizedScores(qTerms)
        val termSets = texts.map { Tokenizer.terms(it).filter { t -> t.length > 3 }.toSet() }
        val figs = texts.map { figures(it, qSet) }
        val result = pages.mapIndexed { i, (r, p) ->
            val domain = domainOf(p?.finalUrl ?: r.url)
            val days = recencyDays(p?.publishedAt ?: r.publishedAt, today)
            // Corroboration: share of other sources with substantial key-term overlap.
            val others = termSets.indices.filter { it != i }
            val corr = if (others.isEmpty()) 0.0 else others.count { j ->
                val inter = termSets[i].intersect(termSets[j]).intersect(qSet + termSets[i].take(200).toSet()).size
                inter >= 3
            }.toDouble() / others.size
            val dup = (0 until i).firstOrNull { j ->
                val a = termSets[i]; val b = termSets[j]
                a.isNotEmpty() && b.isNotEmpty() && a.intersect(b).size.toDouble() / minOf(a.size, b.size) > 0.85
            }
            val authority = authority(domain)
            val trust = (0.45 * authority + 0.2 * recencyScore(days) + 0.2 * bm[i] + 0.15 * corr).coerceIn(0.0, 1.0)
            SourceAssessment(
                index = i + 1, title = p?.title?.ifBlank { null } ?: r.title, url = p?.finalUrl ?: r.url, domain = domain,
                authority = authority, recencyDays = days, relevance = bm[i], corroboration = corr, trust = trust,
                passages = bestPassages(texts[i], qTerms), duplicateOf = dup?.plus(1),
                injectionRisk = PromptInjectionDetector.assess(texts[i]).risk, retrievedAt = p?.retrievedAt ?: System.currentTimeMillis(),
            )
        }
        val conflicts = ArrayList<Conflict>()
        val units = figs.flatMap { it.keys }.toSet()
        for (u in units) {
            val values = figs.mapIndexedNotNull { i, f -> f[u]?.let { (i + 1) to it } }.toMap()
            if (values.values.toSet().size > 1 && values.size >= 2) conflicts += Conflict(u, values)
        }
        return result to conflicts
    }

    fun bestPassages(text: String, qTerms: List<String>, n: Int = 2, size: Int = 700): List<String> {
        val paras = text.split(Regex("\\n\\s*\\n")).flatMap { p -> if (p.length > size * 2) p.chunked(size) else listOf(p) }.map { it.trim() }.filter { it.length > 40 }
        if (paras.isEmpty()) return listOf(text.take(size))
        val scores = Bm25(paras.map { Tokenizer.terms(it) }).normalizedScores(qTerms)
        return paras.indices.sortedByDescending { scores[it] }.take(n).sorted().map { paras[it].take(size) }
    }
}

data class ResearchReport(
    val question: String,
    val queries: List<String>,
    val answer: String,
    val sources: List<SourceAssessment>,
    val conflicts: List<Conflict>,
    val failures: List<String>,
    val synthesizedBy: String?,
) {
    fun sourcesMarkdown(): String = buildString {
        append("\n\n**Sources** (retrieved ${java.time.LocalDate.now()})\n")
        sources.filter { it.duplicateOf == null }.forEach { s ->
            append("[${s.index}] ${s.title} — ${s.domain} · trust ${s.trustLabel}")
            s.recencyDays?.let { append(" · ${if (it < 1) "today" else "$it days old"}") }
            if (s.cached) append(" · cached")
            append("\n${s.url}\n")
        }
        if (conflicts.isNotEmpty()) {
            append("\n⚠ Sources disagree: ")
            append(conflicts.joinToString("; ") { c -> c.values.entries.joinToString(" vs ") { "[${it.key}] ${it.value} ${c.topic}" } })
            append('\n')
        }
        if (failures.isNotEmpty()) append("\nCould not read: ${failures.joinToString()}\n")
    }
}

/**
 * QUESTION → SEARCH → SOURCE COLLECTION → SOURCE QUALITY → CROSS-CHECK → SYNTHESIS → CITATIONS.
 * Sources are fenced as untrusted data; the model must cite [n] and say when sources disagree.
 * Without a model, it returns the most relevant passages with citations (no invented summary).
 */
class ResearchPipeline(
    private val search: SearchProvider,
    private val fetcher: WebFetcher,
    private val cache: WebCache?,
) {
    suspend fun run(
        question: String,
        model: AiProvider?,
        onStep: suspend (String, String) -> Unit,
        onToken: suspend (String) -> Unit,
        maxSources: Int = 5,
        maxOutputTokens: Int = 900,
    ): ResearchReport {
        val queries = buildQueries(question)
        val failures = ArrayList<String>()
        val results = LinkedHashMap<String, SearchResult>()
        for (q in queries) {
            onStep("Search", "${search.name}: $q")
            runCatching { search.search(q, 6) }.onSuccess { list -> list.forEach { results.putIfAbsent(it.url.substringBefore('#'), it) } }
                .onFailure { failures += "${search.name} (${it.message})" }
        }
        if (results.isEmpty()) {
            return ResearchReport(question, queries, "No search results were found${if (failures.isNotEmpty()) " (${failures.joinToString()})" else ""}.", emptyList(), emptyList(), failures, null)
        }
        val chosen = results.values.take(maxSources)
        val pages = chosen.map { r ->
            onStep("Read", SourceTrust.domainOf(r.url))
            val page = runCatching { fetcher.fetch(r.url) }.onFailure { failures += "${SourceTrust.domainOf(r.url)} (${it.message})" }.getOrNull()
            page?.let { p -> runCatching { cache?.put(p) } }
            r to page
        }
        onStep("Cross-check", "Scoring authority, recency, relevance and agreement")
        val (sources, conflicts) = SourceTrust.assess(question, pages)
        val usable = sources.filter { it.duplicateOf == null && it.injectionRisk != Sensitivity.HIGH }.sortedByDescending { it.trust }

        if (model == null) {
            val extract = buildString {
                append("I don't have a model available to write a summary, so here are the most relevant passages:\n\n")
                usable.take(3).forEach { s -> append("**[${s.index}] ${s.title}**\n${s.passages.firstOrNull().orEmpty()}\n\n") }
            }
            onToken(extract)
            return ResearchReport(question, queries, extract, sources, conflicts, failures, null)
        }

        onStep("Synthesize", model.info.displayName)
        val fenced = usable.joinToString("\n\n") { s ->
            UntrustedFence.wrap(ContentSource.WEB, "[${s.index}] ${s.domain}", "Title: ${s.title}\nTrust: ${s.trustLabel}\n" + s.passages.joinToString("\n…\n"), s.injectionRisk)
        }
        val conflictNote = if (conflicts.isEmpty()) "" else "\nNote: sources disagree on: " + conflicts.joinToString { c -> c.values.entries.joinToString(" vs ") { "[${it.key}] ${it.value} ${c.topic}" } }
        val turns = listOf(
            PromptTurn(Role.SYSTEM, listOf(Part.Text(
                "You are ASTRA's research writer. Answer the question using ONLY the numbered web sources provided. " +
                    "Put the source number in square brackets after every factual claim, like [2]. " +
                    "If sources disagree, say so and show both. If the sources don't answer the question, say that plainly. " +
                    "Never invent sources, numbers or URLs. Be concise and well organised. " + UntrustedFence.SYSTEM_RULE,
            )), setOf(ContentSource.SYSTEM)),
            PromptTurn(Role.USER, listOf(Part.Text("Sources:\n\n$fenced\n$conflictNote\n\nQuestion: $question")), setOf(ContentSource.USER, ContentSource.WEB)),
        )
        val sb = StringBuilder()
        val think = ThinkFilter()
        model.stream(GenerationRequest(turns, maxOutputTokens, 0.2)).collect { e ->
            if (e is ai.astra.core.provider.StreamEvent.Token) {
                val visible = think.accept(e.text)
                if (visible.isNotEmpty()) { sb.append(visible); onToken(visible) }
            }
        }
        think.finish().takeIf { it.isNotEmpty() }?.let { sb.append(it); onToken(it) }
        // Keep only citations that point at real sources.
        val valid = sources.map { it.index }.toSet()
        val answer = Regex("\\[(\\d{1,2})]").replace(sb.toString()) { m -> if (m.groupValues[1].toInt() in valid) m.value else "" }
        return ResearchReport(question, queries, answer.trim(), sources, conflicts, failures, model.info.displayName)
    }

    fun buildQueries(question: String): List<String> {
        val q = question.trim().removePrefix("/research").trim()
        val keywords = Tokenizer.terms(q).take(8).joinToString(" ")
        return listOf(q, keywords).filter { it.isNotBlank() }.distinct()
    }
}
