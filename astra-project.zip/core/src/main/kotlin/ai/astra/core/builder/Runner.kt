package ai.astra.core.builder

import ai.astra.core.data.DataTable
import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.int
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.model.newId
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

/** What a driver (browser extension or phone agent) is asked to do. */
sealed interface DriverCommand {
    data class Navigate(val url: String) : DriverCommand
    data class FillFields(val values: List<FieldValue>) : DriverCommand
    data class Click(val target: String) : DriverCommand
    data class WaitFor(val target: String, val timeoutMs: Long) : DriverCommand
    data class CheckText(val text: String, val timeoutMs: Long) : DriverCommand
    data class Extract(val target: String) : DriverCommand
    data class LaunchApp(val app: String) : DriverCommand
    data class Tap(val target: String) : DriverCommand
    data class Type(val target: String, val value: String) : DriverCommand
    data class Scroll(val direction: String) : DriverCommand
    data object Back : DriverCommand
    /** Read the current form/screen. */
    data object Scan : DriverCommand
}

data class DriverResult(
    val ok: Boolean,
    val message: String = "",
    val data: String = "",
    val snapshot: FormSnapshot? = null,
    /** Fields the driver could not find or set. */
    val failedFields: List<String> = emptyList(),
)

interface AutomationDriver {
    val name: String
    suspend fun ready(): Boolean
    suspend fun execute(command: DriverCommand): DriverResult
}

sealed interface ReviewDecision {
    data object Approve : ReviewDecision
    data object Skip : ReviewDecision
    data object Stop : ReviewDecision
    /** The user corrected values (selector → value); ASTRA re-fills them and asks again. */
    data class Edit(val values: Map<String, String>) : ReviewDecision
}

enum class RunEventKind { INFO, STEP, WAITING, REVIEW, RECORD_DONE, RECORD_FAILED, RECORD_SKIPPED, WARNING, FINISHED }

data class RunEvent(val kind: RunEventKind, val text: String, val record: Int? = null, val time: Long = System.currentTimeMillis())

/** The UI side of a run: every pause for the human goes through here. */
interface RunHost {
    /** Login, CAPTCHA, OTP, manual save… Returns false if the user stops the run. */
    suspend fun waitForUser(message: String): Boolean
    suspend fun review(record: PreparedRecord, data: Map<String, String>, position: Int, total: Int): ReviewDecision
    /** Asked once when review is turned off but the automation saves records. */
    suspend fun confirmUnreviewedSaves(count: Int): Boolean
    fun event(e: RunEvent)
}

enum class RecordStatus { PENDING, DONE, SKIPPED, FAILED, BLOCKED }

data class LedgerEntry(val index: Int, val status: RecordStatus, val message: String = "", val extracted: Map<String, String> = emptyMap(), val at: Long = System.currentTimeMillis())

/** Per-record progress. Saved after every record so a run can resume exactly where it stopped. */
class RunLedger(val runId: String = newId(), val automationId: String, val source: String, val total: Int) {
    private val entries = sortedMapOf<Int, LedgerEntry>()
    var startedAt: Long = System.currentTimeMillis(); private set
    var finishedAt: Long? = null

    @Synchronized fun set(e: LedgerEntry) { entries[e.index] = e }
    @Synchronized fun get(i: Int): LedgerEntry = entries[i] ?: LedgerEntry(i, RecordStatus.PENDING, at = 0)
    @Synchronized fun all(): List<LedgerEntry> = (0 until total).map { get(it) }
    fun count(s: RecordStatus) = all().count { it.status == s }
    fun firstPending(): Int? = (0 until total).firstOrNull { get(it).status == RecordStatus.PENDING }

    /** Original data plus Status / Message / extracted columns — the run report the user keeps. */
    fun report(table: DataTable): DataTable {
        val extraCols = all().flatMap { it.extracted.keys }.distinct()
        val headers = table.headers + listOf("ASTRA status", "ASTRA message") + extraCols
        val rows = table.rows.mapIndexed { i, r -> val e = get(i); r + listOf(e.status.name, e.message) + extraCols.map { e.extracted[it].orEmpty() } }
        return DataTable(table.name + " — run report", headers, rows, table.origin)
    }

    fun toJson(): JsonValue.Obj = jsonObj(
        "runId" to runId, "automationId" to automationId, "source" to source, "total" to total, "startedAt" to startedAt, "finishedAt" to finishedAt,
        "entries" to all().filter { it.status != RecordStatus.PENDING }.map { jsonObj("i" to it.index, "s" to it.status.name, "m" to it.message, "x" to it.extracted, "at" to it.at) },
    )

    companion object {
        fun fromJson(o: JsonValue.Obj): RunLedger = RunLedger(o["runId"].str() ?: newId(), o["automationId"].str().orEmpty(), o["source"].str().orEmpty(), o["total"].int() ?: 0).also { l ->
            l.startedAt = o["startedAt"].long() ?: System.currentTimeMillis()
            l.finishedAt = o["finishedAt"].long()
            o["entries"].arr().forEach { e ->
                val eo = e.obj() ?: return@forEach
                val st = eo["s"].str()?.let { s -> RecordStatus.entries.firstOrNull { it.name == s } } ?: return@forEach
                l.set(LedgerEntry(eo["i"].int() ?: return@forEach, st, eo["m"].str().orEmpty(),
                    eo["x"].obj()?.fields?.mapValues { it.value.str().orEmpty() }.orEmpty(), eo["at"].long() ?: 0))
            }
        }
        fun decode(text: String) = fromJson(Json.parse(text).obj() ?: error("bad ledger"))
    }
}

data class RunSummary(val done: Int, val failed: Int, val skipped: Int, val blocked: Int, val stoppedReason: String?, val ledger: RunLedger)

/**
 * Executes an [AutomationSpec] over a data table, one record at a time, with the human in the
 * loop: the user logs in and handles CAPTCHA/OTP, reviews each filled record, and can stop at
 * any moment. Nothing is saved for a record that has validation errors.
 */
class AutomationRunner(
    private val spec: AutomationSpec,
    private val table: DataTable?,
    private val driver: AutomationDriver,
    private val host: RunHost,
    val ledger: RunLedger = RunLedger(automationId = spec.id, source = table?.origin ?: "", total = table?.size ?: 1),
    private val onProgress: suspend (RunLedger) -> Unit = {},
    private val sleep: suspend (Long) -> Unit = { delay(it) },
) {
    private class StopRun(val reason: String) : Exception(reason)

    suspend fun run(): RunSummary {
        val stopped: String? = try {
            execute(); null
        } catch (e: StopRun) {
            e.reason
        } catch (e: CancellationException) {
            host.event(RunEvent(RunEventKind.FINISHED, "Stopped")); throw e
        }
        ledger.finishedAt = System.currentTimeMillis()
        onProgress(ledger)
        val s = RunSummary(ledger.count(RecordStatus.DONE), ledger.count(RecordStatus.FAILED), ledger.count(RecordStatus.SKIPPED), ledger.count(RecordStatus.BLOCKED), stopped, ledger)
        host.event(RunEvent(RunEventKind.FINISHED, "Finished: ${s.done} done, ${s.failed} failed, ${s.skipped} skipped, ${s.blocked} need fixing" + (stopped?.let { " — $it" } ?: "")))
        return s
    }

    private suspend fun execute() {
        spec.problems().takeIf { it.isNotEmpty() }?.let { throw StopRun(it.joinToString("; ")) }
        if (!driver.ready()) throw StopRun("${driver.name} is not connected")
        if (table != null && spec.expectedColumns.isNotEmpty()) {
            val missing = spec.expectedColumns.filter { c -> table.headers.none { it.equals(c, true) } }
            if (missing.isNotEmpty()) host.event(RunEvent(RunEventKind.WARNING, "This data has no column(s): ${missing.joinToString()} — check the mappings"))
        }
        val saves = spec.recordSteps.any { it.action == StepAction.SUBMIT } && !spec.options.dryRun
        if (saves && !spec.options.reviewEachRecord && !host.confirmUnreviewedSaves(table?.size ?: 1)) throw StopRun("You chose not to save without review")

        for (step in spec.setupSteps) runStep(step, null, emptyMap(), -1)

        if (table == null) {
            if (spec.recordSteps.isNotEmpty()) runRecord(0, emptyMap())
            return
        }
        var consecutiveFailures = 0
        while (true) {
            val i = ledger.firstPending() ?: break
            val ok = runRecord(i, table.record(i))
            consecutiveFailures = if (ok) 0 else consecutiveFailures + (if (ledger.get(i).status == RecordStatus.FAILED) 1 else 0)
            onProgress(ledger)
            if (consecutiveFailures >= spec.options.stopAfterFailures) {
                consecutiveFailures = 0
                if (!host.waitForUser("${spec.options.stopAfterFailures} records failed in a row. Check the page, then Continue — or Stop.")) throw StopRun("Paused after repeated failures")
            }
        }
    }

    /** Returns true if the record finished DONE or was intentionally skipped. */
    private suspend fun runRecord(i: Int, data: Map<String, String>): Boolean {
        val total = table?.size ?: 1
        var prepared = RecordPreparer.prepare(i, data, spec.mappings)
        if (prepared.blocked && spec.recordSteps.any { it.action == StepAction.FILL_FORM }) {
            val msg = prepared.issues.filter { it.level == IssueLevel.ERROR }.joinToString("; ") { "${it.field}: ${it.message}" }
            ledger.set(LedgerEntry(i, RecordStatus.BLOCKED, msg))
            host.event(RunEvent(RunEventKind.RECORD_FAILED, "Record ${i + 1} needs fixing: $msg", i))
            return true
        }
        host.event(RunEvent(RunEventKind.INFO, "Record ${i + 1} of $total", i))
        val extracted = LinkedHashMap<String, String>()
        var reviewed = false
        try {
            for (step in spec.recordSteps) {
                when (step.action) {
                    StepAction.NEXT_RECORD -> break
                    StepAction.REVIEW -> {
                        if (!spec.options.reviewEachRecord) { reviewed = true; continue }
                        while (true) {
                            when (val d = host.review(prepared, data, i + 1, total)) {
                                ReviewDecision.Approve -> { reviewed = true; break }
                                ReviewDecision.Skip -> { ledger.set(LedgerEntry(i, RecordStatus.SKIPPED, "Skipped at review")); host.event(RunEvent(RunEventKind.RECORD_SKIPPED, "Record ${i + 1} skipped", i)); return true }
                                ReviewDecision.Stop -> throw StopRun("Stopped at review")
                                is ReviewDecision.Edit -> {
                                    val changed = prepared.values.map { v -> d.values[v.selector]?.let { v.copy(value = it) } ?: v }
                                    prepared = prepared.copy(values = changed)
                                    val r = driver.execute(DriverCommand.FillFields(changed.filter { it.selector in d.values }))
                                    if (!r.ok) host.event(RunEvent(RunEventKind.WARNING, "Could not re-fill: ${r.message}", i))
                                }
                            }
                        }
                    }
                    StepAction.SUBMIT -> {
                        if (spec.options.dryRun) {
                            if (!host.waitForUser("Fill-only mode: check the form and click “${step.target}” yourself, then Continue.")) throw StopRun("Stopped")
                            continue
                        }
                        if (spec.options.reviewEachRecord && !reviewed) throw IllegalStateException("Save without review is not allowed")
                        val r = driver.execute(DriverCommand.Click(step.target))
                        if (!r.ok) return fail(i, "Save button: ${r.message}")
                        host.event(RunEvent(RunEventKind.STEP, "Saved record ${i + 1}", i))
                    }
                    StepAction.EXTRACT -> {
                        val r = driver.execute(DriverCommand.Extract(step.target))
                        if (r.ok) extracted[step.value.ifBlank { step.target }] = r.data.trim() else host.event(RunEvent(RunEventKind.WARNING, "Couldn't read ${step.target}: ${r.message}", i))
                    }
                    else -> {
                        val r = runStep(step, prepared, data, i)
                        if (r != null && !r.ok) return fail(i, "${step.describe()}: ${r.message}")
                    }
                }
                if (spec.options.stepDelayMs > 0) sleep(spec.options.stepDelayMs)
            }
        } catch (e: StopRun) {
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return fail(i, e.message ?: e::class.simpleName.orEmpty())
        }
        val warn = prepared.issues.filter { it.level == IssueLevel.WARNING }.joinToString("; ") { "${it.field}: ${it.message}" }
        ledger.set(LedgerEntry(i, RecordStatus.DONE, warn, extracted))
        host.event(RunEvent(RunEventKind.RECORD_DONE, "Record ${i + 1} done" + if (extracted.isNotEmpty()) " (" + extracted.entries.joinToString { "${it.key}: ${it.value}" } + ")" else "", i))
        return true
    }

    private fun fail(i: Int, message: String): Boolean {
        ledger.set(LedgerEntry(i, RecordStatus.FAILED, message))
        host.event(RunEvent(RunEventKind.RECORD_FAILED, "Record ${i + 1} failed: $message", i))
        return false
    }

    /** Runs a non-review step. Returns null for steps that have no driver result. */
    private suspend fun runStep(step: Step, prepared: PreparedRecord?, data: Map<String, String>, i: Int): DriverResult? {
        val timeout = spec.options.waitTimeoutSec * 1000L
        fun v(t: String) = ValueEngine.render(t, data)
        val idx = i.takeIf { it >= 0 }
        host.event(RunEvent(RunEventKind.STEP, step.describe(), idx))
        val cmd: DriverCommand = when (step.action) {
            StepAction.WAIT_FOR_USER -> {
                host.event(RunEvent(RunEventKind.WAITING, step.value.ifBlank { "Waiting for you" }, idx))
                if (!host.waitForUser(step.value.ifBlank { "Do this step on the device, then tap Continue." })) throw StopRun("Stopped")
                return null
            }
            StepAction.PAUSE -> { sleep(((step.value.toDoubleOrNull() ?: 1.0) * 1000).toLong().coerceIn(0, 120_000)); return null }
            StepAction.OPEN_URL -> DriverCommand.Navigate(v(step.target))
            StepAction.FILL_FORM -> DriverCommand.FillFields(prepared?.values.orEmpty())
            StepAction.FILL -> DriverCommand.FillFields(listOf(FieldValue(step.target, step.target, v(step.value), FieldType.TEXT)))
            StepAction.SELECT -> DriverCommand.FillFields(listOf(FieldValue(step.target, step.target, v(step.value), FieldType.SELECT)))
            StepAction.CLICK -> DriverCommand.Click(step.target)
            StepAction.WAIT_FOR -> DriverCommand.WaitFor(step.target, step.value.toDoubleOrNull()?.let { (it * 1000).toLong() } ?: timeout)
            StepAction.CHECK_TEXT -> DriverCommand.CheckText(v(step.target), timeout)
            StepAction.LAUNCH_APP -> DriverCommand.LaunchApp(step.target)
            StepAction.TAP -> DriverCommand.Tap(v(step.target))
            StepAction.TYPE -> DriverCommand.Type(step.target, v(step.value))
            StepAction.SCROLL -> DriverCommand.Scroll(step.value.ifBlank { "down" })
            StepAction.BACK -> DriverCommand.Back
            StepAction.REVIEW, StepAction.SUBMIT, StepAction.NEXT_RECORD, StepAction.EXTRACT -> return null
        }
        val r = driver.execute(cmd)
        if (r.ok && r.failedFields.isNotEmpty()) host.event(RunEvent(RunEventKind.WARNING, "Not found on page: ${r.failedFields.joinToString()}", idx))
        if (!r.ok && i < 0) throw StopRun("Setup step failed — ${step.describe()}: ${r.message}")
        return r
    }
}
