package ai.astra.core.web

import ai.astra.core.documents.TextExtractors
import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.models.Checksums
import ai.astra.core.provider.HttpRequest
import ai.astra.core.provider.HttpTransport
import ai.astra.core.provider.ProviderErrorKind
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.isPrivateHost
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

const val USER_AGENT = "ASTRA-PersonalAI/0.2 (Android; local-first assistant; +https://github.com)"

data class SearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val provider: String,
    val publishedAt: String? = null,
)

/** A web search backend. Every call is network traffic and goes through the NetworkGate. */
interface SearchProvider {
    val id: String
    val name: String
    suspend fun search(query: String, limit: Int = 6): List<SearchResult>
}

internal fun enc(s: String): String = URLEncoder.encode(s, StandardCharsets.UTF_8.name())

private fun getJson(transport: HttpTransport, url: String, headers: Map<String, String> = emptyMap()): ai.astra.core.json.JsonValue {
    val resp = transport.open(HttpRequest(url, "GET", mapOf("User-Agent" to USER_AGENT, "Accept" to "application/json") + headers, null, 15_000, 25_000))
    resp.use {
        val body = it.readText()
        if (it.status !in 200..299) throw ProviderException(
            if (it.status == 401 || it.status == 403) ProviderErrorKind.AUTH else if (it.status == 429) ProviderErrorKind.RATE_LIMIT else ProviderErrorKind.SERVER,
            "Search HTTP ${it.status}",
        )
        return Json.parse(body)
    }
}

private fun stripTags(s: String) = TextExtractors.htmlToText(s).replace(Regex("\\s+"), " ").trim()

private val DEVANAGARI = Regex("[\\u0900-\\u097F]")

/** Wikipedia full-text search (no key). Uses Hindi Wikipedia for Devanagari queries. */
class WikipediaSearch(private val transport: HttpTransport) : SearchProvider {
    override val id = "wikipedia"
    override val name = "Wikipedia"
    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val lang = if (DEVANAGARI.containsMatchIn(query)) "hi" else "en"
        val root = getJson(transport, "https://$lang.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=$limit&srsearch=${enc(query)}")
        root.obj()?.get("query").obj()?.get("search").arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            val title = o["title"].str() ?: return@mapNotNull null
            SearchResult(title, "https://$lang.wikipedia.org/wiki/${enc(title.replace(' ', '_')).replace("+", "_")}", stripTags(o["snippet"].str().orEmpty()), name, o["timestamp"].str())
        }
    }
}

/** DuckDuckGo Instant Answer API (no key): good for definitions and entities, not full web results. */
class DuckDuckGoInstant(private val transport: HttpTransport) : SearchProvider {
    override val id = "duckduckgo"
    override val name = "DuckDuckGo Instant Answers"
    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val o = getJson(transport, "https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q=${enc(query)}").obj() ?: return@withContext emptyList()
        val out = ArrayList<SearchResult>()
        val abs = o["AbstractText"].str().orEmpty()
        val absUrl = o["AbstractURL"].str().orEmpty()
        if (abs.isNotBlank() && absUrl.isNotBlank()) out += SearchResult(o["Heading"].str() ?: query, absUrl, abs, name)
        fun topics(v: ai.astra.core.json.JsonValue?) {
            v.arr().forEach { t ->
                val to = t.obj() ?: return@forEach
                if (to["Topics"] != null) topics(to["Topics"]) else {
                    val url = to["FirstURL"].str(); val text = to["Text"].str()
                    if (!url.isNullOrBlank() && !text.isNullOrBlank()) out += SearchResult(text.substringBefore(" - ").take(90), url, text, name)
                }
            }
        }
        topics(o["RelatedTopics"])
        out.take(limit)
    }
}

/** Brave Search API (free key available). Full web results. */
class BraveSearch(private val transport: HttpTransport, private val key: () -> String?) : SearchProvider {
    override val id = "brave"
    override val name = "Brave Search"
    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val k = key() ?: throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Brave Search key not set (Requires provider)")
        getJson(transport, "https://api.search.brave.com/res/v1/web/search?count=$limit&q=${enc(query)}", mapOf("X-Subscription-Token" to k))
            .obj()?.get("web").obj()?.get("results").arr().mapNotNull { v ->
                val o = v.obj() ?: return@mapNotNull null
                SearchResult(stripTags(o["title"].str().orEmpty()), o["url"].str() ?: return@mapNotNull null, stripTags(o["description"].str().orEmpty()), name, o["page_age"].str() ?: o["age"].str())
            }
    }
}

/** A SearXNG instance the user runs or trusts (JSON output must be enabled). */
class SearxngSearch(private val transport: HttpTransport, private val baseUrl: () -> String?) : SearchProvider {
    override val id = "searxng"
    override val name = "SearXNG"
    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val base = baseUrl()?.trimEnd('/') ?: throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "SearXNG URL not set (Requires provider)")
        getJson(transport, "$base/search?format=json&q=${enc(query)}").obj()?.get("results").arr().take(limit).mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            SearchResult(o["title"].str().orEmpty(), o["url"].str() ?: return@mapNotNull null, stripTags(o["content"].str().orEmpty()), name, o["publishedDate"].str())
        }
    }
}

/** Tavily search API (key). */
class TavilySearch(private val transport: HttpTransport, private val key: () -> String?) : SearchProvider {
    override val id = "tavily"
    override val name = "Tavily"
    override suspend fun search(query: String, limit: Int): List<SearchResult> = withContext(Dispatchers.IO) {
        val k = key() ?: throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Tavily key not set (Requires provider)")
        val body = Json.write(jsonObj("query" to query, "max_results" to limit))
        val resp = transport.open(HttpRequest("https://api.tavily.com/search", "POST",
            mapOf("User-Agent" to USER_AGENT, "Content-Type" to "application/json", "Authorization" to "Bearer $k"), body, 15_000, 30_000))
        val text = resp.use { it.readText().also { _ -> if (it.status !in 200..299) throw ProviderException(ProviderErrorKind.SERVER, "Tavily HTTP ${it.status}") } }
        Json.parse(text).obj()?.get("results").arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            SearchResult(o["title"].str().orEmpty(), o["url"].str() ?: return@mapNotNull null, o["content"].str().orEmpty(), name, o["published_date"].str())
        }
    }
}

data class WebPage(
    val url: String,
    val finalUrl: String,
    val title: String,
    val text: String,
    val retrievedAt: Long,
    val sha256: String,
    val contentType: String,
    val publishedAt: String? = null,
)

/**
 * Fetches a public web page and extracts readable text. Refuses non-http(s) schemes and private
 * network addresses (so a web page can't make ASTRA probe your LAN), follows at most 5 redirects
 * re-checking each hop, and caps the download size.
 */
class WebFetcher(private val transport: HttpTransport, private val maxBytes: Int = 2_000_000) {

    suspend fun fetch(url: String): WebPage = withContext(Dispatchers.IO) {
        var current = url.trim()
        repeat(6) { hop ->
            val uri = runCatching { URI(current) }.getOrElse { throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Invalid URL: $current") }
            val scheme = uri.scheme?.lowercase()
            if (scheme != "https" && scheme != "http") throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Only http(s) pages can be fetched")
            val host = uri.host ?: throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "URL has no host")
            if (isPrivateHost(host)) throw ProviderException(ProviderErrorKind.NOT_CONFIGURED, "Refusing to fetch a private-network address ($host)")
            if (scheme == "http") current = "https://" + current.substringAfter("://") // upgrade; transport refuses public http anyway
            val resp = transport.open(HttpRequest(current, "GET", mapOf("User-Agent" to USER_AGENT, "Accept" to "text/html,text/plain;q=0.9,*/*;q=0.5"), null, 15_000, 30_000))
            resp.use { r ->
                if (r.status in 300..399) {
                    val loc = r.header("location") ?: throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Redirect without location")
                    current = URI(current).resolve(loc).toString()
                    if (hop == 5) throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Too many redirects")
                    return@use
                }
                if (r.status !in 200..299) throw ProviderException(ProviderErrorKind.SERVER, "HTTP ${r.status} for ${URI(current).host}")
                val type = r.header("content-type")?.substringBefore(';')?.trim()?.lowercase() ?: "text/html"
                if (!(type.startsWith("text/") || type.contains("html") || type.contains("xml") || type.contains("json"))) {
                    throw ProviderException(ProviderErrorKind.UNSUPPORTED, "Can't read $type pages yet")
                }
                val sb = StringBuilder()
                while (sb.length < maxBytes) { sb.append(r.readLine() ?: break).append('\n') }
                val raw = sb.toString()
                val isHtml = type.contains("html") || raw.trimStart().startsWith("<")
                val title = if (isHtml) Regex("(?is)<title[^>]*>(.*?)</title>").find(raw)?.groupValues?.get(1)?.let { stripTags(it) }.orEmpty() else ""
                val published = Regex("(?i)<meta[^>]+(?:article:published_time|datePublished|pubdate)[^>]+content=\"([^\"]+)\"").find(raw)?.groupValues?.get(1)
                val main = if (isHtml) (Regex("(?is)<article[^>]*>(.*?)</article>").find(raw) ?: Regex("(?is)<main[^>]*>(.*?)</main>").find(raw))?.groupValues?.get(1) ?: raw else raw
                val text = if (isHtml) TextExtractors.htmlToText(main.replace(Regex("(?is)<(nav|header|footer|aside|form)[^>]*>.*?</\\1>"), " ")) else raw
                return@withContext WebPage(url, current, title.ifBlank { URI(current).host }, text.take(200_000), System.currentTimeMillis(),
                    Checksums.sha256(ByteArrayInputStream(text.toByteArray())), type, published)
            }
        }
        throw ProviderException(ProviderErrorKind.BAD_RESPONSE, "Too many redirects")
    }
}

/** Local web cache: saved research pages, always labelled as cached (not live). */
interface WebCache {
    suspend fun put(page: WebPage)
    suspend fun get(url: String): WebPage?
    suspend fun all(): List<WebPage>
    suspend fun delete(url: String)
}

class InMemoryWebCache : WebCache {
    private val map = LinkedHashMap<String, WebPage>()
    private val lock = Any()
    override suspend fun put(page: WebPage) { synchronized(lock) { map[page.url] = page } }
    override suspend fun get(url: String) = synchronized(lock) { map[url] }
    override suspend fun all() = synchronized(lock) { map.values.toList() }
    override suspend fun delete(url: String) { synchronized(lock) { map.remove(url) } }
}
