package ai.astra.core

import ai.astra.core.builder.AutomationCodec
import ai.astra.core.builder.AutomationDriver
import ai.astra.core.builder.AutomationRunner
import ai.astra.core.builder.AutomationSpec
import ai.astra.core.builder.AutomationTarget
import ai.astra.core.builder.DriverCommand
import ai.astra.core.builder.DriverResult
import ai.astra.core.builder.FieldMapper
import ai.astra.core.builder.FieldMapping
import ai.astra.core.builder.FieldType
import ai.astra.core.builder.FormField
import ai.astra.core.builder.FormSnapshot
import ai.astra.core.builder.IssueLevel
import ai.astra.core.builder.PreparedRecord
import ai.astra.core.builder.RecordPreparer
import ai.astra.core.builder.RecordStatus
import ai.astra.core.builder.RequirementPlanner
import ai.astra.core.builder.ReviewDecision
import ai.astra.core.builder.RunEvent
import ai.astra.core.builder.RunHost
import ai.astra.core.builder.RunLedger
import ai.astra.core.builder.RunOptions
import ai.astra.core.builder.Step
import ai.astra.core.builder.StepAction
import ai.astra.core.builder.Transform
import ai.astra.core.builder.ValueEngine
import ai.astra.core.data.CsvCodec
import ai.astra.core.data.DataTable
import ai.astra.core.data.InMemoryTableStore
import ai.astra.core.data.TableQueryTool
import ai.astra.core.data.TextTableExtractor
import ai.astra.core.data.XlsxReader
import ai.astra.core.data.XlsxWriter
import ai.astra.core.desk.DeskCrypto
import ai.astra.core.desk.DeskDriver
import ai.astra.core.desk.DeskHub
import ai.astra.core.desk.DeskListener
import ai.astra.core.desk.DeskServer
import ai.astra.core.desk.InMemoryPairedDeviceStore
import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.learn.Example
import ai.astra.core.learn.FeedbackRecord
import ai.astra.core.learn.Rating
import ai.astra.core.learn.Skill
import ai.astra.core.learn.SkillMatcher
import ai.astra.core.learn.TeachParser
import ai.astra.core.learn.TrainingExporter
import ai.astra.core.live.Mood
import ai.astra.core.live.Persona
import ai.astra.core.live.PersonaPrompt
import ai.astra.core.live.SpeechChunker
import ai.astra.core.live.ToneReader
import ai.astra.core.live.VoiceCommands
import ai.astra.core.tools.ToolResult
import java.net.HttpURLConnection
import java.net.URI
import java.security.interfaces.ECPublicKey
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TablesTest {
    @Test fun csvQuotedNewlinesSemicolonsAndTitleRow() {
        val csv = "﻿Member register 2025;;\n;;\nName;Village;Amount\n\"Ram, Lal\";Mandhan;\"12,500\"\n\"Sita\nDevi\";Behror;800\n"
        val t = CsvCodec.parse("m.csv", csv)
        assertEquals(listOf("Name", "Village", "Amount"), t.headers)
        assertEquals(2, t.size)
        assertEquals("Ram, Lal", t.cell(0, "name"))
        assertEquals("Sita\nDevi", t.cell(1, "Name"))
        val back = CsvCodec.parse("x.csv", CsvCodec.write(t))
        assertEquals(t.rows, back.rows)
    }

    @Test fun xlsxRoundTripKeepsEmptyCellsAndDates() {
        val t = DataTable("Loans", listOf("Name", "Aadhaar", "Remarks", "Amount"), listOf(listOf("Ram", "234123412346", "", "5000"), listOf("Sita", "", "new", "7500.5")))
        val bytes = XlsxWriter.write(listOf(t))
        val read = XlsxReader.read("loans.xlsx", bytes).single()
        assertEquals(t.headers, read.headers)
        assertEquals(t.rows, read.rows)
        assertEquals("2025-01-01", XlsxReader.excelDate(45658.0))
        assertEquals(27, XlsxReader.columnIndex("AB"))
    }

    @Test fun pdfOrOcrTextTable() {
        val text = """
            KRISHI SEWA SAHKARI SAMITI - Loan list
            S.No   Member Name     Father Name    Amount
            1      Ramesh Kumar    Mohan Lal      25000
            2      Sita Devi       Hari Ram       18000
            3      Gopal           Bhanwar Lal    9000
            Page 1 of 1
        """.trimIndent()
        val t = TextTableExtractor.extract("p1", text)!!
        assertEquals(listOf("S.No", "Member Name", "Father Name", "Amount"), t.headers)
        assertEquals(3, t.size)
        assertEquals("Sita Devi", t.cell(1, "Member Name"))
        assertTrue(t.confidence > 0.5)
    }

    @Test fun tableQueryToolGivesExactNumbers() = runBlocking {
        val store = InMemoryTableStore().apply { tables["loans"] = DataTable("loans", listOf("Village", "Amount"), listOf(listOf("Mandhan", "1,000"), listOf("Behror", "2500"), listOf("Mandhan", "500"))) }
        val tool = TableQueryTool(store)
        val r = tool.run(jsonObj("op" to "aggregate", "table" to "loans", "column" to "Amount", "fn" to "sum", "groupBy" to "Village")) as ToolResult.Ok
        assertTrue(r.output, r.output.contains("Mandhan: 1500") && r.output.contains("Behror: 2500"))
        val f = tool.run(jsonObj("op" to "filter", "table" to "loans", "column" to "Amount", "op2" to ">", "value" to "800")) as ToolResult.Ok
        assertTrue(f.output.startsWith("2 matching"))
    }
}

class FieldMappingTest {
    private val form = FormSnapshot("https://epacs.example/loan", "Loan entry", listOf(
        FormField("#ctl00_txtMemberName", "Member Name", "txtMemberName", FieldType.TEXT, required = true),
        FormField("#ctl00_txtFatherName", "Father/Husband Name", "txtFatherName"),
        FormField("#ctl00_txtMobile", "Mobile No.", "txtMobile", FieldType.TEXT),
        FormField("#ctl00_ddlGender", "Gender", "ddlGender", FieldType.SELECT, options = listOf("--Select--", "Male", "Female")),
        FormField("#ctl00_txtLoanDate", "Loan Date (dd/mm/yyyy)", "txtLoanDate", FieldType.TEXT, placeholder = "dd/mm/yyyy"),
        FormField("#ctl00_txtAmt", "Loan Amount", "txtAmt", FieldType.NUMBER, required = true),
        FormField("#btnSave", "Save", type = FieldType.BUTTON),
    ))

    @Test fun bilingualColumnsMatchFormFields() {
        val cols = listOf("Naam", "Pita ka naam", "Mobile", "Ling", "Dinank", "Rashi")
        val s = FieldMapper.suggest(cols, form).associate { it.field.label to it.column }
        assertEquals("Naam", s["Member Name"])
        assertEquals("Pita ka naam", s["Father/Husband Name"])
        assertEquals("Mobile", s["Mobile No."])
        assertEquals("Ling", s["Gender"])
        assertEquals("Dinank", s["Loan Date (dd/mm/yyyy)"])
        assertEquals("Rashi", s["Loan Amount"])
    }

    @Test fun valuesAreTransformedAndChecked() {
        assertEquals(LocalDate.of(2025, 3, 7), ValueEngine.parseDate("7/3/2025"))
        assertEquals(LocalDate.of(1995, 3, 7), ValueEngine.parseDate("07-03-95"))
        assertEquals(LocalDate.of(2025, 1, 1), ValueEngine.parseDate("45658"))
        assertEquals("07/03/2025", ValueEngine.apply("2025-03-07", Transform.DATE, "dd/MM/yyyy"))
        assertEquals("9876543210", ValueEngine.apply("98765 43210", Transform.DIGITS))
        assertEquals("Female", ValueEngine.matchOption("F", listOf("--Select--", "Male", "Female")))
        assertEquals("Male", ValueEngine.matchOption("purush", listOf("Male", "Female")))
        assertNull(ValueEngine.matchOption("Other", listOf("Male", "Female")))
        assertEquals("Ram s/o Mohan", ValueEngine.render("{name} s/o {Father}", mapOf("Name" to "Ram", "Father" to "Mohan")))
    }

    @Test fun preparerBlocksBadRecordsAndWarnsOnChecksums() {
        val maps = listOf(
            FieldMapping("#n", "Name", "{Name}", required = true),
            FieldMapping("#a", "Aadhaar", "{Aadhaar}", Transform.DIGITS),
            FieldMapping("#g", "Gender", "{G}", type = FieldType.SELECT, options = listOf("Male", "Female")),
            FieldMapping("#amt", "Amount", "{Amt}", type = FieldType.NUMBER),
        )
        val ok = RecordPreparer.prepare(0, mapOf("Name" to "Ram", "Aadhaar" to "2341 2341 2346", "G" to "m", "Amt" to "5000"), maps)
        assertFalse(ok.issues.toString(), ok.blocked)
        assertEquals("Male", ok.values.first { it.selector == "#g" }.value)
        val bad = RecordPreparer.prepare(1, mapOf("Name" to "", "Aadhaar" to "2341 2341 2347", "G" to "x", "Amt" to "abc"), maps)
        assertTrue(bad.blocked)
        assertTrue(bad.issues.any { it.field == "Name" && it.level == IssueLevel.ERROR })
        assertTrue(bad.issues.any { it.field == "Aadhaar" && it.level == IssueLevel.WARNING })
        assertTrue(bad.issues.any { it.field == "Amount" })
    }
}

class PlannerTest {
    private val table = DataTable("loans", listOf("Member Name", "Amount"), listOf(listOf("Ram", "100")))
    private val form = FormSnapshot("u", "t", listOf(FormField("#name", "Member Name"), FormField("#amt", "Amount", type = FieldType.NUMBER, required = true), FormField("#save", "Save", type = FieldType.BUTTON)))

    @Test fun templatePlanForPortalEntry() {
        val r = RequirementPlanner.draft("Enter these loan records into the e-PACS portal https://epacs.example.in/login and save each one", table, form)
        assertEquals("template", r.origin)
        assertEquals(AutomationTarget.BROWSER, r.spec.target)
        assertEquals(StepAction.OPEN_URL, r.spec.setupSteps.first().action)
        assertTrue(r.spec.setupSteps.any { it.action == StepAction.WAIT_FOR_USER })
        val actions = r.spec.recordSteps.map { it.action }
        assertTrue(actions.indexOf(StepAction.REVIEW) < actions.indexOf(StepAction.SUBMIT))
        assertEquals("#save", r.spec.recordSteps.first { it.action == StepAction.SUBMIT }.target)
        assertEquals(2, r.spec.mappings.size)
        assertTrue(r.questions.any { it.key == "success" })
        assertTrue(r.spec.problems().toString(), r.spec.problems().isEmpty())
    }

    @Test fun modelPlanIsValidatedAndMadeSafe() {
        val model = """Sure! ```json
            {"name":"PACS loans","target":"BROWSER","setup":[{"action":"OPEN_URL","target":"https://x.in"}],
             "record":[{"action":"FILL_FORM"},{"action":"SUBMIT","target":"#save"},{"action":"NEXT_RECORD"}],
             "mappings":[{"selector":"#name","template":"{Member Name}"},{"selector":"#ghost","template":"{Nope}"}],
             "questions":["Is the date field mandatory?"]}``` hope this helps"""
        val r = RequirementPlanner.parse(model, "enter loans", table, form)!!
        assertEquals("model", r.origin)
        val actions = r.spec.recordSteps.map { it.action }
        assertEquals(listOf(StepAction.FILL_FORM, StepAction.REVIEW, StepAction.SUBMIT, StepAction.NEXT_RECORD), actions)
        assertTrue(r.warnings.any { it.contains("review") })
        assertTrue(r.spec.mappings.any { it.selector == "#amt" }) // filled in by the offline matcher
        assertTrue(r.spec.mappings.none { it.selector == "#ghost" })
        assertTrue(r.questions.any { it.question.contains("date field") })
        assertNull(RequirementPlanner.parse("I can't do that", "x", null, null))
        val round = AutomationCodec.decode(AutomationCodec.encode(r.spec))
        assertEquals(r.spec.copy(updatedAt = 0, createdAt = 0), round.copy(updatedAt = 0, createdAt = 0))
    }

    @Test fun phoneRequirementTargetsPhone() {
        val r = RequirementPlanner.draft("every morning open the whatsapp app on my phone and send the report", null, null)
        assertEquals(AutomationTarget.PHONE, r.spec.target)
    }
}

class RunnerTest {
    private class FakeDriver : AutomationDriver {
        override val name = "fake"
        val commands = ArrayList<DriverCommand>()
        var savedOk = true
        override suspend fun ready() = true
        override suspend fun execute(command: DriverCommand): DriverResult {
            commands += command
            return when (command) {
                is DriverCommand.CheckText -> DriverResult(savedOk, if (savedOk) "" else "text not found")
                is DriverCommand.Extract -> DriverResult(true, data = "RCPT-${commands.size}")
                else -> DriverResult(true)
            }
        }
    }

    private class Host(val decisions: ArrayDeque<ReviewDecision>, val answers: ArrayDeque<Boolean> = ArrayDeque()) : RunHost {
        val events = ArrayList<RunEvent>(); var waits = 0; var reviews = 0
        override suspend fun waitForUser(message: String): Boolean { waits++; return answers.removeFirstOrNull() ?: true }
        override suspend fun review(record: PreparedRecord, data: Map<String, String>, position: Int, total: Int): ReviewDecision { reviews++; return decisions.removeFirstOrNull() ?: ReviewDecision.Approve }
        override suspend fun confirmUnreviewedSaves(count: Int) = false
        override fun event(e: RunEvent) { events += e }
    }

    private val table = DataTable("t", listOf("Name", "Amount"), listOf(listOf("Ram", "100"), listOf("", "200"), listOf("Gita", "300"), listOf("Hari", "400")))
    private fun spec(opts: RunOptions = RunOptions(stepDelayMs = 0)) = AutomationSpec(
        name = "x", goal = "g", target = AutomationTarget.BROWSER,
        setupSteps = listOf(Step(StepAction.OPEN_URL, "https://portal.example"), Step(StepAction.WAIT_FOR_USER, value = "Log in")),
        recordSteps = listOf(Step(StepAction.FILL_FORM), Step(StepAction.REVIEW), Step(StepAction.SUBMIT, "#save"), Step(StepAction.CHECK_TEXT, "saved"), Step(StepAction.EXTRACT, "#rcpt", "Receipt"), Step(StepAction.NEXT_RECORD)),
        mappings = listOf(FieldMapping("#n", "Name", "{Name}", required = true), FieldMapping("#a", "Amount", "{Amount}", type = FieldType.NUMBER)),
        options = opts,
    )

    @Test fun humanInTheLoopRunWithSkipBlockAndResume() = runBlocking {
        val driver = FakeDriver()
        val host = Host(ArrayDeque(listOf(ReviewDecision.Approve, ReviewDecision.Skip, ReviewDecision.Stop)))
        val runner = AutomationRunner(spec(), table, driver, host, sleep = {})
        val s = runner.run()
        assertEquals(1, s.done); assertEquals(1, s.skipped); assertEquals(1, s.blocked)
        assertEquals("Stopped at review", s.stoppedReason)
        assertEquals(1, host.waits) // login
        assertEquals(1, driver.commands.count { it is DriverCommand.Click }) // saved only the approved record
        assertEquals("RCPT-5", runner.ledger.get(0).extracted["Receipt"])
        assertEquals(RecordStatus.BLOCKED, runner.ledger.get(1).status)
        assertEquals(RecordStatus.PENDING, runner.ledger.get(3).status)
        // Resume from the saved ledger: only record 4 is left.
        val restored = RunLedger.decode(Json.write(runner.ledger.toJson()))
        val driver2 = FakeDriver()
        val s2 = AutomationRunner(spec(), table, driver2, Host(ArrayDeque()), restored, sleep = {}).run()
        assertEquals(2, s2.done)
        assertEquals(1, driver2.commands.count { it is DriverCommand.Click })
        val report = restored.report(table)
        assertEquals(listOf("Name", "Amount", "ASTRA status", "ASTRA message", "Receipt"), report.headers)
    }

    @Test fun dryRunNeverClicksSaveAndFailuresPause() = runBlocking {
        val driver = FakeDriver()
        val host = Host(ArrayDeque())
        AutomationRunner(spec(RunOptions(dryRun = true, stepDelayMs = 0)), table, driver, host, sleep = {}).run()
        assertEquals(0, driver.commands.count { it is DriverCommand.Click })
        assertTrue(host.waits >= 4) // login + manual save per filled record

        val failing = FakeDriver().apply { savedOk = false }
        val t = DataTable("t", listOf("Name", "Amount"), (1..6).map { listOf("N$it", "$it") })
        val h2 = Host(ArrayDeque(), ArrayDeque(listOf(true, false)))
        val s = AutomationRunner(spec(RunOptions(stopAfterFailures = 3, stepDelayMs = 0)), t, failing, h2, sleep = {}).run()
        assertEquals(3, s.failed)
        assertEquals("Paused after repeated failures", s.stoppedReason)
    }

    @Test fun reviewOffRequiresExplicitBatchConsent() = runBlocking {
        val driver = FakeDriver()
        val s = AutomationRunner(spec(RunOptions(reviewEachRecord = false, stepDelayMs = 0)), table, driver, Host(ArrayDeque()), sleep = {}).run()
        assertEquals("You chose not to save without review", s.stoppedReason)
        assertTrue(driver.commands.isEmpty())
    }
}

class DeskTest {
    @Test fun ecdhPairingGivesSameKeyAndCode() {
        val phone = DeskCrypto.newKeyPair(); val ext = DeskCrypto.newKeyPair()
        val pRaw = DeskCrypto.rawPublic(phone.public as ECPublicKey); val eRaw = DeskCrypto.rawPublic(ext.public as ECPublicKey)
        val params = (phone.public as ECPublicKey).params
        val a = DeskCrypto.derive(DeskCrypto.sharedSecret(phone.private, DeskCrypto.publicFromRaw(eRaw, params)), pRaw, eRaw)
        val b = DeskCrypto.derive(DeskCrypto.sharedSecret(ext.private, DeskCrypto.publicFromRaw(pRaw, params)), pRaw, eRaw)
        assertTrue(a.key.contentEquals(b.key)); assertEquals(a.code, b.code); assertEquals(6, a.code.length)
        val box = DeskCrypto.seal(a.key, "hello".toByteArray(), "aad".toByteArray())
        assertEquals("hello", String(DeskCrypto.open(b.key, box, "aad".toByteArray())))
        assertTrue(runCatching { DeskCrypto.open(b.key, box, "other".toByteArray()) }.isFailure)
        val offCurve = eRaw.copyOf().also { it[64] = (it[64] + 1).toByte() }
        assertTrue(runCatching { DeskCrypto.publicFromRaw(offCurve, params) }.isFailure)
    }

    @Test fun hkdfMatchesRfc5869TestCase1() {
        fun hex(s: String) = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val okm = DeskCrypto.hkdf(hex("0b".repeat(22)), hex("000102030405060708090a0b0c"), hex("f0f1f2f3f4f5f6f7f8f9"), 42)
        assertEquals("3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865", okm.joinToString("") { "%02x".format(it) })
    }

    /** Full LAN round trip over real sockets: pair, confirm, poll, command, result, chat, replay rejection. */
    @Test fun endToEndOverHttp() = runBlocking {
        val store = InMemoryPairedDeviceStore()
        var shownCode = ""; var chat = ""
        val hub = DeskHub(store, object : DeskListener {
            override fun onPairingRequest(sessionId: String, computerName: String, code: String) { shownCode = code }
            override fun onChat(deviceId: String, chatId: String, text: String) { chat = text }
        })
        val port = 18000 + (Math.random() * 2000).toInt()
        val server = DeskServer(hub, port).apply { start() }
        try {
            fun post(path: String, body: String): Pair<Int, String> {
                val c = URI("http://127.0.0.1:$port$path").toURL().openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                return code to text
            }
            // Extension side
            val ext = DeskCrypto.newKeyPair()
            val eRaw = DeskCrypto.rawPublic(ext.public as ECPublicKey)
            val hello = Json.parse(post("/desk/hello", Json.write(jsonObj("pub" to DeskCrypto.b64(eRaw), "name" to "Test PC"))).second).obj()!!
            val pRaw = DeskCrypto.unb64(hello["pub"].str()!!)
            val session = hello["session"].str()!!
            val derived = DeskCrypto.derive(DeskCrypto.sharedSecret(ext.private, DeskCrypto.publicFromRaw(pRaw, (ext.public as ECPublicKey).params)), pRaw, eRaw)
            assertEquals(shownCode, derived.code)
            assertTrue(post("/desk/status", """{"session":"$session"}""").second.contains("waiting"))
            assertTrue(hub.confirmPairing(session))
            assertTrue(post("/desk/status", """{"session":"$session"}""").second.contains("confirmed"))

            var lastBox = ""
            fun rpc(msg: Map<String, Any?>): ai.astra.core.json.JsonValue.Obj {
                val sealed = DeskCrypto.seal(derived.key, Json.write(jsonObj(*(msg + ("ts" to System.currentTimeMillis())).toList().toTypedArray())).toByteArray(), "req:$session".toByteArray())
                lastBox = DeskCrypto.b64(sealed)
                val (code, text) = post("/desk/rpc", Json.write(jsonObj("id" to session, "box" to lastBox)))
                assertEquals(text, 200, code)
                val nonce = DeskCrypto.b64(sealed.copyOfRange(0, 12))
                return Json.parse(String(DeskCrypto.open(derived.key, DeskCrypto.unb64(Json.parse(text).obj()!!["box"].str()!!), "resp:$nonce".toByteArray()))).obj()!!
            }
            assertEquals(0, rpc(mapOf("type" to "poll", "wait" to 0)).get("messages").arr().size)
            assertTrue(hub.isConnected())
            // Replaying the exact same box is refused.
            assertEquals(409, post("/desk/rpc", Json.write(jsonObj("id" to session, "box" to lastBox))).first)

            val driver = DeskDriver(hub)
            val pending = async(Dispatchers.Default) { driver.execute(DriverCommand.Click("#btnSave")) }
            var cmd: ai.astra.core.json.JsonValue.Obj? = null
            for (i in 0 until 20) { cmd = rpc(mapOf("type" to "poll", "wait" to 500)).get("messages").arr().firstOrNull()?.obj(); if (cmd != null) break }
            assertNotNull(cmd)
            assertEquals("click", cmd!!["op"].str())
            assertEquals("#btnSave", cmd["target"].str())
            rpc(mapOf("type" to "result", "cmd" to cmd["cmd"].str(), "ok" to true, "message" to "clicked"))
            val result = pending.await()
            assertTrue(result.ok); assertEquals("clicked", result.message)

            rpc(mapOf("type" to "chat", "text" to "namaste astra"))
            assertEquals("namaste astra", chat)

            // A stranger without the key gets nothing.
            val wrongKey = DeskCrypto.seal(ByteArray(32), """{"type":"poll","ts":${System.currentTimeMillis()}}""".toByteArray(), "req:$session".toByteArray())
            assertEquals(403, post("/desk/rpc", Json.write(jsonObj("id" to session, "box" to DeskCrypto.b64(wrongKey)))).first)
        } finally {
            server.stop()
        }
    }
}

class LearnAndLiveTest {
    @Test fun teachCommandsInThreeLanguages() {
        val a = TeachParser.parse("/teach PACS entry: open the loan form, fill member details and wait for my OK before saving")!!
        assertEquals("PACS entry", a.name)
        val b = TeachParser.parse("When I say daily report, summarise today's tasks in 5 bullets")!!
        assertEquals(listOf("daily report"), b.triggers)
        val c = TeachParser.parse("jab main hisaab bolun to aaj ke kharche ka total batao")!!
        assertEquals(listOf("hisaab"), c.triggers)
        val d = TeachParser.parse("जब मैं रिपोर्ट कहूं तो आज का सारांश बताओ")!!
        assertEquals(listOf("रिपोर्ट"), d.triggers)
        assertNull(TeachParser.parse("what is the weather"))
    }

    @Test fun skillsMatchAndTrainingExportRedacts() {
        val skills = listOf(
            Skill(name = "Daily report", triggers = listOf("daily report"), instructions = "Summarise tasks in 5 bullets", examples = listOf(Example("daily report", "• Task A done"))),
            Skill(name = "Loan letter", triggers = listOf("loan letter"), instructions = "Write a formal Hindi loan sanction letter for the cooperative society"),
        )
        assertEquals("Daily report", SkillMatcher.match("astra, daily report please", skills).first().name)
        assertEquals("Loan letter", SkillMatcher.match("draft a formal sanction letter for this loan", skills).firstOrNull()?.name)
        assertTrue(SkillMatcher.match("what's the capital of France", skills).isEmpty())
        val ex = TrainingExporter.export(listOf(
            FeedbackRecord(prompt = "my aadhaar is 2341 2341 2346, fill the form", answer = "ok", rating = Rating.GOOD),
            FeedbackRecord(prompt = "translate hello", answer = "हेलो", rating = Rating.CORRECTED, correction = "नमस्ते"),
            FeedbackRecord(prompt = "x", answer = "bad", rating = Rating.BAD),
        ), skills, "You are ASTRA.")
        assertEquals(3, ex.examples) // good + correction + skill example
        assertFalse(ex.jsonl.contains("2341 2341 2346"))
        assertTrue(ex.redactions >= 1)
        assertTrue(ex.jsonl.contains("नमस्ते"))
        ex.jsonl.trim().lines().forEach { l -> assertEquals(3, Json.parse(l).obj()!!["messages"].arr().size) }
    }

    @Test fun toneReading() {
        assertEquals(Mood.STRESSED, ToneReader.read("I'm so stressed, deadline is tomorrow").mood)
        assertEquals(Mood.FRUSTRATED, ToneReader.read("this is not working AGAIN, bekaar").mood)
        assertEquals(Mood.GRATEFUL, ToneReader.read("dhanyavaad astra 🙏").mood)
        assertEquals(Mood.CONFUSED, ToneReader.read("samajh nahi aaya, kaise karu??").mood)
        assertEquals(Mood.NEUTRAL, ToneReader.read("list the files in my folder").mood)
    }

    @Test fun personaPromptIsHonestAndVoiceFriendly() {
        val p = PersonaPrompt.build(Persona(addressAs = "Deepak"), ToneReader.read("very stressed and worried"), voice = true)
        assertTrue(p.contains("Deepak"))
        assertTrue(p.contains("do not claim to have human feelings"))
        assertTrue(p.contains("stressed"))
        assertTrue(p.contains("no markdown"))
    }

    @Test fun speechChunkerSpeaksSentencesEarlyAndSkipsCode() {
        val c = SpeechChunker()
        val out = ArrayList<String>()
        listOf("**Namaste!** Aaj ", "Dr. Sharma ka appointment 10.30 baje hai. ", "Code:\n```kotlin\nval x = 1\n```\n", "- Done", " ✓").forEach { out += c.accept(it) }
        out += c.finish()
        assertEquals("Namaste!", out[0])
        assertEquals("Aaj Dr. Sharma ka appointment 10.30 baje hai.", out[1])
        assertTrue(out.contains("I've put the code on screen."))
        assertFalse(out.any { it.contains("val x") })
        assertEquals("Done ✓", out.last())
        assertEquals(VoiceCommands.Command.STOP, VoiceCommands.parse("ruko"))
        assertEquals(VoiceCommands.Command.REPEAT, VoiceCommands.parse("phir se bolo"))
        assertNull(VoiceCommands.parse("stop the car near the shop"))
    }
}
