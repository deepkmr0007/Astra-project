package ai.astra.core

import ai.astra.core.model.Locality
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.Availability
import ai.astra.core.provider.Capability
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.GenerationStats
import ai.astra.core.provider.HttpRequest
import ai.astra.core.provider.HttpResponse
import ai.astra.core.provider.HttpTransport
import ai.astra.core.provider.ModelCapabilities
import ai.astra.core.provider.ProviderErrorKind
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.ProviderInfo
import ai.astra.core.provider.StreamEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.ByteArrayInputStream

/**
 * Test-only provider that replays scripted replies. It exists so engine logic can be tested
 * deterministically; it is never registered in the app.
 */
class ScriptedProvider(
    id: String,
    locality: Locality,
    private val replies: MutableList<String> = mutableListOf("ok"),
    scores: ModelCapabilities = ModelCapabilities(),
    vision: Boolean = false,
    var available: Availability = Availability.Ready,
    var failWith: ProviderException? = null,
) : AiProvider {
    val requests = ArrayList<GenerationRequest>()

    override val info = ProviderInfo(
        id, "Test $id", "test-model-$id", locality,
        buildSet { add(Capability.CHAT); add(Capability.STREAM); if (vision) add(Capability.VISION) },
        scores, "test",
    )

    override suspend fun availability() = available

    override fun stream(request: GenerationRequest): Flow<StreamEvent> = flow {
        requests += request
        failWith?.let { throw it }
        val reply = if (replies.size > 1) replies.removeAt(0) else replies.firstOrNull() ?: ""
        reply.chunked(4).forEach { emit(StreamEvent.Token(it)) }
        emit(StreamEvent.Done(GenerationStats(reply.length / 4 + 1, 10, 1, if (info.locality.usesNetwork) 100 else 0, 0)))
    }
}

/** Records every request and replays a canned response body. */
class FakeTransport(var status: Int = 200, var body: String = "", var headers: Map<String, String> = emptyMap()) : HttpTransport {
    val requests = ArrayList<HttpRequest>()
    override fun open(request: HttpRequest): HttpResponse {
        requests += request
        return HttpResponse(status, headers, ByteArrayInputStream(body.toByteArray()))
    }
}

fun networkDown() = ProviderException(ProviderErrorKind.NETWORK, "Cannot resolve host (offline?)")
