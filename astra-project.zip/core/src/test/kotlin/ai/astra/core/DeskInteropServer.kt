package ai.astra.core

import ai.astra.core.builder.DriverCommand
import ai.astra.core.desk.DeskDriver
import ai.astra.core.desk.DeskHub
import ai.astra.core.desk.DeskListener
import ai.astra.core.desk.DeskServer
import ai.astra.core.desk.InMemoryPairedDeviceStore
import ai.astra.core.json.jsonObj
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

/**
 * Interop harness for desk-extension/test/interop.mjs (run by desk-extension/test/run-interop.sh):
 * a real phone-side server that auto-confirms pairing, answers chat, and sends a scan command
 * to the JavaScript client once it connects.
 */
object DeskInteropServer {
    @JvmStatic fun main(args: Array<String>) = runBlocking {
        val port = args.firstOrNull()?.toInt() ?: 18765
        lateinit var hub: DeskHub
        hub = DeskHub(InMemoryPairedDeviceStore(), object : DeskListener {
            override fun onPairingRequest(sessionId: String, computerName: String, code: String) {
                println("KOTLIN_CODE=$code NAME=$computerName")
                Thread { Thread.sleep(300); hub.confirmPairing(sessionId) }.start()
            }
            override fun onChat(deviceId: String, chatId: String, text: String) {
                hub.push(jsonObj("type" to "chat_done", "chatId" to chatId, "text" to "echo: $text"), deviceId)
            }
        })
        val server = DeskServer(hub, port).apply { start() }
        println("READY")
        while (!hub.isConnected()) delay(100)
        val r = DeskDriver(hub).execute(DriverCommand.Scan)
        println("SCAN_OK=${r.ok} FIELDS=${r.snapshot?.fields?.size} TITLE=${r.snapshot?.title}")
        val answer = hub.ask("review", "Record 1 of 1", "Approve?", listOf("approve", "skip", "stop"))
        println("ANSWER=$answer")
        delay(1500)
        server.stop()
    }
}
