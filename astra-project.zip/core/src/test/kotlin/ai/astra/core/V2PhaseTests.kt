package ai.astra.core

import ai.astra.core.agent.AgentRole
import ai.astra.core.agent.TeamRunner
import ai.astra.core.agent.TeamWorkflows
import ai.astra.core.audio.Wav
import ai.astra.core.automation.Briefing
import ai.astra.core.automation.FeedParser
import ai.astra.core.chat.ChatEngine
import ai.astra.core.chat.ChatEvent
import ai.astra.core.chat.ChatRequest
import ai.astra.core.chat.ConsentAnswer
import ai.astra.core.chat.ConsentGate
import ai.astra.core.chat.EngineSettings
import ai.astra.core.chat.InMemoryConversationRepository
import ai.astra.core.code.CodeBlocks
import ai.astra.core.code.DiffOp
import ai.astra.core.code.LineDiff
import ai.astra.core.code.SyntaxTokens
import ai.astra.core.device.DeviceState
import ai.astra.core.diagnostics.Diagnostics
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.documents.InMemoryDocumentStore
import ai.astra.core.export.Exporter
import ai.astra.core.json.JsonValue
import ai.astra.core.json.jsonObj
import ai.astra.core.knowledge.EntityType
import ai.astra.core.knowledge.KnowledgeGraph
import ai.astra.core.knowledge.KnowledgeGraphBuilder
import ai.astra.core.knowledge.RelationType
import ai.astra.core.memory.HashingEmbedder
import ai.astra.core.memory.InMemoryMemoryStore
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.RememberResult
import ai.astra.core.model.ContentSource
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Project
import ai.astra.core.model.Role
import ai.astra.core.plugins.HttpPluginTool
import ai.astra.core.plugins.PluginManifest
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.HttpRequest
import ai.astra.core.provider.HttpResponse
import ai.astra.core.provider.HttpTransport
import ai.astra.core.provider.ModelCapabilities
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.PromptTurn
import ai.astra.core.router.DataControl
import ai.astra.core.router.ModelRouter
import ai.astra.core.router.RouterPolicy
import ai.astra.core.security.ConfirmationGate
import ai.astra.core.security.InMemoryPermissionCenter
import ai.astra.core.security.RingAuditLog
import ai.astra.core.security.ToolFirewall
import ai.astra.core.sync.BadPassphraseException
import ai.astra.core.sync.EncryptedBundle
import ai.astra.core.sync.LwwMerge
import ai.astra.core.tasks.TaskItem
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.defaultTools
import ai.astra.core.web.InMemoryWebCache
import ai.astra.core.web.ResearchPipeline
import ai.astra.core.web.SearchProvider
import ai.astra.core.web.SearchResult
import ai.astra.core.web.SourceTrust
import ai.astra.core.web.WebFetcher
import ai.astra.core.web.WikipediaSearch
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.file.Files
import kotlin.random.Random

/** Routes requests to canned responses by URL substring. */
class RoutingTransport(private val routes: List<Pair<String, Triple<Int, Map<String, String>, String>>>) : HttpTransport {
    val requests = ArrayList<HttpRequest>()
    override fun open(request: HttpRequest): HttpResponse {
        requests += request
        val (_, r) = routes.firstOrNull { request.url.contains(it.first) } ?: ("" to Triple(404, emptyMap(), "not found"))
        return HttpResponse(r.first, r.second, ByteArrayInputStream(r.third.toByteArray()))
    }
}

private fun ok(body: String, type: String = "text/html") = Triple(200, mapOf("Content-Type" to type), body)

class WebTest {
    @Test fun wikipediaSearchParses() = runBlocking {
        val t = RoutingTransport(listOf("wikipedia.org/w/api.php" to ok("""{"query":{"search":[{"title":"Green Highways Policy","snippet":"The <span>policy</span> of 2015","timestamp":"2025-01-02T00:00:00Z"}]}}""", "application/json")))
        val r = WikipediaSearch(t).search("green highways policy", 3).single()
        assertEquals("https://en.wikipedia.org/wiki/Green_Highways_Policy", r.url)
        assertEquals("The policy of 2015", r.snippet)
        assertTrue(t.requests.single().headers["User-Agent"]!!.startsWith("ASTRA"))
        val hi = RoutingTransport(listOf("hi.wikipedia.org" to ok("""{"query":{"search":[]}}""", "application/json")))
        WikipediaSearch(hi).search("हरित राजमार्ग", 3)
        assertTrue(hi.requests.single().url.startsWith("https://hi.wikipedia.org"))
    }

    @Test fun fetcherFollowsRedirectsExtractsAndRefusesPrivate() = runBlocking {
        val t = RoutingTransport(listOf(
            "a.example/old" to Triple(301, mapOf("Location" to "/new"), ""),
            "a.example/new" to ok("<html><head><title>Saplings &amp; Survival</title></head><body><nav>menu</nav><article><p>Survival was 82%.</p></article></body></html>"),
        ))
        val p = WebFetcher(t).fetch("https://a.example/old")
        assertEquals("https://a.example/new", p.finalUrl)
        assertEquals("Saplings & Survival", p.title)
        assertTrue(p.text.contains("Survival was 82%"))
        assertFalse(p.text.contains("menu"))
        for (bad in listOf("http://192.168.1.1/admin", "file:///etc/passwd", "https://localhost/x")) {
            try { WebFetcher(t).fetch(bad); fail(bad) } catch (_: ProviderException) {}
        }
    }

    @Test fun sourceTrustScoresAndFindsConflicts() {
        assertTrue(SourceTrust.authority("morth.nic.in") > SourceTrust.authority("en.wikipedia.org"))
        assertTrue(SourceTrust.authority("en.wikipedia.org") > SourceTrust.authority("someblog.blogspot.com"))
        val q = "sapling survival rate highway"
        val pages = listOf(
            SearchResult("Gov report", "https://morth.nic.in/r", "", "x", "2026-09-01") to null,
            SearchResult("Blog", "https://x.blogspot.com/p", "", "x") to null,
        ).mapIndexed { i, (r, _) -> r.copy(snippet = if (i == 0) "Highway sapling survival rate was 82 percent in 2025." else "Highway sapling survival rate was 64 percent in 2025.") to null }
        val (sources, conflicts) = SourceTrust.assess(q, pages)
        assertTrue(sources[0].trust > sources[1].trust)
        assertEquals("%", conflicts.single().topic)
    }

    private class FakeSearch(val results: List<SearchResult>) : SearchProvider {
        override val id = "fake"; override val name = "Fake"
        override suspend fun search(query: String, limit: Int) = results
    }

    @Test fun pipelineCitesOnlyRealSourcesAndCaches() = runBlocking {
        val t = RoutingTransport(listOf(
            "one.gov.in" to ok("<title>One</title><p>The national target for sapling survival is 90 percent.</p>"),
            "two.org" to ok("<title>Two</title><p>Survival audits are done every quarter by the authority.</p>"),
        ))
        val cache = InMemoryWebCache()
        val pipe = ResearchPipeline(FakeSearch(listOf(SearchResult("One", "https://one.gov.in/a", "s", "Fake"), SearchResult("Two", "https://two.org/b", "s", "Fake"))), WebFetcher(t), cache)
        val model = ScriptedProvider("m", Locality.ON_DEVICE, mutableListOf("Target is 90% [1]; audits quarterly [2]; also [7]."))
        val shown = StringBuilder()
        val report = pipe.run("What is the sapling survival target?", model, { _, _ -> }, { shown.append(it) })
        assertEquals("Target is 90% [1]; audits quarterly [2]; also .", report.answer)
        assertEquals(2, cache.all().size)
        assertTrue(report.sourcesMarkdown().contains("[1] One — one.gov.in · trust"))
        val prompt = (model.requests.single().turns.last().parts.single() as Part.Text).text
        assertTrue(prompt.contains("<<UNTRUSTED source=\"web\""))
        // No model → extractive passages, nothing invented.
        val noModel = pipe.run("What is the sapling survival target?", null, { _, _ -> }, {})
        assertTrue(noModel.answer.contains("most relevant passages") && noModel.answer.contains("90 percent"))
    }

    @Test fun engineResearchIsHybridAndRespectsPrivateMode() {
        val mem = MemoryEngine(InMemoryMemoryStore(), HashingEmbedder())
        val docs = DocumentIndex(InMemoryDocumentStore(), HashingEmbedder())
        val t = RoutingTransport(listOf("one.gov.in" to ok("<p>Target sapling survival is 90 percent.</p>")))
        val pipe = ResearchPipeline(FakeSearch(listOf(SearchResult("One", "https://one.gov.in/a", "s", "Fake"))), WebFetcher(t), null)
        val local = ScriptedProvider("local", Locality.ON_DEVICE, mutableListOf("It is 90% [1]."))
        var policy = RouterPolicy()
        val asked = ArrayList<String>()
        val engine = ChatEngine(InMemoryConversationRepository(), { listOf(local) }, ModelRouter(), mem, docs, defaultTools(mem, docs) { null },
            ai.astra.core.agent.AgentRunner(defaultTools(mem, docs) { null }, ToolFirewall(InMemoryPermissionCenter(), ConfirmationGate { true }, RingAuditLog())),
            ConsentGate { asked += it.provider.id; ConsentAnswer.ALLOW_ONCE }, { DeviceState(online = true) }, { EngineSettings(routerPolicy = policy) }, Diagnostics(),
            research = { pipe })
        val ev = runBlocking { engine.research("c", "sapling survival target").toList() }
        val msg = ev.filterIsInstance<ChatEvent.Completed>().single().message
        assertEquals(ExecutionMode.HYBRID, msg.trace!!.mode)
        assertTrue(msg.text.contains("**Sources**") && msg.text.contains("one.gov.in"))
        assertTrue(asked.isEmpty()) // non-sensitive question, default policy: no prompt needed
        policy = RouterPolicy(dataControl = DataControl.NEVER_SEND)
        val before = t.requests.size
        val blocked = runBlocking { engine.research("c", "sapling survival target").toList() }
        assertTrue(blocked.last() is ChatEvent.Failed)
        assertEquals(before, t.requests.size)
        policy = RouterPolicy(dataControl = DataControl.ASK_BEFORE_SENDING)
        runBlocking { engine.research("c2", "anything").toList() }
        assertEquals(listOf("web:search"), asked)
    }
}

class CodeTest {
    @Test fun diffRoundTripsRandomEdits() {
        val rnd = Random(7)
        repeat(200) {
            val a = List(rnd.nextInt(0, 30)) { "line ${rnd.nextInt(0, 12)}" }
            val b = a.toMutableList().apply {
                repeat(rnd.nextInt(0, 8)) {
                    when (rnd.nextInt(3)) {
                        0 -> if (isNotEmpty()) removeAt(rnd.nextInt(size))
                        1 -> add(rnd.nextInt(size + 1), "new ${rnd.nextInt(100)}")
                        else -> if (isNotEmpty()) set(rnd.nextInt(size), "chg ${rnd.nextInt(100)}")
                    }
                }
            }
            val d = LineDiff.diff(a, b)
            assertEquals(b.joinToString("\n"), LineDiff.applyTo(d))
            assertEquals(a, d.filter { it.op != DiffOp.ADD }.map { it.text })
        }
    }

    @Test fun unifiedHunksAndCodeBlocks() {
        val old = (1..20).joinToString("\n") { "l$it" }
        val new = old.replace("l10", "L10")
        val u = LineDiff.unified("a.kt", "a.kt", old, new)
        assertTrue(u.contains("@@ -7,7 +7,7 @@") && u.contains("-l10") && u.contains("+L10"))
        assertEquals(1 to 1, LineDiff.stats(LineDiff.diff(old, new)))
        val b = CodeBlocks.main("Here:\n```kotlin\nfun a() = 1\n```\nand ```\nx\n```")!!
        assertEquals("kotlin", b.language); assertEquals("fun a() = 1", b.code)
        assertTrue(SyntaxTokens.spans("val x = \"s\" // c", "kotlin").map { it.kind }.containsAll(listOf(SyntaxTokens.Kind.KEYWORD, SyntaxTokens.Kind.STRING, SyntaxTokens.Kind.COMMENT)))
    }
}

class TeamTest {
    @Test fun workflowRunsStagesAndReportsVerification() = runBlocking {
        val p = ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf("facts", "analysis", "no problems", "FINAL ANSWER", "ISSUES\n- number 3 unsupported"))
        val base = listOf(PromptTurn(Role.SYSTEM, listOf(Part.Text("sys")), setOf(ContentSource.SYSTEM)), PromptTurn(Role.USER, listOf(Part.Text("Plan plantation audit")), setOf(ContentSource.USER)))
        val shown = StringBuilder()
        val stages = ArrayList<AgentRole>()
        val out = TeamRunner().run(p, TeamWorkflows.RESEARCH, base, GenerationRequest(base), { stages += it }, { shown.append(it) }, {})
        assertEquals(TeamWorkflows.RESEARCH.stages, stages)
        assertEquals("FINAL ANSWER", out.finalText)
        assertEquals(false, out.verified)
        assertTrue(out.issues!!.contains("unsupported"))
        assertTrue(shown.startsWith("FINAL ANSWER"))
        // Writer stage saw the Critic's notes.
        assertTrue((p.requests[3].turns.last().parts.single() as Part.Text).text.contains("### Critic\nno problems"))
        assertEquals(TeamWorkflows.CODE, TeamWorkflows.guess("fix this kotlin function"))
    }
}

class AutomationSyncTest {
    @Test fun parsesRssAndAtom() {
        val rss = """<rss><channel><title>PIB</title><item><title><![CDATA[Highway &amp; plantation drive]]></title><link>https://pib.gov.in/1</link>
            <description>New saplings</description><pubDate>Fri, 09 Oct 2026 08:00:00 +0530</pubDate></item>
            <item><title>Older</title><link>https://pib.gov.in/0</link><pubDate>Mon, 05 Oct 2026 08:00:00 +0530</pubDate></item></channel></rss>"""
        val items = FeedParser.parse(rss)
        assertEquals("Highway & plantation drive", items[0].title)
        assertEquals("PIB", items[0].feed)
        val atom = """<feed><title>Blog</title><entry><title>Post</title><link href="https://b/1"/><updated>2026-10-10T05:00:00Z</updated><summary>S</summary></entry></feed>"""
        val all = items + FeedParser.parse(atom)
        val picked = Briefing.select(all, 2)
        assertEquals(listOf("Post", "Highway & plantation drive"), picked.map { it.title })
        assertTrue(Briefing.prompt(picked).contains("[Blog] Post"))
    }

    @Test fun encryptedBundleRoundTripAndWrongPassword() {
        val data = "{\"format\":\"astra-export\"} नमस्ते".toByteArray()
        val enc = EncryptedBundle.encrypt(data, "correct horse".toCharArray(), iterations = 20_000)
        assertTrue(EncryptedBundle.isEncrypted(enc))
        assertFalse(String(enc).contains("astra-export"))
        assertArrayEquals(data, EncryptedBundle.decrypt(enc, "correct horse".toCharArray()))
        try { EncryptedBundle.decrypt(enc, "wrong horse".toCharArray()); fail() } catch (_: BadPassphraseException) {}
    }

    @Test fun lwwMergeAndBundleRestore() = runBlocking {
        data class R(val id: String, val v: Long, val text: String)
        val m = LwwMerge.merge(listOf(R("a", 1, "x"), R("b", 5, "y")), listOf(R("a", 2, "x2"), R("b", 3, "old"), R("c", 1, "z")), { it.id }, { it.v }, { x, y -> x.text == y.text })
        assertEquals(setOf("a", "c"), m.toUpsert.map { it.id }.toSet())
        assertEquals(2, m.conflicts.size)
        assertEquals("y", m.conflicts.first { it.local.id == "b" }.kept.text)

        val mem = MemoryEngine(InMemoryMemoryStore(), HashingEmbedder())
        val stored = (mem.remember("My village is Mandhan", MemorySource.USER_EXPLICIT) as RememberResult.Stored).record
        val conv = Conversation("c1", "Chat", projectId = "p1")
        val msgs = listOf(ai.astra.core.model.ChatMessage("m1", "c1", Role.USER, listOf(Part.Text("hello")), 10))
        val json = Exporter.bundle(listOf(conv to msgs), listOf(stored), listOf(Project("p1", "Swarlipi")), listOf(TaskItem(title = "Compose", projectId = "p1")), emptyMap())
        val parsed = Exporter.parseBundle(json)
        assertEquals("Swarlipi", parsed.projects.single().name)
        assertEquals("hello", parsed.conversations.single().messages.single().text)
        assertEquals(stored.id, parsed.memories.single().id)
        assertEquals("Compose", parsed.tasks.single().title)
    }

    @Test fun wavSplitKeepsAllAudio() {
        val dir = Files.createTempDirectory("wav").toFile()
        val pcm = ByteArray(16000 * 2 * 65) { (it % 251).toByte() } // 65 s mono 16-bit
        val f = File(dir, "rec.wav").apply { outputStream().use { it.write(Wav.header(16000, 1, 16, pcm.size.toLong())); it.write(pcm) } }
        val info = Wav.read(f)!!
        assertEquals(65.0, info.durationSeconds, 0.01)
        val parts = Wav.split(f, 30, File(dir, "parts"))
        assertEquals(3, parts.size)
        assertEquals(pcm.size.toLong(), parts.sumOf { Wav.read(it)!!.dataSize })
    }
}

class KnowledgeAndPluginTest {
    @Test fun graphLinksPeoplePlacesProjects() = runBlocking {
        val mem = MemoryEngine(InMemoryMemoryStore(), HashingEmbedder())
        mem.remember("My friend Ramesh lives in Mandhan and works at NHAI Regional Office", MemorySource.USER_EXPLICIT)
        mem.remember("Swarlipi needs a tabla rhythm engine", MemorySource.USER_EXPLICIT, projectId = "p1")
        val g = KnowledgeGraphBuilder.build(mem.list(), listOf(Project("p1", "Swarlipi")), listOf(TaskItem(title = "Tabla engine", projectId = "p1")), emptyList())
        assertEquals(EntityType.PERSON, g.entities[KnowledgeGraph.key("Ramesh")]!!.type)
        assertEquals(EntityType.PLACE, g.entities[KnowledgeGraph.key("Mandhan")]!!.type)
        assertTrue(g.neighbors(KnowledgeGraph.key("Swarlipi")).any { it.relation == RelationType.BELONGS_TO && it.entity.name == "Tabla engine" })
        assertTrue(g.entities.values.any { it.type == EntityType.ORGANIZATION && it.name.contains("NHAI") })
        assertTrue(g.mentionedIn("what does Ramesh do?").any { it.name == "Ramesh" })
    }

    @Test fun httpPluginValidatesAndRuns() = runBlocking {
        val bad = PluginManifest.parse("""{"id":"org.x.p","name":"P","version":"1.0.0","permissions":["internet"],
            "tools":[{"name":"t","risk":"low","network":true,"http":{"url":"http://x/{q}"}}]}""")
        val msg = bad.exceptionOrNull()!!.message!!
        assertTrue(msg.contains("https://") && msg.contains("{q}"))
        val m = PluginManifest.parse("""{"id":"org.x.mandi","name":"Mandi","version":"1.0.0","permissions":["internet"],
            "tools":[{"name":"mandi_price","description":"Price","risk":"low","network":true,
            "input_schema":{"type":"object","properties":{"crop":{"type":"string"}}},"http":{"method":"GET","url":"https://api.mandi.example/price?crop={crop}"}}]}""").getOrThrow()
        val t = RoutingTransport(listOf("api.mandi.example" to ok("""{"crop":"bajra","modal":2350}""", "application/json")))
        val tool = HttpPluginTool(m, m.tools.single(), t)
        assertTrue(tool.spec.usesNetwork)
        val r = tool.run(jsonObj("crop" to "bajra & millet"))
        assertTrue((r as ToolResult.Ok).output.contains("2350"))
        assertTrue(t.requests.single().url.endsWith("crop=bajra%20%26%20millet"))
        assertNotNull(m.tools.single().http)
    }
}
