package ai.astra.core

import ai.astra.core.agent.AgentLimits
import ai.astra.core.agent.AgentRunner
import ai.astra.core.chat.ChatEngine
import ai.astra.core.chat.ChatEvent
import ai.astra.core.chat.ChatRequest
import ai.astra.core.chat.ConsentAnswer
import ai.astra.core.chat.ConsentGate
import ai.astra.core.chat.EngineSettings
import ai.astra.core.chat.InMemoryConversationRepository
import ai.astra.core.device.DeviceState
import ai.astra.core.diagnostics.Diagnostics
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.documents.ExtractedDocument
import ai.astra.core.documents.InMemoryDocumentStore
import ai.astra.core.documents.LocatorKind
import ai.astra.core.documents.SourceUnit
import ai.astra.core.export.Exporter
import ai.astra.core.json.Json
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.memory.HashingEmbedder
import ai.astra.core.memory.InMemoryMemoryStore
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.model.AssistMode
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Project
import ai.astra.core.model.Role
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.EndpointKind
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.NetworkGate
import ai.astra.core.provider.PromptTurn
import ai.astra.core.provider.ProviderErrorKind
import ai.astra.core.provider.ProviderException
import ai.astra.core.provider.UrlConnectionTransport
import ai.astra.core.provider.createHttpProvider
import ai.astra.core.router.DataControl
import ai.astra.core.router.ModelRouter
import ai.astra.core.router.RouterPolicy
import ai.astra.core.security.ConfirmationGate
import ai.astra.core.security.InMemoryPermissionCenter
import ai.astra.core.security.Permission
import ai.astra.core.security.PermissionState
import ai.astra.core.security.RingAuditLog
import ai.astra.core.security.RiskLevel
import ai.astra.core.security.ToolFirewall
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec
import ai.astra.core.tools.defaultTools
import ai.astra.core.json.JsonValue
import ai.astra.core.model.ContentSource
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class RemoteProviderTest {
    private fun cfg(kind: EndpointKind, url: String = "https://api.example.com", locality: Locality = Locality.REMOTE) =
        EndpointConfig("e1", "Endpoint", kind, url, "model-x", locality)

    private val turns = listOf(
        PromptTurn(Role.SYSTEM, listOf(Part.Text("be nice")), setOf(ContentSource.SYSTEM)),
        PromptTurn(Role.USER, listOf(Part.Text("hi")), setOf(ContentSource.USER)),
    )

    @Test fun openAiCompatibleStreams() = runBlocking {
        val t = FakeTransport(body = "data: {\"choices\":[{\"delta\":{\"content\":\"Hel\"}}]}\n\n: keepalive\n\ndata: {\"choices\":[{\"delta\":{\"content\":\"lo\"}}]}\n\ndata: [DONE]\n\n")
        val p = createHttpProvider(cfg(EndpointKind.OPENAI_COMPATIBLE), t) { "sk-test" }
        val r = p.generate(GenerationRequest(turns))
        assertEquals("Hello", r.text)
        val req = t.requests.single()
        assertEquals("https://api.example.com/v1/chat/completions", req.url)
        assertEquals("Bearer sk-test", req.headers["Authorization"])
        val body = Json.parse(req.body!!).obj()!!
        assertEquals("model-x", body["model"].str())
        assertTrue(r.stats.bytesSent > 0)
    }

    @Test fun anthropicStreamsAndMapsErrors() = runBlocking {
        val ok = FakeTransport(body = "event: message_start\ndata: {\"type\":\"message_start\"}\n\nevent: content_block_delta\ndata: {\"type\":\"content_block_delta\",\"delta\":{\"type\":\"text_delta\",\"text\":\"Namaste\"}}\n\nevent: message_stop\ndata: {\"type\":\"message_stop\"}\n\n")
        val p = createHttpProvider(cfg(EndpointKind.ANTHROPIC), ok) { "key" }
        assertEquals("Namaste", p.generate(GenerationRequest(turns)).text)
        val body = Json.parse(ok.requests.single().body!!).obj()!!
        assertEquals("be nice", body["system"].str())
        assertEquals("2023-06-01", ok.requests.single().headers["anthropic-version"])

        val auth = FakeTransport(status = 401, body = "{\"error\":{\"message\":\"bad key sk-ant-api03-secretsecretsecretsecret\"}}")
        try { createHttpProvider(cfg(EndpointKind.ANTHROPIC), auth) { "key" }.generate(GenerationRequest(turns)); fail() }
        catch (e: ProviderException) {
            assertEquals(ProviderErrorKind.AUTH, e.kind)
            assertFalse("keys are redacted from errors", e.message!!.contains("secretsecret"))
        }
    }

    @Test fun privateModeGateAndTlsEnforcement() = runBlocking {
        val gate = NetworkGate().apply { privateMode = true }
        val p = createHttpProvider(cfg(EndpointKind.OPENAI_COMPATIBLE), UrlConnectionTransport(gate, Locality.REMOTE)) { null }
        try { p.generate(GenerationRequest(turns)); fail() } catch (e: ProviderException) { assertTrue(e.message!!.contains("private mode")) }
        assertEquals(1, gate.blocked)
        assertEquals(0, gate.requests)

        val plain = createHttpProvider(cfg(EndpointKind.OPENAI_COMPATIBLE, "http://api.example.com"), UrlConnectionTransport(NetworkGate(), Locality.REMOTE)) { null }
        try { plain.generate(GenerationRequest(turns)); fail() } catch (e: ProviderException) { assertTrue(e.message!!.contains("plain HTTP")) }
    }
}

class AgentTest {
    private class DeleteTool : Tool {
        var ran = false
        override val spec = ToolSpec("delete_file", "Deletes a file", "{}", "{}", RiskLevel.HIGH, setOf(Permission.FILES), ExecutionEnvironment.SANDBOX)
        override suspend fun run(args: JsonValue.Obj): ToolResult { ran = true; return ToolResult.Ok("deleted") }
    }

    private fun setup(confirm: Boolean): Triple<AgentRunner, DeleteTool, RingAuditLog> {
        val mem = MemoryEngine(InMemoryMemoryStore(), HashingEmbedder())
        val tools = defaultTools(mem, DocumentIndex(InMemoryDocumentStore(), HashingEmbedder())) { null }
        val del = DeleteTool().also { tools.register(it) }
        val audit = RingAuditLog()
        val perms = InMemoryPermissionCenter().apply { set(Permission.FILES, PermissionState.ALLOWED) }
        return Triple(AgentRunner(tools, ToolFirewall(perms, ConfirmationGate { confirm }, audit)), del, audit)
    }

    private val base = listOf(PromptTurn(Role.USER, listOf(Part.Text("q")), setOf(ContentSource.USER)))

    @Test fun calculatorLoopAndVisibleStream() = runBlocking {
        val (runner, _, audit) = setup(confirm = true)
        val p = ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf(
            "Checking. <tool_call>{\"name\":\"calculator\",\"arguments\":{\"expression\":\"18% of 2500\"}}</tool_call>",
            "GST is 450.",
        ))
        val shown = StringBuilder()
        val out = runner.run(p, base, GenerationRequest(base), AssistMode.ASSIST, AgentLimits.forMode(AssistMode.ASSIST), false, { shown.append(it) }, {})
        assertEquals("GST is 450.", out.text)
        assertEquals(listOf("calculator"), out.toolsUsed)
        assertEquals(true, out.calculationsVerified)
        assertFalse(shown.contains("tool_call"))
        val toolTurn = p.requests[1].turns.last()
        assertEquals(Role.TOOL, toolTurn.role)
        assertTrue((toolTurn.parts.first() as Part.Text).text.contains("= 450"))
        assertTrue(audit.entries().any { it.tool == "calculator" && it.decision.startsWith("ALLOWED") })
    }

    @Test fun firewallBlocksHighRiskInAssistAndAsksInAgent() = runBlocking {
        val call = "<tool_call>{\"name\":\"delete_file\",\"arguments\":{\"path\":\"a.txt\"}}</tool_call>"
        val (assist, delA, _) = setup(confirm = true)
        assist.run(ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf(call, "done")), base, GenerationRequest(base), AssistMode.ASSIST, AgentLimits.forMode(AssistMode.ASSIST), false, {}, {})
        assertFalse("assist mode never runs high-risk tools", delA.ran)

        val (agentNo, delN, auditN) = setup(confirm = false)
        agentNo.run(ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf(call, "done")), base, GenerationRequest(base), AssistMode.AGENT, AgentLimits.forMode(AssistMode.AGENT), false, {}, {})
        assertFalse("user declined", delN.ran)
        assertTrue(auditN.entries().any { it.decision == "DENIED" })

        val (agentYes, delY, _) = setup(confirm = true)
        agentYes.run(ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf(call, "done")), base, GenerationRequest(base), AssistMode.AGENT, AgentLimits.forMode(AssistMode.AGENT), false, {}, {})
        assertTrue(delY.ran)
    }

    @Test fun stepLimitStopsRunawayLoops() = runBlocking {
        val (runner, _, _) = setup(confirm = true)
        val loop = "<tool_call>{\"name\":\"calculator\",\"arguments\":{\"expression\":\"1+1\"}}</tool_call>"
        val out = runner.run(ScriptedProvider("l", Locality.ON_DEVICE, mutableListOf(loop)), base, GenerationRequest(base), AssistMode.AGENT, AgentLimits(3, 60_000, 10_000), false, {}, {})
        assertTrue(out.limitsHit.any { it.contains("max steps") })
        assertEquals(3, out.steps)
    }
}

/**
 * Engine-level version of the master acceptance test (section 73). UI-only steps (voice, camera)
 * are covered by Android instrumentation tests; everything the engine decides is verified here.
 */
class MasterAcceptanceTest {
    private class World(
        val local: ScriptedProvider = ScriptedProvider("local", Locality.ON_DEVICE, mutableListOf("Local answer")),
        val cloud: ScriptedProvider = ScriptedProvider("cloud", Locality.REMOTE, mutableListOf("Cloud answer"), ai.astra.core.provider.ModelCapabilities(reasoning = 9, coding = 9, contextWindow = 100_000)),
        var online: Boolean = false,
        var policy: RouterPolicy = RouterPolicy(),
        var consent: ConsentAnswer = ConsentAnswer.ALLOW_ONCE,
        val memoryStore: InMemoryMemoryStore = InMemoryMemoryStore(),
        val repo: InMemoryConversationRepository = InMemoryConversationRepository(),
        val docs: DocumentIndex = DocumentIndex(InMemoryDocumentStore(), HashingEmbedder()),
    ) {
        val providers = mutableListOf<AiProvider>(local, cloud)
        val consentAsked = ArrayList<String>()
        fun engine(): ChatEngine {
            val mem = MemoryEngine(memoryStore, HashingEmbedder())
            val tools = defaultTools(mem, docs) { null }
            return ChatEngine(
                repo, { providers }, ModelRouter(), mem, docs, tools,
                AgentRunner(tools, ToolFirewall(InMemoryPermissionCenter(), ConfirmationGate { true }, RingAuditLog())),
                ConsentGate { consentAsked += it.provider.id; consent },
                { DeviceState(online = online) }, { EngineSettings(routerPolicy = policy) }, Diagnostics(),
            )
        }
    }

    private fun send(w: World, text: String, conv: String = "c1", mode: AssistMode = AssistMode.CHAT, forced: String? = null, parts: List<Part>? = null) =
        runBlocking { w.engine().send(ChatRequest(conv, parts ?: listOf(Part.Text(text)), mode, forcedProviderId = forced)).toList() }

    private fun List<ChatEvent>.completed() = filterIsInstance<ChatEvent.Completed>().single().message

    @Test fun a_to_d_offlineQuestionAnsweredLocally() {
        val w = World(online = false)
        val ev = send(w, "Analyze and compare step by step the design trade-offs of solar pumps?")
        val msg = ev.completed()
        assertEquals("Local answer", msg.text)
        assertEquals(Locality.ON_DEVICE, msg.trace!!.locality)
        assertFalse(msg.trace!!.networkUsed)
        assertTrue(w.cloud.requests.isEmpty())
    }

    @Test fun e_to_g_memorySurvivesRestartAndIsUsed() {
        val w = World()
        val saved = send(w, "remember that my village dhani is in Mandhan tehsil").completed()
        assertTrue(saved.text.startsWith("Saved to memory"))
        assertTrue("memory command needs no model", w.local.requests.isEmpty())
        // Restart: new engine instance, same persistent stores.
        send(w, "Where is my village dhani?", conv = "c2")
        val system = (w.local.requests.last().turns.first().parts.first() as Part.Text).text
        assertTrue(system.contains("Mandhan tehsil"))
    }

    @Test fun h_i_documentQuestionIsGroundedWithCitation() {
        val w = World()
        runBlocking {
            w.docs.index(ExtractedDocument("Affidavit.pdf", "application/pdf", LocatorKind.PAGE, listOf(SourceUnit(1, "Cover page"), SourceUnit(17, "The respondent planted 12,400 saplings along the corridor in 2025."))), "x", null)
        }
        val ev = send(w, "How many saplings were planted along the corridor?")
        assertTrue(ev.any { it is ChatEvent.Activity && it.item.detail.contains("Affidavit.pdf, page 17") })
        val userTurn = (w.local.requests.last().turns.last().parts.first() as Part.Text).text
        assertTrue(userTurn.contains("12,400") && userTurn.contains("UNTRUSTED"))
    }

    @Test fun j_imageNeedsVisionModel() {
        val w = World()
        val ev = send(w, "", parts = listOf(Part.Text("What plant is this?"), Part.Image("/tmp/leaf.jpg")))
        assertTrue(ev.last() is ChatEvent.Failed)
        val v = ScriptedProvider("vision", Locality.ON_DEVICE, mutableListOf("A neem leaf."), vision = true)
        w.providers += v
        assertEquals("A neem leaf.", send(w, "", parts = listOf(Part.Text("What plant is this?"), Part.Image("/tmp/leaf.jpg"))).completed().text)
    }

    @Test fun m_to_o_onlineProviderAndComparison() {
        val w = World(online = true)
        val msg = send(w, "Analyze and design a step by step architecture, compare trade-offs and evaluate risks?").completed()
        assertEquals("Cloud answer", msg.text)
        assertEquals(ExecutionMode.ONLINE, msg.trace!!.mode)
        assertTrue(msg.trace!!.networkUsed)
        assertTrue(msg.trace!!.dataSent.isNotEmpty())
        // Compare: same question forced onto the local model.
        val localMsg = send(w, "Analyze and design a step by step architecture, compare trade-offs and evaluate risks?", forced = "local").completed()
        assertEquals(Locality.ON_DEVICE, localMsg.trace!!.locality)
    }

    @Test fun p_safeToolRuns() {
        val w = World()
        val tooling = ScriptedProvider("local2", Locality.ON_DEVICE, mutableListOf(
            "<tool_call>{\"name\":\"calculator\",\"arguments\":{\"expression\":\"12400*0.82\"}}</tool_call>", "About 10168 survived."))
        w.providers.clear(); w.providers += tooling
        val msg = send(w, "If 82% of 12400 saplings survived, how many is that?", mode = AssistMode.ASSIST).completed()
        assertEquals(listOf("calculator"), msg.trace!!.tools)
        assertEquals(true, msg.trace!!.verification!!.calculationsVerified)
    }

    @Test fun q_s_projectScopeAndExport() {
        val w = World()
        w.repo.projects["p1"] = Project("p1", "NHAI Green Highways", "Use formal English.")
        w.repo.conversations["pc"] = Conversation("pc", "Plantation", projectId = "p1")
        send(w, "Summarize plantation status", conv = "pc")
        val system = (w.local.requests.last().turns.first().parts.first() as Part.Text).text
        assertTrue(system.contains("NHAI Green Highways") && system.contains("formal English"))
        val export = runBlocking {
            Exporter.bundle(listOf(w.repo.conversations["pc"]!! to w.repo.messages("pc")), MemoryEngine(w.memoryStore, HashingEmbedder()).list(), w.repo.projects.values.toList(), emptyList(), mapOf("dataControl" to "ASK_FOR_SENSITIVE"))
        }
        val root = Json.parse(export).obj()!!
        assertEquals("astra-export", root["format"].str())
        assertTrue(export.contains("Summarize plantation status"))
    }

    @Test fun t_u_deletedMemoryNeverReachesThePrompt() {
        val w = World()
        send(w, "remember that my locker code word is bluebird")
        val mem = MemoryEngine(w.memoryStore, HashingEmbedder())
        val id = runBlocking { mem.list().single().id }
        runBlocking { mem.forget(id) }
        send(w, "what is my locker code word?", conv = "c9")
        val prompt = w.local.requests.last().turns.joinToString { t -> t.parts.joinToString { (it as? Part.Text)?.text ?: "" } }
        assertFalse(prompt.contains("bluebird"))
    }

    @Test fun v_privateModePreventsAnyNetworkTransmission() {
        val gate = NetworkGate().apply { privateMode = true }
        val transport = FakeTransport(body = "data: [DONE]\n\n")
        val guarded = ai.astra.core.provider.HttpTransport { req -> gate.check(Locality.REMOTE, req.url); transport.open(req) }
        val cloud = createHttpProvider(EndpointConfig("cloud", "Cloud", EndpointKind.OPENAI_COMPATIBLE, "https://api.example.com", "m", Locality.REMOTE), guarded) { "k" }
        val w = World(online = true, policy = RouterPolicy(dataControl = DataControl.NEVER_SEND))
        w.providers.clear(); w.providers += listOf(w.local, cloud)
        val msg = send(w, "Analyze and design a step by step architecture, compare trade-offs and evaluate risks?").completed()
        assertEquals(Locality.ON_DEVICE, msg.trace!!.locality)
        assertTrue("no request may reach the transport", transport.requests.isEmpty())
        assertEquals(0, gate.requests)
        // And with no local model the engine refuses rather than sending.
        w.providers.remove(w.local)
        val ev = send(w, "hello there")
        assertTrue(ev.last() is ChatEvent.Failed)
        assertTrue(transport.requests.isEmpty())
    }

    @Test fun consentDeclinedKeepsDataOnDevice() {
        val w = World(online = true, policy = RouterPolicy(dataControl = DataControl.ASK_BEFORE_SENDING), consent = ConsentAnswer.DENY)
        val msg = send(w, "Analyze and design a step by step architecture, compare trade-offs and evaluate risks?").completed()
        assertEquals(listOf("cloud"), w.consentAsked)
        assertEquals("Local answer", msg.text)
        assertTrue(w.cloud.requests.isEmpty())
    }

    @Test fun networkLossRecoversOnDevice() {
        val w = World(online = true)
        w.cloud.failWith = networkDown()
        val ev = send(w, "Analyze and design a step by step architecture, compare trade-offs and evaluate risks?")
        assertTrue(ev.any { it is ChatEvent.Notice && it.text.contains("Connection lost") })
        assertEquals("Local answer", ev.completed().text)
    }

    @Test fun localCrashIsReportedNotFabricated() {
        val w = World(online = false)
        w.local.failWith = ProviderException(ProviderErrorKind.MODEL_CRASH, "native engine died")
        val ev = send(w, "hi")
        val f = ev.last() as ChatEvent.Failed
        assertTrue(f.reason.contains("native engine died"))
        assertTrue(ev.none { it is ChatEvent.Completed })
    }
}
