import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// ASTRA core: pure Kotlin/JVM. No Android dependency, so every engine decision is unit-testable
// on any machine and the same engine can later power a desktop or server build.
plugins {
    alias(libs.plugins.kotlin.jvm)
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    api(libs.kotlinx.coroutines.core)
    testImplementation(libs.junit)
}
