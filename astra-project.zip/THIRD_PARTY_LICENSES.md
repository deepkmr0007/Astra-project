# Third-party licenses

| Component | Use | License |
|---|---|---|
| Kotlin standard library, kotlinx.coroutines | Language runtime, concurrency | Apache-2.0 |
| AndroidX Core, Activity, Lifecycle, Fragment | Android foundations | Apache-2.0 |
| Jetpack Compose (UI, Material 3, Material Icons Extended) | UI | Apache-2.0 |
| Room | Local database | Apache-2.0 |
| DataStore Preferences | Settings | Apache-2.0 |
| AndroidX Biometric | App lock | Apache-2.0 |
| LiteRT-LM (`com.google.ai.edge.litertlm:litertlm-android`) | On-device LLM runtime | Apache-2.0 |
| PDFBox-Android (`com.tom-roush:pdfbox-android`) | PDF text extraction | Apache-2.0 |
| Google ML Kit text recognition (Latin, Devanagari) & image labeling | On-device OCR and labels | ML Kit Terms of Service (free, bundled models) |
| AndroidX CameraX | Camera mode | Apache-2.0 |
| AndroidX WorkManager | Automations | Apache-2.0 |
| AndroidX JavaScriptEngine | Sandboxed JavaScript | Apache-2.0 |
| AndroidX DocumentFile, Lifecycle Compose | Folder workspace, lifecycle | Apache-2.0 |
| kotlinx-coroutines-guava (+ Guava) | Future interop | Apache-2.0 |
| SQLCipher for Android (`net.zetetic:sqlcipher-android`) | Database encryption | BSD-style (Zetetic) |
| JUnit 4, AndroidX Test | Tests | EPL-1.0 / Apache-2.0 |

## Models

No model weights are bundled with ASTRA. The Setup catalog downloads Apache-2.0 models (Gemma 4 E2B/E4B, Qwen3 0.6B, Qwen3.5 0.8B) from litert-community on Hugging Face. Models you import or download keep their own licenses (for example, Gemma models are governed by Google's Gemma Terms of Use). ASTRA records the license text you enter for every installed model and shows it in **Models**. Do not redistribute models whose licenses prohibit it.

## v0.3 additions

- **ASTRA Desk** (`desk-extension/`) is an original, dependency-free Chrome/Edge (MV3) extension. It bundles and loads **no third-party JavaScript**; pairing and encryption use the browser's built-in Web Crypto (ECDH P-256, HKDF-SHA256, AES-256-GCM). The phone side uses the Java platform crypto (`javax.crypto`, `java.security`).
- **Phone automation** uses the Android Accessibility API (`android.accessibilityservice`) — a platform capability, opt-in, with no added dependency.
- **PC training kit** (`tools/train/`) is a separate, optional set of scripts. Its `requirements.txt` lists Apache-2.0 / MIT libraries (Transformers, PEFT, Datasets, Accelerate, TRL) that you install yourself on your computer; none are bundled with the app, and the app does not depend on them.

## Original work

ASTRA's engine (`core/`), app code, the ASTRA Desk extension, the training kit, icon and documentation are original work. ASTRA does not include or reproduce proprietary model weights or provider internals.
