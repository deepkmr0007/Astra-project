# Contributing

1. **Decisions go in `:core`.** If logic can be expressed without Android, put it in `core/` and unit-test it there. The app module should be adapters and UI.
2. **BUILD → TEST → FIX → VERIFY → DOCUMENT.** `./gradlew :core:test :app:testDebugUnitTest :app:assembleDebug` must pass before merging.
3. **No fake features.** If something can't work yet, the UI says “Not configured” or “Requires provider”, and the code throws `UNSUPPORTED` rather than returning a plausible-looking result.
4. **Privacy first.** Anything that sends data off the device must go through `HttpTransport` + `NetworkGate`, be visible in the execution trace, and respect `DataControl`. Never log secrets or private content; use `Redactor`.
5. **Strings are resources.** Add every user-visible string to `values/strings.xml` and `values-hi/strings.xml`.
6. **Licenses.** Record every new dependency or model in `THIRD_PARTY_LICENSES.md`.
7. Style: Kotlin official code style, small classes, interfaces at module boundaries, coroutines + Flow, no global mutable state outside `AppContainer`.
