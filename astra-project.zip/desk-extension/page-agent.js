// Injected into the work tab with chrome.scripting.executeScript({ func: astraPageAgent }).
// It must be fully self-contained: Chrome serialises only this function's source.
// It reads and fills form fields in the page; it never reads cookies, storage or passwords
// (password fields are reported without their values and are never filled).

export function astraPageAgent(op, payload) {
  const norm = (s) => String(s == null ? '' : s).toLowerCase().replace(/[\s\u00a0]+/g, ' ').replace(/[*:：]/g, '').trim();
  const isVisible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  };
  const esc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&'));
  const cssPath = (el) => {
    if (el.id && document.querySelectorAll('#' + esc(el.id)).length === 1) return '#' + esc(el.id);
    const name = el.getAttribute('name');
    if (name) {
      const sel = el.tagName.toLowerCase() + '[name="' + name.replace(/["\\]/g, '\\$&') + '"]';
      if (document.querySelectorAll(sel).length === 1) return sel;
    }
    const parts = [];
    let e = el;
    while (e && e.nodeType === 1 && e !== document.body && parts.length < 10) {
      let i = 1; let s = e;
      while ((s = s.previousElementSibling)) if (s.tagName === e.tagName) i++;
      parts.unshift(e.tagName.toLowerCase() + ':nth-of-type(' + i + ')');
      e = e.parentElement;
    }
    return 'body > ' + parts.join(' > ');
  };
  const text = (el) => (el ? (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim() : '');
  const rawLabel = (el) => {
    if (el.labels && el.labels.length) return text(el.labels[0]);
    const aria = el.getAttribute('aria-label');
    if (aria) return aria;
    const lb = el.getAttribute('aria-labelledby');
    if (lb) { const t = lb.split(/\s+/).map((id) => text(document.getElementById(id))).join(' ').trim(); if (t) return t; }
    const cell = el.closest('td,th');
    if (cell) {
      let p = cell.previousElementSibling;
      while (p && !text(p)) p = p.previousElementSibling;
      if (p && text(p).length < 80) return text(p);
      const row = cell.parentElement && cell.parentElement.previousElementSibling;
      if (row && row.children[cell.cellIndex] && text(row.children[cell.cellIndex]).length < 80) return text(row.children[cell.cellIndex]);
    }
    let prev = el.previousElementSibling;
    while (prev && !text(prev) && prev.tagName !== 'INPUT') prev = prev.previousElementSibling;
    if (prev && prev.tagName !== 'INPUT' && text(prev).length < 80) return text(prev);
    const parent = el.parentElement;
    if (parent && text(parent).length < 80 && text(parent)) return text(parent);
    return el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('name') || el.id || '';
  };
  const typeOf = (el) => {
    const tag = el.tagName;
    if (tag === 'SELECT') return 'SELECT';
    if (tag === 'TEXTAREA') return 'TEXTAREA';
    if (tag === 'BUTTON') return 'BUTTON';
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    return ({ number: 'NUMBER', date: 'DATE', email: 'EMAIL', tel: 'PHONE', password: 'PASSWORD', checkbox: 'CHECKBOX', radio: 'RADIO', file: 'FILE',
      submit: 'BUTTON', button: 'BUTTON', image: 'BUTTON', reset: 'BUTTON' })[t] || 'TEXT';
  };
  const inputs = () => Array.from(document.querySelectorAll('input, select, textarea')).filter((el) => {
    const t = (el.getAttribute('type') || '').toLowerCase();
    return t !== 'hidden' && !el.disabled && isVisible(el);
  });
  const clickables = () => Array.from(document.querySelectorAll('button, input[type=submit], input[type=button], input[type=image], a, [role=button]')).filter(isVisible);
  const clickLabel = (el) => (text(el) || el.value || el.getAttribute('aria-label') || el.title || el.alt || '').trim();
  const flash = (el) => {
    const old = el.style.outline;
    el.style.outline = '3px solid #7c5cff';
    setTimeout(() => { el.style.outline = old; }, 1500);
  };
  const findInput = (selector, label) => {
    if (selector) { try { const e = document.querySelector(selector); if (e) return e; } catch (e) { /* not a selector */ } }
    const want = norm(label || selector);
    if (!want) return null;
    const all = inputs();
    return all.find((el) => norm(rawLabel(el)) === want) || all.find((el) => norm(rawLabel(el)).includes(want)) ||
      all.find((el) => norm(el.getAttribute('placeholder')) === want || norm(el.name) === want) || null;
  };
  const findClickable = (target) => {
    try { const e = document.querySelector(target); if (e) return e; } catch (e) { /* text target */ }
    const want = norm(target);
    const all = clickables();
    return all.find((el) => norm(clickLabel(el)) === want) || all.find((el) => norm(clickLabel(el)).includes(want)) || null;
  };
  const setNative = (el, value) => {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    el.focus();
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  };
  const truthy = (v) => /^(1|y|yes|true|haan|han|हाँ|हां|✓|x|checked|on)$/i.test(String(v).trim());

  if (op === 'scan') {
    const fields = [];
    const radios = {};
    for (const el of inputs()) {
      const type = typeOf(el);
      if (type === 'RADIO') {
        const name = el.name || el.id;
        if (!radios[name]) {
          radios[name] = { selector: 'input[type=radio][name="' + name.replace(/["\\]/g, '\\$&') + '"]', label: '', name, type: 'RADIO', options: [], required: el.required };
          const fs = el.closest('fieldset');
          radios[name].label = (fs && fs.querySelector('legend') && text(fs.querySelector('legend'))) || rawLabel(el.closest('td,th') || el) || name;
          fields.push(radios[name]);
        }
        radios[name].options.push((el.labels && el.labels[0] && text(el.labels[0])) || el.value);
        continue;
      }
      const lab = rawLabel(el);
      const f = {
        selector: cssPath(el), label: lab.replace(/[*:]\s*$/, '').trim(), name: el.name || el.id || '', type,
        options: type === 'SELECT' ? Array.from(el.options).map((o) => o.text.trim()).filter((t) => t) : [],
        required: !!(el.required || el.getAttribute('aria-required') === 'true' || /\*/.test(lab)),
        maxLength: el.maxLength > 0 && el.maxLength < 100000 ? el.maxLength : null,
        pattern: el.getAttribute('pattern') || null,
        value: type === 'PASSWORD' ? '' : (type === 'SELECT' ? (el.selectedOptions[0] ? el.selectedOptions[0].text : '') : (type === 'CHECKBOX' ? String(el.checked) : el.value || '')),
        placeholder: el.getAttribute('placeholder') || '',
      };
      if (type === 'BUTTON') f.label = clickLabel(el);
      fields.push(f);
      if (fields.length >= 300) break;
    }
    for (const b of clickables()) {
      if (b.tagName === 'A' && !(/btn|button/i.test(b.className) || /^javascript:/i.test(b.getAttribute('href') || ''))) continue;
      if (b.tagName === 'INPUT') continue; // already listed
      const l = clickLabel(b);
      if (l && l.length <= 40) fields.push({ selector: cssPath(b), label: l, name: b.name || b.id || '', type: 'BUTTON', options: [], required: false, value: '', placeholder: '' });
      if (fields.length >= 340) break;
    }
    return { ok: true, snapshot: { url: location.href, title: document.title, fields } };
  }

  if (op === 'fill_one') {
    const f = payload;
    let el = findInput(f.selector, f.label);
    if (!el && f.type === 'RADIO') { try { el = document.querySelector(f.selector); } catch (e) { /* ignore */ } }
    if (!el) return { found: false };
    el.scrollIntoView({ block: 'center' });
    const type = f.type === 'RADIO' || typeOf(el) === 'RADIO' ? 'RADIO' : typeOf(el);
    if (type === 'PASSWORD' || type === 'FILE') return { found: true, ok: false, message: 'ASTRA does not fill ' + type.toLowerCase() + ' fields — please do it yourself' };
    if (type === 'SELECT') {
      const want = norm(f.value);
      const opts = Array.from(el.options);
      const o = opts.find((x) => x.text.trim() === f.value) || opts.find((x) => norm(x.text) === want) || opts.find((x) => norm(x.value) === want) ||
        opts.find((x) => want && norm(x.text).includes(want));
      if (!o) return { found: true, ok: false, message: '“' + f.value + '” is not in the list' };
      setNative(el, o.value);
      flash(el);
      return { found: true, ok: true, postback: !!(el.getAttribute('onchange') || '').match(/postback/i) };
    }
    if (type === 'RADIO') {
      const group = el.name ? Array.from(document.querySelectorAll('input[type=radio][name="' + el.name.replace(/["\\]/g, '\\$&') + '"]')) : [el];
      const want = norm(f.value);
      const r = group.find((x) => norm(x.labels && x.labels[0] ? text(x.labels[0]) : '') === want || norm(x.value) === want) ||
        group.find((x) => want && norm(x.labels && x.labels[0] ? text(x.labels[0]) : x.value).includes(want));
      if (!r) return { found: true, ok: false, message: '“' + f.value + '” is not an option' };
      if (!r.checked) r.click();
      flash(r);
      return { found: true, ok: true };
    }
    if (type === 'CHECKBOX') {
      if (el.checked !== truthy(f.value)) el.click();
      flash(el);
      return { found: true, ok: true };
    }
    if (el.readOnly) return { found: true, ok: false, message: 'Field is read-only' };
    setNative(el, f.value);
    flash(el);
    return { found: true, ok: true };
  }

  if (op === 'click') {
    const el = findClickable(payload.target);
    if (!el) return { found: false };
    el.scrollIntoView({ block: 'center' });
    flash(el);
    setTimeout(() => el.click(), 150);
    return { found: true, ok: true, message: 'Clicked “' + clickLabel(el) + '”' };
  }

  if (op === 'probe') {
    if (payload.selector) {
      try { const e = document.querySelector(payload.selector); if (e && isVisible(e)) return { found: true }; } catch (e) { /* text */ }
    }
    if (payload.text) {
      const body = norm(document.body ? document.body.innerText : '');
      if (body.includes(norm(payload.text))) return { found: true };
      // Alerts rendered as dialogs/toasts are usually in the DOM too; also check input values.
      if (inputs().some((i) => norm(i.value).includes(norm(payload.text)))) return { found: true };
    }
    return { found: false };
  }

  if (op === 'extract') {
    const t = payload.target;
    try {
      const e = document.querySelector(t);
      if (e) return { found: true, ok: true, data: e.value != null && e.tagName !== 'DIV' ? String(e.value || text(e)) : text(e) };
    } catch (e) { /* label text */ }
    const lines = (document.body ? document.body.innerText : '').split('\n');
    const want = norm(t);
    for (const line of lines) {
      const i = norm(line).indexOf(want);
      if (i >= 0) {
        const rest = line.replace(/\s+/g, ' ').trim().slice(i + t.length).replace(/^[\s:：\-–=]+/, '').trim();
        if (rest) return { found: true, ok: true, data: rest.split(/\s{2,}/)[0] };
      }
    }
    return { found: false };
  }

  return { ok: false, message: 'Unknown operation ' + op };
}
