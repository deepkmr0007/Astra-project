// ASTRA Desk — pairing and encrypted messaging with the ASTRA app on your phone.
// Same scheme as core/src/main/kotlin/ai/astra/core/desk/DeskCrypto.kt:
// ECDH P-256 → HKDF-SHA256 (salt = SHA-256(phonePub || extensionPub)) → AES-256-GCM.
// Works in Chrome extension pages and in Node 20+ (used by the interop test).

const te = new TextEncoder();
const td = new TextDecoder();

export function b64(bytes) {
  let s = '';
  const b = new Uint8Array(bytes);
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}

export function unb64(str) {
  const s = atob(str);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

function concat(a, b) {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0); out.set(b, a.length);
  return out;
}

export async function newKeyPair() {
  return crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
}

export async function exportRaw(publicKey) {
  return new Uint8Array(await crypto.subtle.exportKey('raw', publicKey));
}

/** Returns { key: Uint8Array(32), code: '123456' } — identical to the phone's result. */
export async function derive(privateKey, phonePubRaw, extPubRaw) {
  const phonePub = await crypto.subtle.importKey('raw', phonePubRaw, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: phonePub }, privateKey, 256));
  const salt = new Uint8Array(await crypto.subtle.digest('SHA-256', concat(phonePubRaw, extPubRaw)));
  const ikm = await crypto.subtle.importKey('raw', shared, 'HKDF', false, ['deriveBits']);
  const key = new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: te.encode('astra-desk-v1 key') }, ikm, 256));
  const sas = new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: te.encode('astra-desk-v1 sas') }, ikm, 32));
  const n = sas[0] * 16777216 + sas[1] * 65536 + sas[2] * 256 + sas[3];
  return { key, code: String(n % 1000000).padStart(6, '0') };
}

async function aesKey(keyBytes) {
  return crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['encrypt', 'decrypt']);
}

/** Returns raw bytes iv(12) || ciphertext+tag. */
export async function seal(keyBytes, text, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: te.encode(aad), tagLength: 128 }, await aesKey(keyBytes), te.encode(text)));
  return concat(iv, ct);
}

export async function open(keyBytes, sealed, aad) {
  const iv = sealed.subarray(0, 12);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: te.encode(aad), tagLength: 128 }, await aesKey(keyBytes), sealed.subarray(12));
  return td.decode(pt);
}

/** Normalises "192.168.1.5", "192.168.1.5:8765" or a full URL to "http://host:port". */
export function phoneBase(input) {
  let s = String(input || '').trim();
  if (!s) throw new Error('Enter the address shown on the phone');
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  const u = new URL(s);
  if (!u.port) u.port = '8765';
  return `${u.protocol}//${u.hostname}:${u.port}`;
}

async function postJson(url, obj, signal) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj), signal });
  const text = await res.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { error: text }; }
  if (!res.ok) { const e = new Error(body.error || `HTTP ${res.status}`); e.status = res.status; throw e; }
  return body;
}

/**
 * Starts pairing. Returns { code, session, finish() } — show `code` to the user, who compares it
 * with the phone and confirms there. `finish()` resolves to { id, key } once the phone confirms.
 */
export async function startPairing(base, computerName) {
  const kp = await newKeyPair();
  const extRaw = await exportRaw(kp.publicKey);
  const hello = await postJson(`${base}/desk/hello`, { pub: b64(extRaw), name: computerName });
  const phoneRaw = unb64(hello.pub);
  const { key, code } = await derive(kp.privateKey, phoneRaw, extRaw);
  const session = hello.session;
  return {
    code,
    session,
    async finish({ timeoutMs = 5 * 60 * 1000, onTick } = {}) {
      const until = Date.now() + timeoutMs;
      while (Date.now() < until) {
        const st = await postJson(`${base}/desk/status`, { session });
        if (st.state === 'confirmed') return { id: session, key: b64(key) };
        if (st.state === 'rejected') throw new Error('Pairing was declined on the phone');
        if (st.state === 'expired' || st.state === 'unknown') throw new Error('Pairing expired — start again');
        onTick && onTick();
        await new Promise((r) => setTimeout(r, 1000));
      }
      throw new Error('Pairing timed out');
    },
  };
}

/** Encrypted request/response with the paired phone. */
export class DeskClient {
  constructor(base, id, keyB64) {
    this.base = base;
    this.id = id;
    this.key = unb64(keyB64);
  }

  async rpc(message, signal) {
    const sealed = await seal(this.key, JSON.stringify({ ...message, ts: Date.now() }), `req:${this.id}`);
    const nonce = b64(sealed.subarray(0, 12));
    const reply = await postJson(`${this.base}/desk/rpc`, { id: this.id, box: b64(sealed) }, signal);
    return JSON.parse(await open(this.key, unb64(reply.box), `resp:${nonce}`));
  }

  poll(waitMs = 20000, signal) { return this.rpc({ type: 'poll', wait: waitMs }, signal); }
  result(cmd, data) { return this.rpc({ type: 'result', cmd, ...data }); }
  answer(ask, value) { return this.rpc({ type: 'answer', ask, value }); }
  chat(text) { return this.rpc({ type: 'chat', text }); }
  sendForm(snapshot) { return this.rpc({ type: 'form', snapshot }); }
  bye() { return this.rpc({ type: 'bye' }); }
}
