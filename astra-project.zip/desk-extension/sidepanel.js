import { startPairing, DeskClient, phoneBase } from './desk-core.js';
import { astraPageAgent } from './page-agent.js';

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let state = {};
let client = null;
let loopToken = 0;
let currentAsk = null;
const bubbles = new Map();

async function load() {
  state = await chrome.storage.local.get(['base', 'id', 'key', 'workTabId', 'pcName']);
  $('pcname').value = state.pcName || '';
  const all = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  $('allSites').checked = all;
  if (state.id && state.key && state.base) showMain(); else showPair();
}

function showPair() {
  $('pair').hidden = false; $('main').hidden = true; setDot('off', 'Not paired');
  $('codeBox').hidden = true; $('pairBtn').disabled = false;
}

async function showMain() {
  $('pair').hidden = true; $('main').hidden = false;
  $('phone').textContent = state.base.replace(/^https?:\/\//, '');
  client = new DeskClient(state.base, state.id, state.key);
  await refreshTab();
  loop(++loopToken);
}

function setDot(kind, title) { const d = $('dot'); d.className = 'dot ' + kind; d.title = title; }

function log(text, cls) {
  const li = document.createElement('li');
  li.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + '  ' + text;
  if (cls) li.className = cls;
  const ol = $('log'); ol.appendChild(li);
  while (ol.children.length > 200) ol.removeChild(ol.firstChild);
  ol.scrollTop = ol.scrollHeight;
}

// ---------- pairing ----------

$('pairBtn').addEventListener('click', async () => {
  $('pairErr').textContent = '';
  let base;
  try { base = phoneBase($('addr').value); } catch (e) { $('pairErr').textContent = e.message; return; }
  const host = new URL(base).hostname;
  // First await in the click handler, so Chrome treats it as a user gesture.
  const granted = await chrome.permissions.request({ origins: [`http://${host}/*`] });
  if (!granted) { $('pairErr').textContent = 'ASTRA Desk needs permission to talk to your phone at ' + host + '.'; return; }
  const pcName = $('pcname').value.trim() || 'Computer';
  await chrome.storage.local.set({ pcName });
  $('pairBtn').disabled = true;
  try {
    const p = await startPairing(base, pcName);
    $('code').textContent = p.code.slice(0, 3) + ' ' + p.code.slice(3);
    $('codeBox').hidden = false;
    const { id, key } = await p.finish();
    state = { ...state, base, id, key, pcName };
    await chrome.storage.local.set({ base, id, key });
    log('Paired with the phone', 'ok');
    showMain();
  } catch (e) {
    $('pairErr').textContent = friendly(e);
    $('pairBtn').disabled = false;
    $('codeBox').hidden = true;
  }
});

$('unpair').addEventListener('click', async () => {
  if (!confirm('Unpair this computer from ASTRA?')) return;
  try { await client?.bye(); } catch (e) { /* phone may be offline */ }
  loopToken++;
  await chrome.storage.local.remove(['id', 'key']);
  state.id = state.key = undefined;
  showPair();
});

function friendly(e) {
  const m = String(e && e.message || e);
  if (/Failed to fetch|NetworkError|ECONNREFUSED|fetch failed/i.test(m)) return 'Can’t reach the phone. Check the address, that ASTRA Desk is on, and that both are on the same Wi-Fi.';
  if (/Cannot access|permission/i.test(m)) return 'ASTRA isn’t allowed on this site yet — click “Use this tab” on it.';
  return m;
}

// ---------- work tab ----------

async function refreshTab() {
  if (!state.workTabId) { $('tabName').textContent = 'None — click “Use this tab”'; return null; }
  try {
    const t = await chrome.tabs.get(state.workTabId);
    $('tabName').textContent = t.title || t.url;
    $('tabName').title = t.url || '';
    return t;
  } catch (e) {
    state.workTabId = undefined; await chrome.storage.local.remove('workTabId');
    $('tabName').textContent = 'None — the tab was closed';
    return null;
  }
}

$('useTab').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !/^https?:/.test(tab.url)) { log('Open the portal page in this window first', 'bad'); return; }
  const origin = new URL(tab.url).origin + '/*';
  const ok = await chrome.permissions.request({ origins: [origin] });
  if (!ok) { log('Permission for this site was not given', 'bad'); return; }
  state.workTabId = tab.id;
  await chrome.storage.local.set({ workTabId: tab.id });
  await refreshTab();
  log('Work tab: ' + (tab.title || tab.url), 'ok');
});

$('allSites').addEventListener('change', async (ev) => {
  const origins = ['http://*/*', 'https://*/*'];
  if (ev.target.checked) {
    const ok = await chrome.permissions.request({ origins });
    ev.target.checked = ok;
  } else {
    await chrome.permissions.remove({ origins }).catch(() => {});
    const phoneOk = state.base && await chrome.permissions.contains({ origins: [`http://${new URL(state.base).hostname}/*`] });
    if (state.base && !phoneOk) log('Access to the phone was removed with it — click Unpair and pair again.', 'bad');
  }
});

$('scanBtn').addEventListener('click', async () => {
  const r = await runCommand({ op: 'scan' });
  if (!r.ok) { log('Scan failed: ' + r.message, 'bad'); return; }
  try {
    await client.sendForm(r.snapshot);
    log(`Sent “${r.snapshot.title}” (${r.snapshot.fields.length} fields) to ASTRA`, 'ok');
  } catch (e) { log('Could not send: ' + friendly(e), 'bad'); }
});

// ---------- page operations ----------

async function inject(tabId, op, payload, frameIds) {
  const target = frameIds ? { tabId, frameIds } : { tabId, allFrames: true };
  const results = await chrome.scripting.executeScript({ target, func: astraPageAgent, args: [op, payload] });
  return results.map((r) => ({ frameId: r.frameId, ...(r.result || {}) }));
}

function splitSelector(sel) {
  const m = /^f(\d+)::(.*)$/s.exec(sel || '');
  return m ? { frameIds: [Number(m[1])], selector: m[2] } : { frameIds: undefined, selector: sel };
}

async function firstFound(tabId, op, payload, selectorKey) {
  const { frameIds, selector } = splitSelector(payload[selectorKey]);
  const results = await inject(tabId, op, { ...payload, [selectorKey]: selector }, frameIds);
  return results.find((r) => r.found) || { found: false };
}

async function waitComplete(tabId, timeoutMs) {
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (!t) return false;
    if (t.status === 'complete') return true;
    await sleep(250);
  }
  return false;
}

async function probeLoop(tabId, probe, timeoutMs) {
  const until = Date.now() + Math.min(timeoutMs || 20000, 120000);
  while (Date.now() < until) {
    try {
      const results = await inject(tabId, 'probe', probe);
      if (results.some((r) => r.found)) return true;
    } catch (e) { /* page navigating — try again */ }
    await sleep(400);
  }
  return false;
}

async function runCommand(m) {
  const tab = await refreshTab();
  if (!tab) return { ok: false, message: 'No work tab on the computer — open the portal and click “Use this tab” in ASTRA Desk.' };
  const tabId = tab.id;
  try {
    switch (m.op) {
      case 'navigate': {
        await chrome.tabs.update(tabId, { url: m.url });
        await sleep(300);
        const done = await waitComplete(tabId, 40000);
        return { ok: done, message: done ? '' : 'The page took too long to load' };
      }
      case 'scan': {
        const results = await inject(tabId, 'scan', {});
        const main = results.find((r) => r.frameId === 0 && r.snapshot) || results.find((r) => r.snapshot);
        if (!main) return { ok: false, message: 'Could not read the page' };
        const fields = [];
        for (const r of results) {
          if (!r.snapshot) continue;
          for (const f of r.snapshot.fields) fields.push(r.frameId === 0 ? f : { ...f, selector: `f${r.frameId}::${f.selector}` });
        }
        return { ok: true, snapshot: { url: main.snapshot.url, title: main.snapshot.title, fields } };
      }
      case 'fill': {
        const failed = []; const errors = [];
        for (const f of m.fields || []) {
          let r;
          try { r = await firstFound(tabId, 'fill_one', f, 'selector'); } catch (e) { await waitComplete(tabId, 10000); r = await firstFound(tabId, 'fill_one', f, 'selector'); }
          if (!r.found) failed.push(f.label || f.selector);
          else if (!r.ok) errors.push(`${f.label || f.selector}: ${r.message}`);
          if (r.postback || f.type === 'SELECT') { await sleep(450); await waitComplete(tabId, 15000); }
          await sleep(60);
        }
        const total = (m.fields || []).length;
        log(`Filled ${total - failed.length - errors.length}/${total} field(s)` + (failed.length ? ` — not found: ${failed.join(', ')}` : ''), failed.length || errors.length ? 'bad' : 'ok');
        return { ok: errors.length === 0 && failed.length < Math.max(1, total), message: errors.join('; '), failed };
      }
      case 'click': {
        const r = await firstFound(tabId, 'click', { target: m.target }, 'target');
        if (!r.found) return { ok: false, message: `Button not found: ${m.target}` };
        log(r.message || 'Clicked', 'ok');
        await sleep(900);
        await waitComplete(tabId, 20000);
        return { ok: true, message: r.message || '' };
      }
      case 'wait_for': {
        const ok = await probeLoop(tabId, { selector: m.target, text: m.target }, m.timeoutMs);
        return { ok, message: ok ? '' : `Did not appear: ${m.target}` };
      }
      case 'check_text': {
        const ok = await probeLoop(tabId, { text: m.text }, m.timeoutMs);
        log(ok ? `Saw “${m.text}”` : `Did not see “${m.text}”`, ok ? 'ok' : 'bad');
        return { ok, message: ok ? '' : `The page did not show “${m.text}”` };
      }
      case 'extract': {
        const r = await firstFound(tabId, 'extract', { target: m.target }, 'target');
        return r.found ? { ok: true, data: r.data || '' } : { ok: false, message: `Not found: ${m.target}` };
      }
      default:
        return { ok: false, message: 'Unknown command ' + m.op };
    }
  } catch (e) {
    return { ok: false, message: friendly(e) };
  }
}

// ---------- questions from ASTRA (review / continue) ----------

const OPTION_LABELS = { approve: 'Approve & save', skip: 'Skip', stop: 'Stop', continue: 'Continue', cancel: 'Cancel' };

function showAsk(m) {
  currentAsk = m.ask;
  $('askTitle').textContent = m.title || 'ASTRA needs you';
  $('askDetail').textContent = m.detail || '';
  const table = $('askFields'); table.innerHTML = '';
  for (const f of m.fields || []) {
    const tr = document.createElement('tr');
    const a = document.createElement('td'); a.textContent = f.label;
    const b = document.createElement('td'); b.textContent = f.value;
    tr.append(a, b); table.appendChild(tr);
  }
  const box = $('askButtons'); box.innerHTML = '';
  (m.options || ['continue']).forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.textContent = OPTION_LABELS[opt] || opt;
    if (i === 0) btn.className = 'primary';
    btn.addEventListener('click', async () => {
      box.querySelectorAll('button').forEach((x) => { x.disabled = true; });
      try { await client.answer(m.ask, opt); log(`You chose: ${btn.textContent}`); } catch (e) { log('Could not send answer: ' + friendly(e), 'bad'); }
      hideAsk(m.ask);
    });
    box.appendChild(btn);
  });
  $('ask').hidden = false;
  $('ask').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function hideAsk(id) { if (!id || id === currentAsk) { $('ask').hidden = true; currentAsk = null; } }

// ---------- chat ----------

function bubble(cls, text) {
  const d = document.createElement('div');
  d.className = 'msg ' + cls; d.textContent = text;
  $('msgs').appendChild(d); $('msgs').scrollTop = $('msgs').scrollHeight;
  return d;
}

$('chatForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const text = $('chatIn').value.trim();
  if (!text || !client) return;
  $('chatIn').value = '';
  bubble('me', text);
  try {
    const r = await client.chat(text);
    bubbles.set(r.chatId, bubble('astra', '…'));
  } catch (e) { bubble('astra', friendly(e)); }
});

$('chatIn').addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); $('chatForm').requestSubmit(); }
});

// ---------- connection loop ----------

async function handle(m) {
  switch (m.type) {
    case 'command': {
      log(`ASTRA: ${m.op}${m.target ? ' ' + m.target : ''}${m.url ? ' ' + m.url : ''}`);
      const res = await runCommand(m);
      try { await client.result(m.cmd, res); } catch (e) { log('Result not delivered: ' + friendly(e), 'bad'); }
      break;
    }
    case 'chat_delta': {
      const b = bubbles.get(m.chatId) || bubble('astra', '');
      if (b.textContent === '…') b.textContent = '';
      b.textContent += m.text; bubbles.set(m.chatId, b);
      $('msgs').scrollTop = $('msgs').scrollHeight;
      break;
    }
    case 'chat_done': {
      const b = bubbles.get(m.chatId) || bubble('astra', '');
      b.textContent = m.text; bubbles.delete(m.chatId);
      break;
    }
    case 'ask': showAsk(m); break;
    case 'ask_cancel': hideAsk(m.ask); break;
    case 'status': log(m.text, m.level === 'error' ? 'bad' : m.level === 'ok' ? 'ok' : undefined); break;
    default: break;
  }
}

async function loop(token) {
  let failures = 0;
  while (token === loopToken) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 32000);
    try {
      const { messages } = await client.poll(20000, ctrl.signal);
      failures = 0;
      setDot('on', 'Connected'); $('status').textContent = 'Connected';
      for (const m of messages || []) await handle(m);
    } catch (e) {
      if (token !== loopToken) break;
      if (e.status === 403) {
        log('This computer is no longer paired with the phone.', 'bad');
        await chrome.storage.local.remove(['id', 'key']);
        showPair(); break;
      }
      failures++;
      setDot('wait', 'Reconnecting'); $('status').textContent = failures > 2 ? 'Phone not reachable — retrying…' : 'Reconnecting…';
      await sleep(Math.min(10000, 1500 * failures));
    } finally {
      clearTimeout(timer);
    }
  }
}

load();
