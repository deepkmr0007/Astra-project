# ASTRA Desk (Chrome/Edge extension)

Links your computer's browser to ASTRA on your phone so ASTRA can **read and fill web forms you
choose** — for example entering records into an ERP/portal — and so you can chat with ASTRA from the
computer. You stay in control: you log in, solve CAPTCHAs and type OTPs yourself, and you approve
every record before it's saved.

## How it connects (and why it's safe)

- The phone runs a small server on your **local Wi-Fi**. The extension connects to it directly; the
  link never goes through the internet or any ASTRA server (there isn't one).
- Pairing uses ECDH (P-256) key exchange and shows a **6-digit code on both screens**. You confirm
  they match — this stops anyone in the middle. After that every message is encrypted with
  AES-256-GCM. The crypto is standard Web Crypto / Java and is interoperable by construction (see
  `desk-core.js` and the interop test in `test/`).
- The extension only acts on the **one tab you pick** ("Use this tab"), and only on sites you grant.
  It never reads passwords and never fills password fields.

## Install (developer mode, no store needed)

1. Open `chrome://extensions`, turn on **Developer mode**.
2. **Load unpacked** → choose this `desk-extension` folder.
3. On the phone: **ASTRA → More → ASTRA Desk**, turn it on, note the address it shows.
4. Click the ASTRA Desk toolbar icon to open the side panel, type that address, and **Pair**.
5. Check the 6-digit code matches on both screens and confirm on the phone.

Then open the portal page, click **Use this tab**, and start a run from the phone's Automation
Builder, or build one there first.

## Files

| File | What it does |
|---|---|
| `manifest.json` | MV3 manifest. Permissions: storage, scripting, tabs, sidePanel; host access is requested per site at runtime. |
| `desk-core.js` | Pairing + encrypted messaging (Web Crypto). Shared scheme with the phone. |
| `page-agent.js` | Injected into the chosen tab to read/fill fields. No network, no storage access. |
| `background.js` | Opens the side panel when you click the icon. |
| `sidepanel.*` | The panel UI: pairing, status, activity log, review prompts, chat. |
| `test/` | A Node interop test (crypto + protocol against the phone server) and a headless page-agent test. |

Everything here is original work. No third-party JavaScript libraries are bundled or loaded.
