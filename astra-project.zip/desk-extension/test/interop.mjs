// Node interop test: the extension's crypto/protocol against the Kotlin phone server.
import { startPairing, DeskClient, phoneBase } from '../desk-core.js';

const base = phoneBase(process.argv[2] || '127.0.0.1:18765');
const pairing = await startPairing(base, 'Node interop');
console.log(`JS_CODE=${pairing.code}`);
const { id, key } = await pairing.finish({ timeoutMs: 15000 });
const client = new DeskClient(base, id, key);

const chat = await client.chat('namaste');
let gotEcho = false, scanned = false, answered = false;
for (let i = 0; i < 40 && !(gotEcho && scanned && answered); i++) {
  const { messages } = await client.poll(1000);
  for (const m of messages) {
    if (m.type === 'chat_done' && m.chatId === chat.chatId) { gotEcho = m.text === 'echo: namaste'; }
    if (m.type === 'command' && m.op === 'scan') {
      await client.result(m.cmd, { ok: true, snapshot: { url: 'https://portal.test/form', title: 'Loan entry', fields: [
        { selector: '#name', label: 'Member Name', type: 'TEXT' }, { selector: '#save', label: 'Save', type: 'BUTTON' } ] } });
      scanned = true;
    }
    if (m.type === 'ask') { await client.answer(m.ask, 'approve'); answered = true; }
  }
}
console.log(`JS_ECHO=${gotEcho} JS_SCANNED=${scanned} JS_ANSWERED=${answered}`);
if (!gotEcho || !scanned || !answered) process.exit(1);
