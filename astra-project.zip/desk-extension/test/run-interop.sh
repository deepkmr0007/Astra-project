#!/bin/bash
# Runs the Kotlin phone-side server and the JS extension client against each other.
# Usage: run-interop.sh <classpath-with-core-main-and-test-classes>
set -e
CP="$1"; PORT=${2:-18765}
DIR="$(cd "$(dirname "$0")" && pwd)"
LOG=$(mktemp)
java -cp "$CP" ai.astra.core.DeskInteropServer $PORT > "$LOG" 2>&1 &
PID=$!
for i in $(seq 1 50); do grep -q READY "$LOG" && break; sleep 0.2; done
JS=$(node "$DIR/interop.mjs" 127.0.0.1:$PORT)
wait $PID || true
cat "$LOG"; echo "$JS"
KC=$(grep -o 'KOTLIN_CODE=[0-9]*' "$LOG" | cut -d= -f2)
JC=$(echo "$JS" | grep -o 'JS_CODE=[0-9]*' | cut -d= -f2)
[ -n "$KC" ] && [ "$KC" = "$JC" ] || { echo "FAIL: codes differ ($KC vs $JC)"; exit 1; }
grep -q "SCAN_OK=true FIELDS=2 TITLE=Loan entry" "$LOG" || { echo "FAIL: scan"; exit 1; }
grep -q "ANSWER=approve" "$LOG" || { echo "FAIL: answer"; exit 1; }
echo "$JS" | grep -q "JS_ECHO=true JS_SCANNED=true JS_ANSWERED=true" || { echo "FAIL: js"; exit 1; }
echo "INTEROP OK"
