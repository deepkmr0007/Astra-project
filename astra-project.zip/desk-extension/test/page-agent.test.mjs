// Runs page-agent.js in headless Chromium against a realistic ERP-style form.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { astraPageAgent } from '../page-agent.js';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';

const dir = path.dirname(fileURLToPath(import.meta.url));
const browser = await chromium.launch();
const page = await browser.newPage();
await page.goto('file://' + path.join(dir, 'form.html'));
const src = astraPageAgent.toString();
const run = (op, payload) => page.evaluate(([s, o, p]) => (0, eval)('(' + s + ')')(o, p), [src, op, payload]);

const scan = await run('scan', {});
const f = Object.fromEntries(scan.snapshot.fields.map((x) => [x.label, x]));
assert.equal(scan.snapshot.title, 'Loan Entry - e-PACS');
assert.ok(f['Member Name'], JSON.stringify(Object.keys(f)));
assert.equal(f['Member Name'].required, true);
assert.equal(f['Member Name'].selector, '#ctl00_ContentPlaceHolder1_txtName');
assert.equal(f['Father/Husband Name'].selector, 'input[name="ctl00$ContentPlaceHolder1$txtFather"]');
assert.deepEqual(f['Gender'].options, ['--Select--', 'Male', 'Female']);
assert.equal(f['Category'].type, 'RADIO');
assert.deepEqual(f['Category'].options, ['General', 'OBC']);
assert.equal(f['Loan Amount'].type, 'NUMBER');
assert.equal(f['Loan Date'].type, 'DATE');
assert.equal(f['Password'].value, '');
assert.ok(scan.snapshot.fields.some((x) => x.type === 'BUTTON' && x.label === 'Save'));
assert.ok(scan.snapshot.fields.some((x) => x.type === 'BUTTON' && x.label === 'Reset'));

const fills = [
  { selector: f['Member Name'].selector, label: 'Member Name', value: 'Ramesh Kumar', type: 'TEXT' },
  { selector: f['Father/Husband Name'].selector, label: 'Father', value: 'Mohan Lal', type: 'TEXT' },
  { selector: f['Gender'].selector, label: 'Gender', value: 'Female', type: 'SELECT' },
  { selector: f['Loan Date'].selector, label: 'Loan Date', value: '2025-03-07', type: 'DATE' },
  { selector: f['Category'].selector, label: 'Category', value: 'OBC', type: 'RADIO' },
  { selector: f['BPL'].selector, label: 'BPL', value: 'yes', type: 'CHECKBOX' },
  { selector: 'nonexistent', label: 'Loan Amount', value: '25000', type: 'NUMBER' }, // label fallback
  { selector: '#ctrl', label: 'Mobile', value: '9876543210', type: 'TEXT' },
];
for (const x of fills) { const r = await run('fill_one', x); assert.equal(r.found, true, x.label); assert.equal(r.ok, true, x.label + ' ' + r.message); }
const pw = await run('fill_one', { selector: '#pw', label: 'Password', value: 'x', type: 'PASSWORD' });
assert.equal(pw.ok, false);
const bad = await run('fill_one', { selector: '#ddlGender', label: 'Gender', value: 'Other', type: 'SELECT' });
assert.equal(bad.ok, false);
const missing = await run('fill_one', { selector: '#nope', label: 'Does not exist', value: 'x', type: 'TEXT' });
assert.equal(missing.found, false);

const values = await page.evaluate(() => ({
  name: document.querySelector('#ctl00_ContentPlaceHolder1_txtName').value,
  gender: document.querySelector('#ddlGender').value, genderChanged: window.genderChanged,
  dt: document.querySelector('#dt').value, cat: document.querySelector('input[name=cat]:checked')?.value,
  bpl: document.querySelector('#bpl').checked, amt: document.querySelector('#amt').value, ctrl: window.ctrlState, pw: document.querySelector('#pw').value,
}));
assert.deepEqual(values, { name: 'Ramesh Kumar', gender: 'F', genderChanged: 'F', dt: '2025-03-07', cat: 'OBC', bpl: true, amt: '25000', ctrl: '9876543210', pw: '' });

assert.equal((await run('probe', { text: 'saved successfully' })).found, false);
assert.equal((await run('click', { target: 'Save' })).found, true);
await page.waitForTimeout(400);
assert.equal((await run('probe', { text: 'Saved Successfully' })).found, true);
assert.equal((await run('extract', { target: 'Receipt No' })).data, 'RC-2025-0042');
assert.equal((await run('extract', { target: '#msg' })).data, 'Record saved successfully. Receipt No: RC-2025-0042');
await browser.close();
console.log('PAGE AGENT OK');
