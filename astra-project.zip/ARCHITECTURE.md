# ASTRA architecture

ASTRA = **MODEL + MEMORY + CONTEXT + TOOLS + DOCUMENTS + PROJECTS + VOICE + VISION + WEB + SECURITY + AUTOMATION + USER CONTROL**, each behind an interface so it can be replaced without touching the rest.

## Modules

| Module | Kind | Responsibility |
|---|---|---|
| `:core` | Kotlin/JVM library, no Android | Every decision ASTRA makes. Testable on any machine; reusable for desktop/server builds later. |
| `:app` | Android application | Platform adapters (Room, DataStore, Keystore, LiteRT-LM, PDFBox, SpeechRecognizer, TTS, ConnectivityManager…) and the Compose UI. |

The prompt suggested ~19 Gradle modules. They exist as **packages** inside these two modules instead; splitting them into Gradle modules is mechanical once the build is green, and keeping two modules makes the first compile far less fragile.

```
core/ai/astra/core/
  provider/   AiProvider interface (generate, stream, embed, transcribe, speak, vision, toolCall),
              ProviderRegistry, HTTP transport with NetworkGate, OpenAI-compatible + Anthropic adapters, SSE parser
  router/     ModelRouter (LOCAL/ONLINE/HYBRID), TaskAnalyzer, RouterPolicy, DataControl
  security/   PrivacyClassifier (+Verhoeff/Luhn), Redactor, PromptInjectionDetector, UntrustedFence,
              ToolFirewall, PermissionCenter, AuditLog
  memory/     MemoryEngine, MemoryClassifier, Embedder (HashingEmbedder, ProviderEmbedder), MemoryStore port
  context/    ContextEngine (budgeted, source-separated prompt), ConversationCompressor, personality/profile
  documents/  Chunker, DocumentIndex (hybrid retrieval with citations), Text/Office extractors, DocumentStore port
  tools/      Tool interface + ToolSpec, ToolRegistry, text tool-call protocol + stream filter, built-in tools
  agent/      AgentRunner (bounded loop, firewall on every call, self-review pass), TeamRunner + workflows, ActivityItem
  chat/       ChatEngine (orchestration + recovery + transparency trace), ConversationRepository port, ConsentGate
  models/     ModelDescriptor, ModelProfile, ProfileRecommender, capability registry data, checksums
  device/     DeviceState, ThermalGovernor, EnergyMode
  tasks/      TaskGraph (topological order, readiness, progress), TaskBreakdown parser
  plugins/    PluginManifest parser/validator, HttpPluginTool (declarative HTTPS tools)
  web/        Search providers (Wikipedia, DuckDuckGo, Brave, SearXNG, Tavily), WebFetcher (SSRF-safe),
              SourceTrust (authority · recency · relevance · corroboration · conflicts), ResearchPipeline, WebCache, web tools
  vision/     ImageAnalyzer port + ImageAnalysis (OCR text + labels → text for text-only models)
  code/       Myers LineDiff + hunks, CodeBlocks extraction/edit prompts, SyntaxTokens
  automation/ RSS/Atom FeedParser, Briefing selection/prompt
  sync/       EncryptedBundle (PBKDF2 + AES-256-GCM), LwwMerge
  knowledge/  KnowledgeGraphBuilder / KnowledgeGraph
  audio/      WAV header/read/split for chunked transcription
  models/     + ModelCatalog (pinned, SHA-256-verified downloads) 
  export/     astra-export v1 JSON + Markdown, memory import
  diagnostics/Diagnostics ring buffer (redacted)
```

## One chat turn

```
User message
  │
  ├─ explicit "remember…/याद रखना…"? → MemoryEngine (on device, no model) → reply + trace
  │
  ├─ PrivacyClassifier.assess(text)                     (on device)
  ├─ MemoryEngine.recall + profile  ·  DocumentIndex.search   (on device)
  ├─ ModelRouter.route(task, privacy, device, policy, providers)
  │      hard filters: ready · connectivity · private mode · capability · context window
  │      scoring: task fit · complexity · sensitivity · preference · heat · battery · RAM
  │      → provider + LOCAL/ONLINE/HYBRID + reasons + consentRequired + local fallback
  ├─ ConsentGate (UI) if network and policy says ask      ← shows exactly what would be sent
  ├─ ThermalGovernor → max tokens / context fraction
  ├─ ContextEngine.build → SYSTEM | MEMORY | history | «UNTRUSTED documents» | USER
  ├─ AgentRunner: stream → parse <tool_call> → ToolFirewall → tool → «UNTRUSTED result» → …
  │      limits: steps · time · tokens; optional self-review
  ├─ recovery: network failure → on-device model; local crash → report + alternatives (never auto-upload)
  └─ ExecutionTrace (model · where · network/bytes · data sent · tools · speed · reasons · verification)
       persisted with the message; ConversationCompressor folds old turns into a summary
```

## Key design choices

- **Ports and adapters.** `MemoryStore`, `DocumentStore`, `ConversationRepository`, `HttpTransport`, `Embedder`, `AiProvider`, `ConsentGate`, `ConfirmationGate`, `PermissionCenter` are interfaces in `:core`; the app supplies Room/Keystore/Android implementations; tests supply in-memory ones.
- **Defense in depth for privacy.** The router excludes network providers in private mode, *and* every HTTP request passes `NetworkGate.check`, *and* the transport refuses plain HTTP to public hosts. A test proves no request reaches the transport in private mode.
- **Context stays ASTRA's.** On-device inference gets a fresh LiteRT-LM conversation per request seeded from ASTRA's own context, so retrieval, budgeting and injection fencing behave identically across providers.
- **Text tool protocol.** Local models without native function calling use `<tool_call>{json}</tool_call>`; the stream filter hides the markup from the user. Native tool calling can be added per provider later.
- **No fake capabilities.** Providers throw `UNSUPPORTED` for what they can't do; the UI says “Not configured” / “Requires provider”.
- **Determinism where practical.** Classifiers, router, embedder, chunker and calculator are deterministic and explainable.

## Extension points (Section 60)

New runtimes (llama.cpp/GGUF, ONNX Runtime GenAI, NPU delegates) implement `AiProvider`. Neural embeddings plug in via `ProviderEmbedder` + `MemoryEngine.reembed`. Web search becomes a `Tool` with `usesNetwork = true` (the router and firewall already treat such tools as online). Plugins declare tools via `PluginManifest`. Sync can be built on the export format plus an operation log.

## v0.2 additions in the app

| Package | What it adapts |
|---|---|
| `inference/ModelManager` | Android DownloadManager (resumable, survives app death), pending-download journal, SHA-256 verification, auto-activation |
| `vision/MlKitVision` | ML Kit bundled text recognition (Latin + Devanagari) and image labeling → core `ImageAnalyzer` |
| `documents/DocumentImporter` | + image OCR and scanned-PDF OCR (PdfRenderer → ML Kit) |
| `voice/WavRecorder`, `voice/Transcriber` | 16 kHz PCM WAV recording; 30 s chunks → `LiteRtLmProvider.transcribe` (Gemma 4 audio) |
| `files/FolderWorkspace` | Storage Access Framework tree grants → file tools with LOW/MEDIUM/HIGH risk |
| `code/JsSandbox` | androidx.javascriptengine isolated process, heap + time limits → `code_run_js` tool |
| `automation/Automations` | WorkManager periodic briefing, notifications |
| `plugins/PluginStore` | Installed manifests, enable/disable → tool registry |
| `sync/BackupManager` | Encrypted export, merge-restore |
| `notify/NotificationCollector` | NotificationListenerService, in-memory only, gated by a setting |
| `data/AstraDatabase` | SQLCipher `SupportOpenHelperFactory`, random key in the Keystore vault |

Research turn: `/research q` → consent for the search query (per policy) → search → fetch ≤5 pages (cached) → `SourceTrust.assess` → writer chosen by the normal router (on-device preferred) → answer with `[n]` citations validated against real sources → sources list + verification summary → trace marked HYBRID (or ONLINE if the writer is remote).
