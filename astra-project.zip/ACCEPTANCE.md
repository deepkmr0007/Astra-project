# Master acceptance test (Section 73) — status

“Engine test” = automated test in `core/src/test/.../AcceptanceTests.kt` (`MasterAcceptanceTest` unless noted). “On device” = manual step in the app once the APK is built.

| Step | What to do on the phone | Engine coverage |
|---|---|---|
| A. Turn off internet | Airplane mode | `a_to_d_offlineQuestionAnsweredLocally` |
| B. Start ASTRA | Open app (badge shows LOCAL) | — |
| C. Ask a question | Type in chat | ✓ |
| D. Answer from local model | Tap ⓘ: *On device · Network: not used* | ✓ asserts locality + no network |
| E. Save a memory | “remember that my dhani is in Mandhan tehsil” | `e_to_g_memorySurvivesRestartAndIsUsed` (handled with no model) |
| F. Restart application | Swipe away, reopen | ✓ new engine over same store |
| G. Retrieve that memory | Ask “where is my dhani?” | ✓ memory present in prompt |
| H. Import a PDF | Files → + | `h_i_documentQuestionIsGroundedWithCitation` (index + citation); PDF parsing on device |
| I. Ask about the PDF | Ask; trace shows sources, Activity shows “page N” | ✓ |
| J. Analyze an image | Attach a photo or use Camera mode. Gemma 4 sees the image directly; text-only models get on-device OCR + labels | `j_imageNeedsVisionModel`, `VisionFallbackTest` |
| K. Voice input | Tap mic, or hands-free from the + menu; Record & transcribe for meetings | On device only; WAV chunking in `wavSplitKeepsAllAudio` |
| L. Voice output | Tap 🔊 on an answer | On device only |
| M. Re-enable internet | Turn off airplane mode | — |
| N. Switch to online provider | Setup → online preset → Fetch models | `m_to_o_onlineProviderAndComparison`, `listModelsParsesBothShapes` |
| O. Compare local vs online | Long-press answer → Retry with another model; compare traces | ✓ forced local vs online traces |
| P. Execute a safe tool | `/assist`, ask “what is 18% of 2500?” | `p_safeToolRuns`, `AgentTest.calculatorLoopAndVisibleStream` |
| Q. Create a project | Projects → + | `q_s_projectScopeAndExport` (project instructions reach prompt) |
| R. Multi-step task | Project → Add task → Break down with AI | `TaskTest` (graph + parsing) |
| S. Export conversation/memory | Chat ⋮ → Export; Memory ⋮ → Export | `q_s_projectScopeAndExport` (astra-export JSON) |
| T. Delete selected memory | Memory → 🗑 | `t_u_deletedMemoryNeverReachesThePrompt` |
| U. Deleted memory not retrieved | Ask again | ✓ asserted absent from prompt; `MemoryEngineTest.deletedMemoryIsNoLongerRetrieved` |
| V. Private mode prevents network | Settings → Never send; Diagnostics shows gate counters | `v_privateModePreventsAnyNetworkTransmission` (transport receives 0 requests), `RemoteProviderTest.privateModeGateAndTlsEnforcement` |

Additional engine tests: consent declined keeps data local, network loss recovers on device, local model crash is reported (never fabricated), prompt-injection passages withheld, step limits stop runaway agents, firewall blocks high-risk tools in Assist mode.

## v0.2 checks on the phone

| Feature | How to check | Engine coverage |
|---|---|---|
| One-tap model | Setup → Download recommended → notification → chat works in airplane mode | `CatalogAndPresetTest` |
| No-model answers | Before downloading, type “18% of 2500” or “hello astra” | `DirectResponderTest` |
| Web research | `/research latest MSP for bajra` → cited answer, Sources list, trace says HYBRID | `WebTest.*` |
| Team | `/team study plan for UPSC EPFO APFC` → Activity shows each stage; trace shows the Verifier result | `TeamTest` |
| Coding Lab | More → Coding Lab → new `main.js` → “add a function that sums an array” → review diff → approve → Run | `CodeTest` |
| Scanned PDF | Import a scanned PDF → ask about page 2 | (ML Kit on device) |
| Encrypted backup | Settings → Back up now → uninstall/reinstall → Restore / merge | `encryptedBundleRoundTripAndWrongPassword`, `lwwMergeAndBundleRestore` |
| Plugins | Plugins → Install example → enable → Agent mode: “use wiki_summary for Jaipur” | `httpPluginValidatesAndRuns` |
| Knowledge graph | Save a few memories → More → Knowledge graph | `graphLinksPeoplePlacesProjects` |

## v0.3 checks

| Feature | How to check | Automated coverage |
|---|---|---|
| Read records | Builder → Import data: an .xlsx, a CSV, or a photo of a register → preview shows rows/columns | `TablesTest.*` (xlsx round-trip, CSV quirks, OCR/PDF table) |
| Plan from words | Builder → describe a portal job → **Make a plan** → editable steps + questions | `PlannerTest.*` (template + model-plan validated and made safe) |
| Field mapping | After scanning a form, columns like *naam/pita/mobile/ling/dinank/rashi* map to the right fields | `FieldMappingTest.bilingualColumnsMatchFormFields` |
| Value checks | A bad row (empty required, wrong Aadhaar checksum, non-number) is flagged before saving | `FieldMappingTest.preparerBlocksBadRecords…` |
| Human-in-the-loop run | Run with review: Approve/Skip/Stop each record; a blocked row is set aside; resume continues | `RunnerTest.humanInTheLoopRun…`, `dryRunNeverClicksSave…`, `reviewOffRequiresExplicitBatchConsent` |
| ASTRA Desk pairing | Install the extension → type the phone's address → codes match on both → confirm | `DeskTest.endToEndOverHttp`, `ecdhPairingGivesSameKeyAndCode`, `hkdfMatchesRfc5869…`; `desk-extension/test/run-interop.sh` |
| Desk form fill | On a portal tab → **Use this tab** → ASTRA fills mapped fields, not passwords | `desk-extension/test/page-agent.test.mjs` (headless Chromium) |
| Teach a skill | Chat: “when I say daily report, …” or Teach screen → it's used when it applies | `LearnAndLiveTest.teachCommands…`, `skillsMatchAndTrainingExportRedacts` |
| Training export | Teach → Export training data → `astra-training.jsonl`, IDs removed | `skillsMatchAndTrainingExportRedacts` |
| Live mode | Live → tap mic → spoken reply starts early, listens again; tap to interrupt | `speechChunkerSpeaksSentencesEarly…`, `toneReading`, `personaPromptIsHonest…` |
| Exact data answers | Ask “total loan amount by village” about an imported sheet | `TablesTest.tableQueryToolGivesExactNumbers` |
