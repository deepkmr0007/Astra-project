# Plugin API (draft)

Status (v0.2): implemented. Plugins are installed from a JSON file in **More → Plugins**, validated, and their tools registered while enabled. Each tool is an HTTPS action (`http`), so no third-party code ever runs on the phone.

## Manifest

```json
{
  "id": "org.example.mandi",
  "name": "Mandi Prices",
  "version": "1.0.0",
  "permissions": ["internet"],
  "tools": [
    {
      "name": "mandi_price",
      "description": "Today's modal price for a crop at a mandi",
      "risk": "low",
      "network": true,
      "input_schema": {"type": "object", "properties": {"crop": {"type": "string"}, "mandi": {"type": "string"}}, "required": ["crop"]},
      "http": {"method": "GET", "url": "https://api.example.org/price?crop={crop}&mandi={mandi}"}
    }
  ],
  "ui": ["chat_card"]
}
```

Rules enforced by the validator (all problems reported at once):

- `id` reverse-DNS, `version` semver, `name` required.
- `permissions` from: MICROPHONE, CAMERA, FILES, LOCATION, CONTACTS, NOTIFICATIONS, INTERNET, BACKGROUND, EXTERNAL_SERVICES, MEMORY, DOCUMENTS.
- Tool names snake_case and unique; `risk` one of LOW/MEDIUM/HIGH/CRITICAL; a tool with `"network": true` requires the INTERNET permission.
- `ui` from: `settings_panel`, `chat_card`, `share_action`.
- `http.method` GET or POST; `http.url` must be `https://`; every `{placeholder}` in the URL or `body` must be a property in `input_schema`; optional `headers` (static) and `body` (JSON template).
- Arguments are URL-encoded into the URL; responses are capped (64 KB read, 4,000 characters returned) and fenced as untrusted tool output.

A working keyless example (Wikipedia page summaries) is built in: **Plugins → Install example**.

## Runtime contract

A plugin tool is a `Tool` (`ai.astra.core.tools.Tool`): `spec` (name, description, schemas, risk, permissions, environment, usesNetwork) and `suspend fun run(args): ToolResult`. Every call goes through the same `ToolFirewall` as built-in tools, so a plugin can never exceed the permissions the user grants, and CRITICAL actions always require explicit confirmation. Plugin output is fenced as untrusted data before the model sees it.
