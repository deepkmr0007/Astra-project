# ASTRA — User Manual (v0.3.1)

ASTRA is your personal AI that lives on your phone. It works offline with a model on the phone, and can use online models only when you allow it. This manual covers installing, first setup, everyday use, and the v0.3 features: the Automation Builder, ASTRA Desk, phone automations, Teach & Learn, and Live mode.

---

## 1. What you need

- An Android phone with **Android 12 or newer**. 6 GB RAM or more is best for the recommended on-device model (4 GB phones can use the small models).
- About **3 GB free storage** for the recommended model.
- A **GitHub account** (free) to build the app from the project zip — no computer needed.
- For ASTRA Desk: a computer with **Chrome or Edge**, on the same Wi-Fi as the phone.

---

## 2. Build and install (from your phone)

You already have a GitHub repository from earlier versions. Do these steps **in order**:

1. **Replace the workflow file** (do this first, once). In your repo, open the folder `.github/workflows` → **Add file → Upload files** → choose the file `build-from-zip.yml` (sent alongside the zip; also inside the zip under `tools/`) → **Commit changes**. It replaces the old one because the name is the same.
   *How to tell it worked:* the next run's warnings no longer mention `actions/checkout@v4` or `ubuntu-latest`.
2. **Remove old zips.** In the repo's main page, if you see more than one zip (for example `astra-project (1).zip`), open each extra one → ⋯ → **Delete file** → Commit. Keep only one.
3. **Upload the new zip**: back on the main page, **Add file → Upload files** → choose `astra-project.zip` → **Commit changes**. If your phone renamed it (e.g. "astra-project (1).zip"), rename it back first, or just make sure the old zip is deleted (step 2).
4. Open the **Actions** tab and tap the **newest** run at the top — the one started by your upload. **Don't** use *Re-run jobs* on an older failed run: that rebuilds the old code.
5. Check the run's **Summary**: it says **"Building ASTRA 0.3.1"**. (The build log also prints this banner.) If it shows an older version, the old zip was built — repeat steps 2–3.
6. When the run is green (about 15 minutes), open **Releases** → newest *ASTRA build* → download the `.apk` → open it → allow "install unknown apps" if asked → **Install**.

**Updating:** v0.2/v0.3 → v0.3.1 installs over the top and keeps your data (the database upgrades itself). Only if you ever installed **v0.1**, uninstall that once first.

**If a build fails:** open the failed run → **Summary** → there is a box titled *ASTRA build errors*. Screenshot that box (and the "Building ASTRA …" line above it) and send it. The full log is also under *Artifacts → build-log*.

---

## 3. First run — give ASTRA a brain

ASTRA opens the **Setup** screen the first time.

- **On-device (private, works offline):** tap **Download** on the recommended model (Gemma 4 E2B, 2.6 GB; use Wi-Fi). You get a notification when it's ready; it loads automatically.
- **Online (smarter, needs internet):** choose a preset (e.g. Google Gemini) → *Get an API key* → paste it → **Fetch models** → Save.
- You can have both. ASTRA picks per message and tells you which one answered.

Even with no model, ASTRA answers calculations, unit conversions, dates and your saved memories.

---

## 4. Everyday chat

- **Badge** at the top: **LOCAL** (on the phone), **ONLINE**, or **HYBRID**. Tap **ⓘ** under any answer to see exactly which model answered, where, and what was sent.
- **Modes:** `/chat` (just answers), `/assist` (may use safe tools like the calculator), `/agent` (multi-step; anything risky asks you first).
- Type `/` to see every command. Useful ones: `/research`, `/team`, `/remember`, `/memory`, `/file`, `/camera`, `/record`.
- **Attach** a photo or document with the **+** button, or share into ASTRA from any app ("Ask ASTRA").
- 👍 / 👎 under an answer saves it as feedback (used later for Teach & Learn). Long-press an answer to copy, regenerate, continue, retry with another model, branch, or delete it.

To reach the new v0.3 tools: open the **More** (⊞) menu in the bottom bar, or type the slash command. Each is also its own screen.

---

## 5. Automation Builder — `/build`

Have ASTRA do a repetitive data-entry job for you. The classic example: entering many records into an ERP/portal (like e-PACS).

**The golden rule:** you stay in control. You log in, you type any CAPTCHA or OTP, and you approve every record before it is saved. ASTRA does the typing in between.

### Step by step

1. **Describe the job** in plain words (English, Hindi or Hinglish). Example: *"Enter these loan records into the e-PACS portal and save each one. I'll log in and type the OTP."*
2. Choose **On the computer** (a website — needs ASTRA Desk, see §6) or **On this phone** (another app — needs §7).
3. Tap **Make a plan**. ASTRA writes an editable list of steps and asks about anything it needs (the portal address, which column goes where, what the page shows after a save). You can rename it and change any field mapping; to change the steps themselves, adjust your description and tap **Make a plan** again.
4. **Import your records** (the *Records* card): an **Excel/CSV** file, a **PDF**, or a **photo of a paper register**. ASTRA reads the rows on the phone (OCR for photos/PDFs) and shows a preview. Pick the one to use.
5. **Read the form:** open the entry page on the computer, in ASTRA Desk click **Use this tab**, then on the phone tap **Read the form on the computer**. ASTRA matches your columns to the form's fields (it understands names like *naam/name*, *pita/father*, *dinank/date*, *rashi/amount*). Fix any mapping by editing the box under each field — put a column in `{curly braces}` or type a fixed value.
6. Tap **Run**.

### During a run

- When it's your turn (log in, CAPTCHA, OTP, or a manual save), ASTRA pauses and shows **"Over to you"** — do that step, then tap **Continue**.
- Before each record is saved you see **Review record N of M** with every value filled in. Tap **Approve & save**, **Skip**, or **Stop**. Values with a problem (missing required field, wrong Aadhaar checksum, a date that doesn't parse) are flagged; a bad record is set aside, not saved.
- A live log shows each step. You can **Stop** at any moment.
- If three records fail in a row, ASTRA pauses so you can check the page.

### After a run

- You get a summary: *done / failed / skipped / need fixing*.
- A **run report** is saved as a new data table (your rows plus a Status and Message column, and anything ASTRA read back like a receipt number). It appears in the *Records* list, and you can ask ASTRA about it in chat (for example *"how many records failed and why?"*).
- Saved automations appear at the bottom — tap to run again, or ▶ to run without re-planning. An interrupted run resumes where it stopped.

**Fill-only mode:** if you'd rather click Save yourself, say so in the description ("only fill, I'll save"). ASTRA fills each record and waits while you save.

---

## 6. ASTRA Desk — link your computer's browser (`/desk`)

This lets ASTRA read and fill forms in your computer's Chrome, and lets you chat with ASTRA from the computer. The link runs over your home Wi-Fi and is **end-to-end encrypted** — it never goes through the internet or any server.

### On the computer (one time)

1. Get the `desk-extension` folder onto the computer (it's inside the project zip).
2. Open **chrome://extensions**, turn on **Developer mode** (top right), click **Load unpacked**, and choose the `desk-extension` folder.
3. Click the ASTRA Desk icon in the toolbar — a side panel opens.

### Pair with the phone

1. On the phone: **More → ASTRA Desk**, turn on **Link my computer**. It shows an address like `192.168.1.20:8765`.
2. In the computer's side panel, type that address and a name for the computer, then click **Pair**.
3. Both screens show a **6-digit code**. Check they match, then tap **Codes match — pair** on the phone. Done — they stay paired.

Both devices must be on the **same Wi-Fi** (a phone hotspot the computer joins also works). If the phone shows "Not on Wi-Fi", connect it first.

### Using it

- On the portal page, click **Use this tab** so ASTRA only acts there. Grant the site when asked.
- Run an automation from the phone's Builder (§5), or just chat in the side panel.
- ASTRA never fills password fields and only touches the tab you chose. Review prompts appear on **both** the phone and the computer — answer on either.
- **Unpair** any time from the phone's ASTRA Desk screen.

---

## 7. Phone automations (optional) — turn on in Accessibility

For automating other **apps on the phone** (not websites), ASTRA uses Android's Accessibility service. This is **off by default**.

1. In the Builder choose **On this phone**, or go to Android **Settings → Accessibility → ASTRA phone automation → turn on**.
2. Android warns that the service can read the screen and tap for you. ASTRA uses this **only while a run you started is active**, shows each step, and stops instantly when you tap Stop. It never reads the screen at other times and never touches password fields.
3. Build the automation the same way, with TYPE/TAP steps for the app's screen.

You can revoke it at any time in the same Accessibility settings.

---

## 8. Teach & Learn — `/teach`

Two ways ASTRA gets better at *your* work. Nothing here leaves your phone.

### Skills (instant, no training)

Teach ASTRA a habit in plain words and she follows it whenever it applies:

- In chat: *"when I say daily report, summarise today's tasks in 5 bullets"* (works in Hindi/Hinglish too: *"jab main hisaab bolun to aaj ke kharche ka total batao"*).
- Or the **Teach** screen: give it a name, the trigger words, and what to do.
- See, switch off, or delete your skills on the Teach screen. Turn all skills off with one switch.

### Train a personal model (advanced, on a computer)

ASTRA can't fine-tune a big model on a phone, so this is optional and done on a PC:

1. Rate answers 👍/👎 — every rating is saved (👍 answers become training examples).
2. Teach → **Export training data** → you get `astra-training.jsonl` (obvious personal details like Aadhaar/cards/phones are removed first; review it yourself).
3. On a computer, follow `tools/train/README.md` to train a small LoRA adapter, then import the result on the phone in **Models → Import**.

---

## 9. Live mode & Persona — `/live`

A hands-free spoken conversation.

- Open **Live**, tap the **mic**. Speak naturally; ASTRA starts replying as soon as the first sentence is ready and listens again when she finishes. Tap while she's speaking to interrupt.
- She reads the tone of what you say and adjusts (calmer when you're stressed, step-by-step when you're confused).
- **Persona** (the button in Live, or `/persona`): set her **name**, what she **calls you**, her **style** (warm / professional / playful / calm / mentor), and her **speaking speed and pitch**.
- ASTRA is honest: she's an AI companion — warm and understanding, but she won't pretend to be human or to have feelings she doesn't have.

Live mode needs microphone permission (asked the first time) and works best with an on-device model so it's fast and private.

---

## 10. Privacy in one minute

- Default: **everything stays on your phone**. No account, no tracking.
- ASTRA asks before sending anything to an online model, and the **ⓘ** trace shows what was sent.
- Settings → Privacy → **"Never send my data online"** forces everything on-device.
- API keys and the ASTRA Desk encryption key are stored in the phone's secure keystore and are never included in backups or exports.
- The whole database is encrypted (SQLCipher). Back it up from Settings → Back up now.

---

## 11. Quick fixes

| Problem | Fix |
|---|---|
| "No model configured" | Setup → download a model, or add an online key. |
| Build failed on GitHub | Open the run → Summary → screenshot the *ASTRA build errors* box → send it. |
| ASTRA Desk won't connect | Same Wi-Fi? Address typed correctly (with `:8765`)? "Link my computer" on? Re-open the portal and click *Use this tab*. |
| A field isn't filled | Open the plan, check the mapping box for that field; click *Read the form* again if the page changed. |
| Phone automation does nothing | Settings → Accessibility → ASTRA turned on? It only runs during a run you started. |
| It saved a wrong record | Turn on review (it's on by default) so you approve each one; fix the data row and re-run — done rows are skipped. |
| Model feels slow | Use a smaller model (Qwen3 0.6B), close other apps, or keep the phone cool and charged. |

---

*ASTRA is yours. It won't do anything you didn't ask for, it won't hide what it sent, and it won't pretend to be more than it is.*
