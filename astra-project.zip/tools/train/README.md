# ASTRA personal fine-tuning kit (run on a computer)

Phones can't fine-tune a multi-billion-parameter model in reasonable time, so ASTRA trains a small
**LoRA adapter** on your computer from the data you export in the app (**Teach & Learn → Export
training data**), and then you load that adapter back on the phone. Nothing here is required for
ASTRA to work — it already learns from saved skills and corrections without any training.

What the adapter changes: your wording, your formats, the way you like answers. It does **not** add
new world knowledge, and it can't make the phone run a bigger model than it already can.

## What you need

- A computer with Python 3.10+ (a GPU helps but is optional for tiny models).
- The file `astra-training.jsonl` you exported from the app (chat-format, one JSON object per line).
- A base model you are allowed to fine-tune. Use the same family you run on the phone (for example a
  Gemma or Qwen instruct model) so the adapter is compatible.

## Steps

```bash
cd tools/train
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt

# 1. Check and clean the dataset (dedupe, drop empty, report size).
python prepare.py --in ~/Downloads/astra-training.jsonl --out data.jsonl

# 2. Train a LoRA adapter (see train.py --help for all options).
python train.py --base <base-model-id-or-path> --data data.jsonl --out astra-adapter

# 3. Convert/quantise for the phone runtime (LiteRT-LM). See convert.py for notes;
#    export the merged or adapter weights to the .litertlm your phone loads.
python convert.py --adapter astra-adapter --base <base-model> --out astra-personal.litertlm
```

Copy `astra-personal.litertlm` to the phone and import it in **Models → Import**. If your runtime
supports loading an adapter separately (LiteRT-LM `LoraConfig`), import the adapter and point it at
the base model instead of merging.

## Privacy

The exporter removes obvious personal identifiers (Aadhaar, PAN, cards, phones, emails) by default,
but **you own this data** — review `data.jsonl` before training, and don't upload it to a service
you don't trust. Training here happens entirely on your computer.

`requirements.txt`, `prepare.py`, `train.py` and `convert.py` are starting points; adjust them to
your base model and hardware. They are intentionally small and readable.
