#!/usr/bin/env python3
"""Notes + helper for turning the trained adapter into something the phone can load.

The exact conversion depends on the on-device runtime version you target:

  * LiteRT-LM: convert the base model to .litertlm with Google's ai-edge-torch / LiteRT converter,
    then either (a) merge the LoRA weights into the base and convert the merged model, or
    (b) keep the adapter separate and load it on the phone via LiteRT-LM's LoraConfig.
  * llama.cpp (.gguf): merge with `peft` then convert with llama.cpp's convert script and quantise.

This script only does the framework-agnostic first step: merge the adapter into the base and save a
standard HF model you can then feed to your converter of choice.
"""
import argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--out", default="astra-merged")
    a = ap.parse_args()
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
    base = AutoModelForCausalLM.from_pretrained(a.base, torch_dtype=torch.float16)
    merged = PeftModel.from_pretrained(base, a.adapter).merge_and_unload()
    merged.save_pretrained(a.out)
    AutoTokenizer.from_pretrained(a.base).save_pretrained(a.out)
    print(f"Merged model saved to {a.out}. Now convert it to your phone format (.litertlm / .gguf).")

if __name__ == "__main__":
    main()
