#!/usr/bin/env python3
"""Train a LoRA adapter from an ASTRA chat-format dataset.

Deliberately small and readable — edit target_modules/hyper-params for your base model.
"""
import argparse, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True, help="HF model id or local path (match the phone's model family)")
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="astra-adapter")
    ap.add_argument("--epochs", type=float, default=3.0)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--max-len", type=int, default=1024)
    a = ap.parse_args()

    import torch
    from datasets import load_dataset
    from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments
    from peft import LoraConfig
    from trl import SFTTrainer

    tok = AutoTokenizer.from_pretrained(a.base)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    ds = load_dataset("json", data_files=a.data, split="train")

    def fmt(ex):
        # Use the model's own chat template so the adapter matches how the phone prompts it.
        return {"text": tok.apply_chat_template(ex["messages"], tokenize=False, add_generation_prompt=False)}
    ds = ds.map(fmt, remove_columns=ds.column_names)

    model = AutoModelForCausalLM.from_pretrained(a.base, torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32)
    peft = LoraConfig(r=a.rank, lora_alpha=a.rank * 2, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM",
                      target_modules=["q_proj", "k_proj", "v_proj", "o_proj"])
    args = TrainingArguments(output_dir=a.out, num_train_epochs=a.epochs, learning_rate=a.lr,
                             per_device_train_batch_size=1, gradient_accumulation_steps=8,
                             logging_steps=10, save_strategy="epoch", bf16=torch.cuda.is_available(), report_to=[])
    trainer = SFTTrainer(model=model, args=args, train_dataset=ds, peft_config=peft,
                         dataset_text_field="text", max_seq_length=a.max_len, tokenizer=tok)
    trainer.train()
    trainer.save_model(a.out)
    tok.save_pretrained(a.out)
    print(f"Saved LoRA adapter to {a.out}")

if __name__ == "__main__":
    main()
