#!/usr/bin/env python3
"""Validate and clean an ASTRA training export (chat-format JSONL)."""
import argparse, json, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", default="data.jsonl")
    a = ap.parse_args()
    seen, kept, bad = set(), [], 0
    with open(a.inp, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
                msgs = o["messages"]
                assert isinstance(msgs, list) and len(msgs) >= 2
                assert any(m["role"] == "user" and m["content"].strip() for m in msgs)
                assert any(m["role"] == "assistant" and m["content"].strip() for m in msgs)
            except Exception:
                bad += 1
                continue
            key = json.dumps(msgs, sort_keys=True, ensure_ascii=False)
            if key in seen:
                continue
            seen.add(key)
            kept.append(o)
    with open(a.out, "w", encoding="utf-8") as f:
        for o in kept:
            f.write(json.dumps(o, ensure_ascii=False) + "\n")
    print(f"kept {len(kept)} examples, dropped {bad} malformed, {len(seen)} unique -> {a.out}")
    if len(kept) < 20:
        print("WARNING: very few examples. A few hundred is a better minimum for noticeable effect.", file=sys.stderr)

if __name__ == "__main__":
    main()
