package ai.astra.app

import ai.astra.app.ui.MainActivity
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** UI smoke test: the app starts offline with no model and shows the chat with a LOCAL/HYBRID badge. */
@RunWith(AndroidJUnit4::class)
class LaunchTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun startsAndShowsAstra() {
        rule.waitForIdle()
        assertTrue(rule.onAllNodesWithText("ASTRA").fetchSemanticsNodes().isNotEmpty())
    }
}
