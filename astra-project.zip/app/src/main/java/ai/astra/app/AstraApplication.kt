package ai.astra.app

import ai.astra.app.security.SecretStore
import android.app.Application
import android.util.Log

class AstraApplication : Application() {
    lateinit var container: AppContainer
        private set

    /** Why startup failed, shown on screen by MainActivity instead of crashing the app. */
    var startupError: Throwable? = null
        private set

    val isReady: Boolean get() = ::container.isInitialized

    override fun onCreate() {
        super.onCreate()
        start()
    }

    /** Builds the app once. Never throws: on failure the error is kept for the startup screen. */
    @Synchronized
    fun start(): Boolean {
        if (isReady) return true
        return try {
            container = AppContainer(this)
            startupError = null
            true
        } catch (t: Throwable) {
            startupError = t
            Log.e("ASTRA", "Startup failed", t)
            false
        }
    }

    /**
     * Last resort when the vault can't be opened: deletes the vault keys and the values sealed
     * with them (API keys, paired computers) and sets the encrypted database aside (renamed, not
     * deleted), then starts again. Settings and downloaded models are not touched.
     */
    @Synchronized
    fun resetSecureStorage(): Boolean {
        SecretStore.wipe(this)
        AppContainer.setAsideDatabase(this)
        return start()
    }
}
