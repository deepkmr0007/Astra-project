package ai.astra.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class ListenState { IDLE, LISTENING, PROCESSING, ERROR }

/**
 * Speech-to-text through Android's recognition service, preferring the on-device recognizer.
 * Listening happens only while the user holds/taps the mic or has explicitly turned on
 * hands-free mode; the platform recognizer does voice-activity detection and end-pointing.
 * A local Whisper engine can be plugged in behind the same API later.
 */
class SpeechInput(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private val _state = MutableStateFlow(ListenState.IDLE)
    val state: StateFlow<ListenState> = _state.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    var onDeviceRecognizer: Boolean = false
        private set

    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String?, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        stop()
        onDeviceRecognizer = SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        val r = if (onDeviceRecognizer) SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = ListenState.LISTENING }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _state.value = ListenState.PROCESSING }
            override fun onError(error: Int) {
                _state.value = ListenState.ERROR
                onError(errorText(error))
                _state.value = ListenState.IDLE
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                _partial.value = ""
                _state.value = ListenState.IDLE
                if (text.isNotBlank()) onFinal(text) else onError("Didn't catch that")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                _partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            languageTag?.let { putExtra(RecognizerIntent.EXTRA_LANGUAGE, it) }
        }
        r.startListening(intent)
    }

    fun stop() {
        recognizer?.run { runCatching { stopListening() }; runCatching { destroy() } }
        recognizer = null
        _state.value = ListenState.IDLE
        _level.value = 0f
    }

    private fun errorText(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service needs internet for this language (no offline pack installed)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off"
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "This language isn't available offline on this phone"
        else -> "Speech recognition error ($code)"
    }
}

/** Text-to-speech through the installed platform engine (offline voices where installed). */
class SpeechOutput(context: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status -> ready = status == TextToSpeech.SUCCESS }
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()
    var onFinished: (() -> Unit)? = null

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { _speaking.value = true }
            override fun onDone(utteranceId: String?) { _speaking.value = false; onFinished?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { _speaking.value = false }
        })
    }

    fun voices(): List<Voice> = if (ready) tts.voices?.sortedBy { it.name }.orEmpty() else emptyList()

    fun setVoice(name: String?) { voices().firstOrNull { it.name == name }?.let { tts.voice = it } }

    fun setRate(rate: Float) { runCatching { tts.setSpeechRate(rate.coerceIn(0.5f, 2.0f)) } }
    fun setPitch(pitch: Float) { runCatching { tts.setPitch(pitch.coerceIn(0.5f, 2.0f)) } }

    fun speak(text: String, locale: Locale? = null) {
        if (!ready) return
        locale?.let { tts.language = it }
        val clean = text.replace(Regex("[*_`#>]+"), "").replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
        clean.chunked(3500).forEachIndexed { i, part ->
            tts.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "astra-$i-${System.nanoTime()}")
        }
    }

    /** Barge-in: the user starts talking or taps stop. */
    fun stop() { tts.stop(); _speaking.value = false }

    fun shutdown() { tts.shutdown() }
}
