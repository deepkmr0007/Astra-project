package ai.astra.app.ui.builder

import ai.astra.app.AppContainer
import ai.astra.core.builder.AutomationDriver
import ai.astra.core.builder.AutomationRunner
import ai.astra.core.builder.AutomationSpec
import ai.astra.core.builder.AutomationTarget
import ai.astra.core.builder.Clarification
import ai.astra.core.builder.DriverCommand
import ai.astra.core.builder.FieldMapping
import ai.astra.core.builder.FormSnapshot
import ai.astra.core.builder.PlanResult
import ai.astra.core.builder.PreparedRecord
import ai.astra.core.builder.RequirementPlanner
import ai.astra.core.builder.RunEvent
import ai.astra.core.builder.RunHost
import ai.astra.core.builder.RunLedger
import ai.astra.core.builder.RunOptions
import ai.astra.core.builder.ReviewDecision
import ai.astra.core.builder.Step
import ai.astra.core.data.DataTable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** On-screen review: the filled record and any problems, awaiting the user's decision. */
data class ReviewState(val record: PreparedRecord, val data: Map<String, String>, val position: Int, val total: Int, val answer: CompletableDeferred<ReviewDecision>)
data class ContinueState(val message: String, val answer: CompletableDeferred<Boolean>)

class BuilderViewModel(private val c: AppContainer) : ViewModel(), RunHost {
    val savedAutomations = c.automationStore.observe()
    val dataTables = c.tableStore.observe()

    // Draft being edited.
    val requirement = MutableStateFlow("")
    val target = MutableStateFlow(AutomationTarget.BROWSER)
    val selectedTable = MutableStateFlow<String?>(null)
    val plan = MutableStateFlow<AutomationSpec?>(null)
    val questions = MutableStateFlow<List<Clarification>>(emptyList())
    val planWarnings = MutableStateFlow<List<String>>(emptyList())
    val planOrigin = MutableStateFlow("")
    val form = MutableStateFlow<FormSnapshot?>(null)
    val busy = MutableStateFlow(false)
    val toast = MutableStateFlow<String?>(null)

    // Run state.
    val runLog = MutableStateFlow<List<RunEvent>>(emptyList())
    val running = MutableStateFlow(false)
    val review = MutableStateFlow<ReviewState?>(null)
    val continuePrompt = MutableStateFlow<ContinueState?>(null)
    val lastSummary = MutableStateFlow<String?>(null)
    private var runJob: Job? = null

    private fun driver(spec: AutomationSpec): AutomationDriver = if (spec.target == AutomationTarget.PHONE) c.phoneDriver else c.desk.driver

    private suspend fun table(): DataTable? = selectedTable.value?.let { c.tableStore.get(it) }

    fun editPlan(transform: (AutomationSpec) -> AutomationSpec) { plan.value = plan.value?.let(transform)?.copy(updatedAt = System.currentTimeMillis()) }

    /** Build an editable plan from the requirement, with or without a model. */
    fun makePlan() {
        if (requirement.value.isBlank()) { toast.value = "Describe what ASTRA should do"; return }
        viewModelScope.launch {
            busy.value = true
            try {
                val t = table()
                val f = form.value ?: c.desk.lastForm.value
                val prompt = RequirementPlanner.prompt(requirement.value, t, f, taughtSummary())
                val model = runCatching { c.engine.oneShot(prompt, 1200) }.getOrNull()?.getOrNull()
                val result: PlanResult = (model?.let { RequirementPlanner.parse(it, requirement.value, t, f) })
                    ?: RequirementPlanner.draft(requirement.value, t, f).also { if (model != null) planWarnings.value = listOf("Used the built-in planner (the model's plan wasn't usable).") }
                applyPlan(result)
            } finally { busy.value = false }
        }
    }

    private fun applyPlan(r: PlanResult) {
        plan.value = r.spec.copy(target = target.value)
        questions.value = r.questions
        planWarnings.value = (planWarnings.value + r.warnings).distinct()
        planOrigin.value = r.origin
        target.value = r.spec.target
    }

    /** Ask the paired computer to read the current form, then re-map columns to its fields. */
    fun scanForm() {
        viewModelScope.launch {
            busy.value = true
            try {
                if (!c.desk.connected.value) { toast.value = "Open ASTRA Desk on your computer and point it at the entry form"; return@launch }
                val r = c.desk.driver.execute(DriverCommand.Scan)
                val snap = r.snapshot ?: c.desk.lastForm.value
                if (snap == null) { toast.value = r.message.ifBlank { "Couldn't read the form" }; return@launch }
                form.value = snap
                remap(snap)
                toast.value = "Read ${snap.inputs.size} fields from ${snap.title}"
            } finally { busy.value = false }
        }
    }

    private suspend fun remap(snap: FormSnapshot) {
        val t = table() ?: return
        val maps = RequirementPlanner.mappingsFor(t.headers, snap)
        plan.value = (plan.value ?: RequirementPlanner.draft(requirement.value, t, snap).spec).copy(mappings = maps, expectedColumns = t.headers, target = AutomationTarget.BROWSER)
        questions.value = plan.value?.let { RequirementPlanner.questions(it, requirement.value, t, snap) }.orEmpty()
    }

    fun setMapping(selector: String, template: String) {
        editPlan { spec -> spec.copy(mappings = spec.mappings.map { if (it.selector == selector) it.copy(template = template) else it }) }
    }

    fun save() {
        val spec = plan.value ?: return
        viewModelScope.launch {
            val problems = spec.problems()
            if (problems.isNotEmpty()) { toast.value = problems.first(); return@launch }
            c.automationStore.save(spec)
            toast.value = "Saved “${spec.name}”"
        }
    }

    fun load(spec: AutomationSpec) {
        plan.value = spec; requirement.value = spec.goal; target.value = spec.target
        questions.value = emptyList(); planWarnings.value = emptyList(); form.value = null
    }

    fun deleteAutomation(id: String) { viewModelScope.launch { c.automationStore.delete(id) } }

    fun run(spec: AutomationSpec, resume: RunLedger? = null) {
        if (running.value) return
        runJob = viewModelScope.launch {
            running.value = true; c.desk.setRunning(true); runLog.value = emptyList(); lastSummary.value = null
            try {
                val drv = driver(spec)
                if (!drv.ready()) { toast.value = if (spec.target == AutomationTarget.PHONE) "Turn on ASTRA in Settings → Accessibility" else "Connect the computer in ASTRA Desk first"; return@launch }
                val t = table()
                val ledger = resume ?: RunLedger(automationId = spec.id, source = t?.origin ?: "", total = t?.size ?: 1)
                val runner = AutomationRunner(spec, t, drv, this@BuilderViewModel, ledger, onProgress = { c.automationStore.saveLedger(it) })
                val s = runner.run()
                lastSummary.value = "${s.done} done · ${s.failed} failed · ${s.skipped} skipped · ${s.blocked} need fixing"
                // Offer the run report as a data table the user can export.
                if (t != null) c.tableStore.save(ledger.report(t))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                toast.value = "Run error: ${e.message}"
            } finally {
                running.value = false; c.desk.setRunning(false); review.value = null; continuePrompt.value = null
            }
        }
    }

    fun stop() { runJob?.cancel(); running.value = false; c.desk.setRunning(false); review.value = null; continuePrompt.value = null }

    // ---------- RunHost (called from the runner; answered by the UI or the computer) ----------

    override suspend fun waitForUser(message: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        continuePrompt.value = ContinueState(message, d)
        val onDesk = viewModelScope.launch(Dispatchers.Default) {
            val ans = c.desk.hub.ask("continue", "ASTRA is waiting", message, listOf("continue", "stop"))
            if (ans != null && !d.isCompleted) d.complete(ans == "continue")
        }
        return try { d.await() } finally { onDesk.cancel(); continuePrompt.value = null }
    }

    override suspend fun review(record: PreparedRecord, data: Map<String, String>, position: Int, total: Int): ReviewDecision {
        val d = CompletableDeferred<ReviewDecision>()
        review.value = ReviewState(record, data, position, total, d)
        val onDesk = viewModelScope.launch(Dispatchers.Default) {
            val fields = record.values.map { it.label to it.value }
            val ans = c.desk.hub.ask("review", "Record $position of $total", record.issues.joinToString("\n") { "${it.field}: ${it.message}" }, listOf("approve", "skip", "stop"), fields)
            if (ans != null && !d.isCompleted) d.complete(when (ans) { "skip" -> ReviewDecision.Skip; "stop" -> ReviewDecision.Stop; else -> ReviewDecision.Approve })
        }
        return try { d.await() } finally { onDesk.cancel(); review.value = null }
    }

    override suspend fun confirmUnreviewedSaves(count: Int): Boolean {
        val d = CompletableDeferred<Boolean>()
        continuePrompt.value = ContinueState("Save all $count records without reviewing each one? This cannot be undone.", d)
        return try { d.await() } finally { continuePrompt.value = null }
    }

    override fun event(e: RunEvent) { runLog.value = (runLog.value + e).takeLast(300) }

    fun answerReview(decision: ReviewDecision) { review.value?.answer?.complete(decision) }
    fun answerContinue(go: Boolean) { continuePrompt.value?.answer?.complete(go) }

    // ---------- data import ----------

    fun importTable(table: DataTable) { viewModelScope.launch { c.tableStore.save(table); selectedTable.value = table.name; toast.value = "Imported ${table.size} rows from ${table.name}" } }
    fun deleteTable(name: String) { viewModelScope.launch { c.tableStore.delete(name); if (selectedTable.value == name) selectedTable.value = null } }

    private suspend fun taughtSummary(): String = c.skillStore.all().filter { it.enabled }.joinToString("\n") { "- ${it.name}: ${it.instructions.take(120)}" }
}
