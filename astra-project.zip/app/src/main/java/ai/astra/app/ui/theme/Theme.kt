package ai.astra.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// "Night sky over the Aravallis": deep ink, teal signal, saffron accent.
val Teal = Color(0xFF5EEAD4)
val Saffron = Color(0xFFF59E0B)
val LocalGreen = Color(0xFF34D399)
val OnlineBlue = Color(0xFF60A5FA)
val HybridViolet = Color(0xFFC084FC)
val Danger = Color(0xFFF87171)

private val Dark = darkColorScheme(
    primary = Teal, onPrimary = Color(0xFF042F2E),
    secondary = Saffron, onSecondary = Color(0xFF3B2400),
    tertiary = HybridViolet,
    background = Color(0xFF0B0F1A), onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF0F1524), onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF1A2236), onSurfaceVariant = Color(0xFFA9B4C8),
    surfaceContainer = Color(0xFF131A2B), surfaceContainerHigh = Color(0xFF1A2236), surfaceContainerHighest = Color(0xFF222B42),
    outline = Color(0xFF3A4660), error = Danger,
)

private val Light = lightColorScheme(
    primary = Color(0xFF0F766E), onPrimary = Color.White,
    secondary = Color(0xFFB45309), onSecondary = Color.White,
    tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF7F8FB), onBackground = Color(0xFF0B0F1A),
    surface = Color.White, onSurface = Color(0xFF0B0F1A),
    surfaceVariant = Color(0xFFE7EBF3), onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1), error = Color(0xFFDC2626),
)

private val Mono = FontFamily.Monospace

val AstraTypography = Typography().let { t ->
    t.copy(
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp),
        labelSmall = TextStyle(fontFamily = Mono, fontSize = 11.sp, letterSpacing = 0.8.sp, fontWeight = FontWeight.Medium),
    )
}

@Composable
fun AstraTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = AstraTypography, content = content)
}
