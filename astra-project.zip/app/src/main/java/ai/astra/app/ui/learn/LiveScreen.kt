@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package ai.astra.app.ui.learn

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.SectionTitle
import ai.astra.app.ui.chat.ChatViewModel
import ai.astra.core.live.Persona
import ai.astra.core.live.PersonaStyle
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

/**
 * Live mode: a hands-free, spoken conversation. ASTRA starts speaking as soon as the first
 * sentence is ready, listens again when she finishes, and you can tap to interrupt. Honest by
 * design — she's an AI companion, warm but never pretending to be human.
 */
@Composable
fun LiveScreen(c: AppContainer, onBack: () -> Unit, onEditPersona: () -> Unit, toast: (String) -> Unit) {
    val vm: ChatViewModel = viewModel { ChatViewModel(c) }
    val context = LocalContext.current
    val handsFree by vm.handsFree.collectAsState()
    val listenState by c.speechIn.state.collectAsState()
    val partial by c.speechIn.partial.collectAsState()
    val speaking by c.speechOut.speaking.collectAsState()
    val streaming by vm.streaming.collectAsState()
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val settings by c.settingsStore.settings.collectAsState()
    val persona = settings.profile.persona

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleHandsFree() else toast(context.getString(R.string.live_mic_needed))
    }
    fun start() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleHandsFree()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    DisposableEffect(Unit) { onDispose { if (vm.handsFree.value) vm.toggleHandsFree() } }

    val status = when {
        speaking -> stringResource(R.string.live_speaking)
        listenState == ai.astra.app.voice.ListenState.LISTENING -> stringResource(R.string.live_listening)
        busy -> stringResource(R.string.live_thinking)
        handsFree -> stringResource(R.string.live_ready)
        else -> stringResource(R.string.live_tap_to_start)
    }
    val lastAnswer = streaming.ifBlank { messages.lastOrNull { it.role == ai.astra.core.model.Role.ASSISTANT }?.text.orEmpty() }

    Scaffold(topBar = {
        TopAppBar(title = { Text(persona.name) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
            actions = { Button(onClick = onEditPersona) { Text(stringResource(R.string.live_persona)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Text(status, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (partial.isNotBlank()) Text("“$partial”", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), contentAlignment = Alignment.Center) {
                Text(lastAnswer.ifBlank { stringResource(R.string.live_intro, persona.name) }, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge)
            }
            FilledIconButton(onClick = { if (speaking) vm.bargeIn() else start() }, modifier = Modifier.size(96.dp)) {
                Icon(if (handsFree || speaking) Icons.Filled.Stop else Icons.Filled.Mic, status, modifier = Modifier.size(44.dp))
            }
            Text(if (handsFree) stringResource(R.string.live_tap_stop) else stringResource(R.string.live_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

/** Edit how ASTRA presents herself. Everything here is the user's choice. */
@Composable
fun PersonaScreen(c: AppContainer, onBack: () -> Unit, toast: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val settings by c.settingsStore.settings.collectAsState()
    val p = settings.profile.persona
    var name by remember(p.name) { mutableStateOf(p.name) }
    var addressAs by remember(p.addressAs) { mutableStateOf(p.addressAs) }
    var style by remember(p.style) { mutableStateOf(p.style) }
    var rate by remember(p.speechRate) { mutableStateOf(p.speechRate) }
    var pitch by remember(p.speechPitch) { mutableStateOf(p.speechPitch) }
    var proactive by remember(p.proactive) { mutableStateOf(p.proactive) }
    var extra by remember(p.extra) { mutableStateOf(p.extra) }

    fun persist(np: Persona) { scope.launch { c.settingsStore.update { it.copy(profile = it.profile.copy(persona = np)) } } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.persona_title)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionTitle(stringResource(R.string.persona_who))
                    androidx.compose.material3.OutlinedTextField(name, { name = it; persist(p.copy(name = it.ifBlank { "ASTRA" })) }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.persona_name)) }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(addressAs, { addressAs = it; persist(p.copy(addressAs = it)) }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.persona_address)) }, singleLine = true)
                    SectionTitle(stringResource(R.string.persona_style))
                    androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PersonaStyle.entries.forEach { s ->
                            FilterChip(style == s, { style = s; persist(p.copy(style = s)) }, { Text(stringResource(styleLabel(s))) })
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(stringResource(R.string.persona_voice))
                    Text(stringResource(R.string.persona_rate, rate), style = MaterialTheme.typography.bodySmall)
                    Slider(rate, { rate = it }, valueRange = 0.5f..1.8f, onValueChangeFinished = { persist(p.copy(speechRate = rate)) })
                    Text(stringResource(R.string.persona_pitch, pitch), style = MaterialTheme.typography.bodySmall)
                    Slider(pitch, { pitch = it }, valueRange = 0.6f..1.6f, onValueChangeFinished = { persist(p.copy(speechPitch = pitch)) })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.persona_proactive), Modifier.weight(1f))
                        Switch(proactive, { proactive = it; persist(p.copy(proactive = it)) })
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(stringResource(R.string.persona_extra))
                    androidx.compose.material3.OutlinedTextField(extra, { extra = it; persist(p.copy(extra = it)) }, Modifier.fillMaxWidth().heightIn(min = 72.dp), placeholder = { Text(stringResource(R.string.persona_extra_hint)) })
                    Text(stringResource(R.string.persona_honesty), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun styleLabel(s: PersonaStyle) = when (s) {
    PersonaStyle.WARM -> R.string.persona_warm
    PersonaStyle.PROFESSIONAL -> R.string.persona_professional
    PersonaStyle.PLAYFUL -> R.string.persona_playful
    PersonaStyle.CALM -> R.string.persona_calm
    PersonaStyle.MENTOR -> R.string.persona_mentor
}
