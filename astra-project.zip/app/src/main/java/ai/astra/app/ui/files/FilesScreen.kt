@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.files

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import ai.astra.app.ui.SectionTitle
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun FilesScreen(c: AppContainer, importStatus: String?, onImport: () -> Unit, onAsk: (String) -> Unit, toast: (String) -> Unit) {
    val docs by remember { c.documentStore.observe() }.collectAsState(initial = emptyList())
    val pages by remember { c.webCache.observe() }.collectAsState(initial = emptyList())
    val settings by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.onFailure { toast(it.message ?: "Permission not granted"); return@rememberLauncherForActivityResult }
        scope.launch { c.settingsStore.update { s -> s.copy(authorizedFolders = (s.authorizedFolders + uri.toString()).distinct()) } }
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_files)) }) },
        floatingActionButton = { FloatingActionButton(onClick = onImport) { Icon(Icons.Filled.Add, stringResource(R.string.import_document)) } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            Text(stringResource(R.string.files_explainer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            importStatus?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }

            SectionTitle(stringResource(R.string.documents))
            if (docs.isEmpty() && importStatus == null) EmptyState(stringResource(R.string.files_empty_title), stringResource(R.string.files_empty_body))
            docs.forEach { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.title, fontWeight = FontWeight.SemiBold)
                        Text("${d.unitCount} ${d.locator.label}(s) · ${d.chunkCount} passages · ${DateFormat.getDateInstance().format(Date(d.importedAt))}" + (if (d.projectId != null) " · project" else ""),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            TextButton(onClick = { onAsk(d.title) }) { Text(stringResource(R.string.ask_about_this)) }
                            TextButton(onClick = { scope.launch { c.documents.delete(d.id) } }) { Text(stringResource(R.string.delete)) }
                        }
                    }
                }
            }

            SectionTitle(stringResource(R.string.authorized_folders))
            Text(stringResource(R.string.authorized_folders_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            settings.authorizedFolders.forEach { u ->
                val name = remember(u) { runCatching { DocumentFile.fromTreeUri(context, Uri.parse(u))?.name }.getOrNull() ?: u }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("📁 $name", Modifier.weight(1f))
                    TextButton(onClick = {
                        runCatching { context.contentResolver.releasePersistableUriPermission(Uri.parse(u), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                        scope.launch { c.settingsStore.update { s -> s.copy(authorizedFolders = s.authorizedFolders - u) } }
                    }) { Text(stringResource(R.string.remove_access)) }
                }
            }
            OutlinedButton(onClick = { pickFolder.launch(null) }) { Text(stringResource(R.string.authorize_folder)) }

            SectionTitle(stringResource(R.string.saved_web_pages))
            Text(stringResource(R.string.saved_web_pages_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (pages.isEmpty()) Text(stringResource(R.string.no_saved_pages), style = MaterialTheme.typography.bodySmall)
            pages.forEach { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.title, fontWeight = FontWeight.SemiBold)
                        Text("${p.finalUrl}\n" + stringResource(R.string.cached_on, DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.retrievedAt))),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            TextButton(onClick = {
                                scope.launch {
                                    val full = c.webCache.get(p.url) ?: return@launch
                                    runCatching { c.importer.indexBytes("${full.title} (web)", "text/plain", ("Source: ${full.finalUrl}\nRetrieved: ${Date(full.retrievedAt)}\n\n" + full.text).toByteArray(), c.currentProjectId) {} }
                                        .onSuccess { toast(context.getString(R.string.added_to_documents)) }.onFailure { toast(it.message ?: "") }
                                }
                            }) { Text(stringResource(R.string.add_to_documents)) }
                            TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.finalUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) { Text(stringResource(R.string.open_live)) }
                            TextButton(onClick = { scope.launch { c.webCache.delete(p.url) } }) { Text(stringResource(R.string.delete)) }
                        }
                    }
                }
            }
            Text("", Modifier.padding(bottom = 72.dp))
        }
    }
}
