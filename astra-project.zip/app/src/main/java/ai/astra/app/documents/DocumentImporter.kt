package ai.astra.app.documents

import ai.astra.app.vision.MlKitVision
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.documents.DocumentMeta
import ai.astra.core.documents.ExtractedDocument
import ai.astra.core.documents.LocatorKind
import ai.astra.core.documents.OfficeExtractors
import ai.astra.core.documents.SourceUnit
import ai.astra.core.documents.TextExtractors
import ai.astra.core.models.Checksums
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File

/**
 * IMPORT → EXTRACT on Android: PDF (PDFBox, real page numbers; scanned pages are OCR'd on device),
 * photos of documents (on-device OCR, Hindi + English), DOCX/XLSX, text/Markdown/CSV/JSON/HTML/code.
 * Then hands off to the core index.
 */
class DocumentImporter(private val context: Context, private val index: DocumentIndex, private val vision: MlKitVision) {
    @Volatile private var pdfReady = false

    companion object {
        const val MAX_BYTES = 60L * 1024 * 1024
        const val MAX_OCR_PAGES = 80
    }

    suspend fun import(uri: Uri, projectId: String?, onProgress: (String) -> Unit): Result<DocumentMeta> = withContext(Dispatchers.IO) {
        runCatching {
            val (name, size) = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) (c.getString(0) ?: "document") to (if (c.isNull(1)) -1L else c.getLong(1)) else null
            } ?: ("document" to -1L)
            require(size <= MAX_BYTES) { "File is larger than ${MAX_BYTES / 1_048_576} MB" }
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            onProgress("Reading $name")
            val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            require(bytes.size <= MAX_BYTES) { "File is too large" }
            indexBytes(name, mime, bytes, projectId, onProgress)
        }
    }

    /** Also used for transcripts, saved web pages and Coding Lab files. */
    suspend fun indexBytes(name: String, mime: String, bytes: ByteArray, projectId: String?, onProgress: (String) -> Unit): DocumentMeta {
        val sha = Checksums.sha256(ByteArrayInputStream(bytes))
        onProgress("Extracting text")
        val doc = extract(name, mime, bytes, onProgress)
        require(doc.units.any { it.text.isNotBlank() }) { "No readable text found in $name" }
        onProgress("Indexing ${doc.units.size} ${doc.locator.label}(s)")
        return index.index(doc, sha, projectId) { done, total -> onProgress("Embedding $done / $total passages") }
    }

    /** Reads records for the automation builder: .xlsx (positional), CSV/TSV, or a table found in PDF/photo text. */
    suspend fun importTable(uri: Uri, onProgress: (String) -> Unit): Result<ai.astra.core.data.DataTable> = withContext(Dispatchers.IO) {
        runCatching {
            val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "data"
            val mime = context.contentResolver.getType(uri) ?: ""
            val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            require(bytes.size <= MAX_BYTES) { "File is too large" }
            val ext = name.substringAfterLast('.', "").lowercase()
            when {
                ext == "xlsx" || mime.contains("spreadsheetml") -> {
                    onProgress("Reading spreadsheet")
                    ai.astra.core.data.XlsxReader.read(name, bytes).maxByOrNull { it.size } ?: error("No data found in the spreadsheet")
                }
                ext == "csv" || ext == "tsv" || mime == "text/csv" || mime == "text/tab-separated-values" -> ai.astra.core.data.CsvCodec.parse(name, String(bytes, Charsets.UTF_8))
                else -> {
                    onProgress("Looking for a table")
                    val doc = extract(name, mime, bytes, onProgress)
                    val text = doc.units.joinToString("\n") { it.text }
                    ai.astra.core.data.TextTableExtractor.extract(name, text, name) ?: error("Couldn't find a table here. Use an Excel/CSV file, or a clear photo of the register.")
                }
            }
        }
    }

    suspend fun extract(name: String, mime: String, bytes: ByteArray, onProgress: (String) -> Unit = {}): ExtractedDocument = when {
        mime == "application/pdf" || name.endsWith(".pdf", true) -> pdf(name, bytes, onProgress)
        OfficeExtractors.supports(name) -> OfficeExtractors.extract(name, mime, bytes)
        mime.startsWith("image/") || name.substringAfterLast('.').lowercase() in setOf("jpg", "jpeg", "png", "webp", "heic") -> image(name, mime, bytes, onProgress)
        TextExtractors.supports(mime, name) -> TextExtractors.extract(name, mime, bytes)
        else -> throw IllegalArgumentException("Unsupported file type ($mime)")
    }

    private suspend fun image(name: String, mime: String, bytes: ByteArray, onProgress: (String) -> Unit): ExtractedDocument {
        onProgress("Recognising text in the photo (on device)")
        val tmp = File.createTempFile("ocr", ".img", context.cacheDir)
        try {
            tmp.writeBytes(bytes)
            val analysis = vision.analyze(tmp.absolutePath)
            return ExtractedDocument(name, mime, LocatorKind.PAGE, listOf(SourceUnit(1, analysis.ocrText)),
                listOf("Text recognised on device; check important numbers against the original."))
        } finally { tmp.delete() }
    }

    private suspend fun pdf(name: String, bytes: ByteArray, onProgress: (String) -> Unit): ExtractedDocument {
        if (!pdfReady) { PDFBoxResourceLoader.init(context.applicationContext); pdfReady = true }
        val pages = PDDocument.load(bytes).use { doc ->
            val stripper = PDFTextStripper()
            (1..doc.numberOfPages).map { page ->
                stripper.startPage = page
                stripper.endPage = page
                SourceUnit(page, stripper.getText(doc))
            }
        }.toMutableList()
        // Scanned pages have (almost) no text layer: render and OCR them on device.
        val scanned = pages.indices.filter { pages[it].text.trim().length < 25 }
        val warnings = ArrayList<String>()
        if (scanned.isNotEmpty()) {
            val tmp = File.createTempFile("scan", ".pdf", context.cacheDir)
            try {
                tmp.writeBytes(bytes)
                ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        scanned.take(MAX_OCR_PAGES).forEachIndexed { n, i ->
                            onProgress("OCR page ${i + 1} (${n + 1} of ${minOf(scanned.size, MAX_OCR_PAGES)})")
                            renderer.openPage(i).use { page ->
                                val scale = 2000f / maxOf(page.width, page.height).coerceAtLeast(1)
                                val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                bmp.eraseColor(Color.WHITE)
                                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                val text = runCatching { vision.ocr(bmp) }.getOrDefault("")
                                bmp.recycle()
                                pages[i] = SourceUnit(i + 1, text)
                            }
                        }
                    }
                }
                warnings += "${minOf(scanned.size, MAX_OCR_PAGES)} scanned page(s) read with on-device OCR"
                if (scanned.size > MAX_OCR_PAGES) warnings += "Only the first $MAX_OCR_PAGES scanned pages were OCR'd"
            } finally { tmp.delete() }
        }
        return ExtractedDocument(name, "application/pdf", LocatorKind.PAGE, pages, warnings)
    }
}
