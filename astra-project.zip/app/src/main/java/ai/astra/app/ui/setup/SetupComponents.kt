@file:OptIn(ExperimentalLayoutApi::class)

package ai.astra.app.ui.setup

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.inference.DownloadState
import ai.astra.app.inference.DownloadStatus
import ai.astra.app.security.SecretStore
import ai.astra.core.model.Locality
import ai.astra.core.models.CatalogModel
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.EndpointKind
import ai.astra.core.provider.EndpointPreset
import ai.astra.core.provider.EndpointPresets
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

fun sizeText(bytes: Long): String = if (bytes >= 1_073_741_824) "%.1f GB".format(bytes / 1_073_741_824.0) else "${bytes / 1_048_576} MB"

@Composable
fun DownloadCard(c: AppContainer, d: DownloadState) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val label = when (d.status) {
                DownloadStatus.PENDING -> stringResource(R.string.dl_pending)
                DownloadStatus.RUNNING -> stringResource(R.string.dl_running)
                DownloadStatus.PAUSED -> d.error ?: stringResource(R.string.dl_paused)
                DownloadStatus.VERIFYING -> stringResource(R.string.dl_verifying)
                DownloadStatus.DONE -> stringResource(R.string.dl_done)
                DownloadStatus.FAILED -> stringResource(R.string.dl_failed)
            }
            Text("${d.request.name} — $label", fontWeight = FontWeight.SemiBold)
            when {
                d.status == DownloadStatus.VERIFYING -> LinearProgressIndicator(Modifier.fillMaxWidth())
                d.totalBytes > 0 -> {
                    LinearProgressIndicator(progress = { (d.downloaded.toFloat() / d.totalBytes).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text("${sizeText(d.downloaded)} / ${sizeText(d.totalBytes)} · ${(d.downloaded * 100 / d.totalBytes)}%", style = MaterialTheme.typography.bodySmall)
                }
                d.status != DownloadStatus.DONE && d.status != DownloadStatus.FAILED -> LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (d.status == DownloadStatus.FAILED) d.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (d.status == DownloadStatus.RUNNING || d.status == DownloadStatus.PENDING || d.status == DownloadStatus.PAUSED) {
                Text(stringResource(R.string.dl_background_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row {
                if (d.status != DownloadStatus.DONE && d.status != DownloadStatus.FAILED && d.status != DownloadStatus.VERIFYING) {
                    TextButton(onClick = { c.models.cancel(d.id) }) { Text(stringResource(R.string.cancel)) }
                } else TextButton(onClick = { c.models.dismiss(d.id) }) { Text(stringResource(R.string.dismiss)) }
            }
        }
    }
}

@Composable
fun CatalogModelCard(c: AppContainer, m: CatalogModel, recommended: Boolean, reasons: List<String>, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val downloads by c.models.downloads.collectAsState()
    val models by c.models.models.collectAsState()
    val active = downloads.values.firstOrNull { it.request.catalogId == m.id && it.status != DownloadStatus.DONE && it.status != DownloadStatus.FAILED }
    val installed = models.any { it.id == m.id }
    var wifiOnly by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = if (recommended) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)) else CardDefaults.cardColors(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (recommended) Text(stringResource(R.string.recommended_for_phone), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text(m.name, style = MaterialTheme.typography.titleMedium)
            Text(m.summary, style = MaterialTheme.typography.bodyMedium)
            Text(
                listOf(sizeText(m.sizeBytes), stringResource(R.string.needs_ram, (m.minRamMb + 999) / 1000), m.license,
                    if (m.vision) stringResource(R.string.cap_photos) else null, if (m.audio) stringResource(R.string.cap_audio) else null).filterNotNull().joinToString(" · "),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (recommended) reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            Text(stringResource(R.string.from_source, m.repo), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            when {
                installed -> Text(stringResource(R.string.installed_check), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                active != null -> DownloadCard(c, active)
                else -> {
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(wifiOnly, { wifiOnly = it }); Text(stringResource(R.string.wifi_only)) }
                    Button(onClick = {
                        c.models.downloadCatalog(m, wifiOnly)
                            .onSuccess { onMessage(context.getString(R.string.dl_started, m.name)) }
                            .onFailure { onMessage(it.message ?: "Download failed") }
                    }) { Text(stringResource(R.string.download_size, sizeText(m.sizeBytes))) }
                }
            }
        }
    }
}

/** Add or edit an online / LAN endpoint, with presets and a "Fetch models" picker. */
@Composable
fun EndpointDialog(c: AppContainer, initial: EndpointConfig, isNew: Boolean, preset: EndpointPreset? = null, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var chosenPreset by remember { mutableStateOf(preset) }
    val start = preset?.let { EndpointPresets.toConfig(it, initial.id) } ?: initial
    var name by remember { mutableStateOf(start.displayName) }
    var kind by remember { mutableStateOf(start.kind) }
    var url by remember { mutableStateOf(start.baseUrl) }
    var model by remember { mutableStateOf(start.model) }
    var locality by remember { mutableStateOf(start.locality) }
    var vision by remember { mutableStateOf(start.vision) }
    var embed by remember { mutableStateOf(start.embeddingModel ?: "") }
    var ctx by remember { mutableStateOf(start.scores.contextWindow.toString()) }
    var key by remember { mutableStateOf("") }
    var fetched by remember { mutableStateOf<List<String>>(emptyList()) }
    var fetching by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val hasKey = remember { c.secrets.has(SecretStore.endpointKey(initial.id)) }

    fun applyPreset(p: EndpointPreset) {
        chosenPreset = p
        val cfg = EndpointPresets.toConfig(p, initial.id)
        name = cfg.displayName; kind = cfg.kind; url = cfg.baseUrl; model = cfg.model; locality = cfg.locality
        vision = cfg.vision; ctx = cfg.scores.contextWindow.toString(); fetched = emptyList(); message = null
    }

    fun current() = initial.copy(
        displayName = name.ifBlank { model }, kind = kind, baseUrl = url.trim(), model = model.trim(), locality = locality, vision = vision,
        embeddingModel = embed.trim().ifBlank { null },
        scores = start.scores.copy(contextWindow = ctx.toIntOrNull()?.coerceAtLeast(2048) ?: start.scores.contextWindow,
            reasoning = if (locality == Locality.LAN) 6 else start.scores.reasoning, coding = if (locality == Locality.LAN) 6 else start.scores.coding),
    )

    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(if (isNew) R.string.add_endpoint else R.string.edit_endpoint)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isNew) {
                    Text(stringResource(R.string.choose_service), style = MaterialTheme.typography.labelSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        EndpointPresets.all.forEach { p -> FilterChip(chosenPreset?.id == p.id, { applyPreset(p) }, label = { Text(p.name.substringBefore(" (")) }) }
                    }
                }
                chosenPreset?.let { p ->
                    Text(p.note, style = MaterialTheme.typography.bodySmall)
                    p.keyUrl?.let { link ->
                        TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
                            Text(stringResource(R.string.get_api_key))
                        }
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, singleLine = true)
                OutlinedTextField(url, { url = it }, label = { Text(stringResource(R.string.base_url)) }, singleLine = true)
                if (chosenPreset?.needsKey != false) {
                    OutlinedTextField(key, { key = it }, label = { Text(if (hasKey) stringResource(R.string.api_key_saved) else stringResource(R.string.api_key)) },
                        singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
                OutlinedTextField(model, { model = it }, label = { Text(stringResource(R.string.model_id)) }, singleLine = true)
                TextButton(enabled = url.isNotBlank() && !fetching, onClick = {
                    scope.launch {
                        fetching = true; message = null
                        c.providers.listModels(current(), key).onSuccess { list ->
                            fetched = list
                            if (list.isEmpty()) message = context.getString(R.string.no_models_listed)
                            else if (model.isBlank() || model !in list) model = list.firstOrNull { it.contains("flash") || it.contains("sonnet") || it.contains("mini") } ?: list.first()
                        }.onFailure { message = context.getString(R.string.fetch_failed, it.message ?: "") }
                        fetching = false
                    }
                }) { Text(stringResource(if (fetching) R.string.fetching else R.string.fetch_models)) }
                if (fetched.isNotEmpty()) {
                    Column(Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            fetched.take(80).forEach { id -> AssistChip(onClick = { model = id }, label = { Text((if (id == model) "✓ " else "") + id) }) }
                        }
                    }
                }
                message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text(stringResource(R.string.where_does_it_run), style = MaterialTheme.typography.labelSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Locality.REMOTE to R.string.loc_remote, Locality.USER_HOSTED to R.string.loc_user_hosted, Locality.LAN to R.string.loc_lan).forEach { (l, res) ->
                        FilterChip(locality == l, { locality = l }, label = { Text(stringResource(res)) })
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(kind == EndpointKind.OPENAI_COMPATIBLE, { kind = EndpointKind.OPENAI_COMPATIBLE }, label = { Text(stringResource(R.string.kind_openai)) })
                    FilterChip(kind == EndpointKind.ANTHROPIC, { kind = EndpointKind.ANTHROPIC }, label = { Text(stringResource(R.string.kind_anthropic)) })
                }
                OutlinedTextField(ctx, { ctx = it.filter(Char::isDigit) }, label = { Text(stringResource(R.string.context_window)) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (kind == EndpointKind.OPENAI_COMPATIBLE) OutlinedTextField(embed, { embed = it }, label = { Text(stringResource(R.string.embedding_model_optional)) }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(vision, { vision = it }); Text(stringResource(R.string.supports_images)) }
                Text(stringResource(R.string.key_vault_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = url.isNotBlank() && model.isNotBlank(), onClick = {
                val cfg = current()
                if (key.isNotBlank()) c.secrets.put(SecretStore.endpointKey(initial.id), key.trim())
                scope.launch { c.settingsStore.update { s -> s.copy(endpoints = s.endpoints.filter { it.id != cfg.id } + cfg) } }
                onDismiss()
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } })
}
