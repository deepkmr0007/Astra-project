@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.settings

import ai.astra.app.AppContainer
import ai.astra.app.BuildConfig
import ai.astra.app.R
import ai.astra.app.data.AppSettings
import ai.astra.app.security.AppLock
import ai.astra.app.ui.SectionTitle
import ai.astra.app.ui.shareFile
import ai.astra.core.context.Personality
import ai.astra.core.context.ReplyLanguage
import ai.astra.core.device.EnergyMode
import ai.astra.core.export.Exporter
import ai.astra.core.model.AssistMode
import ai.astra.core.router.DataControl
import ai.astra.core.router.RoutePreference
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private enum class Page { MAIN, DIAGNOSTICS, AUTOMATIONS, ABOUT }

@Composable
fun SettingsScreen(c: AppContainer, toast: (String) -> Unit) {
    var page by remember { mutableStateOf(Page.MAIN) }
    when (page) {
        Page.MAIN -> MainSettings(c, toast) { page = it }
        Page.DIAGNOSTICS -> DiagnosticsPage(c) { page = Page.MAIN }
        Page.AUTOMATIONS -> ai.astra.app.ui.extras.AutomationsScreen(c, { page = Page.MAIN }, {}, toast)
        Page.ABOUT -> AboutPage { page = Page.MAIN }
    }
}

@Composable
private fun <T> Choice(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (v, label) -> FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(label) }) }
    }
}

/** Text setting with local state so typing never lags behind the async settings store. */
@Composable
private fun SettingField(label: String, initial: String, minLines: Int, modifier: Modifier, onChange: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    OutlinedTextField(v, { v = it; onChange(it) }, label = { Text(label) }, singleLine = minLines == 1, minLines = minLines, modifier = modifier)
}

@Composable
private fun Toggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun MainSettings(c: AppContainer, toast: (String) -> Unit, go: (Page) -> Unit) {
    val s by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    fun upd(f: (AppSettings) -> AppSettings) { scope.launch { c.settingsStore.update(f) } }

    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val convs = c.chatRepo.allConversations().filter { !it.temporary }.map { it to c.chatRepo.messages(it.id) }
            val json = Exporter.bundle(convs, c.memory.list(), c.chatRepo.allProjects(), c.chatRepo.allTasks(), c.settingsStore.exportable(s))
            withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } }
            toast(context.getString(R.string.exported))
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_settings)) }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            SectionTitle(stringResource(R.string.privacy))
            Text(stringResource(R.string.data_control), fontWeight = FontWeight.SemiBold)
            listOf(
                DataControl.NEVER_SEND to R.string.dc_never, DataControl.ASK_BEFORE_SENDING to R.string.dc_ask_always,
                DataControl.ASK_FOR_SENSITIVE to R.string.dc_ask_sensitive, DataControl.ALLOW to R.string.dc_allow,
            ).forEach { (v, res) ->
                Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(s.dataControl == v, { upd { it.copy(dataControl = v) } }); Text(stringResource(res)) }
            }
            Text(stringResource(R.string.dc_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Toggle(stringResource(R.string.allow_lan_private), stringResource(R.string.allow_lan_private_sub), s.allowLanInPrivate) { on -> upd { it.copy(allowLanInPrivate = on) } }
            Text(stringResource(R.string.routing_preference), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            Choice(listOf(RoutePreference.AUTO to stringResource(R.string.route_auto), RoutePreference.PREFER_LOCAL to stringResource(R.string.route_prefer_local),
                RoutePreference.LOCAL_ONLY to stringResource(R.string.route_local_only), RoutePreference.PREFER_ONLINE to stringResource(R.string.route_prefer_online)), s.routePreference) { v -> upd { it.copy(routePreference = v) } }

            WebResearchSettings(c)
            SectionTitle(stringResource(R.string.assistant))
            SettingField(stringResource(R.string.your_name), s.profile.userName, 1, Modifier.fillMaxWidth()) { v -> upd { it.copy(profile = it.profile.copy(userName = v)) } }
            Text(stringResource(R.string.personality), modifier = Modifier.padding(top = 8.dp))
            Choice(Personality.entries.map { it to it.name.lowercase().replaceFirstChar { ch -> ch.uppercase() } }, s.profile.personality) { v -> upd { it.copy(profile = it.profile.copy(personality = v)) } }
            Text(stringResource(R.string.reply_language), modifier = Modifier.padding(top = 8.dp))
            Choice(listOf(ReplyLanguage.AUTO to stringResource(R.string.lang_auto), ReplyLanguage.ENGLISH to "English", ReplyLanguage.HINDI to "हिन्दी", ReplyLanguage.HINGLISH to "Hinglish"), s.profile.language) { v -> upd { it.copy(profile = it.profile.copy(language = v)) } }
            Text(stringResource(R.string.units), modifier = Modifier.padding(top = 8.dp))
            Choice(listOf("metric" to stringResource(R.string.metric), "imperial" to stringResource(R.string.imperial)), s.profile.units) { v -> upd { it.copy(profile = it.profile.copy(units = v)) } }
            SettingField(stringResource(R.string.technical_level), s.profile.technicalLevel, 1, Modifier.fillMaxWidth().padding(top = 8.dp)) { v -> upd { it.copy(profile = it.profile.copy(technicalLevel = v)) } }
            SettingField(stringResource(R.string.writing_style), s.profile.writingStyle, 1, Modifier.fillMaxWidth()) { v -> upd { it.copy(profile = it.profile.copy(writingStyle = v)) } }
            SettingField(stringResource(R.string.custom_instructions), s.profile.customInstructions, 3, Modifier.fillMaxWidth()) { v -> upd { it.copy(profile = it.profile.copy(customInstructions = v)) } }
            Text(stringResource(R.string.default_mode), modifier = Modifier.padding(top = 8.dp))
            Choice(listOf(AssistMode.CHAT to stringResource(R.string.assist_chat), AssistMode.ASSIST to stringResource(R.string.assist_assist), AssistMode.AGENT to stringResource(R.string.assist_agent)), s.defaultMode) { v -> upd { it.copy(defaultMode = v) } }
            Toggle(stringResource(R.string.self_review), stringResource(R.string.self_review_sub), s.selfReview) { on -> upd { it.copy(selfReview = on) } }
            Toggle(stringResource(R.string.auto_speak), null, s.autoSpeak) { on -> upd { it.copy(autoSpeak = on) } }
            Text(stringResource(R.string.max_answer_length, s.maxOutputTokens))
            Slider(s.maxOutputTokens.toFloat(), { v -> upd { it.copy(maxOutputTokens = (v / 128).toInt() * 128) } }, valueRange = 256f..4096f)
            Text(stringResource(R.string.creativity, "%.1f".format(s.temperature)))
            Slider(s.temperature.toFloat(), { v -> upd { it.copy(temperature = (v * 10).toInt() / 10.0) } }, valueRange = 0f..1.2f)

            SectionTitle(stringResource(R.string.memory_policy))
            Toggle(stringResource(R.string.memory_enabled), null, s.memoryEnabled) { on -> upd { it.copy(memoryEnabled = on) } }
            Toggle(stringResource(R.string.auto_capture), stringResource(R.string.auto_capture_sub), s.autoCapture) { on -> upd { it.copy(autoCapture = on) } }
            Toggle(stringResource(R.string.allow_sensitive_memory), stringResource(R.string.allow_sensitive_memory_sub), s.allowSensitiveMemory) { on -> upd { it.copy(allowSensitiveMemory = on) } }

            SectionTitle(stringResource(R.string.energy))
            Choice(listOf(EnergyMode.PERFORMANCE to stringResource(R.string.energy_performance), EnergyMode.BALANCED to stringResource(R.string.energy_balanced), EnergyMode.BATTERY_SAVER to stringResource(R.string.energy_saver)), s.energyMode) { v -> upd { it.copy(energyMode = v) } }

            SectionTitle(stringResource(R.string.security))
            Toggle(stringResource(R.string.app_lock), stringResource(if (AppLock.available(context)) R.string.app_lock_sub else R.string.app_lock_unavailable), s.appLock) { on ->
                if (!on || AppLock.available(context)) upd { it.copy(appLock = on) } else toast(context.getString(R.string.app_lock_unavailable))
            }
            Toggle(stringResource(R.string.auto_medium), stringResource(R.string.auto_medium_sub), s.autoApproveMedium) { on -> upd { it.copy(autoApproveMedium = on) } }
            Toggle(stringResource(R.string.auto_high), stringResource(R.string.auto_high_sub), s.autoApproveHigh) { on -> upd { it.copy(autoApproveHigh = on) } }
            Text(stringResource(R.string.vault_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            SectionTitle(stringResource(R.string.your_data))
            OutlinedButton(onClick = { exportAll.launch("astra-export.json") }) { Text(stringResource(R.string.export_everything)) }
            Text(stringResource(R.string.export_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            BackupSettings(c, toast)
            VoiceSettings(c)
            NotificationSettings(c)
            SectionTitle(stringResource(R.string.more))
            TextButton(onClick = { go(Page.DIAGNOSTICS) }) { Text(stringResource(R.string.diagnostics)) }
            TextButton(onClick = { go(Page.AUTOMATIONS) }) { Text(stringResource(R.string.nav_automations)) }
            TextButton(onClick = { go(Page.ABOUT) }) { Text(stringResource(R.string.about_licenses)) }
            Text("", Modifier.padding(bottom = 40.dp))
        }
    }
}

@Composable
private fun DiagnosticsPage(c: AppContainer, onBack: () -> Unit) {
    val device by c.device.state.collectAsState()
    val status by c.providers.status.collectAsState()
    val context = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val events = remember(version) { c.diagnostics.events().asReversed() }
    val gens = remember(version) { c.diagnostics.generations().asReversed() }
    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.diagnostics)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(stringResource(R.string.device), fontWeight = FontWeight.SemiBold)
                    Text("Network: ${if (device.online) "online" else "offline"}${if (device.metered) " (metered)" else ""}")
                    Text("Battery: ${device.batteryPercent ?: "?"}%${if (device.charging) " charging" else ""} · ${device.batteryTempC ?: "?"} °C")
                    Text("Thermal: ${device.thermal.name.lowercase()}")
                    Text("RAM: ${device.availableRamMb ?: "?"} MB free of ${device.totalRamMb ?: "?"} MB")
                    Text("Storage free: ${device.freeStorageMb?.div(1024) ?: "?"} GB · CPU cores: ${device.cpuCores}")
                    Text("Network gate: ${c.gate.requests} requests, ${c.gate.blocked} blocked by private mode")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(stringResource(R.string.models_runtime), fontWeight = FontWeight.SemiBold)
                    if (status.isEmpty()) Text(stringResource(R.string.no_models))
                    status.forEach { Text("${it.info.displayName}: ${it.detail}") }
                }
            }
            Text(stringResource(R.string.recent_generations), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            gens.take(20).forEach { g -> Text("${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(g.time))} ${g.model.take(24)} · ${g.tokensOut} tok · ${"%.1f".format(g.tokensPerSecond)} tok/s · TTFT ${g.firstTokenMs} ms · sent ${g.bytesSent} B", style = MaterialTheme.typography.bodySmall) }
            Text(stringResource(R.string.events), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            events.take(80).forEach { e -> Text("${DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(e.time))} [${e.tag}] ${e.message}", style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                OutlinedButton(onClick = {
                    val text = c.diagnostics.export(mapOf("app" to BuildConfig.VERSION_NAME, "device" to device.toString(), "providers" to status.joinToString { "${it.info.id}=${it.detail}" }))
                    val f = File(File(context.cacheDir, "exports").apply { mkdirs() }, "astra-diagnostics.txt").apply { writeText(text) }
                    shareFile(context, f, "text/plain")
                }) { Text(stringResource(R.string.export_diagnostics)) }
                OutlinedButton(onClick = { c.diagnostics.clear(); c.clearActivity(); version++ }) { Text(stringResource(R.string.clear_logs)) }
            }
        }
    }
}

@Composable
private fun AboutPage(onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.about_licenses)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ASTRA ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.about_body))
            Text(stringResource(R.string.licenses_body), style = MaterialTheme.typography.bodySmall)
        }
    }
}
