package ai.astra.app

import ai.astra.app.data.AstraDatabase
import ai.astra.app.data.ChatRepository
import ai.astra.app.data.RoomDocumentStore
import ai.astra.app.data.RoomMemoryStore
import ai.astra.app.data.RoomWebCache
import ai.astra.app.automation.Automations
import ai.astra.app.code.JsSandbox
import ai.astra.app.files.FolderWorkspace
import ai.astra.app.notify.NotificationCollector
import ai.astra.app.plugins.PluginStore
import ai.astra.app.vision.MlKitVision
import ai.astra.app.voice.Transcriber
import ai.astra.app.voice.WavRecorder
import ai.astra.core.chat.DirectResponder
import ai.astra.core.model.Locality
import ai.astra.core.provider.UrlConnectionTransport
import ai.astra.core.web.BraveSearch
import ai.astra.core.web.DuckDuckGoInstant
import ai.astra.core.web.ResearchPipeline
import ai.astra.core.web.SearchProvider
import ai.astra.core.web.SearxngSearch
import ai.astra.core.web.TavilySearch
import ai.astra.core.web.WebFetchTool
import ai.astra.core.web.WebFetcher
import ai.astra.core.web.WebSearchTool
import ai.astra.core.web.WikipediaSearch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import ai.astra.app.data.SettingsStore
import ai.astra.app.device.DeviceMonitor
import ai.astra.app.documents.DocumentImporter
import ai.astra.app.inference.ModelManager
import ai.astra.app.inference.ProviderManager
import ai.astra.app.security.SecretStore
import ai.astra.app.voice.SpeechInput
import ai.astra.app.voice.SpeechOutput
import ai.astra.core.agent.AgentRunner
import ai.astra.core.chat.ChatEngine
import ai.astra.core.chat.ConsentAnswer
import ai.astra.core.chat.ConsentGate
import ai.astra.core.chat.ConsentRequest
import ai.astra.core.diagnostics.Diagnostics
import ai.astra.core.documents.DocumentIndex
import ai.astra.core.memory.HashingEmbedder
import ai.astra.core.memory.MemoryEngine
import ai.astra.core.provider.NetworkGate
import ai.astra.core.router.ModelRouter
import ai.astra.core.security.ConfirmationGate
import ai.astra.core.security.ConfirmationRequest
import ai.astra.core.security.RingAuditLog
import ai.astra.core.security.ToolFirewall
import ai.astra.core.tools.defaultTools
import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** A question the engine is waiting on the user to answer. */
sealed interface PendingPrompt {
    data class Consent(val request: ConsentRequest, val answer: CompletableDeferred<ConsentAnswer>) : PendingPrompt
    data class Confirm(val request: ConfirmationRequest, val answer: CompletableDeferred<Boolean>) : PendingPrompt
}

/** Bridges engine suspension points (consent, tool confirmation) to dialogs in the UI. */
class UiBridge {
    private val _pending = MutableStateFlow<PendingPrompt?>(null)
    val pending: StateFlow<PendingPrompt?> = _pending.asStateFlow()
    private val serial = Mutex()

    val consentGate = ConsentGate { req ->
        serial.withLock {
            val d = CompletableDeferred<ConsentAnswer>()
            _pending.value = PendingPrompt.Consent(req, d)
            try { d.await() } finally { _pending.value = null }
        }
    }

    val confirmationGate = ConfirmationGate { req ->
        serial.withLock {
            val d = CompletableDeferred<Boolean>()
            _pending.value = PendingPrompt.Confirm(req, d)
            try { d.await() } finally { _pending.value = null }
        }
    }
}

/**
 * Manual dependency injection: one place that wires every replaceable component. Swapping the
 * embedder, a provider, a store, a search backend or the router is a one-line change here.
 */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val secrets = SecretStore(appContext)
    val diagnostics = Diagnostics()
    val db = AstraDatabase.create(appContext, databaseKey())
    val settingsStore = SettingsStore(appContext, scope)
    val device = DeviceMonitor(appContext).also { it.start() }
    val audit = RingAuditLog()
    val bridge = UiBridge()
    val gate = NetworkGate()
    private val webTransport = UrlConnectionTransport(gate, Locality.REMOTE)

    val chatRepo = ChatRepository(db)
    val automationStore = ai.astra.app.data.RoomAutomationStore(db.automations())
    val skillStore = ai.astra.app.data.RoomSkillStore(db.skills())
    val tableStore = ai.astra.app.data.RoomTableStore(db.dataTables())
    val memoryStore = RoomMemoryStore(db)
    val documentStore = RoomDocumentStore(db)
    val webCache = RoomWebCache(db)
    val embedder = HashingEmbedder()
    val memory = MemoryEngine(memoryStore, embedder, settingsStore.settings.value.memoryPolicy())
    val documents = DocumentIndex(documentStore, embedder)
    val vision = MlKitVision(appContext)
    val importer = DocumentImporter(appContext, documents, vision)

    val models = ModelManager(appContext, scope)
    val providers = ProviderManager(appContext, models, secrets, gate, device)

    /** Project of the conversation currently on screen (scopes memory/document tools). */
    @Volatile var currentProjectId: String? = null
    val tools = defaultTools(memory, documents) { currentProjectId }
    val firewall = ToolFirewall(settingsStore.permissionCenter, bridge.confirmationGate, audit)
    val agent = AgentRunner(tools, firewall)

    // Phase 3: web, files, code.
    fun searchProvider(): SearchProvider {
        val s = settingsStore.settings.value
        return when (s.searchProvider) {
            "duckduckgo" -> DuckDuckGoInstant(webTransport)
            "brave" -> BraveSearch(webTransport) { secrets.get(SEARCH_KEY_BRAVE) }
            "searxng" -> SearxngSearch(webTransport) { s.searxngUrl.ifBlank { null } }
            "tavily" -> TavilySearch(webTransport) { secrets.get(SEARCH_KEY_TAVILY) }
            else -> WikipediaSearch(webTransport)
        }
    }
    val webFetcher = WebFetcher(webTransport)
    val workspace = FolderWorkspace(appContext) { settingsStore.settings.value.authorizedFolders }
    val js = JsSandbox(appContext)
    val plugins: PluginStore

    val engine: ChatEngine

    /** "AI Activity" panel: every routing decision, retrieval, tool call and policy event. */
    private val _activity = MutableStateFlow<List<ai.astra.core.agent.ActivityItem>>(emptyList())
    val activity: StateFlow<List<ai.astra.core.agent.ActivityItem>> = _activity.asStateFlow()
    fun recordActivity(item: ai.astra.core.agent.ActivityItem) { _activity.value = (_activity.value + item).takeLast(300) }
    fun clearActivity() { _activity.value = emptyList() }

    val speechIn = SpeechInput(appContext)
    val speechOut = SpeechOutput(appContext)
    val recorder = WavRecorder(scope)
    val transcriber = Transcriber(providers, java.io.File(appContext.cacheDir, "audio"))
    val automations: Automations

    // v0.3: builder, computer link, phone agent.
    val phoneDriver = ai.astra.app.automation.PhoneDriver(appContext)
    val desk = ai.astra.app.automation.DeskManager(
        appContext, ai.astra.app.data.VaultPairedDeviceStore(secrets), scope,
        answerChat = { text, onToken ->
            val reply = StringBuilder()
            engine.send(ai.astra.core.chat.ChatRequest("astra-desk-chat", listOf(ai.astra.core.model.Part.Text(text)), persistUserMessage = false)).collect { e ->
                if (e is ai.astra.core.chat.ChatEvent.Token) { reply.append(e.text); onToken(e.text) }
            }
            reply.toString().ifBlank { "(no answer)" }
        },
        log = { diagnostics.log("desk", it) },
    )

    @Volatile var builtInToolNames: Set<String> = emptySet()
        private set

    companion object {
        const val SEARCH_KEY_BRAVE = "search_key:brave"
        const val SEARCH_KEY_TAVILY = "search_key:tavily"
    }

    init {
        tools.register(WebSearchTool { searchProvider() })
        tools.register(WebFetchTool(webFetcher, webCache))
        tools.register(js.tool())
        tools.register(ai.astra.core.data.TableQueryTool(tableStore))
        workspace.registerTools(tools)
        val builtIn = tools.all().map { it.spec.name }.toSet()
        plugins = PluginStore(appContext, webTransport, tools)
        builtInToolNames = builtIn

        engine = ChatEngine(
            repo = chatRepo,
            providers = { providers.providers() },
            router = ModelRouter(),
            memory = memory,
            documents = documents,
            tools = tools,
            agent = agent,
            consent = bridge.consentGate,
            device = { device.state.value },
            settings = { settingsStore.settings.value.engineSettings() },
            diagnostics = diagnostics,
            direct = DirectResponder(memory, documents),
            imageAnalyzer = vision,
            research = { ResearchPipeline(searchProvider(), webFetcher, webCache) },
            skillLookup = { text -> if (settingsStore.settings.value.skillsEnabled) ai.astra.core.learn.SkillMatcher.match(text, skillStore.all()) else emptyList() },
        )

        automations = Automations(
            appContext, webTransport, { settingsStore.settings.value },
            summarize = { prompt -> engine.oneShot(prompt, 700, localOnly = true) },
            saveChat = { conv, msgs -> chatRepo.save(conv); msgs.forEach { chatRepo.append(it) } },
        )
        automations.ensureChannel()

        // Keep providers, policies, gates and schedules in sync with settings + installed models.
        scope.launch {
            combine(settingsStore.settings, models.models) { s, m -> s to m }.collect { (s, m) ->
                memory.policy = s.memoryPolicy()
                firewall.policy = s.firewallPolicy()
                NotificationCollector.enabled = s.notificationSummaries
                if (!s.notificationSummaries) NotificationCollector.clear()
                providers.rebuild(s, m)
                providers.refreshStatus()
                speechOut.setRate(s.profile.persona.speechRate)
                speechOut.setPitch(s.profile.persona.speechPitch)
                if (s.deskEnabled && !desk.isServerRunning) desk.start()
                else if (!s.deskEnabled && desk.isServerRunning) desk.stop()
            }
        }
        scope.launch {
            settingsStore.settings.map { Triple(it.briefingEnabled, it.briefingHour, it.briefingFeeds) }.distinctUntilChanged().collect {
                runCatching { automations.schedule(settingsStore.settings.value) }.onFailure { e -> diagnostics.log("automation", e.message ?: "schedule failed") }
            }
        }
        // A freshly downloaded model becomes active and is loaded right away.
        scope.launch {
            models.installed.collect { d ->
                val s = settingsStore.settings.value
                val current = models.models.value.firstOrNull { it.id == s.activeLocalModelId }
                if (current == null || !current.runnable || current.id == d.id) {
                    settingsStore.update { it.copy(activeLocalModelId = d.id) }
                }
                diagnostics.log("models", "Installed ${d.name} (${d.sha256.take(12)}…)")
                kotlinx.coroutines.delay(500)
                providers.loadLocal().onFailure { e -> diagnostics.log("models", "Auto-load failed: ${e.message}") }
                automations.notify(appContext.getString(R.string.model_ready_title, d.name), appContext.getString(R.string.model_ready_body))
            }
        }
        scope.launch { device.state.collect { providers.refreshStatus() } }
        scope.launch {
            val purged = memory.purgeExpired()
            if (purged > 0) diagnostics.log("memory", "Purged $purged expired temporary memories")
        }
    }

    /** Random SQLCipher key, kept only inside the Keystore-protected vault. */
    private fun databaseKey(): ByteArray {
        val name = "db_key_v1"
        secrets.get(name)?.let { hex -> return hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray() }
        val dbFile = appContext.getDatabasePath("astra-secure.db")
        if (dbFile.exists()) {
            // Key lost (e.g. Keystore reset): the old database can't be opened; keep it aside, start fresh.
            dbFile.renameTo(java.io.File(dbFile.parentFile, "astra-secure.db.unreadable-${System.currentTimeMillis()}"))
            diagnostics.log("security", "Database key unavailable; previous encrypted database set aside")
        }
        val key = ByteArray(32).also { java.security.SecureRandom().nextBytes(it) }
        secrets.put(name, key.joinToString("") { "%02x".format(it) })
        return key
    }
}
