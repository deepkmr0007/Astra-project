@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.builder

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.SectionTitle
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * ASTRA Desk: link this phone to the ASTRA Desk extension in the user's computer browser over
 * Wi-Fi. Pairing is confirmed by matching a 6-digit code on both screens, and the link is
 * end-to-end encrypted.
 */
@Composable
fun DeskScreen(c: AppContainer, onBack: () -> Unit, toast: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val settings by c.settingsStore.settings.collectAsState()
    val connected by c.desk.connected.collectAsState()
    val devices by c.desk.devices.collectAsState()
    val pairing by c.desk.pairing.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.desk_title)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Computer, null)
                            Text(stringResource(R.string.desk_enable), Modifier.weight(1f).padding(start = 8.dp), fontWeight = FontWeight.SemiBold)
                            Switch(settings.deskEnabled, { on -> scope.launch { c.settingsStore.update { it.copy(deskEnabled = on) } } })
                        }
                        Text(stringResource(R.string.desk_explain), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val status = when {
                            !settings.deskEnabled -> stringResource(R.string.desk_off)
                            connected -> stringResource(R.string.desk_connected)
                            else -> stringResource(R.string.desk_waiting)
                        }
                        Text(status, color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (settings.deskEnabled) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SectionTitle(stringResource(R.string.desk_how_to))
                            Text(stringResource(R.string.desk_step1), style = MaterialTheme.typography.bodySmall)
                            Text(stringResource(R.string.desk_step2), style = MaterialTheme.typography.bodySmall)
                            c.desk.wifiName()?.let { Text(stringResource(R.string.desk_wifi, it), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            SectionTitle(stringResource(R.string.desk_address))
                            val addrs = c.desk.addresses()
                            if (addrs.isEmpty()) Text(stringResource(R.string.desk_no_wifi), color = MaterialTheme.colorScheme.error)
                            addrs.forEach { a ->
                                Text(a, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                if (devices.isNotEmpty()) Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        SectionTitle(stringResource(R.string.desk_paired))
                        devices.forEach { d ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(d.name, Modifier.weight(1f))
                                TextButton(onClick = { c.desk.unpair(d.id); toast(c.appContext.getString(R.string.desk_unpaired)) }) { Text(stringResource(R.string.desk_unpair)) }
                            }
                        }
                    }
                }
            }

            pairing?.let { p ->
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { c.desk.rejectPairing() },
                    title = { Text(stringResource(R.string.desk_confirm_title, p.computerName)) },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.desk_confirm_body))
                            Text(p.code.chunked(3).joinToString(" "), fontSize = 40.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp))
                        }
                    },
                    confirmButton = { Button(onClick = { c.desk.confirmPairing() }) { Text(stringResource(R.string.desk_codes_match)) } },
                    dismissButton = { OutlinedButton(onClick = { c.desk.rejectPairing() }) { Text(stringResource(R.string.desk_reject)) } },
                )
            }
        }
    }
}
