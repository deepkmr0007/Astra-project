package ai.astra.app.vision

import ai.astra.core.vision.ImageAnalysis
import ai.astra.core.vision.ImageAnalyzer
import ai.astra.core.vision.ImageLabel
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
    addOnCanceledListener { cont.cancel() }
}

/**
 * On-device vision with Google ML Kit bundled models (no network, no Play download):
 * text recognition for Latin and Devanagari scripts, plus general image labels.
 */
class MlKitVision(private val context: Context) : ImageAnalyzer {
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val devanagari by lazy { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
    private val devanagariChars = Regex("[\\u0900-\\u097F]")

    override suspend fun analyze(path: String): ImageAnalysis {
        val image = InputImage.fromFilePath(context, Uri.fromFile(File(path)))
        return analyze(image)
    }

    suspend fun analyze(bitmap: Bitmap): ImageAnalysis = analyze(InputImage.fromBitmap(bitmap, 0))

    suspend fun ocr(bitmap: Bitmap): String = ocr(InputImage.fromBitmap(bitmap, 0))

    private suspend fun analyze(image: InputImage): ImageAnalysis {
        val text = runCatching { ocr(image) }.getOrDefault("")
        val labels = runCatching { labeler.process(image).awaitTask().map { ImageLabel(it.text, it.confidence) } }.getOrDefault(emptyList())
        return ImageAnalysis(text, labels.filter { it.confidence >= 0.55f }, image.width, image.height)
    }

    /** Devanagari model also reads Latin; fall back to the Latin model when no Devanagari is present. */
    private suspend fun ocr(image: InputImage): String {
        val deva = runCatching { devanagari.process(image).awaitTask().text }.getOrDefault("")
        if (devanagariChars.containsMatchIn(deva)) return deva
        val lat = runCatching { latin.process(image).awaitTask().text }.getOrDefault("")
        return if (lat.length >= deva.length) lat else deva
    }
}
