package ai.astra.app.automation

import ai.astra.app.AstraApplication
import ai.astra.app.R
import ai.astra.app.data.AppSettings
import ai.astra.app.ui.MainActivity
import ai.astra.core.automation.Briefing
import ai.astra.core.automation.FeedItem
import ai.astra.core.automation.FeedParser
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.ExecutionTrace
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.provider.HttpRequest
import ai.astra.core.provider.HttpTransport
import ai.astra.core.router.DataControl
import ai.astra.core.web.USER_AGENT
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

data class BriefingStatus(val time: Long, val ok: Boolean, val message: String, val conversationId: String?)

/**
 * Opt-in automations. Today: the morning briefing — read chosen RSS/Atom feeds, pick the newest
 * items, summarise them on the device (if a local model is installed), save the result as a chat
 * and post a notification. Runs with WorkManager, so Android decides the exact time (battery rules).
 */
class Automations(
    private val context: Context,
    private val transport: HttpTransport,
    private val settings: () -> AppSettings,
    private val summarize: suspend (String) -> Result<String>,
    private val saveChat: suspend (Conversation, List<ChatMessage>) -> Unit,
) {
    private val _last = MutableStateFlow<BriefingStatus?>(null)
    val last: StateFlow<BriefingStatus?> = _last.asStateFlow()

    companion object {
        const val WORK = "astra-morning-briefing"
        const val CHANNEL = "astra_general"
    }

    fun ensureChannel() {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, context.getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun schedule(s: AppSettings) {
        val wm = WorkManager.getInstance(context)
        if (!s.briefingEnabled) { wm.cancelUniqueWork(WORK); return }
        val now = ZonedDateTime.now()
        var next = now.withHour(s.briefingHour.coerceIn(0, 23)).withMinute(0).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMinutes()
        val req = PeriodicWorkRequestBuilder<BriefingWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delay, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    suspend fun runBriefing(): BriefingStatus = withContext(Dispatchers.IO) {
        val s = settings()
        if (s.dataControl == DataControl.NEVER_SEND) return@withContext record(false, context.getString(R.string.briefing_blocked_private), null)
        val items = ArrayList<FeedItem>()
        val failures = ArrayList<String>()
        for (url in s.briefingFeeds.filter { it.startsWith("https://") }) {
            runCatching {
                transport.open(HttpRequest(url, "GET", mapOf("User-Agent" to USER_AGENT, "Accept" to "application/rss+xml, application/atom+xml, text/xml"), null, 15_000, 30_000)).use { r ->
                    if (r.status !in 200..299) error("HTTP ${r.status}")
                    val sb = StringBuilder()
                    while (sb.length < 3_000_000) { sb.append(r.readLine() ?: break).append('\n') }
                    items += FeedParser.parse(sb.toString())
                }
            }.onFailure { failures += "${java.net.URI(url).host}: ${it.message}" }
        }
        if (items.isEmpty()) return@withContext record(false, context.getString(R.string.briefing_no_items) + if (failures.isNotEmpty()) " (${failures.joinToString()})" else "", null)
        val picked = Briefing.select(items, 12, System.currentTimeMillis() - 36L * 3600_000).ifEmpty { Briefing.select(items, 12) }
        val summary = summarize(Briefing.prompt(picked))
        val body = summary.getOrNull()?.takeIf { it.isNotBlank() }?.let { it + "\n\n" + context.getString(R.string.briefing_sources) + "\n" + picked.joinToString("\n") { i -> "• ${i.title} — ${i.link}" } }
            ?: (context.getString(R.string.briefing_headlines_only) + "\n\n" + picked.joinToString("\n") { "• ${it.title} (${it.feed})\n  ${it.link}" })
        val conv = Conversation(title = context.getString(R.string.briefing_title, LocalDate.now().toString()))
        val msg = ChatMessage(conversationId = conv.id, role = Role.ASSISTANT, parts = listOf(Part.Text(body + if (failures.isNotEmpty()) "\n\n⚠ " + failures.joinToString() else "")),
            trace = ExecutionTrace("astra-briefing", if (summary.isSuccess) "On-device model" else "Headlines only", Locality.ON_DEVICE, ExecutionMode.HYBRID, true, 0,
                listOf("feed requests to ${s.briefingFeeds.size} site(s)"), listOf("rss"), 0, 0.0, 0, listOf("Morning briefing automation")))
        saveChat(conv, listOf(msg))
        notify(context.getString(R.string.briefing_ready), picked.firstOrNull()?.title.orEmpty())
        record(true, context.getString(R.string.briefing_saved, picked.size), conv.id)
    }

    private fun record(ok: Boolean, message: String, convId: String?) = BriefingStatus(System.currentTimeMillis(), ok, message, convId).also { _last.value = it }

    fun notify(title: String, text: String) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannel()
        val pi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % 100000).toInt(), n) }
    }
}

class BriefingWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as AstraApplication
        if (!app.start()) return Result.failure() // startup problem is explained when the app is opened
        val c = app.container
        val status = c.automations.runBriefing()
        return if (status.ok) Result.success() else if (runAttemptCount < 2) Result.retry() else Result.failure()
    }
}
