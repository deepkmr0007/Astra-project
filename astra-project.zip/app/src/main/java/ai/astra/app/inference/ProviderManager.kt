package ai.astra.app.inference

import ai.astra.app.data.AppSettings
import ai.astra.app.device.DeviceMonitor
import ai.astra.app.security.SecretStore
import ai.astra.core.model.ContentSource
import ai.astra.core.model.Part
import ai.astra.core.model.Role
import ai.astra.core.models.ModelDescriptor
import ai.astra.core.provider.AiProvider
import ai.astra.core.provider.Availability
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.GenerationRequest
import ai.astra.core.provider.NetworkGate
import ai.astra.core.provider.PromptTurn
import ai.astra.core.provider.ProviderInfo
import ai.astra.core.provider.ProviderRegistry
import ai.astra.core.provider.StreamEvent
import ai.astra.core.provider.UrlConnectionTransport
import ai.astra.core.provider.createHttpProvider
import android.content.Context
import android.os.Debug
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ProviderStatus(val info: ProviderInfo, val availability: Availability, val detail: String)

data class BenchmarkResult(
    val providerId: String,
    val firstTokenMs: Long,
    val tokensPerSecond: Double,
    val tokens: Int,
    val totalMs: Long,
    val nativeHeapDeltaMb: Long,
    val batteryTempBeforeC: Double?,
    val batteryTempAfterC: Double?,
    val batteryDropPercent: Int?,
    val loadMs: Long?,
)

/**
 * Builds the live provider set from installed models and configured endpoints. Only one local
 * model is kept in memory at a time; network providers all go through the shared [NetworkGate].
 */
class ProviderManager(
    private val context: Context,
    private val models: ModelManager,
    private val secrets: SecretStore,
    val gate: NetworkGate,
    private val device: DeviceMonitor,
) {
    val registry = ProviderRegistry()
    private var local: LiteRtLmProvider? = null
    private var localKey: String? = null

    private val _status = MutableStateFlow<List<ProviderStatus>>(emptyList())
    val status: StateFlow<List<ProviderStatus>> = _status.asStateFlow()

    fun providers(): List<AiProvider> = registry.all()
    fun localProvider(): LiteRtLmProvider? = local

    @Synchronized
    fun rebuild(settings: AppSettings, installed: List<ModelDescriptor>) {
        gate.privateMode = settings.dataControl == ai.astra.core.router.DataControl.NEVER_SEND
        gate.allowLanInPrivateMode = settings.allowLanInPrivate

        // Local model.
        val active = installed.firstOrNull { it.id == settings.activeLocalModelId } ?: installed.firstOrNull { it.runnable }
        val key = active?.let { "${it.id}:${settings.useGpu}:${it.supportsVision}:${it.supportsAudio}:${it.capabilities}" }
        if (key != localKey) {
            local?.let { registry.unregister(it.info.id) }
            local = active?.let { LiteRtLmProvider(it, models.fileFor(it), context.cacheDir, settings.useGpu) }
            local?.let { registry.register(it) }
            localKey = key
        }

        // Endpoints.
        val wanted = settings.endpoints.map { "endpoint:${it.id}" }.toSet()
        registry.all().filter { it.info.id.startsWith("endpoint:") && it.info.id !in wanted }.forEach { registry.unregister(it.info.id) }
        settings.endpoints.forEach { cfg ->
            val c = cfg.copy(id = "endpoint:${cfg.id}")
            registry.register(createHttpProvider(c, UrlConnectionTransport(gate, c.locality)) { secrets.get(SecretStore.endpointKey(cfg.id)) })
        }
    }

    suspend fun refreshStatus() {
        _status.value = registry.all().map { p ->
            val a = p.availability()
            val detail = when (p) {
                is LiteRtLmProvider -> "LiteRT-LM · ${p.loadState.name.lowercase()}" + (if (p.loadState == LoadState.READY) " · ${p.backendName}" else "") + (p.loadError?.let { " · $it" } ?: "")
                else -> p.info.runtime + " · " + p.info.locality.name.lowercase()
            }
            ProviderStatus(p.info, a, detail)
        }
    }

    suspend fun loadLocal(): Result<Unit> {
        val p = local ?: return Result.failure(IllegalStateException("No local model installed"))
        return p.load().also { refreshStatus() }
    }

    fun unloadLocal() { local?.close() }

    suspend fun testEndpoint(cfg: EndpointConfig): Result<String> = runCatching {
        val p = createHttpProvider(cfg.copy(id = "test"), UrlConnectionTransport(gate, cfg.locality)) { secrets.get(SecretStore.endpointKey(cfg.id)) }
        val r = p.generate(GenerationRequest(listOf(PromptTurn(Role.USER, listOf(Part.Text("Reply with the single word: ready")), setOf(ContentSource.USER))), maxOutputTokens = 16, temperature = 0.0))
        "OK in ${r.stats.durationMs} ms: “${r.text.trim().take(40)}”"
    }

    /** Asks an endpoint which models it offers. Uses the key typed in the form if given, else the saved one. */
    suspend fun listModels(cfg: EndpointConfig, keyOverride: String?): Result<List<String>> = runCatching {
        createHttpProvider(cfg.copy(id = "probe"), UrlConnectionTransport(gate, cfg.locality)) {
            keyOverride?.takeIf { it.isNotBlank() } ?: secrets.get(SecretStore.endpointKey(cfg.id))
        }.listModels()
    }

    /** Fixed-prompt benchmark: latency, speed, memory and thermal/battery impact. */
    suspend fun benchmark(provider: AiProvider): BenchmarkResult {
        val before = device.state.value
        val heapBefore = Debug.getNativeHeapAllocatedSize()
        var loadMs: Long? = null
        if (provider is LiteRtLmProvider && provider.loadState != LoadState.READY) {
            provider.load().getOrThrow(); loadMs = provider.loadMillis
        }
        val req = GenerationRequest(
            listOf(PromptTurn(Role.USER, listOf(Part.Text("Write exactly five sentences about how monsoon rain helps farmers in Rajasthan.")), setOf(ContentSource.USER))),
            maxOutputTokens = 200, temperature = 0.0,
        )
        val start = System.currentTimeMillis()
        var first = -1L
        var tokens = 0
        provider.stream(req).collect { e ->
            if (e is StreamEvent.Token) { if (first < 0) first = System.currentTimeMillis() - start; tokens++ }
        }
        val total = System.currentTimeMillis() - start
        device.refresh()
        val after = device.state.value
        return BenchmarkResult(
            providerId = provider.info.id,
            firstTokenMs = first.coerceAtLeast(0),
            tokensPerSecond = if (total > 0) tokens * 1000.0 / total else 0.0,
            tokens = tokens,
            totalMs = total,
            nativeHeapDeltaMb = (Debug.getNativeHeapAllocatedSize() - heapBefore) / (1024 * 1024),
            batteryTempBeforeC = before.batteryTempC,
            batteryTempAfterC = after.batteryTempC,
            batteryDropPercent = if (before.batteryPercent != null && after.batteryPercent != null) before.batteryPercent!! - after.batteryPercent!! else null,
            loadMs = loadMs,
        )
    }
}
