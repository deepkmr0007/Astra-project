package ai.astra.app.automation

import ai.astra.core.builder.AutomationDriver
import ai.astra.core.builder.DriverCommand
import ai.astra.core.builder.DriverResult
import ai.astra.core.builder.FieldType
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Phone automation runs through Android's Accessibility API — the same mechanism assistive apps
 * use. It is strictly opt-in: the user turns the service on in Android Settings, every run asks
 * first and shows each step, and a floating Stop (the Live/Run bar) ends it instantly. ASTRA never
 * reads the screen unless a run the user started is active, and never touches password fields.
 */
class PhoneAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile var instance: PhoneAccessibilityService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val name = "${context.packageName}/${PhoneAccessibilityService::class.java.name}"
            return flat.split(':').any { it.equals(name, ignoreCase = true) }
        }

        fun settingsIntent(): Intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}

/**
 * Drives other apps on the phone for PHONE-target automations. Only active while a user-started run
 * is in progress. Refuses to type into password fields.
 */
class PhoneDriver(private val context: Context, private val sleep: suspend (Long) -> Unit = { delay(it) }) : AutomationDriver {
    override val name = "This phone"
    val running = MutableStateFlow(false)

    override suspend fun ready(): Boolean = PhoneAccessibilityService.isEnabled(context) && PhoneAccessibilityService.instance != null

    override suspend fun execute(command: DriverCommand): DriverResult {
        val svc = PhoneAccessibilityService.instance ?: return DriverResult(false, "Turn on ASTRA in Settings → Accessibility first")
        return when (command) {
            is DriverCommand.LaunchApp -> launch(command.app)
            is DriverCommand.Tap -> if (tap(svc, command.target)) DriverResult(true) else DriverResult(false, "Couldn't find “${command.target}” on screen")
            is DriverCommand.Click -> if (tap(svc, command.target)) DriverResult(true) else DriverResult(false, "Couldn't find “${command.target}” on screen")
            is DriverCommand.Type -> type(svc, command.target, command.value)
            is DriverCommand.FillFields -> fill(svc, command)
            is DriverCommand.Scroll -> { scroll(svc, command.direction); DriverResult(true) }
            DriverCommand.Back -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); DriverResult(true) }
            is DriverCommand.WaitFor -> { val ok = waitFor(svc, command.target, command.timeoutMs); DriverResult(ok, if (ok) "" else "Did not appear") }
            is DriverCommand.CheckText -> { val ok = waitFor(svc, command.text, command.timeoutMs); DriverResult(ok, if (ok) "" else "Not shown") }
            is DriverCommand.Extract -> extract(svc, command.target)
            is DriverCommand.Navigate, DriverCommand.Scan -> DriverResult(false, "That step is for the computer browser, not the phone")
        }
    }

    private fun launch(app: String): DriverResult {
        val pm = context.packageManager
        // Launcher apps are visible thanks to the <queries> entry in the manifest (Android 11+ package visibility).
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = runCatching { pm.queryIntentActivities(launcher, 0) }.getOrDefault(emptyList())
        val want = app.trim()
        val match = apps.firstOrNull { it.activityInfo.packageName.equals(want, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().equals(want, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(want, true) }
            ?: return DriverResult(false, "App not found: $app")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return DriverResult(false, "Can't open $app")
        (PhoneAccessibilityService.instance ?: context).startActivity(intent)
        return DriverResult(true, "Opened ${match.loadLabel(pm)}")
    }

    private fun root(svc: AccessibilityService): AccessibilityNodeInfo? = svc.rootInActiveWindow

    private fun findByText(node: AccessibilityNodeInfo?, text: String): AccessibilityNodeInfo? {
        node ?: return null
        val want = text.trim().lowercase()
        node.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }?.let { return it }
        // Manual walk for content-description and partial matches.
        val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(node)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            val label = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
            if (n.isVisibleToUser && label.trim().lowercase().contains(want)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return null
    }

    private fun clickable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n
        while (cur != null) { if (cur.isClickable) return cur; cur = cur.parent }
        return n
    }

    private fun tap(svc: AccessibilityService, target: String): Boolean {
        val n = clickable(findByText(root(svc), target)) ?: return false
        return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun editableFor(svc: AccessibilityService, label: String): AccessibilityNodeInfo? {
        val node = findByText(root(svc), label) ?: return null
        if (node.isEditable) return node
        // Label next to a field: search siblings/parent subtree for the nearest editable.
        val parent = node.parent ?: return null
        for (i in 0 until parent.childCount) parent.getChild(i)?.takeIf { it.isEditable && it.isVisibleToUser }?.let { return it }
        val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(root(svc) ?: return null)
        while (stack.isNotEmpty()) { val x = stack.removeLast(); if (x.isEditable && x.isVisibleToUser) return x; for (i in 0 until x.childCount) x.getChild(i)?.let { stack.add(it) } }
        return null
    }

    private fun type(svc: AccessibilityService, target: String, value: String): DriverResult {
        val n = editableFor(svc, target) ?: return DriverResult(false, "No text field for “$target”")
        if (n.isPassword) return DriverResult(false, "Won't type into a password field — please do it yourself")
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) DriverResult(true) else DriverResult(false, "Couldn't set the text")
    }

    private suspend fun fill(svc: AccessibilityService, c: DriverCommand.FillFields): DriverResult {
        val failed = ArrayList<String>()
        for (f in c.values) {
            if (f.value.isBlank()) continue
            val r = if (f.type == FieldType.BUTTON) DriverResult(ok = tap(svc, f.label)) else type(svc, f.label.ifBlank { f.selector }, f.value)
            if (!r.ok) failed += f.label.ifBlank { f.selector }
            sleep(250)
        }
        return DriverResult(failed.size < c.values.size, if (failed.isEmpty()) "" else "Not found: ${failed.joinToString()}", failedFields = failed)
    }

    private fun scroll(svc: AccessibilityService, direction: String) {
        val action = if (direction.contains("up")) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        val stack = ArrayDeque<AccessibilityNodeInfo>(); root(svc)?.let { stack.add(it) }
        while (stack.isNotEmpty()) { val n = stack.removeLast(); if (n.isScrollable) { n.performAction(action); return }; for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) } }
    }

    private suspend fun waitFor(svc: AccessibilityService, text: String, timeoutMs: Long): Boolean {
        val until = System.currentTimeMillis() + timeoutMs.coerceIn(0, 120_000)
        while (System.currentTimeMillis() < until) {
            if (findByText(root(svc), text) != null) return true
            sleep(400)
        }
        return false
    }

    private fun extract(svc: AccessibilityService, target: String): DriverResult {
        val n = findByText(root(svc), target) ?: return DriverResult(false, "Not found: $target")
        val self = (n.text?.toString() ?: n.contentDescription?.toString()).orEmpty()
        val after = self.substringAfter(target, "").trim(' ', ':', '-', '–').ifBlank {
            n.parent?.let { p -> (0 until p.childCount).mapNotNull { p.getChild(it)?.text?.toString() }.firstOrNull { !it.contains(target, true) } }.orEmpty()
        }
        return if (after.isNotBlank()) DriverResult(true, data = after) else DriverResult(false, "No value near “$target”")
    }
}
