package ai.astra.app.voice

import ai.astra.app.inference.ProviderManager
import ai.astra.core.audio.Wav
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Long recordings → 30-second WAV chunks → on-device audio model → one transcript.
 * Requires an installed audio-capable model (Gemma 4 E2B/E4B); otherwise says so plainly.
 */
class Transcriber(private val providers: ProviderManager, private val workDir: File) {

    fun available(): Boolean = providers.localProvider()?.info?.capabilities?.contains(ai.astra.core.provider.Capability.TRANSCRIBE) == true

    suspend fun transcribe(file: File, language: String?, onProgress: (Int, Int) -> Unit): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val local = providers.localProvider() ?: error("No on-device model installed. Download Gemma 4 E2B in Setup to transcribe offline.")
            check(available()) { "${local.info.displayName} can't listen to audio. Gemma 4 E2B (in Setup) can." }
            val parts = if (Wav.read(file) != null) Wav.split(file, 30, File(workDir, "chunks-${file.nameWithoutExtension}")) else listOf(file)
            val out = StringBuilder()
            try {
                parts.forEachIndexed { i, part ->
                    onProgress(i + 1, parts.size)
                    val text = local.transcribe(part.absolutePath, language)
                    if (text.isNotBlank() && text != "[inaudible]") out.append(text.trim()).append(if (parts.size > 1) "\n" else "")
                }
            } finally {
                parts.filter { it != file }.forEach { it.delete() }
            }
            out.toString().trim().ifEmpty { "[No speech recognised]" }
        }
    }
}
