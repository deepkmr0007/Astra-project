package ai.astra.app.device

import ai.astra.core.device.DeviceState
import ai.astra.core.device.ThermalLevel
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import android.os.StatFs
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Live device health from platform APIs: connectivity, battery, charging, thermal status, RAM and
 * storage. Values the platform doesn't expose stay null rather than being guessed.
 */
class DeviceMonitor(private val context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val pm = context.getSystemService(PowerManager::class.java)
    private val am = context.getSystemService(ActivityManager::class.java)

    private val _state = MutableStateFlow(snapshot())
    val state: StateFlow<DeviceState> = _state.asStateFlow()

    private var started = false

    fun start() {
        if (started) return
        started = true
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = refresh()
            override fun onLost(network: Network) = refresh()
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refresh()
        })
        ContextCompat.registerReceiver(context, object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) = refresh()
        }, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        pm.addThermalStatusListener(context.mainExecutor) { refresh() }
    }

    fun refresh() { _state.value = snapshot() }

    private fun snapshot(): DeviceState {
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val plugged = (battery?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val stat = StatFs(context.filesDir.absolutePath)
        return DeviceState(
            online = online,
            metered = metered,
            batteryPercent = if (level >= 0 && scale > 0) level * 100 / scale else null,
            charging = plugged,
            thermal = when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
                else -> ThermalLevel.CRITICAL
            },
            totalRamMb = mem.totalMem / (1024 * 1024),
            availableRamMb = mem.availMem / (1024 * 1024),
            freeStorageMb = stat.availableBytes / (1024 * 1024),
            batteryTempC = if (tempTenths != Int.MIN_VALUE) tempTenths / 10.0 else null,
        )
    }
}
