@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.memory

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import ai.astra.core.export.Exporter
import ai.astra.core.memory.ConsolidationGroup
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.PrivacyLevel
import ai.astra.core.memory.RememberResult
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun MemoryScreen(c: AppContainer, toast: (String) -> Unit) {
    val all by remember { c.memoryStore.observe() }.collectAsState(initial = emptyList())
    val settings by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MemoryRecord>?>(null) }
    var editing by remember { mutableStateOf<MemoryRecord?>(null) }
    var adding by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var groups by remember { mutableStateOf<List<ConsolidationGroup>?>(null) }
    var menu by remember { mutableStateOf(false) }

    val exportJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val list = c.memory.list()
            val json = Exporter.bundle(emptyList(), list, emptyList(), emptyList(), emptyMap())
            withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } }
            toast(context.getString(R.string.exported_n, list.size))
        }
    }
    val exportMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val md = Exporter.memoriesMarkdown(c.memory.list())
            withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { it.write(md.toByteArray()) } }
            toast(context.getString(R.string.exported))
        }
    }
    val importJson = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val r = runCatching {
                val text = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }
                var stored = 0
                Exporter.parseMemories(text).forEach { m ->
                    if (c.memory.remember(m.content, MemorySource.IMPORT, projectId = m.projectId, explicit = true, typeOverride = m.type) is RememberResult.Stored) stored++
                }
                stored
            }
            toast(r.fold({ context.getString(R.string.imported_n, it) }, { context.getString(R.string.import_failed, it.message ?: "") }))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(stringResource(R.string.nav_memory)) }, actions = {
                Switch(checked = settings.memoryEnabled, onCheckedChange = { on -> scope.launch { c.settingsStore.update { it.copy(memoryEnabled = on) } } })
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.cd_more)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.consolidate)) }, onClick = { menu = false; scope.launch { groups = c.memory.proposeConsolidation() } })
                    DropdownMenuItem(text = { Text(stringResource(R.string.export_json)) }, onClick = { menu = false; exportJson.launch("astra-memory.json") })
                    DropdownMenuItem(text = { Text(stringResource(R.string.export_markdown)) }, onClick = { menu = false; exportMd.launch("astra-memory.md") })
                    DropdownMenuItem(text = { Text(stringResource(R.string.import_json)) }, onClick = { menu = false; importJson.launch(arrayOf("application/json", "text/plain")) })
                    DropdownMenuItem(text = { Text(stringResource(R.string.clear_all_memory)) }, onClick = { menu = false; confirmClear = true })
                }
            })
        },
        floatingActionButton = { FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, stringResource(R.string.add_memory)) } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
            Text(
                if (settings.memoryEnabled) stringResource(R.string.memory_explainer) else stringResource(R.string.memory_disabled),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(query, { q ->
                query = q
                scope.launch { results = if (q.isBlank()) null else c.memory.recall(q, projectId = c.currentProjectId, limit = 30, minScore = 0.05).map { it.record } }
            }, placeholder = { Text(stringResource(R.string.search_memory)) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            val shown = results ?: all.filter { !it.isExpired() }
            if (shown.isEmpty()) EmptyState(stringResource(R.string.memory_empty_title), stringResource(R.string.memory_empty_body))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { m ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(m.content)
                                Text(
                                    listOfNotNull(
                                        m.type.name.lowercase().replace('_', ' '),
                                        m.projectId?.let { context.getString(R.string.project_scoped) },
                                        if (m.privacyLevel == PrivacyLevel.SENSITIVE) context.getString(R.string.sensitive) else null,
                                        m.expiry?.let { context.getString(R.string.expires, DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(it))) },
                                        m.source.name.lowercase().replace('_', ' '),
                                    ).joinToString(" · "),
                                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            IconButton(onClick = { scope.launch { c.memory.setPinned(m.id, !m.pinned) } }) {
                                Icon(Icons.Filled.PushPin, stringResource(R.string.pin), tint = if (m.pinned) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (m.userEditable) IconButton(onClick = { editing = m }) { Icon(Icons.Filled.Edit, stringResource(R.string.edit)) }
                            IconButton(onClick = { scope.launch { c.memory.forget(m.id); results = results?.filter { it.id != m.id }; toast(context.getString(R.string.forgotten)) } }) {
                                Icon(Icons.Filled.Delete, stringResource(R.string.delete))
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { m ->
        var text by remember(m) { mutableStateOf(m.content) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text(stringResource(R.string.edit_memory)) },
            text = { OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { scope.launch { c.memory.edit(m.id, text) }; editing = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } })
    }
    if (adding) {
        var text by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { adding = false }, title = { Text(stringResource(R.string.add_memory)) },
            text = { OutlinedTextField(text, { text = it }, placeholder = { Text(stringResource(R.string.add_memory_hint)) }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val r = c.memory.remember(text, MemorySource.USER_EXPLICIT, projectId = c.currentProjectId)
                        toast(when (r) {
                            is RememberResult.Stored -> context.getString(R.string.saved_to_memory)
                            is RememberResult.Duplicate -> context.getString(R.string.already_in_memory)
                            is RememberResult.Conflict -> context.getString(R.string.memory_conflict_toast, r.existing.content)
                            is RememberResult.Refused -> r.reason
                        })
                    }
                    adding = false
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text(stringResource(R.string.cancel)) } })
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text(stringResource(R.string.clear_all_memory)) },
        text = { Text(stringResource(R.string.clear_all_memory_body)) },
        confirmButton = { TextButton(onClick = { scope.launch { c.memory.clearAll() }; confirmClear = false; toast(context.getString(R.string.memory_cleared)) }) { Text(stringResource(R.string.delete_everything)) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.cancel)) } })
    groups?.let { gs ->
        AlertDialog(onDismissRequest = { groups = null }, title = { Text(stringResource(R.string.consolidate)) },
            text = {
                LazyColumn {
                    if (gs.isEmpty()) item { Text(stringResource(R.string.consolidate_none)) }
                    items(gs) { g ->
                        Column(Modifier.padding(vertical = 8.dp)) {
                            Text(stringResource(R.string.consolidate_merge_n, g.members.size), fontWeight = FontWeight.SemiBold)
                            Text(g.merged, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { scope.launch { c.memory.applyConsolidation(g); groups = groups?.minus(g) } }) { Text(stringResource(R.string.apply)) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { groups = null }) { Text(stringResource(R.string.done)) } })
    }
}
