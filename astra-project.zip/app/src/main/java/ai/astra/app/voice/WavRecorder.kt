package ai.astra.app.voice

import ai.astra.core.audio.Wav
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.RandomAccessFile

/**
 * Records 16 kHz mono PCM to a WAV file for on-device transcription. Recording runs only while the
 * user keeps the recorder screen open and has pressed Record — never in the background.
 */
class WavRecorder(private val scope: CoroutineScope) {
    private val sampleRate = 16_000
    private var record: AudioRecord? = null
    private var job: Job? = null
    private var file: File? = null

    private val _seconds = MutableStateFlow(0.0)
    val seconds: StateFlow<Double> = _seconds.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    /** Caller must hold RECORD_AUDIO. */
    @SuppressLint("MissingPermission")
    fun start(target: File): Result<Unit> = runCatching {
        check(record == null) { "Already recording" }
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minBuf > 0) { "Microphone not available" }
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 4)
        check(r.state == AudioRecord.STATE_INITIALIZED) { "Microphone could not be opened" }
        record = r
        file = target
        target.parentFile?.mkdirs()
        RandomAccessFile(target, "rw").use { it.setLength(0); it.write(ByteArray(44)) } // header placeholder
        r.startRecording()
        _recording.value = true
        _seconds.value = 0.0
        job = scope.launch(Dispatchers.IO) {
            val buf = ShortArray(minBuf)
            val bytes = ByteArray(minBuf * 2)
            var total = 0L
            RandomAccessFile(target, "rw").use { out ->
                out.seek(44)
                while (isActive && _recording.value) {
                    val n = r.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    var peak = 0
                    for (i in 0 until n) {
                        val v = buf[i].toInt()
                        bytes[2 * i] = (v and 0xff).toByte(); bytes[2 * i + 1] = ((v shr 8) and 0xff).toByte()
                        if (kotlin.math.abs(v) > peak) peak = kotlin.math.abs(v)
                    }
                    out.write(bytes, 0, n * 2)
                    total += n * 2
                    _level.value = (peak / 32768f).coerceIn(0f, 1f)
                    _seconds.value = total / (sampleRate * 2.0)
                }
                out.seek(0)
                out.write(Wav.header(sampleRate, 1, 16, total))
            }
        }
    }

    /** Stops and finalises the WAV header. Returns the file. */
    suspend fun stop(): File? {
        _recording.value = false
        job?.join()
        job = null
        record?.run { runCatching { stop() }; release() }
        record = null
        _level.value = 0f
        return file.also { file = null }
    }
}
