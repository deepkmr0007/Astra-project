package ai.astra.app.plugins

import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.jsonArr
import ai.astra.core.json.str
import ai.astra.core.plugins.HttpPluginTool
import ai.astra.core.plugins.PluginManifest
import ai.astra.core.provider.HttpTransport
import ai.astra.core.tools.ToolRegistry
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

data class InstalledPlugin(val manifest: PluginManifest, val enabled: Boolean, val raw: String)

/**
 * Declarative plugins: a validated JSON manifest whose tools are HTTPS calls. No third-party code
 * is loaded. Tools are registered only while the plugin is enabled, and every call still goes
 * through the firewall (permissions, risk, confirmation) and the network gate.
 */
class PluginStore(context: Context, private val transport: HttpTransport, private val registry: ToolRegistry) {
    private val dir = File(context.filesDir, "plugins").apply { mkdirs() }
    private val enabledFile = File(dir, "enabled.json")
    private val _plugins = MutableStateFlow<List<InstalledPlugin>>(emptyList())
    val plugins: StateFlow<List<InstalledPlugin>> = _plugins.asStateFlow()

    companion object {
        /** A real, keyless example: Wikipedia's page-summary REST API. */
        val EXAMPLE = """
            {
              "id": "org.wikipedia.summary",
              "name": "Wikipedia Summary",
              "version": "1.0.0",
              "permissions": ["internet"],
              "tools": [
                {
                  "name": "wiki_summary",
                  "description": "Short summary of a Wikipedia article by exact title (English).",
                  "risk": "low",
                  "network": true,
                  "input_schema": {"type": "object", "properties": {"title": {"type": "string"}}, "required": ["title"]},
                  "http": {"method": "GET", "url": "https://en.wikipedia.org/api/rest_v1/page/summary/{title}"}
                }
              ],
              "ui": ["chat_card"]
            }
        """.trimIndent()
    }

    init { reload() }

    private fun enabledIds(): Set<String> = runCatching { Json.parse(enabledFile.readText()).arr().mapNotNull { it.str() }.toSet() }.getOrDefault(emptySet())

    fun reload() {
        val enabled = enabledIds()
        val list = dir.listFiles { f -> f.name.endsWith(".plugin.json") }.orEmpty().mapNotNull { f ->
            val raw = runCatching { f.readText() }.getOrNull() ?: return@mapNotNull null
            PluginManifest.parse(raw).getOrNull()?.let { InstalledPlugin(it, it.id in enabled, raw) }
        }.sortedBy { it.manifest.name }
        // Re-sync tool registrations.
        _plugins.value.forEach { p -> p.manifest.tools.forEach { registry.unregister(it.name) } }
        list.filter { it.enabled }.forEach { p ->
            p.manifest.tools.filter { it.http != null }.forEach { registry.register(HttpPluginTool(p.manifest, it, transport)) }
        }
        _plugins.value = list
    }

    fun install(raw: String, builtInToolNames: Set<String>): Result<PluginManifest> = PluginManifest.parse(raw).mapCatching { m ->
        val clash = m.tools.map { it.name }.filter { it in builtInToolNames && _plugins.value.none { p -> p.manifest.id == m.id } }
        require(clash.isEmpty()) { "Tool name already used by ASTRA: ${clash.joinToString()}" }
        require(m.tools.all { it.http != null }) { "Every plugin tool needs an \"http\" action (no code plugins are allowed)" }
        File(dir, "${m.id}.plugin.json").writeText(raw)
        reload()
        m
    }

    fun setEnabled(id: String, on: Boolean) {
        val ids = enabledIds().let { if (on) it + id else it - id }
        enabledFile.writeText(Json.write(jsonArr(ids.toList())))
        reload()
    }

    fun remove(id: String) {
        setEnabled(id, false)
        File(dir, "$id.plugin.json").delete()
        reload()
    }
}
