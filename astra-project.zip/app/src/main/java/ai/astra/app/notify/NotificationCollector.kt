package ai.astra.app.notify

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CapturedNotification(val app: String, val title: String, val text: String, val time: Long)

/**
 * Optional notification intelligence. Android only binds this after you grant notification access
 * in system settings; ASTRA additionally ignores everything unless "Notification summaries" is on.
 * Notifications are kept in memory only (never stored or sent), and ASTRA never replies.
 */
class NotificationCollector : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!enabled || sbn.packageName == packageName || sbn.isOngoing) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }.getOrDefault(sbn.packageName)
        _recent.value = (_recent.value + CapturedNotification(app, title.take(120), text.take(400), sbn.postTime)).takeLast(100)
    }

    companion object {
        @Volatile var enabled: Boolean = false
        private val _recent = MutableStateFlow<List<CapturedNotification>>(emptyList())
        val recent: StateFlow<List<CapturedNotification>> = _recent.asStateFlow()
        fun clear() { _recent.value = emptyList() }

        fun hasAccess(context: Context): Boolean = NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)


        fun prompt(items: List<CapturedNotification>): String = buildString {
            append("Summarise these phone notifications for me. Group by app, highlight anything that needs action or looks important, ")
            append("and ignore promotions. Do not invent details. Never suggest replying automatically.\n\n")
            items.forEach { append("[${it.app}] ${it.title}: ${it.text}\n") }
        }
    }
}
