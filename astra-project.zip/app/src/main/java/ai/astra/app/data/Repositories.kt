package ai.astra.app.data

import ai.astra.core.chat.ConversationRepository
import ai.astra.core.documents.DocChunk
import ai.astra.core.documents.DocumentMeta
import ai.astra.core.documents.DocumentStore
import ai.astra.core.documents.LocatorKind
import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.int
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.num
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemorySource
import ai.astra.core.memory.MemoryStore
import ai.astra.core.memory.MemoryType
import ai.astra.core.memory.PrivacyLevel
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Conversation
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.ExecutionTrace
import ai.astra.core.model.Feedback
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.model.Project
import ai.astra.core.model.Role
import ai.astra.core.model.VerificationSummary
import ai.astra.core.tasks.Priority
import ai.astra.core.tasks.TaskItem
import ai.astra.core.tasks.TaskStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** JSON codecs for values Room stores as text. */
object Codec {
    fun floats(v: FloatArray): ByteArray = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN).apply { v.forEach { putFloat(it) } }.array()
    fun floats(b: ByteArray): FloatArray { val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN); return FloatArray(b.size / 4) { bb.getFloat() } }

    fun parts(parts: List<Part>): String = Json.write(jsonArr(parts.map { p ->
        when (p) {
            is Part.Text -> jsonObj("t" to "text", "text" to p.text)
            is Part.Image -> jsonObj("t" to "image", "path" to p.path, "mime" to p.mimeType)
            is Part.Audio -> jsonObj("t" to "audio", "path" to p.path, "mime" to p.mimeType)
            is Part.DocumentRef -> jsonObj("t" to "doc", "id" to p.documentId, "title" to p.title)
            is Part.Code -> jsonObj("t" to "code", "lang" to p.language, "code" to p.code)
        }
    }))

    fun parts(json: String): List<Part> = runCatching {
        Json.parse(json).arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            when (o["t"].str()) {
                "text" -> Part.Text(o["text"].str() ?: "")
                "image" -> Part.Image(o["path"].str() ?: "", o["mime"].str() ?: "image/jpeg")
                "audio" -> Part.Audio(o["path"].str() ?: "", o["mime"].str() ?: "audio/wav")
                "doc" -> Part.DocumentRef(o["id"].str() ?: "", o["title"].str() ?: "")
                "code" -> Part.Code(o["lang"].str() ?: "", o["code"].str() ?: "")
                else -> null
            }
        }
    }.getOrDefault(listOf(Part.Text(json)))

    fun trace(t: ExecutionTrace?): String? = t?.let {
        Json.write(jsonObj(
            "providerId" to it.providerId, "model" to it.model, "locality" to it.locality, "mode" to it.mode,
            "networkUsed" to it.networkUsed, "bytesSent" to it.bytesSent, "dataSent" to it.dataSent, "tools" to it.tools,
            "tokensOut" to it.tokensOut, "tps" to it.tokensPerSecond, "latencyMs" to it.latencyMs, "reasons" to it.routeReasons,
            "warnings" to it.warnings,
            "verification" to it.verification?.let { v ->
                jsonObj("steps" to v.steps, "toolCalls" to v.toolCalls, "toolFailures" to v.toolFailures, "calc" to v.calculationsVerified,
                    "sources" to v.sourcesUsed, "selfReview" to v.selfReview, "uncertainties" to v.uncertainties, "limits" to v.limitsHit)
            },
        ))
    }

    private fun strings(v: JsonValue?): List<String> = v.arr().mapNotNull { it.str() }

    fun trace(json: String?): ExecutionTrace? = json?.let { s ->
        runCatching {
            val o = Json.parse(s).obj()!!
            val v = o["verification"].obj()
            ExecutionTrace(
                providerId = o["providerId"].str() ?: "", model = o["model"].str() ?: "",
                locality = Locality.valueOf(o["locality"].str() ?: "ON_DEVICE"), mode = ExecutionMode.valueOf(o["mode"].str() ?: "LOCAL"),
                networkUsed = o["networkUsed"].bool() ?: false, bytesSent = o["bytesSent"].long() ?: 0,
                dataSent = strings(o["dataSent"]), tools = strings(o["tools"]), tokensOut = o["tokensOut"].int() ?: 0,
                tokensPerSecond = o["tps"].num() ?: 0.0, latencyMs = o["latencyMs"].long() ?: 0, routeReasons = strings(o["reasons"]),
                warnings = strings(o["warnings"]),
                verification = v?.let {
                    VerificationSummary(it["steps"].int() ?: 0, it["toolCalls"].int() ?: 0, it["toolFailures"].int() ?: 0, it["calc"].bool(),
                        it["sources"].int() ?: 0, it["selfReview"].bool() ?: false, strings(it["uncertainties"]), strings(it["limits"]))
                },
            )
        }.getOrNull()
    }
}

fun ConversationEntity.toModel() = Conversation(id, title, projectId, folder, pinned, archived, parentId, forkedFromMessageId, temporary, createdAt, updatedAt)
fun Conversation.toEntity(summary: String? = null, until: Long? = null) = ConversationEntity(id, title, projectId, folder, pinned, archived, parentConversationId, forkedFromMessageId, temporary, createdAt, updatedAt, summary, until)
fun MessageEntity.toModel() = ChatMessage(id, conversationId, Role.valueOf(role), Codec.parts(partsJson), createdAt, Codec.trace(traceJson), runCatching { Feedback.valueOf(feedback) }.getOrDefault(Feedback.NONE))
fun ChatMessage.toEntity() = MessageEntity(id, conversationId, role.name, Codec.parts(parts), createdAt, Codec.trace(trace), feedback.name)
fun ProjectEntity.toModel() = Project(id, name, instructions, privateByDefault, createdAt)
fun Project.toEntity() = ProjectEntity(id, name, instructions, privateByDefault, createdAt)
fun TaskEntity.toModel() = TaskItem(id, title, description, runCatching { Priority.valueOf(priority) }.getOrDefault(Priority.MEDIUM), deadline,
    runCatching { TaskStatus.valueOf(status) }.getOrDefault(TaskStatus.TODO), projectId, parentId, dependsOn.split(',').filter { it.isNotBlank() }.toSet(), estimateMinutes, createdAt)
fun TaskItem.toEntity() = TaskEntity(id, title, description, priority.name, deadline, status.name, projectId, parentId, dependsOn.joinToString(","), estimateMinutes, createdAt)

fun MemoryEntity.toModel() = MemoryRecord(
    id, createdAt, updatedAt, MemorySource.valueOf(source), MemoryType.valueOf(type), importance, confidence, PrivacyLevel.valueOf(privacyLevel),
    projectId, conversationId, content, Codec.floats(embedding), embedderId, expiry, userEditable, subjectKey, pinned,
)
fun MemoryRecord.toEntity() = MemoryEntity(
    id, createdAt, updatedAt, source.name, type.name, importance, confidence, privacyLevel.name, projectId, conversationId, content,
    Codec.floats(embedding), embedderId, expiry, userEditable, subjectKey, pinned,
)

class ChatRepository(private val db: AstraDatabase) : ConversationRepository {
    fun observeConversations(archived: Boolean = false): Flow<List<Conversation>> = db.conversations().observe(archived).map { l -> l.map { it.toModel() } }
    fun observeProjectConversations(projectId: String): Flow<List<Conversation>> = db.conversations().observeForProject(projectId).map { l -> l.map { it.toModel() } }
    fun observeMessages(conversationId: String): Flow<List<ChatMessage>> = db.messages().observe(conversationId).map { l -> l.map { it.toModel() } }

    override suspend fun conversation(id: String) = db.conversations().get(id)?.toModel()
    override suspend fun messages(conversationId: String) = db.messages().list(conversationId).map { it.toModel() }
    override suspend fun append(message: ChatMessage) {
        db.messages().insert(message.toEntity())
        db.conversations().touch(message.conversationId, System.currentTimeMillis())
    }
    override suspend fun summary(conversationId: String): Pair<String, Long>? =
        db.conversations().get(conversationId)?.let { c -> c.summary?.let { s -> s to (c.summaryUntil ?: 0L) } }
    override suspend fun setSummary(conversationId: String, summary: String, coveredUntil: Long) = db.conversations().setSummary(conversationId, summary, coveredUntil)
    override suspend fun project(id: String) = db.projects().get(id)?.toModel()

    suspend fun save(c: Conversation) {
        val existing = db.conversations().get(c.id)
        db.conversations().upsert(c.toEntity(existing?.summary, existing?.summaryUntil))
    }
    suspend fun delete(id: String) { db.messages().deleteForConversation(id); db.conversations().delete(id) }
    suspend fun deleteMessage(id: String) = db.messages().delete(id)
    suspend fun deleteAfter(conversationId: String, after: Long) = db.messages().deleteAfter(conversationId, after)
    suspend fun setFeedback(id: String, f: Feedback) = db.messages().setFeedback(id, f.name)
    suspend fun search(q: String) = db.conversations().search(q).map { it.toModel() }
    suspend fun allConversations() = db.conversations().all().map { it.toModel() }

    fun observeProjects(): Flow<List<Project>> = db.projects().observe().map { l -> l.map { it.toModel() } }
    suspend fun allProjects() = db.projects().all().map { it.toModel() }
    suspend fun saveProject(p: Project) = db.projects().upsert(p.toEntity())
    suspend fun deleteProject(id: String) = db.projects().delete(id)

    fun observeTasks(): Flow<List<TaskItem>> = db.tasks().observe().map { l -> l.map { it.toModel() } }
    suspend fun allTasks() = db.tasks().all().map { it.toModel() }
    suspend fun saveTask(t: TaskItem) = db.tasks().upsert(t.toEntity())
    suspend fun deleteTask(id: String) = db.tasks().delete(id)
}

class RoomMemoryStore(private val db: AstraDatabase) : MemoryStore {
    fun observe(): Flow<List<MemoryRecord>> = db.memories().observe().map { l -> l.mapNotNull { runCatching { it.toModel() }.getOrNull() } }
    override suspend fun upsert(record: MemoryRecord) = db.memories().upsert(record.toEntity())
    override suspend fun get(id: String) = db.memories().get(id)?.toModel()
    override suspend fun delete(id: String) = db.memories().delete(id) > 0
    override suspend fun all() = db.memories().all().mapNotNull { runCatching { it.toModel() }.getOrNull() }
    override suspend fun clear() = db.memories().clear()
}

class RoomDocumentStore(private val db: AstraDatabase) : DocumentStore {
    fun observe(): Flow<List<DocumentMeta>> = db.documents().observe().map { l -> l.map { it.toModel() } }

    override suspend fun put(meta: DocumentMeta, chunks: List<DocChunk>) {
        db.documents().upsert(DocumentEntity(meta.id, meta.title, meta.mimeType, meta.locator.name, meta.unitCount, meta.chunkCount, meta.projectId, meta.sha256, meta.importedAt, meta.embedderId))
        chunks.chunked(200).forEach { batch -> db.documents().insertChunks(batch.map { ChunkEntity(it.id, it.documentId, it.ordinal, it.unit, it.text, Codec.floats(it.embedding)) }) }
    }
    override suspend fun documents() = db.documents().all().map { it.toModel() }
    override suspend fun chunks(documentIds: Collection<String>): List<DocChunk> =
        if (documentIds.isEmpty()) emptyList() else documentIds.chunked(500).flatMap { ids ->
            db.documents().chunks(ids).map { DocChunk(it.id, it.documentId, it.ordinal, it.unit, it.text, Codec.floats(it.embedding)) }
        }
    override suspend fun delete(documentId: String) { db.documents().deleteChunks(documentId); db.documents().deleteDocument(documentId) }

    private fun DocumentEntity.toModel() = DocumentMeta(id, title, mimeType, runCatching { LocatorKind.valueOf(locator) }.getOrDefault(LocatorKind.SECTION), unitCount, chunkCount, projectId, sha256, importedAt, embedderId)
}

class RoomWebCache(private val db: AstraDatabase) : ai.astra.core.web.WebCache {
    private fun WebPageEntity.toModel() = ai.astra.core.web.WebPage(url, finalUrl, title, text, retrievedAt, sha256, contentType, publishedAt)
    fun observe(): Flow<List<ai.astra.core.web.WebPage>> = db.webCache().observeHeaders().map { l -> l.map { it.toModel() } }
    override suspend fun put(page: ai.astra.core.web.WebPage) = db.webCache().upsert(
        WebPageEntity(page.url, page.finalUrl, page.title, page.text, page.retrievedAt, page.sha256, page.contentType, page.publishedAt))
    override suspend fun get(url: String) = db.webCache().get(url)?.toModel()
    override suspend fun all() = db.webCache().all().map { it.toModel() }
    override suspend fun delete(url: String) = db.webCache().delete(url)
}
