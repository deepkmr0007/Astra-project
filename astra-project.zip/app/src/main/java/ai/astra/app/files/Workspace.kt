package ai.astra.app.files

import ai.astra.core.json.JsonValue
import ai.astra.core.json.str
import ai.astra.core.security.Permission
import ai.astra.core.security.RiskLevel
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolRegistry
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec
import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Controlled file workspace: ASTRA can only touch folders you picked with the system folder
 * picker (persisted Storage Access Framework grants). Paths look like "FolderName/sub/file.txt".
 */
class FolderWorkspace(private val context: Context, private val folders: () -> List<String>) {

    fun roots(): List<DocumentFile> = folders().mapNotNull { runCatching { DocumentFile.fromTreeUri(context, Uri.parse(it)) }.getOrNull() }
        .filter { it.exists() && it.isDirectory }

    fun resolve(path: String): DocumentFile? {
        val segs = path.trim().trim('/').split('/').filter { it.isNotBlank() }
        if (segs.isEmpty() || segs.any { it == ".." || it == "." }) return null
        var cur = roots().firstOrNull { it.name.equals(segs[0], ignoreCase = true) } ?: return null
        for (s in segs.drop(1)) cur = cur.findFile(s) ?: return null
        return cur
    }

    private fun parentAndName(path: String): Pair<DocumentFile, String>? {
        val p = path.trim().trim('/')
        val name = p.substringAfterLast('/')
        if (!p.contains('/') || name.isBlank() || name == ".." || name.contains('\\')) return null
        val parent = resolve(p.substringBeforeLast('/')) ?: return null
        return if (parent.isDirectory) parent to name else null
    }

    private fun mimeFor(name: String) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"

    fun list(path: String): String {
        if (path.isBlank() || path == "/") return roots().joinToString("\n") { "📁 ${it.name}/" }.ifEmpty { "No folders authorised. Add one in Files → Authorised folders." }
        val d = resolve(path) ?: return "Not found: $path"
        if (!d.isDirectory) return "${d.name} (${d.length()} bytes)"
        return d.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase() })).joinToString("\n") {
            if (it.isDirectory) "📁 ${it.name}/" else "📄 ${it.name} (${it.length()} bytes)"
        }.ifEmpty { "(empty)" }
    }

    fun search(query: String, limit: Int = 50): String {
        val q = query.lowercase()
        val hits = ArrayList<String>()
        fun walk(d: DocumentFile, prefix: String, depth: Int) {
            if (depth > 6 || hits.size >= limit) return
            for (f in d.listFiles()) {
                val p = "$prefix/${f.name}"
                if (f.name?.lowercase()?.contains(q) == true) hits += p
                if (f.isDirectory) walk(f, p, depth + 1)
                if (hits.size >= limit) return
            }
        }
        roots().forEach { walk(it, it.name ?: "", 0) }
        return hits.joinToString("\n").ifEmpty { "No files named like “$query”." }
    }

    fun read(path: String, maxChars: Int = 20_000): String {
        val f = resolve(path) ?: return "Not found: $path"
        if (f.isDirectory) return list(path)
        if (f.length() > 5_000_000) return "File is too large to read here (${f.length()} bytes)."
        val text = context.contentResolver.openInputStream(f.uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return "Cannot open $path"
        return text.take(maxChars) + if (text.length > maxChars) "\n[…truncated]" else ""
    }

    fun create(path: String, content: String): String {
        val (parent, name) = parentAndName(path) ?: return "Invalid path: $path"
        if (parent.findFile(name) != null) return "Refused: $name already exists (ASTRA never silently overwrites)."
        val f = parent.createFile(mimeFor(name), name) ?: return "Could not create $name"
        context.contentResolver.openOutputStream(f.uri)?.use { it.write(content.toByteArray()) }
        return "Created $path (${content.length} chars)"
    }

    fun mkdir(path: String): String {
        val (parent, name) = parentAndName(path) ?: return "Invalid path: $path"
        return if (parent.findFile(name) != null) "Already exists: $path" else if (parent.createDirectory(name) != null) "Created folder $path" else "Could not create folder"
    }

    fun rename(path: String, newName: String): String {
        if (newName.contains('/') || newName.isBlank()) return "Invalid new name"
        val f = resolve(path) ?: return "Not found: $path"
        return if (f.renameTo(newName)) "Renamed to $newName" else "Rename failed"
    }

    fun copy(src: String, destDir: String): String {
        val s = resolve(src) ?: return "Not found: $src"
        val d = resolve(destDir)?.takeIf { it.isDirectory } ?: return "Destination folder not found: $destDir"
        if (s.isDirectory) return "Copying folders isn't supported yet"
        val name = s.name ?: return "Bad source"
        if (d.findFile(name) != null) return "Refused: $name already exists in $destDir"
        val out = d.createFile(s.type ?: mimeFor(name), name) ?: return "Could not create copy"
        context.contentResolver.openInputStream(s.uri)?.use { i -> context.contentResolver.openOutputStream(out.uri)?.use { o -> i.copyTo(o) } }
        return "Copied to $destDir/$name"
    }

    fun move(src: String, destDir: String): String {
        val r = copy(src, destDir)
        if (!r.startsWith("Copied")) return r
        return if (resolve(src)?.delete() == true) r.replace("Copied", "Moved") else "$r (original could not be removed)"
    }

    fun delete(path: String): String {
        val f = resolve(path) ?: return "Not found: $path"
        if (roots().any { it.uri == f.uri }) return "Refused: won't delete an authorised root folder"
        return if (f.delete()) "Deleted $path" else "Delete failed"
    }

    fun zip(paths: List<String>, dest: String): String {
        val (parent, name) = parentAndName(dest) ?: return "Invalid destination"
        if (parent.findFile(name) != null) return "Refused: $name already exists"
        val files = paths.mapNotNull { resolve(it) }.filter { it.isFile }
        if (files.isEmpty()) return "No files to compress"
        val out = parent.createFile("application/zip", name) ?: return "Could not create $name"
        context.contentResolver.openOutputStream(out.uri)?.use { os ->
            ZipOutputStream(os).use { z ->
                files.forEach { f ->
                    z.putNextEntry(ZipEntry(f.name ?: "file"))
                    context.contentResolver.openInputStream(f.uri)?.use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
        return "Compressed ${files.size} file(s) into $dest"
    }

    fun unzip(zipPath: String, destDir: String): String {
        val z = resolve(zipPath) ?: return "Not found: $zipPath"
        val d = resolve(destDir)?.takeIf { it.isDirectory } ?: return "Destination folder not found"
        var count = 0
        var total = 0L
        context.contentResolver.openInputStream(z.uri)?.use { input ->
            ZipInputStream(input).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val name = e.name.substringAfterLast('/')
                    if (e.isDirectory || name.isBlank() || e.name.contains("..")) continue // zip-slip guard: flat extract only
                    if (d.findFile(name) != null) continue
                    val f = d.createFile(mimeFor(name), name) ?: continue
                    context.contentResolver.openOutputStream(f.uri)?.use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zin.read(buf); if (n < 0) break
                            total += n
                            if (total > 500L * 1024 * 1024) throw IllegalStateException("Archive too large (zip-bomb guard)")
                            o.write(buf, 0, n)
                        }
                    }
                    count++
                    if (count > 2000) break
                }
            }
        }
        return "Extracted $count file(s) into $destDir"
    }

    /** Registers the file tools. Risk levels drive the firewall: deletion and moves always ask. */
    fun registerTools(registry: ToolRegistry) {
        fun tool(name: String, desc: String, schema: String, risk: RiskLevel, block: (JsonValue.Obj) -> String) = object : Tool {
            override val spec = ToolSpec(name, desc, schema, """{"type":"string"}""", risk, setOf(Permission.FILES), ExecutionEnvironment.DEVICE_API)
            override suspend fun run(args: JsonValue.Obj): ToolResult = withContext(Dispatchers.IO) {
                runCatching { ToolResult.Ok(block(args)) }.getOrElse { ToolResult.Error(it.message ?: "File operation failed") }
            }
        }
        val p = """{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}"""
        registry.register(tool("file_list", "Lists an authorised folder. Use path \"/\" to see the authorised roots.", p, RiskLevel.LOW) { list(it["path"].str() ?: "/") })
        registry.register(tool("file_search", "Finds files by name inside authorised folders.", """{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}""", RiskLevel.LOW) { search(it["query"].str().orEmpty()) })
        registry.register(tool("file_read", "Reads a text file from an authorised folder.", p, RiskLevel.LOW) { read(it["path"].str().orEmpty()) })
        registry.register(tool("file_create", "Creates a NEW text file (never overwrites).", """{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"]}""", RiskLevel.MEDIUM) { create(it["path"].str().orEmpty(), it["content"].str().orEmpty()) })
        registry.register(tool("file_mkdir", "Creates a folder.", p, RiskLevel.MEDIUM) { mkdir(it["path"].str().orEmpty()) })
        registry.register(tool("file_rename", "Renames a file or folder.", """{"type":"object","properties":{"path":{"type":"string"},"new_name":{"type":"string"}},"required":["path","new_name"]}""", RiskLevel.MEDIUM) { rename(it["path"].str().orEmpty(), it["new_name"].str().orEmpty()) })
        registry.register(tool("file_copy", "Copies a file into another authorised folder.", """{"type":"object","properties":{"path":{"type":"string"},"dest_dir":{"type":"string"}},"required":["path","dest_dir"]}""", RiskLevel.MEDIUM) { copy(it["path"].str().orEmpty(), it["dest_dir"].str().orEmpty()) })
        registry.register(tool("file_move", "Moves a file (copy, then remove the original).", """{"type":"object","properties":{"path":{"type":"string"},"dest_dir":{"type":"string"}},"required":["path","dest_dir"]}""", RiskLevel.HIGH) { move(it["path"].str().orEmpty(), it["dest_dir"].str().orEmpty()) })
        registry.register(tool("file_delete", "Deletes a file or folder. Always asks the user first.", p, RiskLevel.HIGH) { delete(it["path"].str().orEmpty()) })
        registry.register(tool("file_zip", "Compresses files into a new .zip.", """{"type":"object","properties":{"paths":{"type":"array","items":{"type":"string"}},"dest":{"type":"string"}},"required":["paths","dest"]}""", RiskLevel.MEDIUM) { a ->
            zip((a["paths"] as? JsonValue.Arr)?.items?.mapNotNull { it.str() }.orEmpty(), a["dest"].str().orEmpty())
        })
        registry.register(tool("file_unzip", "Extracts a .zip into an authorised folder (no overwrites).", """{"type":"object","properties":{"path":{"type":"string"},"dest_dir":{"type":"string"}},"required":["path","dest_dir"]}""", RiskLevel.MEDIUM) { unzip(it["path"].str().orEmpty(), it["dest_dir"].str().orEmpty()) })
    }
}
