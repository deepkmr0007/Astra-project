package ai.astra.app.automation

import ai.astra.core.desk.DeskDriver
import ai.astra.core.builder.FormSnapshot
import ai.astra.core.desk.DeskHub
import ai.astra.core.desk.DeskListener
import ai.astra.core.desk.DeskServer
import ai.astra.core.desk.PairedDevice
import ai.astra.core.desk.PairedDeviceStore
import ai.astra.core.json.jsonObj
import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

data class PairingRequest(val sessionId: String, val computerName: String, val code: String)

/**
 * The phone side of ASTRA Desk. Owns the LAN server and the encrypted hub, surfaces pairing and
 * connection state to the UI, answers the computer's chat through the engine, and hands the builder
 * a [DeskDriver] to run browser automations in the user's own Chrome.
 */
class DeskManager(
    private val context: Context,
    store: PairedDeviceStore,
    private val scope: CoroutineScope,
    /** Answers a chat message from the computer. Returns the reply; tokens stream via onToken. */
    private val answerChat: suspend (text: String, onToken: (String) -> Unit) -> String,
    private val log: (String) -> Unit = {},
) {
    private val _pairing = MutableStateFlow<PairingRequest?>(null)
    val pairing: StateFlow<PairingRequest?> = _pairing.asStateFlow()
    private val _devices = MutableStateFlow<List<PairedDevice>>(emptyList())
    val devices: StateFlow<List<PairedDevice>> = _devices.asStateFlow()
    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    /** Latest form the computer sent with "Scan form" (for the builder). */
    val lastForm = MutableStateFlow<FormSnapshot?>(null)

    val hub = DeskHub(store, object : DeskListener {
        override fun onPairingRequest(sessionId: String, computerName: String, code: String) { _pairing.value = PairingRequest(sessionId, computerName, code) }
        override fun onPaired(device: PairedDevice) { _pairing.value = null; refresh() }
        override fun onConnectionChanged() { refresh() }
        override fun onFormReport(deviceId: String, snapshot: FormSnapshot) { lastForm.value = snapshot }
        override fun onChat(deviceId: String, chatId: String, text: String) { scope.launch { handleChat(deviceId, chatId, text) } }
    })
    private var server: DeskServer? = null
    val driver = DeskDriver(hub)

    init { refresh() }

    val isServerRunning: Boolean get() = server?.isRunning == true

    fun start(): Boolean {
        if (server?.isRunning == true) return true
        return try {
            server = DeskServer(hub, DeskServer.DEFAULT_PORT, log).apply { start() }
            refresh(); true
        } catch (e: Exception) { log("Desk server failed: ${e.message}"); false }
    }

    fun stop() { server?.stop(); server = null; refresh() }

    fun confirmPairing() { _pairing.value?.let { hub.confirmPairing(it.sessionId); _pairing.value = null; refresh() } }
    fun rejectPairing() { _pairing.value?.let { hub.rejectPairing(it.sessionId); _pairing.value = null } }
    fun unpair(id: String) { hub.unpair(id); refresh() }

    private fun refresh() {
        _devices.value = hub.pairedDevices()
        _connected.value = hub.isConnected()
    }

    fun setRunning(v: Boolean) { _running.value = v }

    private suspend fun handleChat(deviceId: String, chatId: String, text: String) {
        val reply = runCatching {
            answerChat(text) { token -> hub.push(jsonObj("type" to "chat_delta", "chatId" to chatId, "text" to token), deviceId) }
        }.getOrElse { "Sorry, I couldn't answer that: ${it.message}" }
        hub.push(jsonObj("type" to "chat_done", "chatId" to chatId, "text" to reply), deviceId)
    }

    /** All non-loopback IPv4 addresses on the phone, best guess first (Wi-Fi / hotspot ranges). */
    fun addresses(): List<String> {
        val port = DeskServer.DEFAULT_PORT
        val list = ArrayList<String>()
        runCatching {
            NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }.forEach { nif ->
                nif.inetAddresses.toList().filterIsInstance<Inet4Address>().forEach { a -> list += "${a.hostAddress}:$port" }
            }
        }
        // Wi-Fi first (192.168 / 10. / 172.), then the rest.
        return list.sortedByDescending { it.startsWith("192.168") || it.startsWith("10.") || it.startsWith("172.") }
    }

    fun primaryAddress(): String? = addresses().firstOrNull()
    fun wifiName(): String? = runCatching { (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager)?.connectionInfo?.ssid?.trim('"')?.takeIf { it.isNotBlank() && it != "<unknown ssid>" } }.getOrNull()
}
