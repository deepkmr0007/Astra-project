@file:OptIn(ExperimentalLayoutApi::class)

package ai.astra.app.ui.settings

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.notify.NotificationCollector
import ai.astra.app.sync.BackupManager
import ai.astra.app.ui.SectionTitle
import ai.astra.core.sync.BadPassphraseException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WebResearchSettings(c: AppContainer) {
    val s by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var braveKey by remember { mutableStateOf("") }
    var tavilyKey by remember { mutableStateOf("") }
    var searx by remember { mutableStateOf(s.searxngUrl) }
    SectionTitle(stringResource(R.string.web_research))
    Text(stringResource(R.string.web_research_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("wikipedia" to "Wikipedia", "duckduckgo" to "DuckDuckGo", "brave" to "Brave", "searxng" to "SearXNG", "tavily" to "Tavily").forEach { (id, label) ->
            FilterChip(s.searchProvider == id, { scope.launch { c.settingsStore.update { it.copy(searchProvider = id) } } }, label = { Text(label) })
        }
    }
    when (s.searchProvider) {
        "brave" -> Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(braveKey, { braveKey = it }, label = { Text(stringResource(if (c.secrets.has(AppContainer.SEARCH_KEY_BRAVE)) R.string.api_key_saved else R.string.api_key)) },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f))
            TextButton(enabled = braveKey.isNotBlank(), onClick = { c.secrets.put(AppContainer.SEARCH_KEY_BRAVE, braveKey.trim()); braveKey = "" }) { Text(stringResource(R.string.save)) }
        }
        "tavily" -> Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(tavilyKey, { tavilyKey = it }, label = { Text(stringResource(if (c.secrets.has(AppContainer.SEARCH_KEY_TAVILY)) R.string.api_key_saved else R.string.api_key)) },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f))
            TextButton(enabled = tavilyKey.isNotBlank(), onClick = { c.secrets.put(AppContainer.SEARCH_KEY_TAVILY, tavilyKey.trim()); tavilyKey = "" }) { Text(stringResource(R.string.save)) }
        }
        "searxng" -> Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(searx, { searx = it }, label = { Text("https://searx.example.org") }, singleLine = true, modifier = Modifier.weight(1f))
            TextButton(onClick = { scope.launch { c.settingsStore.update { it.copy(searxngUrl = searx.trim()) } } }) { Text(stringResource(R.string.save)) }
        }
        "duckduckgo" -> Text(stringResource(R.string.ddg_note), style = MaterialTheme.typography.bodySmall)
        else -> Text(stringResource(R.string.wikipedia_note), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun VoiceSettings(c: AppContainer) {
    val s by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    SectionTitle(stringResource(R.string.voice))
    Text(stringResource(R.string.voice_language), style = MaterialTheme.typography.bodyMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("" to stringResource(R.string.lang_device), "hi-IN" to "हिन्दी", "en-IN" to "English (India)", "en-US" to "English (US)").forEach { (tag, label) ->
            FilterChip(s.voiceLanguage == tag, { scope.launch { c.settingsStore.update { it.copy(voiceLanguage = tag) } } }, label = { Text(label) })
        }
    }
    Text(stringResource(R.string.voice_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun NotificationSettings(c: AppContainer) {
    val s by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    SectionTitle(stringResource(R.string.notification_summaries))
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.notification_summaries_toggle))
            Text(stringResource(R.string.notification_summaries_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(s.notificationSummaries, { on -> scope.launch { c.settingsStore.update { it.copy(notificationSummaries = on) } } })
    }
    if (s.notificationSummaries && !NotificationCollector.hasAccess(context)) {
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
            Text(stringResource(R.string.grant_notification_access))
        }
    }
}

@Composable
fun BackupSettings(c: AppContainer, toast: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val backup = remember { BackupManager(c) }
    var askPass by remember { mutableStateOf<String?>(null) } // "export" or "restore"
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val createFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri != null) { pendingUri = uri; askPass = "export" }
    }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) { pendingUri = uri; askPass = "restore" }
    }
    SectionTitle(stringResource(R.string.encrypted_backup))
    Text(stringResource(R.string.encrypted_backup_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
        OutlinedButton(enabled = !busy, onClick = { createFile.launch("astra-backup.astra") }) { Text(stringResource(R.string.backup_now)) }
        OutlinedButton(enabled = !busy, onClick = { openFile.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.restore_merge)) }
    }
    askPass?.let { mode ->
        AlertDialog(onDismissRequest = { askPass = null; pass = "" },
            title = { Text(stringResource(if (mode == "export") R.string.backup_passphrase_title else R.string.restore_passphrase_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(if (mode == "export") R.string.backup_passphrase_body else R.string.restore_passphrase_body), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(pass, { pass = it }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(enabled = mode == "restore" || pass.length >= 8, onClick = {
                    val uri = pendingUri ?: return@TextButton
                    val pw = pass.toCharArray()
                    askPass = null; pass = ""
                    scope.launch {
                        busy = true
                        val r = runCatching {
                            if (mode == "export") {
                                val bytes = backup.export(pw)
                                withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } }
                                context.getString(R.string.backup_done)
                            } else {
                                val bytes = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
                                val s = backup.restore(bytes, pw.takeIf { it.isNotEmpty() })
                                context.getString(R.string.restore_done, s.chats, s.messages, s.memoriesAdded, s.memoriesUpdated, s.conflicts, s.projects, s.tasks)
                            }
                        }
                        pw.fill(' ')
                        busy = false
                        toast(r.getOrElse { e -> if (e is BadPassphraseException) context.getString(R.string.wrong_passphrase) else (e.message ?: "Failed") })
                    }
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { askPass = null; pass = "" }) { Text(stringResource(R.string.cancel)) } })
    }
}
