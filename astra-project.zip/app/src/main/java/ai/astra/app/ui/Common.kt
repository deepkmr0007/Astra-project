package ai.astra.app.ui

import ai.astra.app.PendingPrompt
import ai.astra.app.R
import ai.astra.app.ui.theme.HybridViolet
import ai.astra.app.ui.theme.LocalGreen
import ai.astra.app.ui.theme.OnlineBlue
import ai.astra.core.chat.ConsentAnswer
import ai.astra.core.model.ExecutionMode
import ai.astra.core.security.RiskLevel
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

fun modeColor(mode: ExecutionMode): Color = when (mode) {
    ExecutionMode.LOCAL -> LocalGreen
    ExecutionMode.ONLINE -> OnlineBlue
    ExecutionMode.HYBRID -> HybridViolet
}

/** LOCAL / ONLINE / HYBRID indicator. Always visible in the chat top bar. */
@Composable
fun ModeIndicator(mode: ExecutionMode, private: Boolean, modifier: Modifier = Modifier) {
    val color = modeColor(mode)
    val label = when (mode) {
        ExecutionMode.LOCAL -> stringResource(R.string.mode_local)
        ExecutionMode.ONLINE -> stringResource(R.string.mode_online)
        ExecutionMode.HYBRID -> stringResource(R.string.mode_hybrid)
    }
    val desc = stringResource(R.string.cd_execution_mode, label)
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .semantics { contentDescription = desc },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            when { private -> Icons.Filled.Shield; mode == ExecutionMode.LOCAL -> Icons.Filled.PhoneAndroid; mode == ExecutionMode.ONLINE -> Icons.Filled.Cloud; else -> Icons.Filled.Hub },
            contentDescription = null, tint = color, modifier = Modifier.size(14.dp),
        )
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

@Composable
fun Dot(color: Color) = Box(Modifier.size(8.dp).clip(CircleShape).background(color))

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) =
    Text(text.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = modifier.padding(top = 20.dp, bottom = 6.dp))

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Lightweight Markdown: fenced code blocks, **bold**, `inline code`, headings and bullets. */
@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    val segments = remember(text) { text.split("```") }
    SelectionContainer(modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            segments.forEachIndexed { i, seg ->
                if (i % 2 == 1) {
                    val code = seg.substringAfter('\n', seg).trimEnd()
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                        Text(code, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp).horizontalScroll(rememberScrollState()))
                    }
                } else if (seg.isNotBlank()) {
                    Text(inlineMarkdown(seg.trim('\n')), style = MaterialTheme.typography.bodyLarge, color = color)
                }
            }
        }
    }
}

fun inlineMarkdown(src: String): AnnotatedString = buildAnnotatedString {
    src.lines().forEachIndexed { li, rawLine ->
        if (li > 0) append('\n')
        var line = rawLine
        val heading = Regex("^#{1,6}\\s+").find(line)
        if (heading != null) {
            line = line.substring(heading.range.last + 1)
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(line) }
            return@forEachIndexed
        }
        if (Regex("^\\s*[-*]\\s+").containsMatchIn(line)) line = line.replaceFirst(Regex("^(\\s*)[-*]\\s+"), "$1• ")
        var i = 0
        while (i < line.length) {
            when {
                line.startsWith("**", i) && line.indexOf("**", i + 2) > i -> {
                    val end = line.indexOf("**", i + 2)
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(line.substring(i + 2, end)) }
                    i = end + 2
                }
                line[i] == '`' && line.indexOf('`', i + 1) > i -> {
                    val end = line.indexOf('`', i + 1)
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x332A3550))) { append(line.substring(i + 1, end)) }
                    i = end + 1
                }
                else -> { append(line[i]); i++ }
            }
        }
    }
}

fun shareFile(context: Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Root-level dialogs for engine questions: consent before sending online, and risky tool confirmation. */
@Composable
fun PendingPromptDialog(prompt: PendingPrompt?) {
    when (prompt) {
        null -> Unit
        is PendingPrompt.Consent -> {
            val r = prompt.request
            AlertDialog(
                onDismissRequest = { prompt.answer.complete(ConsentAnswer.DENY) },
                icon = { Icon(Icons.Filled.Cloud, contentDescription = null, tint = OnlineBlue) },
                title = { Text(stringResource(R.string.consent_title, r.provider.displayName)) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.consent_where, r.provider.locality.name.lowercase().replace('_', ' ')))
                        Text(stringResource(R.string.consent_what), fontWeight = FontWeight.SemiBold)
                        r.dataSummary.forEach { Text("• $it") }
                        if (r.sensitiveKinds.isNotEmpty()) Text(stringResource(R.string.consent_sensitive, r.sensitiveKinds.joinToString()), color = MaterialTheme.colorScheme.error)
                        Text(stringResource(R.string.consent_size, (r.approxBytes / 1024).coerceAtLeast(1)), style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    Column(horizontalAlignment = Alignment.End) {
                        TextButton(onClick = { prompt.answer.complete(ConsentAnswer.ALLOW_ONCE) }) { Text(stringResource(R.string.consent_once)) }
                        TextButton(onClick = { prompt.answer.complete(ConsentAnswer.ALLOW_FOR_CHAT) }) { Text(stringResource(R.string.consent_chat)) }
                    }
                },
                dismissButton = { TextButton(onClick = { prompt.answer.complete(ConsentAnswer.DENY) }) { Text(stringResource(R.string.consent_keep_local)) } },
            )
        }
        is PendingPrompt.Confirm -> {
            val r = prompt.request
            var typed by remember(prompt) { mutableStateOf("") }
            val strong = r.requiresStrongConfirmation
            AlertDialog(
                onDismissRequest = { prompt.answer.complete(false) },
                icon = { Icon(Icons.Filled.Shield, contentDescription = null, tint = if (r.risk >= RiskLevel.HIGH) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) },
                title = { Text(r.title) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(r.detail)
                        if (strong) {
                            Text(stringResource(R.string.confirm_type_word), color = MaterialTheme.colorScheme.error)
                            OutlinedTextField(typed, { typed = it }, singleLine = true)
                        }
                    }
                },
                confirmButton = { TextButton(enabled = !strong || typed.trim().equals("CONFIRM", true), onClick = { prompt.answer.complete(true) }) { Text(stringResource(R.string.allow)) } },
                dismissButton = { TextButton(onClick = { prompt.answer.complete(false) }) { Text(stringResource(R.string.deny)) } },
            )
        }
    }
}
