@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.camera

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.core.vision.ImageAnalysis as AstraAnalysis
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Camera mode: point → (optional) live on-device text recognition and labels at a chosen rate →
 * "Ask about this" captures the frame and sends it to chat with your question.
 * Frames are analysed on the phone; nothing is uploaded unless the chosen model is online.
 */
@Composable
fun CameraScreen(c: AppContainer, onBack: () -> Unit, onAsk: (imagePath: String, question: String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var live by remember { mutableStateOf(false) }
    var fps by remember { mutableStateOf(1f) }
    var latest by remember { mutableStateOf<AstraAnalysis?>(null) }
    var question by remember { mutableStateOf("") }
    var capturing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val lastFrame = remember { AtomicLong(0L) }
    val busy = remember { AtomicBoolean(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val previewView = remember { PreviewView(context) }
    val capture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val liveRef = remember { mutableStateOf(false) }
    val fpsRef = remember { mutableStateOf(1f) }
    liveRef.value = live
    fpsRef.value = fps

    LaunchedEffect(Unit) { if (!granted) permission.launch(Manifest.permission.CAMERA) }

    DisposableEffect(granted) {
        var provider: ProcessCameraProvider? = null
        if (granted) scope.launch {
            runCatching {
                val p = ProcessCameraProvider.getInstance(context).await()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { proxy ->
                    val now = System.currentTimeMillis()
                    val interval = (1000f / fpsRef.value.coerceIn(0.2f, 4f)).toLong()
                    if (!liveRef.value || now - lastFrame.get() < interval || !busy.compareAndSet(false, true)) { proxy.close(); return@setAnalyzer }
                    lastFrame.set(now)
                    val bmp = runCatching {
                        val raw = proxy.toBitmap()
                        val rot = proxy.imageInfo.rotationDegrees
                        if (rot == 0) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
                    }.getOrNull()
                    proxy.close()
                    if (bmp == null) { busy.set(false); return@setAnalyzer }
                    scope.launch {
                        latest = runCatching { c.vision.analyze(bmp) }.getOrNull()
                        busy.set(false)
                    }
                }
                p.unbindAll()
                p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, analysis)
            }.onFailure { error = it.message ?: "Camera failed to start" }
        }
        onDispose { runCatching { provider?.unbindAll() } }
    }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.camera_mode)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (granted) AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                else Text(stringResource(R.string.camera_permission_needed), Modifier.align(Alignment.Center).padding(24.dp))
                if (live) latest?.let { a ->
                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().heightIn(max = 200.dp).background(Color(0xAA000000), RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                        .verticalScroll(rememberScrollState()).padding(10.dp)) {
                        if (a.labels.isNotEmpty()) Text(a.labels.joinToString { "${it.text} ${(it.confidence * 100).toInt()}%" }, color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                        Text(a.ocrText.ifBlank { stringResource(R.string.no_text_seen) }.take(600), color = Color.White, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.live_recognition), Modifier.weight(1f))
                    Switch(live, { live = it; if (!it) latest = null })
                }
                if (live) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.5f, 1f, 2f).forEach { f -> FilterChip(fps == f, { fps = f }, label = { Text(stringResource(R.string.frames_per_sec, f.toString())) }) }
                }
                OutlinedTextField(question, { question = it }, placeholder = { Text(stringResource(R.string.camera_question_hint)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(enabled = granted && !capturing, modifier = Modifier.fillMaxWidth(), onClick = {
                    capturing = true
                    val file = File(File(context.filesDir, "attachments").apply { mkdirs() }, "cam-${System.currentTimeMillis()}.jpg")
                    capture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            capturing = false
                            onAsk(file.absolutePath, question.ifBlank { context.getString(R.string.camera_default_question) })
                        }
                        override fun onError(exception: ImageCaptureException) {
                            capturing = false
                            error = exception.message ?: "Capture failed"
                        }
                    })
                }) { Text(stringResource(if (capturing) R.string.capturing else R.string.ask_about_this_frame)) }
            }
        }
    }
}
