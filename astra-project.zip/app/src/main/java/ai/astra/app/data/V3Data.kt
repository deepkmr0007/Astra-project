package ai.astra.app.data

import ai.astra.core.builder.AutomationCodec
import ai.astra.core.builder.AutomationSpec
import ai.astra.core.builder.RunLedger
import ai.astra.core.data.CsvCodec
import ai.astra.core.data.DataTable
import ai.astra.core.data.InMemoryTableStore
import ai.astra.core.data.TableStore
import ai.astra.core.desk.PairedDevice
import ai.astra.core.desk.PairedDeviceStore
import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.learn.FeedbackRecord
import ai.astra.core.learn.Skill
import ai.astra.core.learn.SkillStore
import ai.astra.app.security.SecretStore
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

// ---------- Room entities (added in database version 2) ----------

@Entity(tableName = "automations")
data class AutomationEntity(@PrimaryKey val id: String, val name: String, val json: String, val updatedAt: Long)

@Entity(tableName = "run_ledgers")
data class RunLedgerEntity(@PrimaryKey val runId: String, val automationId: String, val json: String, val updatedAt: Long)

@Entity(tableName = "skills")
data class SkillEntity(@PrimaryKey val id: String, val json: String, val updatedAt: Long)

@Entity(tableName = "feedback")
data class FeedbackEntity(@PrimaryKey val id: String, val json: String, val createdAt: Long)

/** Imported data tables (Excel/CSV/OCR/PDF) kept for automations, stored as CSV. */
@Entity(tableName = "data_tables")
data class DataTableEntity(@PrimaryKey val name: String, val origin: String, val csv: String, val confidence: Double, val importedAt: Long)

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automations ORDER BY updatedAt DESC") fun observe(): Flow<List<AutomationEntity>>
    @Query("SELECT * FROM automations") suspend fun all(): List<AutomationEntity>
    @Query("SELECT * FROM automations WHERE id = :id") suspend fun get(id: String): AutomationEntity?
    @Upsert suspend fun upsert(a: AutomationEntity)
    @Query("DELETE FROM automations WHERE id = :id") suspend fun delete(id: String)
    @Query("SELECT * FROM run_ledgers WHERE automationId = :automationId ORDER BY updatedAt DESC") suspend fun ledgers(automationId: String): List<RunLedgerEntity>
    @Query("SELECT * FROM run_ledgers ORDER BY updatedAt DESC LIMIT 100") fun observeLedgers(): Flow<List<RunLedgerEntity>>
    @Upsert suspend fun upsertLedger(l: RunLedgerEntity)
    @Query("DELETE FROM run_ledgers WHERE runId = :runId") suspend fun deleteLedger(runId: String)
}

@Dao
interface SkillDao {
    @Query("SELECT * FROM skills ORDER BY updatedAt DESC") fun observe(): Flow<List<SkillEntity>>
    @Query("SELECT * FROM skills") suspend fun all(): List<SkillEntity>
    @Upsert suspend fun upsert(s: SkillEntity)
    @Query("DELETE FROM skills WHERE id = :id") suspend fun delete(id: String)
    @Query("SELECT * FROM feedback ORDER BY createdAt DESC") suspend fun feedback(): List<FeedbackEntity>
    @Query("SELECT COUNT(*) FROM feedback") fun feedbackCount(): Flow<Int>
    @Upsert suspend fun upsertFeedback(f: FeedbackEntity)
    @Query("DELETE FROM feedback") suspend fun clearFeedback()
}

@Dao
interface DataTableDao {
    @Query("SELECT * FROM data_tables ORDER BY importedAt DESC") fun observe(): Flow<List<DataTableEntity>>
    @Query("SELECT * FROM data_tables") suspend fun all(): List<DataTableEntity>
    @Query("SELECT * FROM data_tables WHERE name = :name") suspend fun get(name: String): DataTableEntity?
    @Upsert suspend fun upsert(t: DataTableEntity)
    @Query("DELETE FROM data_tables WHERE name = :name") suspend fun delete(name: String)
}

// ---------- Stores ----------

class RoomAutomationStore(private val dao: AutomationDao) {
    fun observe(): Flow<List<AutomationEntity>> = dao.observe()
    fun observeLedgers(): Flow<List<RunLedgerEntity>> = dao.observeLedgers()
    suspend fun all(): List<AutomationSpec> = dao.all().mapNotNull { runCatching { AutomationCodec.decode(it.json) }.getOrNull() }
    suspend fun get(id: String): AutomationSpec? = dao.get(id)?.let { runCatching { AutomationCodec.decode(it.json) }.getOrNull() }
    suspend fun save(spec: AutomationSpec) = dao.upsert(AutomationEntity(spec.id, spec.name, AutomationCodec.encode(spec, false), spec.updatedAt))
    suspend fun delete(id: String) = dao.delete(id)
    suspend fun ledgers(automationId: String): List<RunLedger> = dao.ledgers(automationId).mapNotNull { runCatching { RunLedger.decode(it.json) }.getOrNull() }
    suspend fun saveLedger(l: RunLedger) = dao.upsertLedger(RunLedgerEntity(l.runId, l.automationId, Json.write(l.toJson()), System.currentTimeMillis()))
    suspend fun deleteLedger(runId: String) = dao.deleteLedger(runId)
}

class RoomSkillStore(private val dao: SkillDao) : SkillStore {
    fun observe(): Flow<List<SkillEntity>> = dao.observe()
    override suspend fun all(): List<Skill> = dao.all().mapNotNull { runCatching { Skill.fromJson(Json.parse(it.json).obj()!!) }.getOrNull() }
    override suspend fun save(skill: Skill) = dao.upsert(SkillEntity(skill.id, Json.write(skill.toJson()), skill.updatedAt))
    override suspend fun delete(id: String) = dao.delete(id)

    fun feedbackCount(): Flow<Int> = dao.feedbackCount()
    suspend fun feedback(): List<FeedbackRecord> = dao.feedback().mapNotNull { runCatching { FeedbackRecord.fromJson(Json.parse(it.json).obj()!!) }.getOrNull() }
    suspend fun addFeedback(f: FeedbackRecord) = dao.upsertFeedback(FeedbackEntity(f.id, Json.write(f.toJson()), f.createdAt))
    suspend fun clearFeedback() = dao.clearFeedback()
}

class RoomTableStore(private val dao: DataTableDao) : TableStore {
    fun observe(): Flow<List<DataTableEntity>> = dao.observe()
    override suspend fun names(): List<String> = dao.all().map { it.name }
    override suspend fun get(name: String): DataTable? = (dao.get(name) ?: dao.all().firstOrNull { it.name.equals(name, true) })?.let { e ->
        CsvCodec.parse(e.name, e.csv).copy(origin = e.origin, confidence = e.confidence)
    }
    suspend fun save(table: DataTable) = dao.upsert(DataTableEntity(table.name, table.origin, CsvCodec.write(table), table.confidence, System.currentTimeMillis()))
    suspend fun delete(name: String) = dao.delete(name)
}

/**
 * Paired computers kept in encrypted preferences; the AES-256 channel key never leaves the device
 * and is never written in plaintext or included in exports.
 */
class VaultPairedDeviceStore(private val secrets: SecretStore) : PairedDeviceStore {
    private val index = "desk_devices_v1"

    @Synchronized override fun all(): List<PairedDevice> {
        val json = secrets.get(index) ?: return emptyList()
        return runCatching { Json.parse(json).arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            PairedDevice(o["id"].str() ?: return@mapNotNull null, o["name"].str() ?: "Computer",
                ai.astra.core.desk.DeskCrypto.unb64(o["key"].str() ?: return@mapNotNull null), (o["pairedAt"].str() ?: "0").toLongOrNull() ?: 0)
        } }.getOrDefault(emptyList())
    }

    @Synchronized override fun save(device: PairedDevice) {
        val list = all().filter { it.id != device.id } + device
        write(list)
    }

    @Synchronized override fun remove(id: String) { write(all().filter { it.id != id }) }

    private fun write(list: List<PairedDevice>) {
        secrets.put(index, Json.write(jsonArr(list.map { d ->
            jsonObj("id" to d.id, "name" to d.name, "key" to ai.astra.core.desk.DeskCrypto.b64(d.key), "pairedAt" to d.pairedAt.toString())
        })))
    }
}
