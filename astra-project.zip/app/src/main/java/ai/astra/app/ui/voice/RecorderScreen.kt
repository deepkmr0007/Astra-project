@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.voice

import ai.astra.app.AppContainer
import ai.astra.app.R
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Record a meeting or a voice note, then transcribe it fully on the device. */
@Composable
fun RecorderScreen(c: AppContainer, onBack: () -> Unit, onRecorded: (File, String) -> Unit, toast: (String) -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val recording by c.recorder.recording.collectAsState()
    val seconds by c.recorder.seconds.collectAsState()
    val level by c.recorder.level.collectAsState()
    val canTranscribe = c.transcriber.available()

    fun start() {
        val name = "Recording " + SimpleDateFormat("yyyy-MM-dd HH-mm", Locale.US).format(Date())
        val f = File(File(context.filesDir, "recordings").apply { mkdirs() }, "$name.wav")
        c.recorder.start(f).onFailure { toast(it.message ?: "Microphone error") }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) start() else toast(context.getString(R.string.mic_denied)) }

    // Keep the screen on while recording (recording never continues in the background).
    DisposableEffect(recording) {
        view.keepScreenOn = recording
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) { onDispose { if (c.recorder.recording.value) scope.launch { c.recorder.stop() } } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.record_and_transcribe)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%d:%02d".format(seconds.toInt() / 60, seconds.toInt() % 60), style = MaterialTheme.typography.displayMedium)
            LinearProgressIndicator(progress = { level }, modifier = Modifier.fillMaxWidth())
            Text(stringResource(if (canTranscribe) R.string.recorder_note else R.string.recorder_no_audio_model), style = MaterialTheme.typography.bodySmall,
                color = if (canTranscribe) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
            if (!recording) Button(onClick = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
                else permission.launch(Manifest.permission.RECORD_AUDIO)
            }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(stringResource(R.string.record)) }
            else Button(onClick = {
                scope.launch {
                    val f = c.recorder.stop() ?: return@launch
                    if (canTranscribe) onRecorded(f, f.nameWithoutExtension) else toast(context.getString(R.string.recording_saved, f.name))
                }
            }) { Text(stringResource(R.string.stop_and_transcribe)) }
        }
    }
}
