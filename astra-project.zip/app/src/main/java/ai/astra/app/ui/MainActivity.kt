package ai.astra.app.ui

import ai.astra.app.AstraApplication
import ai.astra.app.R
import ai.astra.app.security.AppLock
import ai.astra.app.ui.theme.AstraTheme
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.runBlocking

/**
 * Single activity. FragmentActivity is required by BiometricPrompt for the app lock.
 * Handles the Android share sheet and the text-selection "Ask ASTRA" action.
 */
class MainActivity : FragmentActivity() {
    private var locked by mutableStateOf(false)
    private var shared by mutableStateOf<SharedContent?>(null)
    private var lockError by mutableStateOf<String?>(null)
    private var backgroundedAt = 0L

    private val container get() = (application as AstraApplication).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Read persisted settings synchronously so the lock can never be skipped on a cold start.
        locked = runBlocking { container.settingsStore.current() }.appLock
        shared = parseShare(intent)
        setContent {
            AstraTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (locked) LockScreen() else AstraRoot(container, shared) { shared = null }
                }
            }
        }
        if (locked) unlock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        parseShare(intent)?.let { shared = it }
    }

    override fun onStop() {
        super.onStop()
        backgroundedAt = SystemClock.elapsedRealtime()
        container.speechIn.stop() // never keep listening in the background
    }

    override fun onStart() {
        super.onStart()
        val s = container.settingsStore.settings.value
        if (s.appLock && backgroundedAt > 0 && SystemClock.elapsedRealtime() - backgroundedAt > s.lockAfterSeconds * 1000L) {
            locked = true
            unlock()
        }
    }

    private fun unlock() {
        if (!AppLock.available(this)) { locked = false; return }
        AppLock.prompt(this, getString(R.string.unlock_title), getString(R.string.unlock_subtitle)) { ok, err ->
            if (ok) { locked = false; lockError = null } else lockError = err
        }
    }

    @Suppress("DEPRECATION")
    private fun parseShare(i: Intent?): SharedContent? {
        i ?: return null
        return when (i.action) {
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.let { SharedContent.TextIn(it) }
            Intent.ACTION_SEND -> {
                val type = i.type.orEmpty()
                val stream: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra(Intent.EXTRA_STREAM)
                when {
                    stream != null && type.startsWith("image/") -> SharedContent.ImageIn(stream)
                    stream != null -> SharedContent.DocumentIn(stream)
                    else -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { text ->
                        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT)
                        SharedContent.TextIn(if (subject != null) "$subject\n$text" else text)
                    }
                }
            }
            else -> null
        }
    }

    @androidx.compose.runtime.Composable
    private fun LockScreen() {
        Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
            Text(stringResource(R.string.locked_title), style = MaterialTheme.typography.titleLarge)
            lockError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(onClick = { unlock() }) { Text(stringResource(R.string.unlock)) }
        }
    }
}
