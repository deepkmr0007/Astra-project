@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.projects

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import ai.astra.app.ui.SectionTitle
import ai.astra.core.model.Project
import ai.astra.core.tasks.Priority
import ai.astra.core.tasks.TaskBreakdown
import ai.astra.core.tasks.TaskGraph
import ai.astra.core.tasks.TaskItem
import ai.astra.core.tasks.TaskStatus
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun ProjectsScreen(c: AppContainer, onOpenChat: (String) -> Unit, onNewChatInProject: (String) -> Unit, toast: (String) -> Unit) {
    val projects by remember { c.chatRepo.observeProjects() }.collectAsState(initial = emptyList())
    var openId by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val open = projects.firstOrNull { it.id == openId }

    if (open != null) {
        ProjectDetail(c, open, onBack = { openId = null }, onOpenChat = onOpenChat, onNewChat = { onNewChatInProject(open.id) }, toast = toast)
        return
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_projects)) }) },
        floatingActionButton = { FloatingActionButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, stringResource(R.string.new_project)) } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (projects.isEmpty()) EmptyState(stringResource(R.string.projects_empty_title), stringResource(R.string.projects_empty_body))
            projects.forEach { p ->
                Card(Modifier.fillMaxWidth().clickable { openId = p.id }) {
                    Column(Modifier.padding(14.dp)) {
                        Text((if (p.privateByDefault) "🔒 " else "") + p.name, fontWeight = FontWeight.SemiBold)
                        if (p.instructions.isNotBlank()) Text(p.instructions.take(120), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    if (creating) {
        var name by remember { mutableStateOf("") }
        var instructions by remember { mutableStateOf("") }
        var isPrivate by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { creating = false }, title = { Text(stringResource(R.string.new_project)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, singleLine = true)
                    OutlinedTextField(instructions, { instructions = it }, label = { Text(stringResource(R.string.project_instructions)) }, minLines = 3)
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.project_private), Modifier.weight(1f)); Switch(isPrivate, { isPrivate = it }) }
                }
            },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { scope.launch { c.chatRepo.saveProject(Project(name = name.trim(), instructions = instructions.trim(), privateByDefault = isPrivate)) }; creating = false }) { Text(stringResource(R.string.create)) } },
            dismissButton = { TextButton(onClick = { creating = false }) { Text(stringResource(R.string.cancel)) } })
    }
}

@Composable
private fun ProjectDetail(c: AppContainer, p: Project, onBack: () -> Unit, onOpenChat: (String) -> Unit, onNewChat: () -> Unit, toast: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val chats by remember(p.id) { c.chatRepo.observeProjectConversations(p.id) }.collectAsState(initial = emptyList())
    val allTasks by remember { c.chatRepo.observeTasks() }.collectAsState(initial = emptyList())
    val tasks = allTasks.filter { it.projectId == p.id }
    var instructions by remember(p.id) { mutableStateOf(p.instructions) }
    var addingTask by remember { mutableStateOf(false) }
    var breaking by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(p.name) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
            actions = { IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(instructions, { instructions = it }, label = { Text(stringResource(R.string.project_instructions)) }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { scope.launch { c.chatRepo.saveProject(p.copy(instructions = instructions)); toast(context.getString(R.string.saved)) } }) { Text(stringResource(R.string.save_instructions)) }
                Text(stringResource(R.string.project_private), Modifier.weight(1f))
                Switch(p.privateByDefault, { on -> scope.launch { c.chatRepo.saveProject(p.copy(privateByDefault = on)) } })
            }
            Text(stringResource(R.string.project_boundary_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            SectionTitle(stringResource(R.string.conversations))
            OutlinedButton(onClick = onNewChat) { Text(stringResource(R.string.new_chat_in_project)) }
            chats.forEach { conv -> Text("💬 ${conv.title}", modifier = Modifier.fillMaxWidth().clickable { onOpenChat(conv.id) }.padding(vertical = 10.dp)) }

            SectionTitle(stringResource(R.string.tasks))
            if (tasks.isNotEmpty()) {
                val progress = TaskGraph.progress(tasks)
                LinearProgressIndicator(progress = { progress.toFloat() }, modifier = Modifier.fillMaxWidth())
                Text(stringResource(R.string.progress_percent, (progress * 100).toInt()), style = MaterialTheme.typography.bodySmall)
            }
            val ordered = runCatching { TaskGraph.order(tasks) }.getOrElse { tasks }
            val ready = runCatching { TaskGraph.readyNow(tasks).map { it.id }.toSet() }.getOrDefault(emptySet())
            ordered.filter { it.parentId == null || tasks.none { t -> t.id == it.parentId } }.forEach { t ->
                TaskRow(c, t, t.id in ready, indent = false, onBreakDown = {
                    scope.launch {
                        breaking = t.id
                        c.engine.oneShot(TaskBreakdown.prompt(t)).onSuccess { out ->
                            val subs = TaskBreakdown.parse(t, out)
                            if (subs.isEmpty()) toast(context.getString(R.string.breakdown_unparsed)) else subs.forEach { c.chatRepo.saveTask(it) }
                        }.onFailure { toast(it.message ?: "") }
                        breaking = null
                    }
                }, breaking = breaking == t.id)
                ordered.filter { it.parentId == t.id }.forEach { s -> TaskRow(c, s, s.id in ready, indent = true, onBreakDown = null, breaking = false) }
            }
            OutlinedButton(onClick = { addingTask = true }) { Text(stringResource(R.string.add_task)) }
        }
    }

    if (addingTask) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var prio by remember { mutableStateOf(Priority.MEDIUM) }
        AlertDialog(onDismissRequest = { addingTask = false }, title = { Text(stringResource(R.string.add_task)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text(stringResource(R.string.title)) }, singleLine = true)
                    OutlinedTextField(desc, { desc = it }, label = { Text(stringResource(R.string.description)) })
                    Row { Priority.entries.forEach { pr -> TextButton(onClick = { prio = pr }) { Text((if (pr == prio) "● " else "") + pr.name.lowercase()) } } }
                }
            },
            confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { scope.launch { c.chatRepo.saveTask(TaskItem(title = title.trim(), description = desc.trim(), priority = prio, projectId = p.id)) }; addingTask = false }) { Text(stringResource(R.string.create)) } },
            dismissButton = { TextButton(onClick = { addingTask = false }) { Text(stringResource(R.string.cancel)) } })
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text(stringResource(R.string.delete_project)) },
        text = { Text(stringResource(R.string.delete_project_body)) },
        confirmButton = { TextButton(onClick = { scope.launch { c.chatRepo.deleteProject(p.id) }; confirmDelete = false; onBack() }) { Text(stringResource(R.string.delete)) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun TaskRow(c: AppContainer, t: TaskItem, ready: Boolean, indent: Boolean, onBreakDown: (() -> Unit)?, breaking: Boolean) {
    val scope = rememberCoroutineScope()
    val symbol = when (t.status) { TaskStatus.DONE -> "☑"; TaskStatus.IN_PROGRESS -> "◐"; TaskStatus.BLOCKED -> "⛔"; TaskStatus.CANCELLED -> "✕"; TaskStatus.TODO -> "☐" }
    Card(Modifier.fillMaxWidth().padding(start = if (indent) 24.dp else 0.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(symbol, Modifier.clickable {
                    val next = when (t.status) { TaskStatus.TODO -> TaskStatus.IN_PROGRESS; TaskStatus.IN_PROGRESS -> TaskStatus.DONE; TaskStatus.DONE -> TaskStatus.TODO; else -> TaskStatus.TODO }
                    scope.launch { c.chatRepo.saveTask(t.copy(status = next)) }
                }.padding(end = 10.dp), style = MaterialTheme.typography.titleLarge)
                Column(Modifier.weight(1f)) {
                    Text(t.title, fontWeight = if (ready) FontWeight.SemiBold else FontWeight.Normal)
                    Text(listOfNotNull(t.priority.name.lowercase(), t.estimateMinutes?.let { "~$it min" }, if (ready && t.status == TaskStatus.TODO) "ready" else null, if (t.dependsOn.isNotEmpty()) "after ${t.dependsOn.size}" else null).joinToString(" · "),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { scope.launch { c.chatRepo.deleteTask(t.id) } }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
            }
            if (onBreakDown != null) TextButton(onClick = onBreakDown, enabled = !breaking) { Text(stringResource(if (breaking) R.string.breaking_down else R.string.break_down_ai)) }
        }
    }
}
