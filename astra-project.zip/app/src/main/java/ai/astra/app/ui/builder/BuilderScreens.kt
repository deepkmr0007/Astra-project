@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.builder

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import ai.astra.app.ui.SectionTitle
import ai.astra.core.builder.AutomationCodec
import ai.astra.core.builder.AutomationTarget
import ai.astra.core.builder.FieldMapping
import ai.astra.core.builder.ReviewDecision
import ai.astra.core.builder.RunEventKind
import ai.astra.core.builder.StepAction
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

@Composable
private fun BackBar(title: String, onBack: () -> Unit, action: @Composable () -> Unit = {}) {
    TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }, actions = { action() })
}

/**
 * The Automation Builder: describe a job, let ASTRA draft the steps, import the records, map the
 * columns to the form, and run with you approving each record. You stay in control of login,
 * CAPTCHA and OTP.
 */
@Composable
fun BuilderScreen(c: AppContainer, onBack: () -> Unit, onOpenDesk: () -> Unit, toast: (String) -> Unit) {
    val vm: BuilderViewModel = viewModel { BuilderViewModel(c) }
    val toastMsg by vm.toast.collectAsState()
    LaunchedEffect(toastMsg) { toastMsg?.let { toast(it); vm.toast.value = null } }
    val plan by vm.plan.collectAsState()
    val running by vm.running.collectAsState()

    Scaffold(topBar = { BackBar(stringResource(R.string.builder_title), onBack) }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                DraftCard(vm, c, onOpenDesk, toast)
                plan?.let { PlanCard(vm, it, onOpenDesk) }
                DataCard(vm, c, toast)
                SavedCard(vm)
                Text(stringResource(R.string.builder_safety_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (running) RunOverlay(vm)
        }
    }
}

@Composable
private fun DraftCard(vm: BuilderViewModel, c: AppContainer, onOpenDesk: () -> Unit, toast: (String) -> Unit) {
    val requirement by vm.requirement.collectAsState()
    val target by vm.target.collectAsState()
    val busy by vm.busy.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle(stringResource(R.string.builder_describe))
            OutlinedTextField(requirement, { vm.requirement.value = it }, Modifier.fillMaxWidth().heightIn(min = 96.dp),
                placeholder = { Text(stringResource(R.string.builder_describe_hint)) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(target == AutomationTarget.BROWSER, { vm.target.value = AutomationTarget.BROWSER }, { Text(stringResource(R.string.builder_on_computer)) })
                FilterChip(target == AutomationTarget.PHONE, { vm.target.value = AutomationTarget.PHONE }, { Text(stringResource(R.string.builder_on_phone)) })
            }
            Button(onClick = { vm.makePlan() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) stringResource(R.string.builder_thinking) else stringResource(R.string.builder_make_plan))
            }
            if (target == AutomationTarget.PHONE) Text(stringResource(R.string.builder_phone_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PlanCard(vm: BuilderViewModel, spec: ai.astra.core.builder.AutomationSpec, onOpenDesk: () -> Unit) {
    val questions by vm.questions.collectAsState()
    val warnings by vm.planWarnings.collectAsState()
    val origin by vm.planOrigin.collectAsState()
    val form by vm.form.collectAsState()
    val busy by vm.busy.collectAsState()
    var name by remember(spec.id) { mutableStateOf(spec.name) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(stringResource(R.string.builder_plan))
            Text(if (origin == "model") stringResource(R.string.builder_plan_by_astra) else stringResource(R.string.builder_plan_builtin), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(name, { name = it; vm.editPlan { s -> s.copy(name = it) } }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.builder_name)) }, singleLine = true)
            Text(stringResource(R.string.builder_setup_steps), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
            spec.setupSteps.forEach { StepLine(it.describe()) }
            Text(stringResource(R.string.builder_each_record), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
            spec.recordSteps.forEach { StepLine(it.describe(), commit = it.action == StepAction.SUBMIT) }

            if (spec.mappings.isNotEmpty()) {
                Text(stringResource(R.string.builder_field_map), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                spec.mappings.forEach { m -> MappingRow(vm, m) }
            }
            if (form == null && spec.recordSteps.any { it.action == StepAction.FILL_FORM }) {
                OutlinedButton(onClick = { onOpenDesk() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.builder_connect_to_scan)) }
                OutlinedButton(onClick = { vm.scanForm() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.builder_scan_form)) }
            }
            questions.forEach { q ->
                Text("• ${q.question}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
            }
            warnings.forEach { Text("⚠ $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { vm.save() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.save)) }
                Button(onClick = { vm.run(spec) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PlayArrow, null); Text(stringResource(R.string.builder_run))
                }
            }
        }
    }
}

@Composable
private fun StepLine(text: String, commit: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(if (commit) "💾" else "•", style = MaterialTheme.typography.bodySmall)
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MappingRow(vm: BuilderViewModel, m: FieldMapping) {
    var value by remember(m.selector) { mutableStateOf(m.template) }
    OutlinedTextField(value, { value = it; vm.setMapping(m.selector, it) }, Modifier.fillMaxWidth(),
        label = { Text(m.label.ifBlank { m.selector } + if (m.required) " *" else "") },
        supportingText = { Text(stringResource(R.string.builder_map_hint)) }, singleLine = true)
}

@Composable
private fun DataCard(vm: BuilderViewModel, c: AppContainer, toast: (String) -> Unit) {
    val tables by vm.dataTables.collectAsState(initial = emptyList())
    val selected by vm.selectedTable.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            importing = true
            c.importer.importTable(uri) {}.onSuccess { vm.importTable(it) }.onFailure { toast(it.message ?: "Couldn't read that file") }
            importing = false
        }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(stringResource(R.string.builder_data))
            Text(stringResource(R.string.builder_data_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            tables.forEach { t ->
                Row(Modifier.fillMaxWidth().clickable { vm.selectedTable.value = t.name }, verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected == t.name, { vm.selectedTable.value = t.name }, { Text("${t.name} · ${t.csv.lineSequence().count() - 1} rows") })
                    Box(Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteTable(t.name) }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
                }
            }
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !importing, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null); Text(if (importing) stringResource(R.string.importing) else stringResource(R.string.builder_import_data))
            }
        }
    }
}

@Composable
private fun SavedCard(vm: BuilderViewModel) {
    val saved by vm.savedAutomations.collectAsState(initial = emptyList())
    if (saved.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionTitle(stringResource(R.string.builder_saved))
            saved.forEach { e ->
                val spec = remember(e.id, e.updatedAt) { runCatching { AutomationCodec.decode(e.json) }.getOrNull() }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { spec?.let { vm.load(it) } }) {
                        Text(e.name, fontWeight = FontWeight.SemiBold)
                        spec?.let { Text("${it.target.name.lowercase()} · ${it.recordSteps.size} steps", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    spec?.let { IconButton(onClick = { vm.run(it) }) { Icon(Icons.Filled.PlayArrow, stringResource(R.string.builder_run)) } }
                    IconButton(onClick = { vm.deleteAutomation(e.id) }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
                }
            }
        }
    }
}

/** Shows the live run: step log, the current record for approval, and pauses for login/OTP. */
@Composable
private fun RunOverlay(vm: BuilderViewModel) {
    val log by vm.runLog.collectAsState()
    val review by vm.review.collectAsState()
    val cont by vm.continuePrompt.collectAsState()

    cont?.let { state ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.builder_your_turn)) },
            text = { Text(state.message) },
            confirmButton = { Button(onClick = { vm.answerContinue(true) }) { Text(stringResource(R.string.builder_continue)) } },
            dismissButton = { TextButton(onClick = { vm.answerContinue(false) }) { Text(stringResource(R.string.builder_stop)) } },
        )
    }

    review?.let { state ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.builder_review_record, state.position, state.total)) },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.record.values.forEach { v ->
                        Row { Text(v.label + ": ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall); Text(v.value.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall) }
                    }
                    state.record.issues.forEach { Text("⚠ ${it.field}: ${it.message}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { Button(onClick = { vm.answerReview(ReviewDecision.Approve) }) { Text(stringResource(R.string.builder_approve_save)) } },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { vm.answerReview(ReviewDecision.Skip) }) { Text(stringResource(R.string.builder_skip)) }
                    TextButton(onClick = { vm.answerReview(ReviewDecision.Stop) }) { Text(stringResource(R.string.builder_stop)) }
                }
            },
        )
    }

    Card(Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.builder_running), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.stop() }) { Text(stringResource(R.string.builder_stop)) }
            }
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
            LazyColumn(Modifier.heightIn(max = 180.dp)) {
                items(log.asReversed()) { e ->
                    Text("• ${e.text}", style = MaterialTheme.typography.bodySmall,
                        color = if (e.kind == RunEventKind.RECORD_FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
