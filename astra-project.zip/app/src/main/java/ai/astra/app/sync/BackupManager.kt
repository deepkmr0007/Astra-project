package ai.astra.app.sync

import ai.astra.app.AppContainer
import ai.astra.core.export.Exporter
import ai.astra.core.memory.MemoryRecord
import ai.astra.core.memory.MemorySource
import ai.astra.core.model.ChatMessage
import ai.astra.core.model.Part
import ai.astra.core.sync.EncryptedBundle
import ai.astra.core.sync.LwwMerge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class RestoreSummary(val chats: Int, val messages: Int, val memoriesAdded: Int, val memoriesUpdated: Int, val conflicts: Int, val projects: Int, val tasks: Int)

/**
 * Encrypted backup + merge-restore ("sync through any folder you choose", e.g. a Drive folder via
 * the system picker). Merge rules: new records are added; the same memory edited on two devices
 * keeps the newer version and the change is counted as a conflict. API keys are never included.
 */
class BackupManager(private val c: AppContainer) {

    suspend fun export(passphrase: CharArray): ByteArray = withContext(Dispatchers.IO) {
        val convs = c.chatRepo.allConversations().filter { !it.temporary }.map { it to c.chatRepo.messages(it.id) }
        val json = Exporter.bundle(convs, c.memory.list(), c.chatRepo.allProjects(), c.chatRepo.allTasks(), c.settingsStore.exportable(c.settingsStore.settings.value))
        EncryptedBundle.encrypt(json.toByteArray(Charsets.UTF_8), passphrase)
    }

    suspend fun restore(bytes: ByteArray, passphrase: CharArray?): RestoreSummary = withContext(Dispatchers.IO) {
        val text = if (EncryptedBundle.isEncrypted(bytes)) {
            requireNotNull(passphrase) { "This backup is encrypted — enter its passphrase" }
            String(EncryptedBundle.decrypt(bytes, passphrase), Charsets.UTF_8)
        } else String(bytes, Charsets.UTF_8)
        val b = Exporter.parseBundle(text)

        val existingProjects = c.chatRepo.allProjects().map { it.id }.toSet()
        val newProjects = b.projects.filter { it.id !in existingProjects }
        newProjects.forEach { c.chatRepo.saveProject(it) }

        var chats = 0; var messages = 0
        for (pc in b.conversations) {
            val existing = c.chatRepo.conversation(pc.conversation.id)
            if (existing == null) { c.chatRepo.save(pc.conversation); chats++ }
            val have = c.chatRepo.messages(pc.conversation.id).map { it.id }.toSet()
            pc.messages.filter { it.id !in have }.forEach { m ->
                c.chatRepo.append(ChatMessage(m.id, pc.conversation.id, m.role, listOf(Part.Text(m.text)), m.createdAt)); messages++
            }
        }

        data class MemView(val id: String, val updatedAt: Long, val content: String)
        val local = c.memory.list()
        val incoming = b.memories.filter { it.id != null }
        val merge = LwwMerge.merge(local.map { MemView(it.id, it.updatedAt, it.content) }, incoming.map { MemView(it.id!!, it.updatedAt, it.content) },
            { it.id }, { it.updatedAt }, { a, x -> a.content == x.content })
        val byId = incoming.associateBy { it.id!! }
        var added = 0; var updated = 0
        for (v in merge.toUpsert) {
            val m = byId.getValue(v.id)
            val prev = local.firstOrNull { it.id == v.id }
            val record = MemoryRecord(
                id = v.id, createdAt = prev?.createdAt ?: m.updatedAt, updatedAt = m.updatedAt, source = MemorySource.IMPORT, type = m.type,
                importance = m.importance, confidence = 0.9, privacyLevel = m.privacy, projectId = m.projectId, content = m.content,
                embedding = c.embedder.embedOne(m.content), embedderId = c.embedder.id, pinned = m.pinned,
            )
            c.memoryStore.upsert(record)
            if (prev == null) added++ else updated++
        }
        // Memories exported without ids (older files) are added through the normal duplicate check.
        b.memories.filter { it.id == null }.forEach { m ->
            if (c.memory.remember(m.content, MemorySource.IMPORT, projectId = m.projectId, explicit = true, typeOverride = m.type) is ai.astra.core.memory.RememberResult.Stored) added++
        }

        val haveTasks = c.chatRepo.allTasks().map { it.id }.toSet()
        val newTasks = b.tasks.filter { it.id !in haveTasks }
        newTasks.forEach { c.chatRepo.saveTask(it) }
        RestoreSummary(chats, messages, added, updated, merge.conflicts.size, newProjects.size, newTasks.size)
    }
}
