@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.code

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.shareFile
import ai.astra.core.code.CodeBlocks
import ai.astra.core.code.DiffOp
import ai.astra.core.code.LineDiff
import ai.astra.core.code.SyntaxTokens
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Highlighter(private val language: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val b = AnnotatedString.Builder(text.text)
        if (text.length < 60_000) SyntaxTokens.spans(text.text, language).forEach { s ->
            val style = when (s.kind) {
                SyntaxTokens.Kind.KEYWORD -> SpanStyle(color = Color(0xFFC084FC))
                SyntaxTokens.Kind.STRING -> SpanStyle(color = Color(0xFF34D399))
                SyntaxTokens.Kind.COMMENT -> SpanStyle(color = Color(0xFF7C8AA5), fontStyle = FontStyle.Italic)
                SyntaxTokens.Kind.NUMBER -> SpanStyle(color = Color(0xFFF59E0B))
                SyntaxTokens.Kind.PLAIN -> SpanStyle()
            }
            b.addStyle(style, s.start, s.end)
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

/**
 * Coding Lab: files in ASTRA's private "lab" folder. Understand → propose → show diff → you approve
 * → apply (a backup is kept) → run JavaScript in the sandbox. Code is never overwritten silently.
 */
@Composable
fun CodeLabScreen(c: AppContainer, onBack: () -> Unit, toast: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lab = remember { File(context.filesDir, "lab").apply { mkdirs() } }
    var version by remember { mutableIntStateOf(0) }
    val files = remember(version) { lab.walkTopDown().filter { it.isFile && !it.path.contains("/.history/") }.sortedBy { it.path }.toList() }
    var open by remember { mutableStateOf<File?>(null) }
    var text by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }
    var instruction by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var proposal by remember { mutableStateOf<String?>(null) }
    var output by remember { mutableStateOf<String?>(null) }
    var newFile by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("") }

    fun openFile(f: File) { open = f; text = runCatching { f.readText() }.getOrDefault(""); saved = text; proposal = null; output = null }

    fun save(content: String) {
        val f = open ?: return
        if (f.exists() && f.readText() != content) {
            val hist = File(lab, ".history").apply { mkdirs() }
            f.copyTo(File(hist, "${f.name}.${System.currentTimeMillis()}"), overwrite = true)
        }
        f.writeText(content); saved = content; text = content
        toast(context.getString(R.string.saved_with_backup))
    }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val f = withContext(Dispatchers.IO) {
                runCatching {
                    val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null } ?: "file.txt"
                    val target = File(lab, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    require(!target.exists()) { "A file named ${target.name} already exists in the Lab" }
                    context.contentResolver.openInputStream(uri)!!.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
                    target
                }
            }
            f.onSuccess { version++; openFile(it) }.onFailure { toast(it.message ?: "Import failed") }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text(open?.name ?: stringResource(R.string.code_lab)) }, navigationIcon = {
            IconButton(onClick = { if (open != null) open = null else onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
        })
    }) { pad ->
        val f = open
        if (f == null) {
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.code_lab_intro), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { newFile = true }) { Text(stringResource(R.string.new_file)) }
                    OutlinedButton(onClick = { importer.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.import_file)) }
                }
                OutlinedTextField(filter, { filter = it }, placeholder = { Text(stringResource(R.string.search_files)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (files.isEmpty()) Text(stringResource(R.string.lab_empty))
                files.filter { filter.isBlank() || it.name.contains(filter, true) || runCatching { it.length() < 500_000 && it.readText().contains(filter, true) }.getOrDefault(false) }.forEach { file ->
                    Text("📄 " + file.relativeTo(lab).path + "  ·  ${file.length()} B", Modifier.fillMaxWidth().clickable { openFile(file) }.padding(vertical = 10.dp))
                    HorizontalDivider()
                }
                Text(stringResource(R.string.js_sandbox_status, stringResource(if (c.js.supported()) R.string.available else R.string.not_available)), style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val lang = CodeBlocks.languageFor(f.name)
            Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    TextButton(enabled = text != saved, onClick = { save(text) }) { Text(stringResource(R.string.save)) }
                    TextButton(onClick = {
                        if (lang != "javascript") { output = context.getString(R.string.cannot_run_language, lang); return@TextButton }
                        scope.launch {
                            working = true
                            val r = c.js.run(text)
                            working = false
                            output = buildString {
                                if (r.output.isNotEmpty()) append(r.output.joinToString("\n")).append('\n')
                                r.result?.let { append("→ ").append(it).append('\n') }
                                r.error?.let { append("Error: ").append(it).append('\n') }
                                append("(${r.millis} ms, sandboxed)")
                            }
                        }
                    }) { Text(stringResource(R.string.run)) }
                    TextButton(onClick = { shareFile(context, f, "text/plain") }) { Text(stringResource(R.string.export_share)) }
                    TextButton(onClick = { f.delete(); open = null; version++ }) { Text(stringResource(R.string.delete)) }
                }
                Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.weight(1f).fillMaxWidth()) {
                    androidx.compose.foundation.text.BasicTextField(
                        value = text, onValueChange = { text = it },
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface),
                        visualTransformation = remember(lang) { Highlighter(lang) },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false),
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()).padding(8.dp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                    )
                }
                output?.let { Text(it, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall, modifier = Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState()).padding(vertical = 4.dp)) }
                if (working) LinearProgressIndicator(Modifier.fillMaxWidth())
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedTextField(instruction, { instruction = it }, placeholder = { Text(stringResource(R.string.ai_edit_hint)) }, modifier = Modifier.weight(1f), maxLines = 3)
                    Button(enabled = instruction.isNotBlank() && !working, onClick = {
                        scope.launch {
                            working = true
                            val r = c.engine.oneShot(CodeBlocks.editPrompt(f.name, text, instruction), 3000)
                            working = false
                            r.onSuccess { ans ->
                                val block = CodeBlocks.main(ans)
                                if (block == null) toast(context.getString(R.string.no_code_in_answer)) else proposal = block.code
                            }.onFailure { toast(it.message ?: "Model failed") }
                        }
                    }) { Text(stringResource(R.string.propose)) }
                }
            }
        }
    }

    proposal?.let { p ->
        val diff = remember(p, text) { LineDiff.diff(text, p) }
        val (add, del) = LineDiff.stats(diff)
        AlertDialog(onDismissRequest = { proposal = null }, title = { Text(stringResource(R.string.review_changes, add, del)) },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())) {
                    LineDiff.hunks(diff).forEach { h ->
                        Text(h.header, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                        h.lines.forEach { l ->
                            val (prefix, bg) = when (l.op) { DiffOp.ADD -> "+" to Color(0x3334D399); DiffOp.DELETE -> "-" to Color(0x33F87171); DiffOp.EQUAL -> " " to Color.Transparent }
                            Text("$prefix ${l.text}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.background(bg))
                        }
                    }
                    if (add == 0 && del == 0) Text(stringResource(R.string.no_changes))
                }
            },
            confirmButton = { TextButton(enabled = add + del > 0, onClick = { save(p); proposal = null }) { Text(stringResource(R.string.approve_apply)) } },
            dismissButton = { TextButton(onClick = { proposal = null }) { Text(stringResource(R.string.reject)) } })
    }
    if (newFile) {
        var name by remember { mutableStateOf("main.js") }
        AlertDialog(onDismissRequest = { newFile = false }, title = { Text(stringResource(R.string.new_file)) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val target = File(lab, clean)
                    if (target.exists()) toast(context.getString(R.string.file_exists)) else { target.writeText(""); version++; openFile(target) }
                    newFile = false
                }) { Text(stringResource(R.string.create)) }
            },
            dismissButton = { TextButton(onClick = { newFile = false }) { Text(stringResource(R.string.cancel)) } })
    }
}
