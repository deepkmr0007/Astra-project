@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.extras

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.EmptyState
import ai.astra.app.ui.SectionTitle
import ai.astra.core.knowledge.EntityType
import ai.astra.core.knowledge.KnowledgeGraph
import ai.astra.core.knowledge.KnowledgeGraphBuilder
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
private fun BackBar(title: String, onBack: () -> Unit) {
    TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
}

/** Plugins: install validated declarative manifests, enable/disable, remove. */
@Composable
fun PluginsScreen(c: AppContainer, onBack: () -> Unit, toast: (String) -> Unit) {
    val plugins by c.plugins.plugins.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val install = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val raw = withContext(Dispatchers.IO) { runCatching { context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull() }
            if (raw == null) toast(context.getString(R.string.import_failed, "")) else
                c.plugins.install(raw, c.builtInToolNames).onSuccess { toast(context.getString(R.string.plugin_installed, it.name)) }.onFailure { toast(it.message ?: "Invalid plugin") }
        }
    }
    Scaffold(topBar = { BackBar(stringResource(R.string.plugins), onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.plugins_intro), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { install.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text(stringResource(R.string.install_from_file)) }
                OutlinedButton(onClick = {
                    c.plugins.install(ai.astra.app.plugins.PluginStore.EXAMPLE, c.builtInToolNames).onSuccess { toast(context.getString(R.string.plugin_installed, it.name)) }.onFailure { toast(it.message ?: "") }
                }) { Text(stringResource(R.string.install_example)) }
            }
            if (plugins.isEmpty()) EmptyState(stringResource(R.string.no_plugins), stringResource(R.string.no_plugins_body))
            plugins.forEach { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${p.manifest.name} ${p.manifest.version}", fontWeight = FontWeight.SemiBold)
                                Text(p.manifest.id, style = MaterialTheme.typography.labelSmall)
                            }
                            Switch(p.enabled, { c.plugins.setEnabled(p.manifest.id, it) })
                        }
                        Text(stringResource(R.string.plugin_permissions, p.manifest.permissions.joinToString { it.name.lowercase() }.ifEmpty { "—" }), style = MaterialTheme.typography.bodySmall)
                        p.manifest.tools.forEach { t -> Text("• ${t.name} (${t.risk.name.lowercase()}) — ${t.description}\n  ${t.http?.method} ${t.http?.url}", style = MaterialTheme.typography.bodySmall) }
                        TextButton(onClick = { c.plugins.remove(p.manifest.id) }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }
}

/** Knowledge graph: people, places, projects, organisations and how they connect. */
@Composable
fun KnowledgeScreen(c: AppContainer, onBack: () -> Unit) {
    var graph by remember { mutableStateOf<KnowledgeGraph?>(null) }
    var selected by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        graph = withContext(Dispatchers.Default) {
            KnowledgeGraphBuilder.build(c.memory.list(), c.chatRepo.allProjects(), c.chatRepo.allTasks(), c.documents.documents())
        }
    }
    Scaffold(topBar = { BackBar(stringResource(R.string.knowledge_graph), onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.knowledge_intro), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(filter, { filter = it }, singleLine = true, placeholder = { Text(stringResource(R.string.search_hint)) }, modifier = Modifier.fillMaxWidth())
            val g = graph
            if (g == null) Text(stringResource(R.string.building)) else {
                Text(stringResource(R.string.graph_stats, g.entities.size, g.relations.size), style = MaterialTheme.typography.labelSmall)
                EntityType.entries.forEach { type ->
                    val ents = g.entities.values.filter { it.type == type && it.key != "me" && (filter.isBlank() || it.name.contains(filter, true)) }
                    if (ents.isNotEmpty()) {
                        SectionTitle(type.name.lowercase().replaceFirstChar { it.uppercase() } + " (${ents.size})")
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ents.sortedBy { it.name }.forEach { e -> AssistChip(onClick = { selected = e.key }, label = { Text(e.name + " · ${g.neighbors(e.key).size}") }) }
                        }
                    }
                }
                if (g.entities.size <= 1) EmptyState(stringResource(R.string.graph_empty_title), stringResource(R.string.graph_empty_body))
            }
        }
    }
    val g = graph
    selected?.let { key ->
        if (g != null) AlertDialog(onDismissRequest = { selected = null }, title = { Text(g.entities[key]?.name ?: key) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    g.neighbors(key).forEach { n ->
                        Text((if (n.outgoing) "→ " else "← ") + n.relation.name.lowercase().replace('_', ' ') + " · " + n.entity.name, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { selected = n.entity.key })
                        Text(n.evidence, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text(stringResource(R.string.done)) } })
    }
}

/** Automations: morning briefing from chosen feeds. */
@Composable
fun AutomationsScreen(c: AppContainer, onBack: () -> Unit, onOpenChat: (String) -> Unit, toast: (String) -> Unit) {
    val s by c.settingsStore.settings.collectAsState()
    val last by c.automations.last.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var feeds by remember { mutableStateOf(s.briefingFeeds.joinToString("\n")) }
    var running by remember { mutableStateOf(false) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Scaffold(topBar = { BackBar(stringResource(R.string.nav_automations), onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.automations_intro), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.morning_briefing), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Switch(s.briefingEnabled, { on ->
                            if (on && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            scope.launch { c.settingsStore.update { it.copy(briefingEnabled = on) } }
                        })
                    }
                    Text(stringResource(R.string.briefing_time, s.briefingHour))
                    Slider(s.briefingHour.toFloat(), { v -> scope.launch { c.settingsStore.update { it.copy(briefingHour = v.toInt()) } } }, valueRange = 0f..23f, steps = 22)
                    OutlinedTextField(feeds, { feeds = it }, label = { Text(stringResource(R.string.feeds_label)) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            val list = feeds.lines().map { it.trim() }.filter { it.startsWith("https://") }
                            scope.launch { c.settingsStore.update { it.copy(briefingFeeds = list) }; toast(context.getString(R.string.saved)) }
                        }) { Text(stringResource(R.string.save)) }
                        OutlinedButton(enabled = !running, onClick = {
                            scope.launch { running = true; val st = c.automations.runBriefing(); running = false; toast(st.message); st.conversationId?.let(onOpenChat) }
                        }) { Text(stringResource(if (running) R.string.running else R.string.run_now)) }
                    }
                    last?.let { st -> Text("${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(st.time))} · ${st.message}", style = MaterialTheme.typography.bodySmall,
                        color = if (st.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                    Text(stringResource(R.string.briefing_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
