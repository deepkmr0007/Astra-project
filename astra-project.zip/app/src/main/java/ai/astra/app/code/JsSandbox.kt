package ai.astra.app.code

import ai.astra.core.json.Json
import ai.astra.core.json.JsonValue
import ai.astra.core.json.arr
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.security.RiskLevel
import ai.astra.core.tools.ExecutionEnvironment
import ai.astra.core.tools.Tool
import ai.astra.core.tools.ToolResult
import ai.astra.core.tools.ToolSpec
import android.content.Context
import androidx.javascriptengine.IsolateStartupParameters
import androidx.javascriptengine.JavaScriptSandbox
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout

data class JsResult(val output: List<String>, val result: String?, val error: String?, val millis: Long)

/**
 * Safe code execution: JavaScript runs in Android's JavaScriptSandbox — a separate, isolated
 * process with no file system, no network and no access to ASTRA's data, a heap limit and a
 * time limit. Other languages are not executed (honest "can't run" instead of pretending).
 */
class JsSandbox(private val context: Context) {
    private var sandbox: JavaScriptSandbox? = null
    private val mutex = Mutex()

    fun supported(): Boolean = runCatching { JavaScriptSandbox.isSupported() }.getOrDefault(false)

    suspend fun run(code: String, timeoutMs: Long = 5_000): JsResult {
        if (!supported()) return JsResult(emptyList(), null, "This phone's WebView doesn't support the isolated JavaScript sandbox (update Android System WebView).", 0)
        val started = System.currentTimeMillis()
        val sb = mutex.withLock { sandbox ?: JavaScriptSandbox.createConnectedInstanceAsync(context.applicationContext).await().also { sandbox = it } }
        val params = IsolateStartupParameters()
        if (sb.isFeatureSupported(JavaScriptSandbox.JS_FEATURE_ISOLATE_MAX_HEAP_SIZE)) params.setMaxHeapSizeBytes(64L * 1024 * 1024)
        val isolate = sb.createIsolate(params)
        return try {
            val raw = withTimeout(timeoutMs) { isolate.evaluateJavaScriptAsync(wrap(code)).await() }
            val o = runCatching { Json.parse(raw).obj() }.getOrNull()
            JsResult(o?.get("out").arr().mapNotNull { it.str() }, o?.get("result").str(), o?.get("error").str(), System.currentTimeMillis() - started)
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            JsResult(emptyList(), null, "Stopped: took longer than ${timeoutMs / 1000}s", System.currentTimeMillis() - started)
        } catch (e: Exception) {
            JsResult(emptyList(), null, e.message ?: e.javaClass.simpleName, System.currentTimeMillis() - started)
        } finally {
            runCatching { isolate.close() }
        }
    }

    /** Captures console output and the last expression's value as a JSON string. */
    private fun wrap(code: String): String = """
        (function(){
          var __out = [];
          function __fmt(a){ try { return typeof a === 'string' ? a : JSON.stringify(a); } catch(e) { return String(a); } }
          var console = { log: function(){ __out.push(Array.prototype.map.call(arguments, __fmt).join(' ')); } };
          console.info = console.log; console.warn = console.log; console.error = console.log;
          var __r, __e = null;
          try { __r = eval(${Json.quote(code)}); } catch (e) { __e = String(e && e.stack ? e.stack : e); }
          return JSON.stringify({ out: __out.slice(0, 500), result: __r === undefined ? null : __fmt(__r), error: __e });
        })()
    """.trimIndent()

    fun close() { runCatching { sandbox?.close() }; sandbox = null }

    fun tool(): Tool = object : Tool {
        override val spec = ToolSpec(
            "code_run_js", "Runs JavaScript in an isolated sandbox (no files, no network, 5 s limit) and returns console output and the result. Use for calculations, data transforms and testing small functions.",
            """{"type":"object","properties":{"code":{"type":"string"}},"required":["code"]}""",
            """{"type":"string"}""", RiskLevel.LOW, emptySet(), ExecutionEnvironment.SANDBOX,
        )
        override suspend fun run(args: JsonValue.Obj): ToolResult {
            val code = args["code"].str() ?: return ToolResult.Error("Missing 'code'")
            val r = this@JsSandbox.run(code)
            return if (r.error != null && r.output.isEmpty()) ToolResult.Error(r.error)
            else ToolResult.Ok(buildString {
                if (r.output.isNotEmpty()) append("Console:\n").append(r.output.joinToString("\n")).append('\n')
                r.result?.let { append("Result: ").append(it).append('\n') }
                r.error?.let { append("Error: ").append(it) }
            }.trim().ifEmpty { "(no output)" })
        }
    }
}
