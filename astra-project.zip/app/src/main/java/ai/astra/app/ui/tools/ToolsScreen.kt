@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.tools

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.SectionTitle
import ai.astra.app.ui.chat.ActivitySheet
import ai.astra.core.security.Permission
import ai.astra.core.security.PermissionState
import ai.astra.core.security.RiskLevel
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun riskLabel(r: RiskLevel) = when (r) {
    RiskLevel.LOW -> stringResource(R.string.risk_low)
    RiskLevel.MEDIUM -> stringResource(R.string.risk_medium)
    RiskLevel.HIGH -> stringResource(R.string.risk_high)
    RiskLevel.CRITICAL -> stringResource(R.string.risk_critical)
}

@Composable
fun ToolsScreen(c: AppContainer) {
    val settings by c.settingsStore.settings.collectAsState()
    val activity by c.activity.collectAsState()
    val scope = rememberCoroutineScope()
    var showActivity by remember { mutableStateOf(false) }
    var auditVersion by remember { mutableIntStateOf(0) }
    val audit = remember(auditVersion, activity.size) { c.audit.entries().asReversed() }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_tools)) }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Text(stringResource(R.string.tools_explainer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { showActivity = true }, modifier = Modifier.padding(top = 8.dp)) { Text(stringResource(R.string.ai_activity) + " (${activity.size})") }

            SectionTitle(stringResource(R.string.available_tools))
            c.tools.all().forEach { t ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.spec.name, fontWeight = FontWeight.SemiBold)
                        Text(t.spec.description, style = MaterialTheme.typography.bodySmall)
                        Text("${riskLabel(t.spec.risk)} · ${t.spec.environment.name.lowercase().replace('_', ' ')}" +
                            (if (t.spec.permissions.isNotEmpty()) " · " + t.spec.permissions.joinToString { it.name.lowercase() } else "") +
                            (if (t.spec.usesNetwork) " · network" else " · offline"),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Text(stringResource(R.string.tools_planned), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))

            SectionTitle(stringResource(R.string.permission_center))
            Text(stringResource(R.string.permission_center_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Permission.entries.forEach { p ->
                val state = settings.permissions[p] ?: PermissionState.ASK
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(p.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() })
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PermissionState.entries.forEach { s ->
                            FilterChip(selected = state == s, onClick = { scope.launch { c.settingsStore.update { it.copy(permissions = it.permissions + (p to s)) } } },
                                label = { Text(when (s) { PermissionState.ALLOWED -> stringResource(R.string.allowed); PermissionState.DENIED -> stringResource(R.string.denied); PermissionState.ASK -> stringResource(R.string.ask_every_time) }) })
                        }
                    }
                }
            }

            SectionTitle(stringResource(R.string.audit_log))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.audit_log_body), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { c.audit.clear(); auditVersion++ }) { Text(stringResource(R.string.clear)) }
            }
            if (audit.isEmpty()) Text(stringResource(R.string.audit_empty), style = MaterialTheme.typography.bodySmall)
            audit.take(100).forEach { e ->
                Text("${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(e.time))} · ${e.tool} · ${e.risk.name} · ${e.decision}", style = MaterialTheme.typography.labelSmall)
                if (e.detail.isNotBlank()) Text(e.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp))
            }
            Text("", Modifier.padding(bottom = 32.dp))
        }
    }
    if (showActivity) ActivitySheet(activity) { showActivity = false }
}
