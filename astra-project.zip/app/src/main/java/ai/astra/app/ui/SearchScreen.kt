@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.core.documents.DocHit
import ai.astra.core.memory.ScoredMemory
import ai.astra.core.model.Conversation
import ai.astra.core.tasks.TaskItem
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Global search across chats, memories, documents and tasks (keyword + hybrid semantic). */
@Composable
fun SearchScreen(c: AppContainer, onBack: () -> Unit, onOpenChat: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var chats by remember { mutableStateOf<List<Conversation>>(emptyList()) }
    var mems by remember { mutableStateOf<List<ScoredMemory>>(emptyList()) }
    var docs by remember { mutableStateOf<List<DocHit>>(emptyList()) }
    var tasks by remember { mutableStateOf<List<TaskItem>>(emptyList()) }
    LaunchedEffect(q) {
        if (q.length < 2) { chats = emptyList(); mems = emptyList(); docs = emptyList(); tasks = emptyList(); return@LaunchedEffect }
        delay(250)
        chats = c.chatRepo.search(q)
        mems = c.memory.recall(q, projectId = c.currentProjectId, limit = 10, minScore = 0.05)
        docs = c.documents.search(q, limit = 8)
        tasks = c.chatRepo.allTasks().filter { it.title.contains(q, true) || it.description.contains(q, true) }
    }
    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.search_everything)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text(stringResource(R.string.search_hint)) }, modifier = Modifier.fillMaxWidth())
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (chats.isNotEmpty()) SectionTitle(stringResource(R.string.conversations))
                chats.forEach { conv -> Text("💬 ${conv.title}", Modifier.fillMaxWidth().clickable { onOpenChat(conv.id) }.padding(vertical = 10.dp)) }
                if (mems.isNotEmpty()) SectionTitle(stringResource(R.string.nav_memory))
                mems.forEach { Text("🧠 ${it.record.content}", Modifier.padding(vertical = 6.dp)) }
                if (docs.isNotEmpty()) SectionTitle(stringResource(R.string.nav_files))
                docs.forEach { h ->
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Text("📄 ${h.citation}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(h.chunk.text.take(240), style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (tasks.isNotEmpty()) SectionTitle(stringResource(R.string.tasks))
                tasks.forEach { Text("☐ ${it.title}", Modifier.padding(vertical = 6.dp)) }
                if (q.length >= 2 && chats.isEmpty() && mems.isEmpty() && docs.isEmpty() && tasks.isEmpty()) Text(stringResource(R.string.no_results), Modifier.padding(vertical = 16.dp))
            }
        }
    }
}
