package ai.astra.app.security

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.GeneralSecurityException
import java.security.KeyStore
import java.security.ProviderException
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Thrown when the phone's Keystore can't encrypt even with a freshly made key. */
class VaultUnavailableException(message: String, cause: Throwable?) : Exception(message, cause)

/** Where the vault's AES key lives. Separated from the cipher so the recovery logic is unit-testable. */
interface VaultKeys {
    /** The current key, created on first use. */
    fun current(): SecretKey
    /** The key used by ASTRA 0.3.2 and earlier, if it still exists (read-only, for migration). */
    fun legacy(): SecretKey?
    /** Deletes the current key so the next [current] call makes a new one. */
    fun resetCurrent()
    /** Deletes every vault key (used by "Reset secure storage"). */
    fun deleteAll()
}

/**
 * AES-256-GCM key in the Android Keystore, non-exportable and hardware-backed (TEE).
 *
 * 0.3.2 asked for StrongBox first. Some phones create a StrongBox key successfully but then refuse
 * to use it ("Keystore operation failed" in Cipher.init), which crashed ASTRA on every start.
 * The TEE is still hardware isolation and is what Android itself uses for app keys, so the vault
 * now uses it on every phone. The old StrongBox key is only read, to migrate values that still decrypt.
 */
class AndroidVaultKeys(
    private val alias: String = "astra_vault_v2",
    private val legacyAlias: String = "astra_vault_v1",
) : VaultKeys {
    private val ks: KeyStore by lazy { KeyStore.getInstance("AndroidKeyStore").apply { load(null) } }

    @Synchronized override fun current(): SecretKey = existing(alias) ?: generate()

    override fun legacy(): SecretKey? = runCatching { existing(legacyAlias) }.getOrNull()

    @Synchronized override fun resetCurrent() { runCatching { ks.deleteEntry(alias) } }

    @Synchronized override fun deleteAll() {
        runCatching { ks.deleteEntry(alias) }
        runCatching { ks.deleteEntry(legacyAlias) }
    }

    private fun existing(a: String): SecretKey? = ks.getKey(a, null) as? SecretKey

    private fun generate(): SecretKey {
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return gen.generateKey()
    }
}

/**
 * Encrypts with the current key; values are stored as `v2:` + Base64(IV ‖ ciphertext ‖ tag).
 * Values without the prefix were written by 0.3.2 with the legacy key.
 */
class KeystoreCipher(private val keys: VaultKeys) {

    fun encrypt(plain: ByteArray): String {
        val c = initEncrypt()
        return PREFIX + B64E.encodeToString(c.iv + c.doFinal(plain))
    }

    fun decrypt(encoded: String): ByteArray {
        val current = encoded.startsWith(PREFIX)
        val all = B64D.decode(if (current) encoded.substring(PREFIX.length) else encoded)
        require(all.size > IV_BYTES) { "Vault value is too short" }
        val key = if (current) keys.current() else keys.legacy() ?: throw GeneralSecurityException("Legacy vault key is gone")
        val c = Cipher.getInstance(TRANSFORMATION)
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, all, 0, IV_BYTES))
        return c.doFinal(all, IV_BYTES, all.size - IV_BYTES)
    }

    /**
     * Two attempts with the stored key (a Keystore can fail transiently), then a fresh key.
     * A key that can't start an encryption can't be relied on to decrypt either, so replacing it
     * loses nothing that was still readable.
     */
    private fun initEncrypt(): Cipher {
        var first: Exception? = null
        for (attempt in 0 until 2) {
            try {
                return Cipher.getInstance(TRANSFORMATION).apply { init(Cipher.ENCRYPT_MODE, keys.current()) }
            } catch (e: GeneralSecurityException) { if (first == null) first = e
            } catch (e: ProviderException) { if (first == null) first = e }
        }
        keys.resetCurrent()
        return try {
            Cipher.getInstance(TRANSFORMATION).apply { init(Cipher.ENCRYPT_MODE, keys.current()) }
        } catch (e: Exception) {
            throw VaultUnavailableException("The phone's Keystore refused to encrypt, even with a new key", e)
                .apply { first?.let { addSuppressed(it) } }
        }
    }

    companion object {
        const val PREFIX = "v2:"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
        private val B64E = Base64.getEncoder()
        private val B64D = Base64.getDecoder()
        fun isCurrent(encoded: String) = encoded.startsWith(PREFIX)
    }
}

/** ASTRA VAULT: encrypted secret storage (API keys, tokens, the database key). Values never appear in logs or exports. */
class SecretStore(private val prefs: SharedPreferences, private val cipher: KeystoreCipher) {

    constructor(context: Context) : this(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE),
        KeystoreCipher(AndroidVaultKeys()),
    )

    sealed interface Read {
        data object Missing : Read
        class Value(val value: String) : Read
        class Unreadable(val error: Throwable) : Read
    }

    /** Written with commit(): the database key must be on disk before the database is created with it. */
    @Synchronized fun put(name: String, value: String?) {
        if (value.isNullOrEmpty()) { prefs.edit().remove(name).commit(); return }
        val sealed = cipher.encrypt(value.toByteArray(Charsets.UTF_8))
        if (!prefs.edit().putString(name, sealed).commit()) throw java.io.IOException("Could not save to the vault")
    }

    fun get(name: String): String? = (read(name) as? Read.Value)?.value

    /** Like [get] but tells "never saved" apart from "saved but can't be decrypted". Migrates legacy values. */
    @Synchronized fun read(name: String): Read {
        val enc = prefs.getString(name, null) ?: return Read.Missing
        return try {
            val value = String(cipher.decrypt(enc), Charsets.UTF_8)
            if (!KeystoreCipher.isCurrent(enc)) runCatching { put(name, value) }
            Read.Value(value)
        } catch (e: Exception) {
            Read.Unreadable(e)
        }
    }

    fun has(name: String): Boolean = prefs.contains(name)
    fun remove(name: String) { prefs.edit().remove(name).apply() }

    /** Keeps an undecryptable value under another name instead of deleting it. */
    @Synchronized fun setAside(name: String, stamp: Long = System.currentTimeMillis()) {
        val raw = prefs.getString(name, null) ?: return
        prefs.edit().putString("$name.unreadable-$stamp", raw).remove(name).commit()
    }

    companion object {
        const val PREFS = "astra_vault"
        fun endpointKey(endpointId: String) = "endpoint_key:$endpointId"
        const val DOWNLOAD_TOKEN = "download_token"

        /** "Reset secure storage": deletes the vault keys and the values sealed with them. */
        fun wipe(context: Context, keys: VaultKeys = AndroidVaultKeys()) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
            keys.deleteAll()
        }
    }
}
