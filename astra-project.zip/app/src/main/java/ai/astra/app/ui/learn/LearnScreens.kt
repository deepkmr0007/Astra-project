@file:OptIn(ExperimentalMaterial3Api::class)

package ai.astra.app.ui.learn

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.ui.SectionTitle
import ai.astra.core.json.obj
import ai.astra.core.learn.Skill
import ai.astra.core.learn.TeachParser
import ai.astra.core.learn.TrainingExporter
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun BackBar(title: String, onBack: () -> Unit) {
    TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
}

/**
 * Teach & Learn: skills the user teaches ASTRA (used in the prompt, no retraining needed), and an
 * export of rated/corrected answers as a dataset for fine-tuning a personal model on a computer.
 */
@Composable
fun TeachScreen(c: AppContainer, onBack: () -> Unit, toast: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val skills by c.skillStore.observe().collectAsState(initial = emptyList())
    val feedbackCount by c.skillStore.feedbackCount().collectAsState(initial = 0)
    val settings by c.settingsStore.settings.collectAsState()
    var name by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("") }

    Scaffold(topBar = { BackBar(stringResource(R.string.teach_title), onBack) }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.teach_use_skills), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Switch(settings.skillsEnabled, { on -> scope.launch { c.settingsStore.update { it.copy(skillsEnabled = on) } } })
                        }
                        Text(stringResource(R.string.teach_explain), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionTitle(stringResource(R.string.teach_add))
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.teach_name)) }, singleLine = true)
                        OutlinedTextField(trigger, { trigger = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.teach_trigger)) }, singleLine = true)
                        OutlinedTextField(instructions, { instructions = it }, Modifier.fillMaxWidth().heightIn(min = 80.dp), label = { Text(stringResource(R.string.teach_instructions)) })
                        Button(onClick = {
                            val base = TeachParser.parse("/teach ${name.ifBlank { trigger }}: $instructions")
                            if (instructions.isBlank() || (name.isBlank() && trigger.isBlank())) { toast(context.getString(R.string.teach_need_fields)); return@Button }
                            val skill = (base ?: Skill(name = name, triggers = emptyList(), instructions = instructions)).copy(
                                name = name.ifBlank { trigger }.ifBlank { "Skill" },
                                triggers = trigger.split(',').map { it.trim().lowercase() }.filter { it.isNotBlank() }.ifEmpty { listOf(name.lowercase()) },
                                instructions = instructions,
                            )
                            scope.launch { c.skillStore.save(skill); name = ""; trigger = ""; instructions = ""; toast(context.getString(R.string.teach_saved)) }
                        }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.save)) }
                        Text(stringResource(R.string.teach_chat_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (skills.isNotEmpty()) Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle(stringResource(R.string.teach_your_skills))
                        skills.forEach { e ->
                            val skill = remember(e.id, e.updatedAt) { runCatching { Skill.fromJson(ai.astra.core.json.Json.parse(e.json).obj()!!) }.getOrNull() }
                            if (skill != null) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(skill.name, fontWeight = FontWeight.SemiBold)
                                    Text(skill.instructions.take(100), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(skill.enabled, { on -> scope.launch { c.skillStore.save(skill.copy(enabled = on)) } })
                                IconButton(onClick = { scope.launch { c.skillStore.delete(skill.id) } }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
                            }
                        }
                    }
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionTitle(stringResource(R.string.teach_training))
                        Text(stringResource(R.string.teach_training_explain, feedbackCount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = {
                            scope.launch {
                                val sys = c.settingsStore.settings.value.profile.let { "You are ${it.persona.name}, the user's personal AI." }
                                val export = TrainingExporter.export(c.skillStore.feedback(), c.skillStore.all(), sys)
                                if (export.examples == 0) { toast(context.getString(R.string.teach_nothing_to_export)); return@launch }
                                val file = withContext(Dispatchers.IO) {
                                    File(c.appContext.cacheDir, "exports").apply { mkdirs() }.let { File(it, "astra-training.jsonl").apply { writeText(export.jsonl) } }
                                }
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                                val share = Intent(Intent.ACTION_SEND).apply { type = "application/json"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                                context.startActivity(Intent.createChooser(share, context.getString(R.string.teach_export)))
                                toast(context.getString(R.string.teach_exported, export.examples, export.redactions))
                            }
                        }, enabled = feedbackCount > 0, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.teach_export)) }
                        Text(stringResource(R.string.teach_training_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
