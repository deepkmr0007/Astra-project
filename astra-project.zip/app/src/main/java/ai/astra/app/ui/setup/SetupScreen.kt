@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ai.astra.app.ui.setup

import ai.astra.app.AppContainer
import ai.astra.app.R
import ai.astra.app.inference.LoadState
import ai.astra.app.ui.SectionTitle
import ai.astra.core.model.Locality
import ai.astra.core.model.newId
import ai.astra.core.models.ModelCatalog
import ai.astra.core.provider.Availability
import ai.astra.core.provider.EndpointConfig
import ai.astra.core.provider.EndpointKind
import ai.astra.core.provider.EndpointPreset
import ai.astra.core.provider.EndpointPresets
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * First-run setup: get ASTRA answering in the fewest taps — one-tap verified model download,
 * or an online model with presets, or an existing model file.
 */
@Composable
fun SetupScreen(c: AppContainer, onBack: () -> Unit, onOpenModels: () -> Unit, onStartChat: () -> Unit, toast: (String) -> Unit) {
    val device by c.device.state.collectAsState()
    val status by c.providers.status.collectAsState()
    val settings by c.settingsStore.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var preset by remember { mutableStateOf<EndpointPreset?>(null) }
    var showOthers by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    val pick = remember(device.totalRamMb, device.freeStorageMb) { ModelCatalog.recommend(device) }
    val ready = status.filter { it.availability is Availability.Ready }
    val local = c.providers.localProvider()

    LaunchedEffect(Unit) { c.settingsStore.update { it.copy(onboardingDone = true) } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.setup_title)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (ready.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.setup_ready), style = MaterialTheme.typography.titleMedium)
                        ready.forEach { Text("✓ ${it.info.displayName} · ${it.info.locality.name.lowercase().replace('_', '-')}") }
                        if (local != null && local.loadState != LoadState.READY) {
                            Text(stringResource(R.string.setup_load_hint), style = MaterialTheme.typography.bodySmall)
                            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                            OutlinedButton(enabled = !loading, onClick = {
                                scope.launch {
                                    loading = true
                                    c.providers.loadLocal().onFailure { toast(it.message ?: "Load failed") }.onSuccess { toast(local.info.displayName + " ✓") }
                                    loading = false
                                }
                            }) { Text(stringResource(R.string.load_now)) }
                        }
                        Button(onClick = onStartChat) { Text(stringResource(R.string.start_chatting)) }
                    }
                }
            } else {
                Text(stringResource(R.string.setup_intro), style = MaterialTheme.typography.bodyMedium)
            }

            SectionTitle(stringResource(R.string.setup_option_offline))
            Text(stringResource(R.string.setup_offline_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            CatalogModelCard(c, pick.model, recommended = true, reasons = pick.reasons, onMessage = toast)
            TextButton(onClick = { showOthers = !showOthers }) { Text(stringResource(if (showOthers) R.string.hide_other_models else R.string.show_other_models)) }
            if (showOthers) ModelCatalog.models.filter { it.id != pick.model.id }.forEach { m ->
                CatalogModelCard(c, m, recommended = false, reasons = emptyList(), onMessage = toast)
            }

            SectionTitle(stringResource(R.string.setup_option_online))
            Text(stringResource(R.string.setup_online_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                EndpointPresets.all.forEach { p -> AssistChip(onClick = { preset = p }, label = { Text(p.name.substringBefore(" (")) }) }
            }
            settings.endpoints.forEach { e -> Text("✓ ${e.displayName} · ${e.model}", style = MaterialTheme.typography.bodySmall) }

            SectionTitle(stringResource(R.string.setup_option_file))
            Text(stringResource(R.string.setup_file_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onOpenModels) { Text(stringResource(R.string.open_models)) }

            SectionTitle(stringResource(R.string.setup_option_none))
            Text(stringResource(R.string.setup_none_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = onStartChat) { Text(stringResource(R.string.setup_skip)) }
            Text(stringResource(R.string.setup_privacy_note), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Light,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp))
        }
    }
    preset?.let { p ->
        EndpointDialog(c, EndpointConfig(newId().take(8), "", EndpointKind.OPENAI_COMPATIBLE, "", "", Locality.REMOTE), isNew = true, preset = p) { preset = null }
    }
}
