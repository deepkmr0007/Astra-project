package ai.astra.app.inference

import ai.astra.core.json.Json
import ai.astra.core.json.arr
import ai.astra.core.json.bool
import ai.astra.core.json.jsonArr
import ai.astra.core.json.jsonObj
import ai.astra.core.json.long
import ai.astra.core.json.obj
import ai.astra.core.json.str
import ai.astra.core.model.newId
import ai.astra.core.models.CatalogModel
import ai.astra.core.models.Checksums
import ai.astra.core.models.ModelDescriptor
import ai.astra.core.models.ModelFormat
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.DigestInputStream
import java.security.MessageDigest

enum class DownloadStatus { PENDING, RUNNING, PAUSED, VERIFYING, DONE, FAILED }

data class DownloadRequest(
    val url: String,
    val name: String,
    val license: String,
    val source: String,
    val expectedSha256: String?,
    val supportsVision: Boolean,
    val supportsAudio: Boolean = false,
    val catalogId: String? = null,
    val wifiOnly: Boolean = false,
)

data class DownloadState(
    val id: String,
    val request: DownloadRequest,
    val totalBytes: Long,
    val downloaded: Long,
    val status: DownloadStatus,
    val error: String? = null,
)

data class ProbeResult(val sizeBytes: Long, val finalHost: String, val fileName: String)

/**
 * Installs models. Downloads go through Android's system DownloadManager, so multi-GB files keep
 * going with the screen off or the app closed, resume after network drops, and show a system
 * notification. Every finished file is SHA-256 verified before ASTRA will use it.
 */
class ModelManager(private val context: Context, private val scope: CoroutineScope) {
    val dir: File = File(context.filesDir, "models").apply { mkdirs() }
    private val catalog = File(dir, "catalog.json")
    private val pendingFile = File(dir, "pending-downloads.json")
    private val dm: DownloadManager = context.getSystemService(DownloadManager::class.java)

    private val _models = MutableStateFlow(load())
    val models: StateFlow<List<ModelDescriptor>> = _models.asStateFlow()

    private val _downloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadState>> = _downloads.asStateFlow()

    private val _installed = MutableSharedFlow<ModelDescriptor>(extraBufferCapacity = 4)
    /** Emits each model the moment it is verified and installed. */
    val installed: SharedFlow<ModelDescriptor> = _installed.asSharedFlow()

    private var monitor: Job? = null

    init {
        if (readPending().isNotEmpty()) ensureMonitor()
    }

    /** Absolute paths (system downloads) or names relative to the private models folder (imports). */
    fun fileFor(d: ModelDescriptor): File = if (d.fileName.startsWith("/")) File(d.fileName) else File(dir, d.fileName)

    private fun load(): List<ModelDescriptor> = if (catalog.exists()) ModelDescriptor.listFromJson(catalog.readText()) else emptyList()

    @Synchronized private fun save(list: List<ModelDescriptor>) {
        val tmp = File(dir, "catalog.json.tmp")
        tmp.writeText(ModelDescriptor.listToJson(list))
        tmp.renameTo(catalog)
        _models.value = list
    }

    fun update(d: ModelDescriptor) = save(_models.value.map { if (it.id == d.id) d else it })

    fun delete(id: String) {
        val d = _models.value.firstOrNull { it.id == id } ?: return
        fileFor(d).delete()
        save(_models.value.filter { it.id != id })
    }

    fun isInstalled(catalogId: String): Boolean = _models.value.any { it.id == catalogId && fileFor(it).exists() }

    /** Copies a user-picked model file into private storage, hashing as it goes. */
    suspend fun import(uri: Uri, onProgress: (Long, Long) -> Unit): Result<ModelDescriptor> = withContext(Dispatchers.IO) {
        runCatching {
            val (name, size) = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) (c.getString(0) ?: "model") to (if (c.isNull(1)) -1L else c.getLong(1)) else null
            } ?: ("model" to -1L)
            val free = dir.usableSpace
            require(size < 0 || size < free - 300L * 1024 * 1024) { "Not enough free storage: needs ${size / 1_048_576} MB, ${free / 1_048_576} MB free" }
            val format = ModelFormat.fromFileName(name)
            val id = newId().take(8)
            val target = File(dir, "$id-${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
            val md = MessageDigest.getInstance("SHA-256")
            var copied = 0L
            context.contentResolver.openInputStream(uri)!!.use { raw ->
                DigestInputStream(raw, md).use { input ->
                    FileOutputStream(target).use { out ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copied += n
                            onProgress(copied, size)
                        }
                    }
                }
            }
            val (profile, caps) = ModelDescriptor.estimateFromSize(copied)
            val d = ModelDescriptor(
                id = id, name = name.substringBeforeLast('.'), fileName = target.name, format = format, sizeBytes = copied,
                sha256 = md.digest().joinToString("") { "%02x".format(it) }, source = "Imported from device storage",
                license = "Not specified — check the model card", profile = profile, capabilities = caps,
            )
            save(_models.value + d)
            d
        }
    }

    /** HEAD request so the user sees the size before agreeing to download. */
    suspend fun probe(url: String, token: String?): Result<ProbeResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(url.startsWith("https://")) { "Only https:// downloads are allowed" }
            val conn = (URI(url).toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"; instanceFollowRedirects = true; connectTimeout = 15_000; readTimeout = 15_000
                token?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            try {
                val code = conn.responseCode
                require(code in 200..299) { "Server answered HTTP $code" + if (code == 401 || code == 403) " (gated model? add an access token)" else "" }
                ProbeResult(conn.contentLengthLong, conn.url.host, url.substringAfterLast('/').substringBefore('?'))
            } finally { conn.disconnect() }
        }
    }

    fun downloadCatalog(m: CatalogModel, wifiOnly: Boolean): Result<String> = startDownload(
        DownloadRequest(m.url, m.name, m.license, m.sourcePage, m.sha256, m.vision, m.audio, m.id, wifiOnly), token = null,
    )

    /** Hands the download to the system. Returns the download id. */
    fun startDownload(req: DownloadRequest, token: String?): Result<String> = runCatching {
        require(req.url.startsWith("https://")) { "Only https:// downloads are allowed" }
        val ext = context.getExternalFilesDir("models") ?: error("Shared storage is not available right now")
        val fileName = (req.catalogId ?: newId().take(8)) + "-" + req.url.substringAfterLast('/').substringBefore('?').ifBlank { "model.litertlm" }
        File(ext, fileName).delete() // DownloadManager would otherwise append "-1"
        val needed = (req.expectedSize() ?: 0L) + 500L * 1024 * 1024
        require(ext.usableSpace > needed) { "Not enough free storage (${ext.usableSpace / 1_048_576} MB free)" }
        val request = DownloadManager.Request(Uri.parse(req.url))
            .setTitle("ASTRA · ${req.name}")
            .setDescription("On-device AI model")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, "models", fileName)
            .setAllowedOverMetered(!req.wifiOnly)
            .setAllowedOverRoaming(false)
        token?.takeIf { it.isNotBlank() }?.let { request.addRequestHeader("Authorization", "Bearer $it") }
        val id = dm.enqueue(request)
        val pending = readPending() + Pending(id, req, File(ext, fileName).absolutePath)
        writePending(pending)
        _downloads.value = _downloads.value + (id.toString() to DownloadState(id.toString(), req, -1, 0, DownloadStatus.PENDING))
        ensureMonitor()
        id.toString()
    }

    private fun DownloadRequest.expectedSize(): Long? = catalogId?.let { ai.astra.core.models.ModelCatalog.byId(it)?.sizeBytes }

    fun cancel(id: String) {
        val longId = id.toLongOrNull() ?: return
        runCatching { dm.remove(longId) }
        readPending().firstOrNull { it.downloadId == longId }?.let { File(it.path).delete() }
        writePending(readPending().filter { it.downloadId != longId })
        _downloads.value = _downloads.value - id
    }

    fun dismiss(id: String) { _downloads.value = _downloads.value - id }

    private fun ensureMonitor() {
        if (monitor?.isActive == true) return
        monitor = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val pending = readPending()
                if (pending.isEmpty()) break
                for (p in pending) poll(p)
                delay(1000)
            }
        }
    }

    private suspend fun poll(p: Pending) {
        val key = p.downloadId.toString()
        val cursor = dm.query(DownloadManager.Query().setFilterById(p.downloadId))
        if (cursor == null) return
        cursor.use { c ->
            if (!c.moveToFirst()) {
                // Removed outside ASTRA (e.g. cleared from the notification).
                writePending(readPending().filter { it.downloadId != p.downloadId })
                _downloads.value = _downloads.value + (key to DownloadState(key, p.request, -1, 0, DownloadStatus.FAILED, "Download was cancelled"))
                return
            }
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            when (status) {
                DownloadManager.STATUS_PENDING -> set(key, p, total, done, DownloadStatus.PENDING, null)
                DownloadManager.STATUS_RUNNING -> set(key, p, total, done, DownloadStatus.RUNNING, null)
                DownloadManager.STATUS_PAUSED -> set(key, p, total, done, DownloadStatus.PAUSED, pausedReason(reason))
                DownloadManager.STATUS_FAILED -> {
                    writePending(readPending().filter { it.downloadId != p.downloadId })
                    File(p.path).delete()
                    set(key, p, total, done, DownloadStatus.FAILED, failedReason(reason))
                }
                DownloadManager.STATUS_SUCCESSFUL -> finish(key, p, total)
            }
        }
    }

    private fun set(key: String, p: Pending, total: Long, done: Long, status: DownloadStatus, err: String?) {
        _downloads.value = _downloads.value + (key to DownloadState(key, p.request, total, done, status, err))
    }

    private fun finish(key: String, p: Pending, total: Long) {
        writePending(readPending().filter { it.downloadId != p.downloadId })
        val file = File(p.path)
        set(key, p, total, total, DownloadStatus.VERIFYING, null)
        if (!file.exists()) { set(key, p, total, 0, DownloadStatus.FAILED, "Downloaded file not found"); return }
        val sha = Checksums.sha256(file)
        val expected = p.request.expectedSha256?.trim()
        if (!expected.isNullOrEmpty() && !sha.equals(expected, ignoreCase = true)) {
            file.delete()
            set(key, p, total, 0, DownloadStatus.FAILED, "Checksum mismatch — the file was corrupted or changed, so it was deleted. Try again.")
            return
        }
        val catalogModel = p.request.catalogId?.let { ai.astra.core.models.ModelCatalog.byId(it) }
        val d = catalogModel?.toDescriptor(file.absolutePath, sha) ?: run {
            val (profile, caps) = ModelDescriptor.estimateFromSize(file.length())
            ModelDescriptor(newId().take(8), p.request.name, file.absolutePath, ModelFormat.fromFileName(file.name), file.length(), sha,
                p.request.source, p.request.license.ifBlank { "Not specified — check the model card" }, profile, caps,
                supportsVision = p.request.supportsVision, supportsAudio = p.request.supportsAudio)
        }
        save(_models.value.filter { it.id != d.id } + d)
        set(key, p, total, total, DownloadStatus.DONE, null)
        _installed.tryEmit(d)
    }

    private fun pausedReason(r: Int) = when (r) {
        DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "Waiting for Wi-Fi"
        DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "Waiting for network"
        DownloadManager.PAUSED_WAITING_TO_RETRY -> "Connection dropped — retrying"
        else -> "Paused"
    }

    private fun failedReason(r: Int) = when (r) {
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Not enough storage space"
        DownloadManager.ERROR_CANNOT_RESUME -> "The download could not resume — please start again"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "Network error while downloading"
        DownloadManager.ERROR_FILE_ERROR -> "Could not write the file"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Too many redirects"
        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Storage not available"
        in 400..599 -> "Server answered HTTP $r" + if (r == 401 || r == 403) " — this model may need an access token" else ""
        else -> "Download failed (code $r)"
    }

    private data class Pending(val downloadId: Long, val request: DownloadRequest, val path: String)

    @Synchronized private fun readPending(): List<Pending> = runCatching {
        if (!pendingFile.exists()) return emptyList()
        Json.parse(pendingFile.readText()).arr().mapNotNull { v ->
            val o = v.obj() ?: return@mapNotNull null
            Pending(
                o["id"].long() ?: return@mapNotNull null,
                DownloadRequest(o["url"].str() ?: "", o["name"].str() ?: "Model", o["license"].str() ?: "", o["source"].str() ?: "",
                    o["sha"].str(), o["vision"].bool() ?: false, o["audio"].bool() ?: false, o["catalogId"].str(), o["wifiOnly"].bool() ?: false),
                o["path"].str() ?: return@mapNotNull null,
            )
        }
    }.getOrDefault(emptyList())

    @Synchronized private fun writePending(list: List<Pending>) {
        pendingFile.writeText(Json.write(jsonArr(list.map { p ->
            jsonObj("id" to p.downloadId, "url" to p.request.url, "name" to p.request.name, "license" to p.request.license,
                "source" to p.request.source, "sha" to p.request.expectedSha256, "vision" to p.request.supportsVision,
                "audio" to p.request.supportsAudio, "catalogId" to p.request.catalogId, "wifiOnly" to p.request.wifiOnly, "path" to p.path)
        })))
    }
}
