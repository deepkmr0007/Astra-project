package ai.astra.app

import ai.astra.app.security.KeystoreCipher
import ai.astra.app.security.SecretStore
import ai.astra.app.security.VaultKeys
import ai.astra.app.security.VaultUnavailableException
import android.content.SharedPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

/**
 * The vault's recovery rules, with software keys standing in for the Android Keystore.
 * Regression for the 0.3.2 startup crash: "InvalidKeyException: Keystore operation failed" in Cipher.init.
 */
class SecretStoreTest {

    private fun aes() = SecretKeySpec(ByteArray(32).also { SecureRandom().nextBytes(it) }, "AES")
    /** A key the AES cipher rejects in init(), like the StrongBox key on the affected phone. */
    private fun broken(): SecretKey = SecretKeySpec(ByteArray(7), "HmacSHA256")

    private class FakeKeys(var currentKey: SecretKey?, var legacyKey: SecretKey? = null, val fresh: () -> SecretKey) : VaultKeys {
        var resets = 0
        override fun current(): SecretKey = currentKey ?: fresh().also { currentKey = it }
        override fun legacy(): SecretKey? = legacyKey
        override fun resetCurrent() { resets++; currentKey = null }
        override fun deleteAll() { currentKey = null; legacyKey = null }
    }

    @Test fun roundTripUsesVersionedFormat() {
        val prefs = FakePrefs()
        val store = SecretStore(prefs, KeystoreCipher(FakeKeys(aes()) { aes() }))
        store.put("k", "secret value")
        assertTrue(prefs.getString("k", null)!!.startsWith(KeystoreCipher.PREFIX))
        assertEquals("secret value", store.get("k"))
    }

    @Test fun unusableKeyIsReplacedInsteadOfCrashing() {
        val keys = FakeKeys(broken()) { aes() }
        val store = SecretStore(FakePrefs(), KeystoreCipher(keys))
        store.put("db_key_v1", "00ff")
        assertEquals(1, keys.resets)
        assertEquals("00ff", store.get("db_key_v1"))
    }

    @Test fun keystoreThatNeverWorksGivesAClearError() {
        val store = SecretStore(FakePrefs(), KeystoreCipher(FakeKeys(broken()) { broken() }))
        try { store.put("k", "v"); fail("expected VaultUnavailableException") } catch (_: VaultUnavailableException) {}
    }

    @Test fun legacyValuesAreReadAndMigrated() {
        val legacy = aes()
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, legacy) }
        val old = Base64.getEncoder().encodeToString(c.iv + c.doFinal("old token".toByteArray()))
        val prefs = FakePrefs().apply { edit().putString("t", old).commit() }
        val store = SecretStore(prefs, KeystoreCipher(FakeKeys(aes(), legacy) { aes() }))
        assertEquals("old token", store.get("t"))
        assertTrue(prefs.getString("t", null)!!.startsWith(KeystoreCipher.PREFIX))
        assertEquals("old token", store.get("t"))
    }

    @Test fun missingAndUnreadableAreToldApartAndUnreadableIsKept() {
        val prefs = FakePrefs().apply { edit().putString("bad", KeystoreCipher.PREFIX + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA").commit() }
        val store = SecretStore(prefs, KeystoreCipher(FakeKeys(aes()) { aes() }))
        assertTrue(store.read("none") is SecretStore.Read.Missing)
        assertTrue(store.read("bad") is SecretStore.Read.Unreadable)
        assertNull(store.get("bad"))
        store.setAside("bad", stamp = 42)
        assertNull(prefs.getString("bad", null))
        assertTrue(prefs.getString("bad.unreadable-42", null) != null)
    }

    @Test fun emptyValueRemoves() {
        val prefs = FakePrefs()
        val store = SecretStore(prefs, KeystoreCipher(FakeKeys(aes()) { aes() }))
        store.put("k", "v"); store.put("k", "")
        assertTrue(!store.has("k"))
    }
}

/** Minimal in-memory SharedPreferences for JVM tests. */
private class FakePrefs : SharedPreferences {
    val map = HashMap<String, Any?>()
    override fun getAll(): MutableMap<String, *> = HashMap(map)
    override fun getString(key: String?, defValue: String?): String? = map[key] as String? ?: defValue
    @Suppress("UNCHECKED_CAST")
    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? = map[key] as MutableSet<String>? ?: defValues
    override fun getInt(key: String?, defValue: Int): Int = map[key] as Int? ?: defValue
    override fun getLong(key: String?, defValue: Long): Long = map[key] as Long? ?: defValue
    override fun getFloat(key: String?, defValue: Float): Float = map[key] as Float? ?: defValue
    override fun getBoolean(key: String?, defValue: Boolean): Boolean = map[key] as Boolean? ?: defValue
    override fun contains(key: String?): Boolean = map.containsKey(key)
    override fun edit(): SharedPreferences.Editor = Ed()
    override fun registerOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}
    override fun unregisterOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}

    inner class Ed : SharedPreferences.Editor {
        private val puts = HashMap<String, Any?>(); private val removes = HashSet<String>(); private var clear = false
        override fun putString(key: String, value: String?): SharedPreferences.Editor { puts[key] = value; return this }
        override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor { puts[key] = values; return this }
        override fun putInt(key: String, value: Int): SharedPreferences.Editor { puts[key] = value; return this }
        override fun putLong(key: String, value: Long): SharedPreferences.Editor { puts[key] = value; return this }
        override fun putFloat(key: String, value: Float): SharedPreferences.Editor { puts[key] = value; return this }
        override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor { puts[key] = value; return this }
        override fun remove(key: String): SharedPreferences.Editor { removes += key; return this }
        override fun clear(): SharedPreferences.Editor { clear = true; return this }
        override fun commit(): Boolean {
            if (clear) map.clear()
            removes.forEach { map.remove(it) }
            map.putAll(puts)
            return true
        }
        override fun apply() { commit() }
    }
}
