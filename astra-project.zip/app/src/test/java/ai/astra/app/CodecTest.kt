package ai.astra.app

import ai.astra.app.data.AppSettings
import ai.astra.app.data.Codec
import ai.astra.app.data.SettingsStore
import ai.astra.core.model.ExecutionMode
import ai.astra.core.model.ExecutionTrace
import ai.astra.core.model.Locality
import ai.astra.core.model.Part
import ai.astra.core.router.DataControl
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class CodecTest {
    @Test fun embeddingsRoundTrip() {
        val v = floatArrayOf(0.1f, -2.5f, 3e-7f)
        assertArrayEquals(v, Codec.floats(Codec.floats(v)), 0f)
    }

    @Test fun partsAndTraceRoundTrip() {
        val parts = listOf(Part.Text("नमस्ते \"hi\""), Part.Image("/x.jpg"), Part.Code("kt", "fun a() = 1"))
        assertEquals(parts, Codec.parts(Codec.parts(parts)))
        val t = ExecutionTrace("p", "m", Locality.ON_DEVICE, ExecutionMode.LOCAL, false, 0, emptyList(), listOf("calculator"), 5, 2.5, 10, listOf("why"))
        assertEquals(t, Codec.trace(Codec.trace(t)))
    }

    @Test fun settingsRoundTripAndPrivacyDefaults() {
        val d = AppSettings()
        assertEquals(DataControl.ASK_FOR_SENSITIVE, d.dataControl)
        assertEquals(false, d.autoCapture)
        val s = d.copy(dataControl = DataControl.NEVER_SEND, maxOutputTokens = 2048)
        assertEquals(s, SettingsStore.decode(SettingsStore.encode(s)))
    }
}
