plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "ai.astra.app"
    // 37: required by SQLCipher 4.19 (AAR metadata). Only affects which APIs compile; minSdk/targetSdk unchanged.
    compileSdk = 37

    defaultConfig {
        applicationId = "ai.astra.personal"
        minSdk = 31 // Android 12+
        targetSdk = 36
        versionCode = 5
        versionName = "0.3.2"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // One fixed key for personal builds, so every new APK installs over the previous one
    // (GitHub's runners would otherwise sign each build with a different random debug key).
    signingConfigs {
        create("astra") {
            storeFile = file("astra-personal.keystore")
            storePassword = "astra-personal"
            keyAlias = "astra"
            keyPassword = "astra-personal"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("astra")
        }
        release {
            signingConfig = signingConfigs.getByName("astra")
            // R8 is off until keep-rules for the LiteRT-LM JNI layer are verified on device.
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/LICENSE*", "/META-INF/NOTICE*")
        }
    }
}

dependencies {
    implementation(project(":core"))

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.lifecycle.runtime.compose)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.extended)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    implementation(libs.datastore.preferences)
    implementation(libs.biometric)

    // On-device inference (Apache-2.0). Models are imported by the user, never bundled.
    implementation(libs.litertlm.android)
    // PDF text extraction (Apache-2.0).
    implementation(libs.pdfbox.android)

    // Phase 2: on-device OCR (Latin + Devanagari) and image labels — bundled models, work offline.
    implementation(libs.mlkit.text)
    implementation(libs.mlkit.text.devanagari)
    implementation(libs.mlkit.labeling)
    // Camera mode.
    implementation(libs.camerax.core)
    implementation(libs.camerax.camera2)
    implementation(libs.camerax.lifecycle)
    implementation(libs.camerax.view)

    // Phase 3: sandboxed JavaScript runner, folder access.
    implementation(libs.javascriptengine)
    implementation(libs.kotlinx.coroutines.guava)
    implementation(libs.documentfile)

    // Phase 4: scheduled automations, encrypted database.
    implementation(libs.work.runtime)
    // SQLCipher is published as an AAR without transitive deps; Room already provides androidx.sqlite.
    implementation("net.zetetic:sqlcipher-android:4.19.0@aar")
    // SQLCipher 4.19 is built against androidx.sqlite 2.7.x; align Room's sqlite artifacts to the same stable line.
    implementation("androidx.sqlite:sqlite:2.7.1")
    implementation("androidx.sqlite:sqlite-framework:2.7.1")

    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.compose.ui.test.junit4)
    debugImplementation(libs.compose.ui.test.manifest)
}

// Printed at the top of every build log, so you can confirm which ASTRA source GitHub is building.
logger.lifecycle("")
logger.lifecycle("==================  Building ASTRA 0.3.2  (compileSdk 37, SQLCipher 4.19)  ==================")
logger.lifecycle("")
