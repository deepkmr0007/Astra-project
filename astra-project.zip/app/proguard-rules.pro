# Keep LiteRT-LM JNI entry points and PDFBox resource loading when minification is enabled.
-keep class com.google.ai.edge.litertlm.** { *; }
-keep class com.tom_roush.pdfbox.** { *; }
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
